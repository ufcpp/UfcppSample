using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace BubbleChart3D
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class Window1 : System.Windows.Window
	{

		public Window1()
		{
			InitializeComponent();
			this.Test();
		}

		struct Tuple
		{
			public double phi;
			public double theta;
			public double intensity;

			public Tuple(double p, double t, double i)
			{
				this.phi = p;
				this.theta = t;
				this.intensity = i;
			}
		}

		Tuple[] table;

		void MakeTable()
		{
			Random rnd = new Random();
			this.table = new Tuple[NUM];
			for (int i = 0; i < this.table.Length; ++i)
			{
				double p = 2 * Math.PI * rnd.NextDouble();
				double t = Math.PI * rnd.NextDouble();
				double x = rnd.NextDouble();
				this.table[i] = new Tuple(p, t, x);
			}
		}

		const int NUM = 200;
		const double MAX_INTENSITY = 0.1;
		const double RADIUS = 0.8;

		void Test()
		{
			this.MakeTable();
			PointLight ss = new PointLight();

			MeshGeometry3D mesh = (MeshGeometry3D)this.FindResource("CubeMesh");
			//Material material = (DiffuseMaterial)this.FindResource("WhiteMaterial");
			Material material = new DiffuseMaterial(new SolidColorBrush(Color.FromRgb(255, 255, 255)));

			for (int i = 0; i < this.table.Length; ++i)
			{
				double p = this.table[i].phi;
				double t = this.table[i].theta;
				double v = MAX_INTENSITY * this.table[i].intensity;
				double x = RADIUS * Math.Cos(p) * Math.Sin(t);
				double y = RADIUS * Math.Sin(p) * Math.Sin(t) + MAX_INTENSITY;
				double z = RADIUS * Math.Cos(t);

				GeometryModel3D model = new GeometryModel3D();
				model.Geometry = mesh;
				model.Material = material;
				Transform3DGroup t3dg = new Transform3DGroup();
				t3dg.Children.Add(new ScaleTransform3D(v, v, v));
				t3dg.Children.Add(new TranslateTransform3D(x, y, z));
				model.Transform = t3dg;
				ModelVisual3D mv3d = new ModelVisual3D();
				mv3d.Content = model;
				this.viewport.Children.Add(mv3d);
			}
		}
	}
}