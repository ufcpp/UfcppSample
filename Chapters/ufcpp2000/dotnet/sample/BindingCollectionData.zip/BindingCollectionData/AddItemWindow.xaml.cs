using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BindingCollectionData
{
	/// <summary>
	/// Interaction logic for AddItemWindow.xaml
	/// </summary>

	public partial class AddItemWindow : System.Windows.Window
	{
		public AddItemWindow()
		{
			InitializeComponent();
		}

		void buttonOk_Click(object sender, RoutedEventArgs e)
		{
			double val;
			if (!double.TryParse(this.textX.Text, out val))
			{
				MessageBox.Show("X �̒l���s���ł�");
				return;
			}
			if (!double.TryParse(this.textY.Text, out val))
			{
				MessageBox.Show("Y �̒l���s���ł�");
				return;
			}
			if (!double.TryParse(this.textV.Text, out val))
			{
				MessageBox.Show("Value �̒l���s���ł�");
				return;
			}

			this.DialogResult = true;
			this.Close();
		}

		void buttonCancel_Click(object sender, RoutedEventArgs e)
		{
			this.DialogResult = false;
			this.Close();
		}

		public double X
		{
			get { return double.Parse(this.textX.Text); }
			set { this.textX.Text = value.ToString(); }
		}

		public double Y
		{
			get { return double.Parse(this.textY.Text); }
			set { this.textY.Text = value.ToString(); }
		}

		public double Value
		{
			get { return double.Parse(this.textV.Text); }
			set { this.textV.Text = value.ToString(); }
		}
	}
}