using System;
using System.Windows;
using System.ComponentModel;

namespace BindingCollectionData
{
	/// <summary>
	/// ���W�ƒl�̃y�A
	/// </summary>
	public class Item : INotifyPropertyChanged
	{
		Point p;
		double v;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="p">���W</param>
		/// <param name="v">�l</param>
		public Item(Point p, double v)
		{
			this.p = p;
			this.v = v;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x">���W�� X �l</param>
		/// <param name="y">���W�� Y �l</param>
		/// <param name="v">�l</param>
		public Item(double x, double y, double v)
		{
			this.p = new Point(x, y);
			this.v = v;
		}

		/// <summary>
		/// ���W
		/// </summary>
		public Point Point
		{
			get { return this.p; }
			set
			{
				this.p = value;
				this.OnPropertyChanged("X");
				this.OnPropertyChanged("Y");
				this.OnPropertyChanged("Point");
			}
		}

		/// <summary>
		/// ���W�� X �l
		/// </summary>
		public double X
		{
			get { return this.p.X; }
			set
			{
				this.p.X = value;
				this.OnPropertyChanged("X");
				this.OnPropertyChanged("Point");
			}
		}

		/// <summary>
		/// ���W�� Y �l
		/// </summary>
		public double Y
		{
			get { return this.p.Y; }
			set
			{
				this.p.Y = value;
				this.OnPropertyChanged("Y");
				this.OnPropertyChanged("Point");
			}
		}

		/// <summary>
		/// �l
		/// </summary>
		public double Value
		{
			get { return this.v; }
			set
			{
				this.v = value;
				this.OnPropertyChanged("Value");
			}
		}

		#region INotifyPropertyChanged �����o

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		#endregion
	}
}
