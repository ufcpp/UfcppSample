using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;

namespace BindingCollectionData
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class Window1 : System.Windows.Window
	{
		ShowItemInTableWindow win1;
		ShowItemInBubbleChartWindow win2;

		public Window1()
		{
			InitializeComponent();

			this.Loaded += new RoutedEventHandler(Window1_Loaded);

			this.buttonCsv.Click += new RoutedEventHandler(buttonCsv_Click);
			this.buttonAddItem.Click += new RoutedEventHandler(buttonAddItem_Click);
		}

		void Window1_Loaded(object sender, RoutedEventArgs e)
		{
			this.win1 = new ShowItemInTableWindow();
			this.win1.Owner = this;
			this.win1.Left = this.Left;
			this.win1.Top = this.Top + 100;
			this.win1.Show();

			this.win2 = new ShowItemInBubbleChartWindow();
			this.win2.Owner = this;
			this.win2.Left = this.Left + 300;
			this.win2.Top = this.Top + 100;
			this.win2.Show();
		}

		void buttonAddItem_Click(object sender, RoutedEventArgs e)
		{
			AddItemWindow dlg = new AddItemWindow();

			if ((bool)dlg.ShowDialog())
			{
				double x = dlg.X;
				double y = dlg.Y;
				double v = dlg.Value;

				((App)Application.Current).Data.Add(new Item(x, y, v));
			}
		}

		void buttonCsv_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Filter = "CVS �t�@�C��|*.csv|���ׂẴt�@�C��|*.* ";

			if ((bool)dlg.ShowDialog(this))
			{
				App app = (App)Application.Current;
				using (StreamReader sr = new StreamReader(dlg.FileName))
				{
					string line;
					while ((line = sr.ReadLine()) != null)
					{
						string[] token = line.Split(',');
						if (token.Length < 3) continue;
						try
						{
							double x = double.Parse(token[0]);
							double y = double.Parse(token[1]);
							double z = double.Parse(token[2]);
							app.Data.Add(new Item(x, y, z));
						}
						catch (FormatException) { continue; }
						catch (OverflowException) { continue; }
					}
				}
			}
		}
	}
}