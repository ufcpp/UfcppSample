using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Collections.ObjectModel;

namespace BindingCollectionData
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>

	public partial class App : System.Windows.Application
	{
		ObservableCollection<Item> data = new ObservableCollection<Item>();

		public ObservableCollection<Item> Data
		{
			get { return data; }
		}
	}
}