﻿using System.Windows.Data;

namespace BindingDependencyProperty
{
  /// <summary>
  /// スライダーコントロールの Value （0～10）を角度（0 ～ 360）に変換。
  /// </summary>
  [ValueConversion(typeof(double), typeof(string))]
  public class SliderAngleConverter : IValueConverter
  {
    const double FACTOR = 360.0 / 10.0;

    public object Convert(object value, System.Type targetType,
			object parameter, System.Globalization.CultureInfo culture)
    {
      double v = (double)value;
      return v * FACTOR;
    }

    public object ConvertBack(object value, System.Type targetType,
			object parameter, System.Globalization.CultureInfo culture)
    {
      string s = (string)value;
      double v;
      if (!double.TryParse(s, out v))
        return 0;
      return v / FACTOR;
    }
  }
}
