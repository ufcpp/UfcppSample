﻿using System.Windows.Controls;

namespace BindingDependencyProperty
{
	public class AngleRangeRule : ValidationRule
	{
		public override ValidationResult Validate(object value,
			System.Globalization.CultureInfo cultureInfo)
		{
			double result;

			if (!double.TryParse(value as string, out result))
				return new ValidationResult(false, "文字列が不正です");

			if (result < 0 || result > 360)
				return new ValidationResult(false, "値の範囲が不正です");

			return new ValidationResult(true, null);
		}
	}
}
