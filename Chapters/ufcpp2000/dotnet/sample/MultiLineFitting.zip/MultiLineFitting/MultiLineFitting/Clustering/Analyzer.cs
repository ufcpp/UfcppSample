﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Point = System.Windows.Point;

namespace MultiLineFitting.Clustering
{
	/// <summary>
	/// m 個の点が、n 本の直線の付近に沿うように分布するようなデータ列に対して、
	/// K平均法クラスタリングと最小二乗法を使って、
	/// n 本の回帰直線を求める。
	/// 
	/// 回帰直線をクラスタ重心と考えて、
	/// 1. 各点に対して一番近い回帰直線を探して帰属情報を更新
	/// 2. クラスタごとに最小二乗法で回帰直線を求めなおす
	/// の2つの処理を反復。
	/// 
	/// クラスタリングの方法に関しては次のURLを参照。
	/// http://www.elet.polimi.it/upload/matteucc/Clustering/tutorial_html/cmeans.html
	/// </summary>
	/// <remarks>
	/// 今、適当に作ってるんで、時々回帰直線が求められない
	/// （データが偏って、クラスタ中の点が1つだけとかになったりするのを避ける仕組みを実装してない）。
	/// 回帰直線の傾き・Y切片がNaNになって、直線の表示時に例外が発生したりするけど、
	/// 特に対策してないのでときどき不正終了します。
	/// </remarks>
	/// <seealso cref=""/>
	public class Analyzer
	{
		#region 定数

		/// <summary>
		/// クラスタ解析、デフォルトの反復回数。
		/// </summary>
		const int NUM_REPEAT = 100;

		#endregion
		#region フィールド

		/// <summary>
		/// クラスタ解析対象の点列。
		/// </summary>
		List<Point> x;

		/// <summary>
		/// i 番目のデータがどのクラスタに帰属するか。
		/// </summary>
		int[] u;

		/// <summary>
		/// 回帰直線。
		/// クラスタ重心(centroid)に相当。
		/// c[j] … j 番目の回帰直線。
		/// </summary>
		Line[] c;

		#endregion
		#region 初期化

		/// <summary>
		/// データ数とクラスタ数を指定して初期化。
		/// </summary>
		/// <param name="numData">データ数。</param>
		/// <param name="numCluster">クラスタ数。</param>
		public Analyzer(int numData, int numCluster)
			: this(new Point[numData], numCluster)
		{
		}

		/// <summary>
		/// データとクラスタ数を指定して初期化。
		/// </summary>
		/// <param name="data">データ。</param>
		/// <param name="numCluster">クラスタ数。</param>
		public Analyzer(IList<Point> data, int numCluster)
		{
			this.x = new List<Point>();
			this.x.AddRange(data);
			this.x.Sort((p, q) => p.X.CompareTo(q.X));
			this.u = new int[data.Count];
			this.c = new Line[numCluster];

			this.Initialize();
		}

		#endregion
		#region プロパティ

		/// <summary>
		/// クラスタ解析対象のデータ。
		/// </summary>
		public IList<Point> Data
		{
			get { return this.x; }
		}

		/// <summary>
		/// j 番目のクラスタの重心を返す。
		/// </summary>
		/// <param name="j">クラスタのインデックス。</param>
		/// <returns>クラスタ重心。</returns>
		public Line Centroid(int j)
		{
			return this.c[j];
		}

		public IEnumerable<Line> Centroids
		{
			get
			{
				return this.c;
			}
		}

		/// <summary>
		/// i 番目のデータが j 番目のクラスタへの帰属するかどうか。
		/// </summary>
		/// <param name="i">データのインデックス。</param>
		/// <param name="j">クラスタのインデックス。</param>
		/// <returns>クラスタ帰属度</returns>
		public bool IsMember(int i, int j)
		{
			return this.u[i] == j;
		}

		/// <summary>
		/// j 番目のクラスタに帰属するデータを全て列挙。
		/// </summary>
		/// <param name="j">クラスタのインデックス。</param>
		/// <returns>クラスタに帰属するメンバ</returns>
		public IEnumerable<Point> Members(int j)
		{
			var list = new List<Point>();
			for (int i = 0; i < this.x.Count; ++i)
			{
				if (this.u[i] == j)
					list.Add(this.x[i]);
			}
			return list;
		}

		#endregion
		#region K-means 法本体

		/// <summary>
		/// クラスタ帰属情報の更新。
		/// 要するに、一番近い回帰直線（クラスタ重心）を探す。
		/// </summary>
		void UpdateMembership()
		{
			for (int i = 0; i < this.x.Count; i++)
			{
				var min = double.MaxValue;

				for (int j = 0; j < this.c.Length; j++)
				{
					var d = Norm(this.x[i], this.c[j]);
					if (d < min)
					{
						min = d;
						this.u[i] = j;
					}
				}
			}
		}

		static double Norm(Point p, Line l)
		{
			return l.DistanceTo(p);
		}

		/// <summary>
		/// 回帰直線（クラスタ重心）の更新。
		/// 要するに、クラスタごとに回帰直線を求めなおす。
		/// 最小二乗法を利用。
		/// </summary>
		/// <remarks>
		/// クラスタ中の全点を使って回帰直線を求めるとどうも局所解に落ち込み安いみたい。
		/// それに対して、（最初にデータを X 座標でソートしてあると言う前提で）
		/// 両端付近の点を除外した状態で回帰直線を求めると局所解に陥りにくくなるっぽい。
		/// useMiddle フラグで、全点使うか、真ん中辺りの点のみを使うか切り替え。
		/// </remarks>
		/// <param name="useMiddle">true ならデータ列の真ん中辺りだけを使って回帰直線を計算</param>
		void UpdateCentroid(bool useMiddle)
		{
			for (int j = 0; j < this.c.Length; j++)
			{
				double sx = 0;
				double sxx = 0;
				double sy = 0;
				double syy = 0;
				double sxy = 0;
				int n = 0;

				var points = this.Members(j).ToList();
				var count = points.Count;

				int begin, end;
				if (useMiddle)
				{
					begin = count / 4;
					end = 3 * count / 4;
				}
				else
				{
					begin = 0;
					end = count;
				}

				for (int i = begin; i < end; i++)
				{
					var x = points[i].X;
					var y = points[i].Y;
					sx += x;
					sxx += x * x;
					sy += y;
					syy += y * y;
					sxy += x * y;
					++n;
				}
				var det = n * sxx - sx * sx;
				var a = n * sxy - sx * sy;
				var b = sxx * sy - sx * sxy;
				a /= det;
				b /= det;

				this.c[j].A = a;
				this.c[j].B = b;
			}
		}

		/// <summary>
		/// 初期重心位置の決定。
		/// (とりあえず、ランダムに初期化。最適化の余地あり。)
		/// </summary>
		public void Initialize()
		{
			// とりあえずランダムに初期化。
			Random rnd = new Random();

			for (int i = 0; i < this.x.Count; i++)
			{
				this.u[i] = rnd.Next(0, this.c.Length);
				//this.u[i] = i % this.c.Length;
			}
		}

		/// <summary>
		/// クラスタ解析開始。
		/// デフォルトの反復回数で実行。
		/// </summary>
		public void Analyze()
		{
			this.Analyze(NUM_REPEAT);
		}

		/// <summary>
		/// クラスタ解析開始。
		/// </summary>
		/// <param name="repeat">反復回数</param>
		public void Analyze(int repeat)
		{
			for (int n = 0; n < repeat; ++n)
			{
				this.UpdateCentroid(true);
				this.UpdateMembership();
			}
			for (int n = 0; n < repeat; ++n)
			{
				this.UpdateCentroid(false);
				this.UpdateMembership();
			}
		}

		#endregion
	}
}
