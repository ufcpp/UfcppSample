﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Point = System.Windows.Point;

namespace MultiLineFitting.Clustering
{
	/// <summary>
	/// 直線 y = A x + b
	/// </summary>
	public struct Line
	{
		/// <summary>
		/// 直線の傾き。
		/// </summary>
		public double A;

		/// <summary>
		/// 直線のY切片。
		/// </summary>
		public double B;

		/// <summary>
		/// 傾き・Y切片を指定して初期化。
		/// </summary>
		/// <param name="a">傾き</param>
		/// <param name="b">Y切片</param>
		public Line(double a, double b)
		{
			this.A = a;
			this.B = b;
		}

		/// <summary>
		/// A x + b を計算。
		/// </summary>
		/// <param name="x">x</param>
		/// <returns>y</returns>
		public double this[double x]
		{
			get { return this.A * x + this.B; }
		}

		/// <summary>
		/// 直線 y = a x + b から点 p までの距離を求める。
		/// </summary>
		/// <param name="p">点 p</param>
		/// <returns>距離</returns>
		public double DistanceTo(Point p)
		{
			var d = Math.Abs(p.Y - this[p.X]);
			var n = Math.Sqrt(1 + this.A * this.A);
			return d / n;
		}
	}
}
