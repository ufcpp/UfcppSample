﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Clustering = MultiLineFitting.Clustering;

namespace MultiLineFitting
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(Window1_Loaded);
		}

		void Window1_Loaded(object sender, RoutedEventArgs e)
		{
			// 定数類
			const int LINES = 3;
			const double RANDOMNESS = 10 - LINES;
			const int POINTS = 30;
			const int REPEAT = 5 * LINES;

			var colors = new[]
				{
					Colors.Blue,
					Colors.Red,
					Colors.Green,
					Colors.Black,
					Colors.Pink,
					Colors.Violet,
					Colors.Brown,
				};

			var brushes = (from c in colors select new SolidColorBrush(c)).ToArray();

			// データ作成
			var funcs = Enumerable.Range(0, LINES).Select(x => this.MakeRandomLine()).ToArray();

			List<Point> points = new List<Point>();

			for (int i = 0; i < POINTS; ++i)
			{
				foreach (var f in funcs)
					points.Add(this.MakeRandomPoint(f, RANDOMNESS));
			}

			// 最小二乗法フィッティング＆クラスタリング
			var analyzer = new Clustering::Analyzer(points.ToArray(), funcs.Length);
			analyzer.Analyze(REPEAT);

			// フィッティング結果の表示
			for (int i = 0; i < funcs.Length; ++i)
			{
				var b = brushes[i];
				this.AddLine(analyzer.Centroid(i), b);

				foreach (var p in analyzer.Members(i))
				{
					var r = new Rectangle { Width = 3, Height = 3, Fill = b };
					r.SetValue(Canvas.LeftProperty, p.X);
					r.SetValue(Canvas.TopProperty, p.Y);
					this.canvas.Children.Add(r);
				}
			}
		}

		/// <summary>
		/// 直線の表示
		/// </summary>
		/// <param name="l">直線の傾き＆Y切片</param>
		/// <param name="brush">ストローク</param>
		void AddLine(Clustering::Line l, Brush brush)
		{
			var a = l.A;
			var b = l.B;
			var line = new Line { X1 = 0, Y1 = b, X2 = 300, Y2 = a * 300 + b, Stroke = brush, StrokeThickness = 1 };
			this.canvas.Children.Add(line);
		}

		/// <summary>
		/// 直線 y = f(x) 付近のランダムな点を作成。
		/// </summary>
		/// <param name="f">直線の式</param>
		/// <returns>直線付近のランダムな点</returns>
		Point MakeRandomPoint(Func<double, double> f, double randomness)
		{
			double x, y;

			do
			{
				x = this.Random(randomness, 300 - randomness);
				y = f(x);
				x += this.Random(-randomness, randomness);
				y += this.Random(-randomness, randomness);
			} while (y < 0 || y > 300);

			return new Point(x, y);
		}

		/// <summary>
		/// ランダムな直線を作成。
		/// 直線は、y = ax + b の形で表すものとして、ax + b の部分を生成。
		/// ランダムな傾きを持っていて、
		/// 画面の中央 (150, 150) から30～100ドット離れた直線を作る。
		/// </summary>
		/// <returns>ax + b</returns>
		Func<double, double> MakeRandomLine()
		{
			var t = Random(-1.5, 1.5);
			if (this.RandomBranch()) t += Math.PI;
			var c = Math.Cos(t);
			var s = Math.Sin(t);
			var d = Random(30, 100);

			// s(x - 150 - d s) + c (y -150 - d c) = 0
			// → sx + cy -150(s + c) - d = 0
			// （画面の中央 (150, 150) から法線方向に d だけ離れた直線）
			// を y = a x + b の形に変形

			var a = -s / c;
			var b = (150 * (s + c) + d) / c;
			return x => a * x + b;
		}

		Random rnd = new Random();

		double Random(double min, double max)
		{
			return (max - min) * rnd.NextDouble() + min;
		}

		bool RandomBranch()
		{
			return this.rnd.Next(2) != 0;
		}
	}
}
