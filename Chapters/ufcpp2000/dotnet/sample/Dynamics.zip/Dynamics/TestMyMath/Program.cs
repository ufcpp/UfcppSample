﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyMath.Lambda;
using CF = MyMath.Lambda.CachedFunction;

namespace TestMyMath
{
  class Program
  {
    static void Main(string[] args)
    {
      TestDifferentiate();
    }

    static void TestDifferentiate()
    {
      Variable x = new Variable("x");
      Variable y = new Variable("y");
      Function x1 = new CachedFunction(x / 2 + 1);
      Function x2 = new CachedFunction(x / 2 - 1);
      Function s1 = CF.Sin(x1);
      Function s2 = CF.Sin(x2);
      Function c1 = CF.Cos(x1);
      Function c2 = CF.Cos(x2);
      Function f = (s1 * c2 + c1 * s2) / (c1 * c2 - s1 * s2) * y;
      // ↑結局、Tan(x) になる式。
      Function f1 = f.Differentiate(x);

      Random rnd = new Random();
      Function.Parameter[] p = new Function.Parameter[]
      {
        new Function.Parameter(x, 0),
        new Function.Parameter(y, 0),
      };

      for (int i = 0; i < 30; ++i)
      {
        double xx = 10 * rnd.NextDouble();
        double yy = rnd.NextDouble();

        double a1, a2;

        a1 = Math.Tan(xx) * yy;
        p[0].val = xx;
        p[1].val = yy;
        //a2 = f.GetValue(p);
        a2 = f.GetValue(x.Set(xx), y.Set(yy));
        Console.Write("{0}\n", a1 - a2);

        a1 = 1 / Math.Cos(xx);
        a1 *= a1;
        a1 *= yy;
        p[0].val = xx;
        p[1].val = yy;
        //a2 = f1.GetValue(p);
        a2 = f1.GetValue(x.Set(xx), y.Set(yy));
        Console.Write("{0}\n", a1 - a2);
      }
    }
  }
}
