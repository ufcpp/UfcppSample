﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyMath.Lambda
{
  using ValueType = System.Double;

  /// <summary>
  /// 関数のパラメータ変数のリスト。
  /// </summary>
  /// <remarks>
  /// Function は、「引数の数がいくつで・・・」みたいな引数の管理のしかたをしてなくて、
  /// 関数 f は変数 x と y の関数です、
  /// x, y にそれぞれ値 xxx と xxx を代入します
  /// みたいな管理のしかたをする。
  /// </remarks>
  /// <example>
  /// Variable x = new Variable("x");
  /// Variable y = new Variable("y");
  /// Function f = x * x + y * y;
  /// VariableTable t = f.GetVariableTable();
  /// t[x] = 1;
  /// t[y] = 2;
  /// ValueType result = f[t];
  /// </example>
  public class VariableTable : ICloneable
  {
    Dictionary<Variable, ValueType> table;

		VariableTable(IDictionary<Variable, ValueType> table)
		{
			this.table = new Dictionary<Variable,double>(table);
		}

    public VariableTable(params Variable[] list)
      : this((IList<Variable>)list)
		{
		}

		public VariableTable(IList<Variable> list)
		{
			this.table = new Dictionary<Variable, ValueType>();

			foreach(Variable v in list)
			{
				this.table.Add(v, (ValueType)0);
			}
		}

		public Function.Parameter[] GetParameterList()
		{
			Function.Parameter[] p = new Function.Parameter[this.table.Count];

			int i = 0;
			foreach(KeyValuePair<Variable, ValueType> entry in this.table)
			{
				p[i] = new Function.Parameter(entry.Key, entry.Value);
				++i;
			}

			return p;
		}

		public ValueType this[Variable v]
		{
			get{return this.table[v];}
			set{this.table[v] = value;}
		}

		public VariableTable Clone()
		{
			return new VariableTable(this.table);
		}

		#region ICloneable メンバ

		object ICloneable.Clone()
		{
			return this.Clone();
		}

		#endregion
	}
}
