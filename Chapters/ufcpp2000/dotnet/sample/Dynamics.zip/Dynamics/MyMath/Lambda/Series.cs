﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyMath.Lambda
{
	/// <summary>
	/// Sum(累和)/Product(累積)クラスの共通基底。
	/// </summary>
	public abstract class Series : Function
	{
		#region フィールド

    protected List<Function> functions;

		#endregion
		#region 初期化

		public Series(params Function[] functions)
		{
      this.functions = new List<Function>();

			foreach(Function f in functions)
			{
				this.functions.Add(f);
			}
		}

		public Series(IList<Function> functions)
		{
			this.functions = new List<Function>(functions);
		}

		#endregion
		#region 関数の追加

		/// <summary>
		/// 加算対象リストに関数を追加する。
		/// </summary>
		/// <param name="f">追加する関数</param>
		internal void AddList(Function f)
		{
			this.functions.Add(f);
		}

		/// <summary>
		/// 加算対象リストに関数を追加する。
		/// </summary>
		/// <param name="list">追加する関数のリスト</param>
		internal void AddList(IList<Function> list)
		{
			foreach(Function f in list)
				this.AddList(f);
		}

		#endregion
    #region 値の計算

    public override IList<Variable> GetVariableList()
    {
      IList<Variable> list = null;

      foreach (Function f in this.functions)
      {
        list = Misc.Merge(list, f.GetVariableList());
      }
      return list;
    }

		#endregion
    #region object

		public override bool Equals(object obj)
		{
			Series s = obj as Series;
			if(s == null) return false;
			if(this.functions.Count != s.functions.Count) return false;

			for(int i=0; i<this.functions.Count; ++i)
			{
				if(!this.functions[i].Equals(s.functions[i])) return false;
			}

			return true;
		}

		public override int GetHashCode()
		{
			int code = 0;
			foreach(Function f in this.functions)
			{
				code <<= 1;
				code ^= f.GetHashCode();
			}

			return code;
		}

		#endregion
	}
}
