﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyMath.Lambda;

namespace MyMath.DifferentialEquation
{
  /// <summary>
  /// 自励系の微分方程式を数値的にといて、解軌跡を得る。
  /// </summary>
  /// <remarks>
  /// 4次のルンゲクッタ法で逐次計算。
  /// </remarks>
  public class DynamicalSystem
  {
    #region protected フィールド

    /// <summary>
    /// 位相空間上の座標変数。
    /// </summary>
    protected Variable[] q;

    /// <summary>
    /// 自励系の右辺の関数。
    /// (d/dt)q = f(q)。
    /// </summary>
    protected Function[] f;

    #endregion
    #region private

    Function.Parameter[] parameter;

    double[] val;

    #endregion
    #region 初期化

    public DynamicalSystem(params Variable[] vars)
      : this(vars, new Function[vars.Length])
    {
    }

    public DynamicalSystem(Variable[] vars, Function[] funcs)
    {
      this.q = vars;
      this.f = funcs;

      this.parameter = new Function.Parameter[vars.Length];
      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i] = new Function.Parameter(this.q[i], 0);
      this.val = new double[vars.Length];
    }

    #endregion
    #region プロパティ

    public void SetF(int i, Function func)
    {
      this.f[i] = func;
    }

    public double CurrentValue(int i)
    {
      return this.val[i];
    }

    #endregion
    #region 数値計算本体

    /// <summary>
    /// 初期値を与える。
    /// </summary>
    /// <param name="val">初期値</param>
    public void SetInitialValue(params double[] val)
    {
      for (int i = 0; i < this.val.Length; ++i)
        this.val[i] = val[i];
    }

    /// <summary>
    /// Δt 分更新。
    /// </summary>
    /// <param name="dt">Δt</param>
    public void Update(double dt)
    {
      /* ガウス法
      double[] k = new double[this.q.Length];

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i];
      for (int i = 0; i < this.q.Length; ++i)
        this.val[i] = this.val[i] + dt * this.f[i].GetValue(this.parameter);
      // */

      /* 中点法
      double[] k = new double[this.q.Length];

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i];
      for (int i = 0; i < this.q.Length; ++i)
        k[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i] + k[i] / 2;
      for (int i = 0; i < this.q.Length; ++i)
        k[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.val[i] = this.val[i] + k[i];
      // */

      //* ルンゲクッタ法
      double[] k1 = new double[this.q.Length];
      double[] k2 = new double[this.q.Length];
      double[] k3 = new double[this.q.Length];
      double[] k4 = new double[this.q.Length];

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i];
      for (int i = 0; i < this.q.Length; ++i)
        k1[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i] + k1[i] / 2;
      for (int i = 0; i < this.q.Length; ++i)
        k2[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i] + k2[i] / 2;
      for (int i = 0; i < this.q.Length; ++i)
        k3[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.parameter[i].val = this.val[i] + k3[i];
      for (int i = 0; i < this.q.Length; ++i)
        k4[i] = dt * this.f[i].GetValue(this.parameter);

      for (int i = 0; i < this.q.Length; ++i)
        this.val[i] = this.val[i] + (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) / 6;
      // */
    }

    #endregion
  }
}
