﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyMath.Lambda;

namespace MyMath.DifferentialEquation
{
  /// <summary>
  /// 曲面上（2変数）のハミルトン系の1体問題。
  /// </summary>
  /// <remarks>
  /// 親クラスの座標変数 vq、自励関数 f は、
  /// 一般化座標   q1 = vq[0], q2 = vq[1]、
  /// 一般化運動量 p1 = vq[2], p2 = vq[3]。
  /// ハミルトニアンを H として、
  /// f[0] =  (∂/∂p1)H、
  /// f[1] =  (∂/∂p2)H、
  /// f[2] = -(∂/∂q1)H、
  /// f[3] = -(∂/∂q2)H。
  /// </remarks>
  public class SurfaceDynamics : DynamicalSystem
  {
    #region フィールド

    /// <summary>
    /// 一般化座標 → 直交座標の変換関数 x(q1, q2)。
    /// </summary>
    public Function X { set; get; }

    /// <summary>
    /// 一般化座標 → 直交座標の変換関数 y(q1, q2)。
    /// </summary>
    public Function Y { set; get; }

    /// <summary>
    /// 一般化座標 → 直交座標の変換関数 z(q1, q2)。
    /// </summary>
    public Function Z { set; get; }

    /// <summary>
    /// ポテンシャル φ(q1, q2)。
    /// </summary>
    public Function Phi { set; get; }

    /// <summary>
    /// 質点の質量。
    /// </summary>
    public double M { set; get; }

    #endregion
    #region 初期化

    public SurfaceDynamics()
      : base(new Variable("q1"), new Variable("q2"), new Variable("p1"), new Variable("p2"))
    {
      this.M = 1;
    }

    #endregion
    #region プロパティ

    public Variable Q1 { get { return this.q[0]; } }
    public Variable Q2 { get { return this.q[1]; } }
    public Variable P1 { get { return this.q[2]; } }
    public Variable P2 { get { return this.q[3]; } }

    public double CurrentQ1 { get { return this.CurrentValue(0); } }
    public double CurrentQ2 { get { return this.CurrentValue(1); } }
    public double CurrentP1 { get { return this.CurrentValue(2); } }
    public double CurrentP2 { get { return this.CurrentValue(3); } }

    public double CurrentX
    {
      get
      {
        return this.X.GetValue(
          this.Q1.Set(this.CurrentQ1),
          this.Q2.Set(this.CurrentQ2));
      }
    }

    public double CurrentY
    {
      get
      {
        return this.Y.GetValue(
          this.Q1.Set(this.CurrentQ1),
          this.Q2.Set(this.CurrentQ2));
      }
    }

    public double CurrentZ
    {
      get
      {
        return this.Z.GetValue(
          this.Q1.Set(this.CurrentQ1),
          this.Q2.Set(this.CurrentQ2));
      }
    }

    #endregion
    #region 自励関数計算

    /// <summary>
    /// X, Y, Z, Phi から自励関数 f(q) を計算。
    /// </summary>
    public void Calculate()
    {
      Variable q1 = this.q[0];
      Variable q2 = this.q[1];
      Variable p1 = this.q[2];
      Variable p2 = this.q[3];

      Function x = this.X;
      Function y = this.Y;
      Function z = this.Z;
      Function phi = this.Phi;

      Function x1 = x.Differentiate(q1);
      Function y1 = y.Differentiate(q1);
      Function z1 = z.Differentiate(q1);
      Function x2 = x.Differentiate(q2);
      Function y2 = y.Differentiate(q2);
      Function z2 = z.Differentiate(q2);

      Function g11 = x1 * x1 + y1 * y1 + z1 * z1;
      Function g12 = x1 * x2 + y1 * y2 + z1 * z2;
      Function g22 = x2 * x2 + y2 * y2 + z2 * z2;

      Function det = g11 * g22 - g12 * g12;

      Function gi11 = g22 / det;
      Function gi12 = -g12 / det;
      Function gi22 = g11 / det;

      this.f[0] = (gi11 * p1 + gi12 * p2) / this.M;
      this.f[1] = (gi12 * p1 + gi22 * p2) / this.M;

      for (int i = 0; i < 2; ++i)
      {
        Function gi11q = gi11.Differentiate(this.q[i]);
        Function gi12q = gi12.Differentiate(this.q[i]);
        Function gi22q = gi22.Differentiate(this.q[i]);
        Function phiq = phi.Differentiate(this.q[i]);

        this.f[2 + i] =
          -(
            (p1 * p1 * gi11q
            + 2 * p1 * p2 * gi12q
            + p2 * p2 * gi22q) / (2 * this.M)
            + phiq
          );
      }

      /*
      for (int i = 0; i < 4; ++i)
      {
        this.f[i] = this.f[i].Optimize();
      }
       * */
    }

    #endregion
  }
}
