﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Media.Media3D;
using System.Threading;

using MyMath.Lambda;
using LF = MyMath.Lambda.Function;
using Dynamics = MyMath.DifferentialEquation.SurfaceDynamics;

namespace PlotIn3D
{
  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>

  public partial class Window1 : Window
  {
    public Window1()
    {
      InitializeComponent();

      this.InitDynamics();

      this.plotArea =
        new Plot3D.Plot3DControl(
          Surface, U0, U1, V0, V1, N,
          Plot3D.Plot3DControl.SurfaceType.Lattice);

      this.dock.Children.Add(this.plotArea);

      CompositionTarget.Rendering += this.Callback;
    }

    #region フィールド

    Plot3D.Plot3DControl plotArea;
    Dynamics dynmics;

    #endregion
    //* 
    #region 定数

    // 拘束面の表示関係
    const double U0 = 0;
    const double U1 = 2 * Math.PI;
    const double V0 = 0;
    const double V1 = 1;
    const int N = 100;

    // Dynamics の初期値
    const double InitialQ1 = 0;
    const double InitialQ2 = 0.8;
    const double InitialP1 = 0.1;
    const double InitialP2 = -0.2;

    // 数値計算用
    const double dt = 0.01;

    #endregion
    #region Dynamics 関連

    void InitDynamics()
    {
      this.dynmics = new Dynamics();

      Variable q1 = this.dynmics.Q1;
      Variable q2 = this.dynmics.Q2;
      Variable p1 = this.dynmics.P1;
      Variable p2 = this.dynmics.P2;

      this.dynmics.X = 1.5 * q2 * LF.Cos(q1);
      this.dynmics.Y = 0.8 * q2 * LF.Sin(q1);
      this.dynmics.Z = LF.Exp(q2) + 0.2 * LF.Cos((5 * Math.PI) * q2) - 2;
      this.dynmics.Phi = this.dynmics.Z;

      this.dynmics.Calculate();

      this.dynmics.SetInitialValue(InitialQ1, InitialQ2, InitialP1, InitialP2);
    }

    #endregion
    // */
    /* 球面
    #region 定数

    // 拘束面の表示関係
    const double U0 = 0;
    const double U1 = 2 * Math.PI;
    const double V0 = 0;
    const double V1 = Math.PI / 2;
    const int N = 30;

    // Dynamics の初期値
    const double InitialQ1 = 0;
    const double InitialQ2 = Math.PI / 2;
    const double InitialP1 = 0.1;
    const double InitialP2 = 0;

    const double M = 0.1; // 質量
    const double G = 10; // 重力定数

    // 数値計算用
    const double dt = 0.005;

    #endregion
    #region Dynamics 関連

    void InitDynamics()
    {
      this.dynmics = new Dynamics();

      Variable q1 = this.dynmics.Q1;
      Variable q2 = this.dynmics.Q2;
      Variable p1 = this.dynmics.P1;
      Variable p2 = this.dynmics.P2;

      this.dynmics.X = LF.Sin(q2) * LF.Cos(q1);
      this.dynmics.Y = LF.Sin(q2) * LF.Sin(q1);
      this.dynmics.Z = -LF.Cos(q2);
      this.dynmics.Phi = (M * G) * this.dynmics.Z;

      this.dynmics.Calculate();

#if false
      Function sin2 = LF.Sin(q2);

      this.dynmics.SetF(0,
        p1 / (M * sin2 * sin2));
      this.dynmics.SetF(1,
        p2 / M);
      this.dynmics.SetF(2,
        (Constant)0);
      this.dynmics.SetF(3,
        p1 * p1 * LF.Cos(q2) / (M * sin2 * sin2 * sin2) - (M * G) * sin2);
#endif
      this.dynmics.SetInitialValue(InitialQ1, InitialQ2, InitialP1, InitialP2);
    }

    #endregion
    // */

    Point3D Surface(double u, double v)
    {
      Function fx = this.dynmics.X;
      Function fy = this.dynmics.Y;
      Function fz = this.dynmics.Z;

      Function.Parameter pu = this.dynmics.Q1.Set(u);
      Function.Parameter pv = this.dynmics.Q2.Set(v);

      double x = fx.GetValue(pu, pv);
      double y = fy.GetValue(pu, pv);
      double z = fz.GetValue(pu, pv);

      return new Point3D(x, y, z);
    }

    void Callback(object sender, EventArgs ea)
    {
      this.dynmics.Update(dt);

      double x = this.dynmics.CurrentX;
      double y = this.dynmics.CurrentY;
      double z = this.dynmics.CurrentZ;

      this.plotArea.SetLoation(new Point3D(x, y, z));
    }
  }
}
