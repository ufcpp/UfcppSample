﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Xml;

namespace PlotIn3D
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
  }
}
