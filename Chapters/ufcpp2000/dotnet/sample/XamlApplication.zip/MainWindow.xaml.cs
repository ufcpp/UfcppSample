using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace XamlWindowsApplication1
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class MainWindow : System.Windows.Window
	{

		public MainWindow()
		{
			InitializeComponent();
		}

		private void ButtonClicked(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("�{�^����������܂���");
			e.Handled = true;
		}

	}
}