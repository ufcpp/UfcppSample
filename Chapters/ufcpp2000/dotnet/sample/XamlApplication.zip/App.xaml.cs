using System;
using System.Windows;
using System.Configuration;

namespace XamlWindowsApplication1
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>

	public partial class App : System.Windows.Application
	{

	}
}