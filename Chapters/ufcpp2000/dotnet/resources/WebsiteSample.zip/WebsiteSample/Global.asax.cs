using System;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;

namespace WebsiteSample
{
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// �A�N�Z�X���̃J�E���g�A�b�v�B
		/// </summary>
		/// <returns>���݂̃J�E���g��</returns>
		string GetTotalCount()
		{
			string filename = Request.PhysicalApplicationPath +
				@"\count\total.txt";

			Application.Lock();

			int num;
			using (FileStream fs = new FileStream(
				filename, FileMode.OpenOrCreate,
				FileAccess.ReadWrite, FileShare.None))
			{
				StreamReader sr = new StreamReader(fs);
				string line = sr.ReadLine();

				if (string.IsNullOrEmpty(line) || !int.TryParse(line, out num))
				{
					num = 0;
				}

				line = (num + 1).ToString();

				fs.Seek(0, SeekOrigin.Begin);

				StreamWriter sw = new StreamWriter(fs);
				sw.WriteLine(line);
				sw.Flush();
			}
			Application.UnLock();

			return num.ToString();
		}

		/// <summary>
		/// �A�N�Z�X���O���L�^�B
		/// </summary>
		/// <param name="count">���݂̃J�E���g��</param>
		void AddAccessLog(string count)
		{
			string basePath = Request.PhysicalApplicationPath + @"\accesslog\";
			DateTime now = DateTime.Now;
			string filename = basePath
				+ string.Format("{0}{1:00}.csv", now.Year, now.Month);

			string prev;
			if (Request.Cookies["PREV"] != null)
				prev = Request.Cookies["PREV"].Value;
			else
				prev = count;

			Response.Cookies["PREV"].Value = count;

			Application.Lock();

			using (StreamWriter sw = new StreamWriter(filename, true))
			{
				sw.Write("\"" + DateTime.Now.ToString() + "\",");
				sw.Write("\"" +
					System.Net.Dns.GetHostEntry(Request.UserHostName).HostName +
					"\",");
				sw.Write("\"" + Request.UserAgent + "\",");
				sw.Write("\"" + Request.Url + "\",");
				sw.Write("\"" + Request.UrlReferrer + "\"\n");
			}
			Application.UnLock();
		}

		/// <summary>
		/// ���O�L�^�E�J�E���^�̑ΏۊO UserAgent ���X�g�B
		/// </summary>
		static readonly string[] excludeList = new string[]
		{
			"Googlebot",
			"Yahoo! Slurp",
			"msnbot",
			"MMCrawler",
			"yetibot@naver.com",
			"AMZNKAssocBot",
			"Mediapartners-Google",
		};

		/// <summary>
		/// ���O���X�g�̃`�F�b�N�B
		/// </summary>
		/// <returns>���O���X�g�ɓ����Ă����� true</returns>
		bool CheckExcludeList()
		{
			string agent = Request.UserAgent;

			foreach (string exclude in excludeList)
			{
				if (agent.Contains(exclude))
					return true;
			}
			return false;
		}

		#region ASP.NET �C�x���g�n���h��

		protected void Session_Start(object sender, EventArgs e)
		{
			if (CheckExcludeList())
				return;

			string count = GetTotalCount();
			Session["count"] = count;
			AddAccessLog(count);
		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{
			this.RewriteUrl();
		}

		#endregion
		#region �����C�g/���_�C���N�g����

		public struct RewriteRule
		{
			public Regex LookFor;
			public string SendTo;

			public RewriteRule(string lookFor, string sendTo)
			{
				this.LookFor = new Regex(lookFor);
				this.SendTo = sendTo;
			}
		}

		static RewriteRule[] rewriteRules = new RewriteRule[]
			{
				new RewriteRule(@"Test/(RewriteTest.aspx)", "$1"),
				new RewriteRule(@"(\d{4})/(\d{2})/(\d{2})\.aspx", "BlogDate.aspx?mode=date&y=$1&m=$2&d=$3"),
				//new RewriteRule(@"(\d{4})(\d{2})(\d{2})\.aspx", "BlogDate.aspx?mode=date&y=$1&m=$2&d=$3"),
			};
		static RewriteRule[] redirectRules = new RewriteRule[]
			{
				new RewriteRule(@"(\d{4})(\d{2})(\d{2})\.aspx", "$1/$2/$3.aspx"),
				//new RewriteRule(@"(\d{4})/(\d{2})/(\d{2})\.aspx", "$1$2$3.aspx"),
			};

		void RewriteUrl()
		{
			string url = Request.Url.AbsolutePath;
			string result;

			foreach (RewriteRule rule in rewriteRules)
			{
				if (!rule.LookFor.IsMatch(url))
					continue;

				result = rule.LookFor.Replace(url, rule.SendTo);
				Context.RewritePath(result, false);
				return;
			}

			foreach (RewriteRule rule in redirectRules)
			{
				if (!rule.LookFor.IsMatch(url))
					continue;

				result = rule.LookFor.Replace(url, rule.SendTo);
				Response.Redirect(result);
				return;
			}
		}

		#endregion
	}
}