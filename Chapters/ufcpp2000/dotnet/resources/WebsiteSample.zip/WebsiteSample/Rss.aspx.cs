﻿using System;
using System.Web;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;

namespace WebsiteSample
{
	public partial class Rss : System.Web.UI.Page
	{
		RssWriter writer = new RssWriter();

		protected void Page_Load(object sender, EventArgs e)
		{
			Response.ContentType = "application/xml";
			Response.ContentEncoding = System.Text.Encoding.UTF8;

			this.writer.Write(Request.Url.AbsoluteUri, Response.OutputStream);
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			this.writer.SiteName = "My Site";
			this.writer.AdministratorName = "admin name";
			this.writer.Url = URL;
			this.ReadItems();
		}

		const int DEFAULT_NUM = 15;
		const int DEFAULT_DIGEST_LENGTH = 128;

		const string URL = "http://my.domain.net/";

		static readonly Regex regYyyyMmDd = new Regex(@"(?<y>\d\d\d\d)(?<m>\d\d)(?<d>\d\d)", RegexOptions.Compiled);
		static readonly Regex regCDATA = new Regex(@"\<!\[CDATA\[.*?\]\]\>", RegexOptions.Compiled);
		static readonly Regex regTags = new Regex(@"\<.*?\>", RegexOptions.Compiled);

		/// <summary>
		/// データを読み出して、RssWriter に項目を追加。
		/// </summary>
		void ReadItems()
		{
			int num, digestLen;
			if (!int.TryParse(Request.QueryString["num"], out num)) num = DEFAULT_NUM;
			if (!int.TryParse(Request.QueryString["len"], out digestLen)) digestLen = DEFAULT_DIGEST_LENGTH;

			string PATH = Server.MapPath(@"~/App_Data");

			DirectoryInfo dataDir = new DirectoryInfo(PATH);
			FileInfo[] files = dataDir.GetFiles("*.xml");

			Array.Sort(files,
				delegate(FileInfo a, FileInfo b)
				{
					return b.Name.CompareTo(a.Name);
				});

			foreach (FileInfo file in files)
			{
				Match m = regYyyyMmDd.Match(file.Name);
				if (!m.Success)
					continue;
				int year = int.Parse(m.Groups["y"].Value);
				int month = int.Parse(m.Groups["m"].Value);
				int day = int.Parse(m.Groups["d"].Value);

				XmlDocument doc = new XmlDocument();
				using (Stream stream = new FileStream(file.FullName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
				{
					doc.Load(stream);
				}

				XmlNodeList list = doc.GetElementsByTagName("blog");
				foreach (XmlNode node in list)
				{
					string pageUrl = URL +
						string.Format("{0}/{1:00}/{2:00}.aspx",
						year, month, day);

					XmlAttribute att;
					string title = string.Empty;
					att = node.Attributes["title"];
					if (att != null) title = att.Value;
					att = node.Attributes["category"];
					if (att != null)
					{
						title += " [" + att.Value + "]";
					}

					string digest = Digest(node.InnerXml, digestLen);

					this.writer.Add(pageUrl, title, new DateTime(year, month, day), digest);
				}

				if (this.writer.Count >= num) break;
			}
		}

		/// <summary>
		/// XML のダイジェストを作る。
		/// XML のタグを取り除いて、テキストのみにして、最初の num 文字だけを返す。
		/// </summary>
		/// <param name="xml">XML 文字列</param>
		/// <param name="num">最初何文字を返すか</param>
		/// <returns>タグを取り除いた結果</returns>
		static string Digest(string xml, int num)
		{
			xml = xml.Replace("\n", "");
			xml = xml.Replace("\r", "");

			string digest;
			digest = regCDATA.Replace(xml, "");
			digest = regTags.Replace(xml, "");

			if (num >= digest.Length)
				return digest;

			digest = digest.Substring(0, num);
			return digest + " …";
		}
	}
}
