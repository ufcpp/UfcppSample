﻿using System;
using System.Web;
using System.Xml;
using System.Xml.Xsl;
using System.IO;
using System.Text;

namespace WebsiteSample
{
	public partial class ShowXml : System.Web.UI.UserControl
	{
		#region プロパティ

		string xmlFileName = null;

		public string XmlFileName
		{
			get { return xmlFileName; }
			set { xmlFileName = value; }
		}

		string xslFileName = null;

		public string XslFileName
		{
			get { return xslFileName; }
			set { xslFileName = value; }
		}

		#endregion

		protected void Page_PreRender(object sender, EventArgs e)
		{
			if (this.xmlFileName == null || this.xslFileName == null
				|| !File.Exists(this.xmlFileName)
				|| !File.Exists(this.xslFileName)
				)
				return;

			XslCompiledTransform xslt = new XslCompiledTransform();
			xslt.Load(this.XslFileName);
			XmlDocument xml = new XmlDocument();
			xml.Load(this.xmlFileName);

			XmlNodeReader reader = new XmlNodeReader(xml);
			MemoryStream s = new MemoryStream();
			XmlTextWriter writer = new XmlTextWriter(s, Encoding.UTF8);
			xslt.Transform(reader, writer);

			s.Seek(0, SeekOrigin.Begin);
			StreamReader sr = new StreamReader(s);

			string result = sr.ReadToEnd();
			this.content.InnerHtml = result;

			s.Dispose();
		}
	}
}