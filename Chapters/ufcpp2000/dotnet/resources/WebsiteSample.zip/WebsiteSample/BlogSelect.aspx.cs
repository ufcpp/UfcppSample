﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace WebsiteSample
{
	public partial class BlogSelect : System.Web.UI.Page
	{
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			const int startedYear = 1998;
			DateTime today = DateTime.Today;
			int year = today.Year;
			int month = today.Month;
			int day = today.Day;

			ListItem li;
			for (int y = startedYear; y <= year; ++y)
			{
				li = new ListItem();
				li.Text = y.ToString();
				li.Value = y.ToString();
				this.listYear.Items.Add(li);
			}
			this.listYear.SelectedIndex = year - startedYear;

			this.listMonth.SelectedIndex = month - 1;

			this.textDay.Text = day.ToString();
		}

		protected void buttonShow_Click(object sender, EventArgs e)
		{
			int y = int.Parse(this.listYear.SelectedItem.Value);
			int m = int.Parse(this.listMonth.SelectedItem.Value);
			int d = int.Parse(this.textDay.Text);

			this.Show(y, m, d);
		}

		protected void calendar_SelectionChanged(object sender, EventArgs e)
		{
			DateTime selected = this.calendar.SelectedDate;

			this.Show(selected.Year, selected.Month, selected.Day);
		}

		void Show(int year, int month, int day)
		{
			string basePath = Context.Server.MapPath("~/App_Data");

			string xmlFile = basePath +
				string.Format(@"\{0}{1:00}{2:00}.xml", year, month, day);

			if (!File.Exists(xmlFile)) return;

			string xslFile = basePath + @"\main.xsl";

			this.xmlContent.XmlFileName = xmlFile;
			this.xmlContent.XslFileName = xslFile;

			this.head.Text = string.Format("{0}年{1}月{2}日",
				year, month, day);
		}
	}
}
