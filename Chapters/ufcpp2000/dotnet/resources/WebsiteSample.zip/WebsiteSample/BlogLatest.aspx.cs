﻿using System;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;

namespace WebsiteSample
{
	public partial class BlogLatest : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			int days = Util.GetIntFrom(Request.QueryString, 0, "days", "d");

			string basePath = Context.Server.MapPath("~/App_Data");
			string[] files = Directory.GetFiles(basePath, "*.xml");
			Array.Sort(files);

			string xmlFile = files[files.Length - 1 - days];
			string xslFile = basePath + @"\main.xsl";

			this.xmlContent.XmlFileName = xmlFile;
			this.xmlContent.XslFileName = xslFile;

			Match match = Util.yyyyMMdd.Match(xmlFile);
			if (match.Success)
			{
				this.head.Text = string.Format("{0}年{1}月{2}日",
					match.Groups[1],
					match.Groups[2].ToString().TrimStart('0'),
					match.Groups[3].ToString().TrimStart('0'));
			}
		}
	}
}
