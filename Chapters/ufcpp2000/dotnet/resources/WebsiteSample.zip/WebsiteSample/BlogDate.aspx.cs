﻿using System;
using System.Web;
using System.IO;

namespace WebsiteSample
{
	public partial class BlogDate : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			int day = Util.GetIntFrom(Request.QueryString, 0, "day", "d");
			int month = Util.GetIntFrom(Request.QueryString, 0, "month", "m");
			int year = Util.GetIntFrom(Request.QueryString, 0, "year", "y");

			string basePath = Context.Server.MapPath("~/App_Data");

			string xmlFile = basePath +
				string.Format(@"\{0}{1:00}{2:00}.xml", year, month, day);

			if (!File.Exists(xmlFile)) return;

			string xslFile = basePath + @"\main.xsl";

			this.xmlContent.XmlFileName = xmlFile;
			this.xmlContent.XslFileName = xslFile;

			this.head.Text = string.Format("{0}年{1}月{2}日",
				year, month, day);
		}
	}
}
