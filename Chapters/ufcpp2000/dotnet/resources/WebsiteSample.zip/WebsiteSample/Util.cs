﻿using System;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace WebsiteSample
{
	public class Util
	{
		internal static Regex yyyyMMdd =
			new Regex(@"(\d{4})(\d{2})(\d{2})\.xml");

		/// <summary>
		/// NameValueCollection から値を取り出す。
		/// 「キーに year がなければ y も試す」というように、
		/// 複数のキーのうちの最初に1つ合致したキーに対応する値を取得。
		/// 1つも合致しなければ defaultValue を返す。
		/// </summary>
		public static int GetIntFrom(
			NameValueCollection collection,
			int defultValue,
			params string[] keys)
		{
			foreach (string key in keys)
			{
				int val;
				string str = collection[key];
				if (!string.IsNullOrEmpty(str))
				{
					int.TryParse(str, out val);
					return val;
				}
			}
			return defultValue;
		}
	}
}
