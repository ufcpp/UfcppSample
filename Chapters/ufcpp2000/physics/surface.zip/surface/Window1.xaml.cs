﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Media.Media3D;
using System.Threading;

delegate double Func2(double p1, double p2);
delegate double Func4(double p1, double p2, double q1, double q2);

namespace WPFApplication1
{
  public class PhaseVector
  {
    public double q1;
    public double q2;
    public double p1;
    public double p2;

    public PhaseVector(double q1, double q2, double p1, double p2)
    {
      this.q1 = q1;
      this.q2 = q2;
      this.p1 = p1;
      this.p2 = p2;
    }

    public static PhaseVector operator +(PhaseVector x, PhaseVector y)
    {
      return new PhaseVector(
               x.q1 + y.q1, x.q2 + y.q2,
               x.p1 + y.p1, x.p2 + y.p2);
    }

    public static PhaseVector operator /(PhaseVector x, double a)
    {
      return new PhaseVector(
               x.q1 / a, x.q2 / a,
               x.p1 / a, x.p2 / a);
    }

    public static PhaseVector operator *(double a, PhaseVector x)
    {
      return new PhaseVector(
               a * x.q1, a * x.q2,
               a * x.p1, a * x.p2);
    }

    public delegate void Callback(double t, PhaseVector x);
    public delegate PhaseVector PhaseFunc(PhaseVector x);

    public static void Simulate(
      double t0, double t1, double dt, int display_interval,
      PhaseVector initial,
      PhaseFunc f, Callback cb)
    {
      PhaseVector q = initial;

      int n = 1;
      for (double t = t0; t < t1; t += dt, ++n)
      {
        PhaseVector k1 = dt * f(q);
        PhaseVector k2 = dt * f(q + k1 / 2);
        PhaseVector k3 = dt * f(q + k2 / 2);
        PhaseVector k4 = dt * f(q + k3);
        q = q + (k1 + 2 * (k2 + k3) + k4) / 6;

        if (n > display_interval)
        {
          cb(t, q);
          n = 1;
        }
      }
    }
  }

  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>
  public partial class Window1 : Window
  {
    public Window1()
    {
      InitializeComponent();

      this.Simulate();
    }

    Func2 x = delegate(double q1_, double q2_) {return Math.Cos(q1_) * Math.Sin(q2_);};
    Func2 y = delegate(double q1_, double q2_) {return Math.Sin(q1_) * Math.Sin(q2_);};
    Func2 z = delegate(double q1_, double q2_) {return -Math.Cos(q2_);};

    static PhaseVector F(PhaseVector q)
    {
      const double M = 0.1;
      const double G = 10;

      double s2 = Math.Sin(q.q2);
      double c2 = Math.Cos(q.q2);

      return new PhaseVector(
        q.p1 / (M * s2),
        q.p2 / M,
        0,
        (q.p1 * q.p1 * c2)
          / (M * s2 * s2 * s2)
         - M * G * s2
       );
    }

    MeshGeometry3D mesh;
    Material material;
    const double SPHERE_SIZE = 0.01;

    void Show(double t, PhaseVector q)
    {
      double x = this.x(q.q1, q.q2);
      double y = this.y(q.q1, q.q2);
      double z = this.z(q.q1, q.q2);

      GeometryModel3D model = new GeometryModel3D();
      model.Geometry = mesh;
      model.Material = material;
      Transform3DGroup t3dg = new Transform3DGroup();
      t3dg.Children.Add(new ScaleTransform3D(SPHERE_SIZE, SPHERE_SIZE, SPHERE_SIZE));
      t3dg.Children.Add(new TranslateTransform3D(x, y, z));
      model.Transform = t3dg;
      ModelVisual3D mv3d = new ModelVisual3D();
      mv3d.Content = model;
      this.viewport.Children.Add(mv3d);
    }

    void Simulate()
    {
      this.mesh = (MeshGeometry3D)this.FindResource("SphereMesh");
      this.material = (DiffuseMaterial)this.FindResource("WhiteMaterial");

      PhaseVector initialQ = new PhaseVector(
                      0, Math.PI / 2, 0.2, 0);

      const double dt = 0.001;
      const double t_end = 10;
      const int DISPLAY_INTERVAL = 20;

      PhaseVector.Simulate(
        0, t_end, dt, DISPLAY_INTERVAL,
        initialQ,
        F, Show);
    }
  }
}
