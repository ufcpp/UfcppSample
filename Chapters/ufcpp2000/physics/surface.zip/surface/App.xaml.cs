﻿using System;
using System.Configuration;
using System.Windows;

namespace WPFApplication1
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
