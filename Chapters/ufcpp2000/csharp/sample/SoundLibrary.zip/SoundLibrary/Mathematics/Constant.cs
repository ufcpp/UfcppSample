using System;

namespace SoundLibrary.Mathematics
{
	/// <summary>
	/// Constant �̊T�v�̐����ł��B
	/// </summary>
	public /*static*/ class Constant
	{
		public const double Epsilon = 1.38777878078144567553E-17; // 2^(-56);
		public const double PI2 = Math.PI / 2;
	}
}
