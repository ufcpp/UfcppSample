include System::Linq

if hand == nil ||  hand.Length == 0 then
	return nil
end

count = table.Length

if count == 0 then
	count = 1
end

if hand.Length < count then
	return nil
end

50.times do
	x = []
	hand.each do |v| x.push v end
	#x = hand
	x.sort_by { rand }
	x = x[0..count]

	if Daifugou::Game::CanPlay(x, table, rank, suit, mode, revolution) then
		return x
	end
end
