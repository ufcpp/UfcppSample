﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CardGame
{
    /// <summary>
    /// カードの山。
    /// 順序を保つ。
    /// </summary>
    public class Pile : List<Card>
    {
        public Pile()
        {
        }

        public Pile(IEnumerable<Card> cards)
            : base(cards)
        {
        }

        public Pile(long bitArray)
            : this(Card.Deserialize(bitArray))
        {
        }

        public long Serialize()
        {
            return Card.Serialize(this);
        }
    }
}
