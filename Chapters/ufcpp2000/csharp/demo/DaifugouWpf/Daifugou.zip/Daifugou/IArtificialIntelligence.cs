﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Daifugou
{
    using CardGame;

    /// <summary>
    /// 大富豪AIインターフェース。
    /// </summary>
    public interface IArtificialIntelligence
    {
        /// <summary>
        /// 出すカードを決定する。
        /// </summary>
        /// <param name="hand">自分の手札。</param>
        /// <param name="table">場に出ているカード。</param>
        /// <param name="rank">場に出ているカードの（最高）ランク。</param>
        /// <param name="suit">場に出ているカードのスイート。</param>
        /// <param name="mode">ゲームモード</param>
        /// <param name="revolution">trueなら革命状態。</param>
        /// <param name="history">過去1ターンの履歴。</param>
        /// <returns>自分が出すカード。パスする場合はnull。</returns>
        IEnumerable<Card> Play(IEnumerable<Card> hand, IEnumerable<Card> table, int rank, Suit suit, Mode mode, bool revolution, History history);
    }
}
