﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Daifugou
{
    using CardGame;

    /// <summary>
    /// プレイヤーの状態のうち、他のプレイヤーからも見える情報。
    /// </summary>
    public class VisibleInfo
    {
        /// <summary>
        /// プレイヤーの手札の残り枚数。
        /// </summary>
        public int Count { set; get; }

        /// <summary>
        /// プレイヤーが前回出したカード。
        /// </summary>
        public IEnumerable<Card> Previous { set; get; }
    }

    /// <summary>
    /// ターン1周分の履歴。
    /// </summary>
    public class History : List<VisibleInfo>
    {
    }
}
