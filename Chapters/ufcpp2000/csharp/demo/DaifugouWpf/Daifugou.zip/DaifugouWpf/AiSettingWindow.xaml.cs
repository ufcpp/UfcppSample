﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DaifugouWpf
{
    /// <summary>
    /// AiSettingWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class AiSettingWindow : Window
    {
        public AiSettingWindow(int numIndex)
        {
            InitializeComponent();

            this.comboIndex.ItemsSource = Enumerable.Range(0, numIndex);
            this.comboIndex.SelectedIndex = 0;

            this.buttonOk.Click += new RoutedEventHandler(buttonOk_Click);
            this.buttonCancel.Click += new RoutedEventHandler(buttonCancel_Click);
            this.buttonRef.Click += new RoutedEventHandler(buttonRef_Click);
        }

        void buttonRef_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.Filter = "All Files (*.*)|*.py;*.rb;*.cs;*.ps1|Python Files(*.py)|*.py|Ruby Files(*.rb)|*.rb|C# Files(*.cs)|*.cs|PowerShell Script Files(*.ps1)|*.ps1";
            //dlg.Filter = "All Files (*.*)|*.py;*.rb;*.cs|Python Files(*.py)|*.py|Ruby Files(*.rb)|*.rb|C# Files(*.cs)|*.cs";

            if (dlg.ShowDialog(this) ?? false)
            {
                this.textPath.Text = dlg.FileName;
            }
        }

        string path = string.Empty;

        public string Path
        {
            get { return this.path; }
        }

        int index = 0;

        public int SelectedIndex
        {
            get { return this.index; }
        }

        void buttonOk_Click(object sender, RoutedEventArgs e)
        {
            this.index = this.comboIndex.SelectedIndex;
            this.path = this.textPath.Text;
            this.DialogResult = true;
            this.Close();
        }

        void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
