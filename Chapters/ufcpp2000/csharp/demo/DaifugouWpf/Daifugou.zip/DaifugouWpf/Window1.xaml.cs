﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DaifugouWpf
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            CommandBinding cb;
            
            cb = new CommandBinding { Command = ApplicationCommands.Open };
            cb.Executed += (s, e) => { this.SetAi(); e.Handled = true; };
            cb.CanExecute += (s, e) => { e.CanExecute = true; e.Handled = true; };
            this.CommandBindings.Add(cb);
        }

        void SetDrlAi(string filename, int index)
        {
            try
            {
                var ai = new ScripAi();
                ai.Init(filename);

                this.daifugou.AI[index] = ai;
            }
            catch (ArgumentException)
            {
                this.status.Content = "ファイル名が不正です";
            }
        }

        void SetPsAi(string filename, int index)
        {
            try
            {
                var ai = new PowerShellAi();
                ai.Init(filename);

                this.daifugou.AI[index] = ai;
            }
            catch (ArgumentException)
            {
                this.status.Content = "ファイル名が不正です";
            }
        }

        void SetCodeDomAi(string filename, int index)
        {
            try
            {
                var ai = CodeDom.Load(filename);
                this.daifugou.AI[index] = ai;
            }
            catch (CodeDomException exc)
            {
                this.status.Content = "コンパイルエラー";

                foreach (var error in exc.Errors)
                {
                    //debug
                    int x = 0;
                    ++x;
                }
            }
            catch (Exception)
            {
                this.status.Content = "何かエラー";
            }
        }

        void SetAi()
        {
            AiSettingWindow setting = new AiSettingWindow(this.daifugou.AI.Length);

            if (setting.ShowDialog() ?? false)
            {
                string filename = setting.Path;

                if (string.IsNullOrEmpty(filename))
                {
                    this.status.Content = "ファイル名を入力してください";
                }

                int index = setting.SelectedIndex;

                var ext = System.IO.Path.GetExtension(filename).Replace(".", "").ToLower();

                switch (ext)
                {
                    case "py":
                    case "rb":
                        this.SetDrlAi(filename, index);
                        break;

                    case "cs":
                        this.SetCodeDomAi(filename, index);
                        break;

                    case "ps1":
                        this.SetPsAi(filename, index);
                        break;
                }

            }
        }
    }
}
