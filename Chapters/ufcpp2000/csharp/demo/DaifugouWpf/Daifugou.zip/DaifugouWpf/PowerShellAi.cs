﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Management.Automation;
using CardGame;
using Daifugou;

namespace DaifugouWpf
{
    class PowerShellAi : IArtificialIntelligence
    {
        string source;

        public void Init(string filename)
        {
            string head =
    "[void][System.Reflection.Assembly]::LoadFrom('" + typeof(Game).Assembly.Location + "')" + @"

$count = 0
foreach($a in $input) {
  switch ($count) {
    0 { $hand = $a }
    1 { $table = $a }
    2 { $rank = $a }
    3 { $suit = $a }
    4 { $mode = $a }
    5 { $revolution = $a }
    6 { $history = $a }
  }
  $count++
}

";
            this.source = head + File.ReadAllText(filename);
        }

        #region IArtificialIntelligence メンバ

        public IEnumerable<Card> Play(IEnumerable<Card> hand, IEnumerable<Card> table, int rank, Suit suit, Mode mode, bool revolution, History history)
        {

            using (var invoker = new RunspaceInvoke())
            {
                var result = invoker.Invoke(this.source, new object[] { hand.ToArray(), table.ToArray(), rank, suit, mode, revolution, history });

                return result.Where(x => x != null).Select(x => (Card)x.BaseObject).ToArray();
            }
        }

        #endregion
    }
}
