﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AsyncCommand
{
    /// <summary>
    /// 非同期操作の開始コマンド/停止コマンドの対。
    /// </summary>
    public interface IAsyncCommandPair
    {
        ICommand StartCommand { get; }
        ICommand CancelCommand { get; }
    }

    /// <summary>
    /// 前処理 → CanExecute 変更 → 非同期処理 → CanExecute 変更 → 後処理。
    /// 進捗報告付き。
    /// </summary>
    public class AsyncCommandPair<TCommandParameter, TProgressValue> : NotificationObject, IAsyncCommandPair
    {
        Action _preAction;
        Action _postAction;
        Func<TCommandParameter, IProgress<TProgressValue>, CancellationToken, Task> _asyncAction;
        Func<TCommandParameter, bool> _canAction;
        IProgress<TProgressValue> _progress;

        /// <summary>
        /// 前処理 → CanExecute 変更 → 非同期処理 → CanExecute 変更 → 後処理。
        /// </summary>
        /// <param name="preAction">await 開始前に呼ばれるアクション。</param>
        /// <param name="asyncAction">await する非同期処理アクション。</param>
        /// <param name="postAction">await 完了後に呼ばれるアクション。</param>
        /// <param name="canAction">処理可能かどうかの判定アクション。</param>
        /// <param name="progressAction">進捗報告を受け取るアクション。</param>
        public AsyncCommandPair(
            Action preAction,
            Func<TCommandParameter, IProgress<TProgressValue>, CancellationToken, Task> asyncAction,
            Action postAction,
            Func<TCommandParameter, bool> canAction,
            Action<TProgressValue> progressAction)
        {
            _preAction = preAction;
            _asyncAction = asyncAction;
            _postAction = postAction;
            _canAction = canAction;

            var ep = new EventProgress<TProgressValue>();
            ep.ProgressChanged += (sender, e) => progressAction(e.Value);
            _progress = ep;

            _StartCommand = new DelegateCommand<TCommandParameter>(Start, CanStart);
            _CancelCommand = new DelegateCommand(CancelExcute, CanCancel);
        }

        CancellationTokenSource _cancel = null;

        /// <summary>
        /// CanExecute 変更通知。
        /// </summary>
        public void RaiseCanExecuteChanged()
        {
            _StartCommand.RaiseCanExecuteChanged();
        }

        #region StartCommand

        private async void Start(TCommandParameter parameter)
        {
            _preAction();

            _cancel = new CancellationTokenSource();
            _StartCommand.RaiseCanExecuteChanged();
            _CancelCommand.RaiseCanExecuteChanged();

            await _asyncAction(parameter, _progress, _cancel.Token);

            _cancel = null;
            _StartCommand.RaiseCanExecuteChanged();
            _CancelCommand.RaiseCanExecuteChanged();

            _postAction();
        }

        private bool CanStart(TCommandParameter parameter)
        {
            return _cancel == null && _canAction(parameter);
        }

        /// <summary>
        /// 非同期処理開始コマンド。
        /// </summary>
        public ICommand StartCommand
        {
            get
            {
                return _StartCommand;
            }
        }
        private DelegateCommandBase _StartCommand;

        #endregion
        #region CancelCommand

        private void CancelExcute()
        {
            if (_cancel != null)
                _cancel.Cancel(false);
        }

        private bool CanCancel()
        {
            return _cancel != null;
        }

        /// <summary>
        /// 非同期処理キャンセル コマンド。
        /// </summary>
        public ICommand CancelCommand
        {
            get
            {
                return _CancelCommand;
            }
        }
        private DelegateCommandBase _CancelCommand;

        #endregion
    }
}
