﻿using System;
using System.Windows.Input;

namespace AsyncCommand
{
    public abstract class DelegateCommandBase : ICommand
    {
        #region ICommand Members

        public abstract void Execute(object parameter);
        public abstract bool CanExecute(object parameter);

        public event EventHandler CanExecuteChanged;

        #endregion

        public void RaiseCanExecuteChanged()
        {
            var d = CanExecuteChanged;
            if (d != null)
                d(this, null);
        }
    }
}
