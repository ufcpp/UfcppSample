﻿using System.ComponentModel;

namespace AsyncCommand
{
    /// <summary>
    /// サンプルなんで、あまり（非標準）ライブラリへの依存したくないので、Prism にあるクラスを簡易的に再実装。
    /// </summary>
    public class NotificationObject : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        public void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
