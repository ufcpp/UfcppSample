﻿using System;

namespace AsyncCommand
{
    /// <summary>
    /// サンプルなんで、あまり（非標準）ライブラリへの依存したくないので、Prism にあるクラスを簡易的に再実装。
    /// </summary>
    public class DelegateCommand<T> : DelegateCommandBase
    {
        private Action<T> _execute;
        Func<T, bool> _canExecute;

        public DelegateCommand(Action<T> execute)
            : this(execute, x => true)
        {
        }

        public DelegateCommand(Action<T> execute, Func<T, bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public override void Execute(object parameter)
        {
            _execute((T)parameter);
        }

        public override bool CanExecute(object parameter)
        {
            if (parameter is T)
            {
                return _canExecute((T)parameter);
            }
            return true;
        }
    }

    /// <summary>
    /// サンプルなんで、あまり（非標準）ライブラリへの依存したくないので、Prism にあるクラスを簡易的に再実装。
    /// </summary>
    public class DelegateCommand : DelegateCommandBase
    {
        private Action _execute;
        Func<bool> _canExecute;

        public DelegateCommand(Action execute)
            : this(execute, () => true)
        {
        }

        public DelegateCommand(Action execute, Func<bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public override void Execute(object parameter)
        {
            _execute();
        }

        public override bool CanExecute(object parameter)
        {
            return _canExecute();
        }
    }
}
