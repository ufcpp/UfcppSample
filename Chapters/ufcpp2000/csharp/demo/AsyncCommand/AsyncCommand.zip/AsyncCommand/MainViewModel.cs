﻿using System.Threading.Tasks;

namespace AsyncCommand
{
    public class MainViewModel : NotificationObject
    {
        #region Run

        /// <remarks>
        /// public にしておかないと、Silverlight で Binding できないみたい。
        /// Run 自体を interface 介してやってるんで、ProgressValue が private のままでも良さそうなものなのに。
        /// </remarks>
        public class ProgressValue
        {
            public int Percentage { get; set; }
            public string Value { get; set; }
        }

        AsyncCommandPair<double, ProgressValue> _run;

        public IAsyncCommandPair Run
        {
            get
            {
                if (_run == null)
                {
                    _run = new AsyncCommandPair<double, ProgressValue>(
                        () =>
                        {
                            CurrentValue = "開始";
                        },
                        async (x, progress, cancel) =>
                        {
                            //todo: 本来はこの辺りでモデルのコードを呼び出す。
                            // 今回はデモということで、1秒おきに値を更新するだけ。

                            for (int i = 1; i <= 10; i++)
                            {
                                await TaskEx.Delay(1000);
                                progress.Report(new ProgressValue
                                {
                                    Percentage = i * 10,
                                    Value = (x * i).ToString(),
                                });

                                if (cancel.IsCancellationRequested) return;
                            }
                        },
                        async () =>
                        {
                            // 1秒後にプログレスバーとかの状態をリセット。
                            CurrentValue = "完了";
                            await TaskEx.Delay(1000);
                            CurrentValue = string.Empty;
                            ProgressPercentage = 0;
                        },
                        x => true,
                        x =>
                        {
                            ProgressPercentage = x.Percentage;
                            CurrentValue = x.Value;
                        }
                        );
                }

                return _run;
            }
        }
        #endregion
        #region CurrentValue

        public string CurrentValue
        {
            get { return _CurrentValue; }
            set
            {
                _CurrentValue = value;
                RaisePropertyChanged("CurrentValue");
            }
        }

        private string _CurrentValue;

        #endregion
        #region ProgressPercentage

        public int ProgressPercentage
        {
            get { return _ProgressPercentage; }
            set
            {
                _ProgressPercentage = value;
                RaisePropertyChanged("ProgressPercentage");
            }
        }

        private int _ProgressPercentage;

        #endregion
    }
}
