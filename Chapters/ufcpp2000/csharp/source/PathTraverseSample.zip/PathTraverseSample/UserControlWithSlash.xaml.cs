﻿using System.Windows.Controls;

namespace PathTraverseSample
{
    public partial class UserControlWithSlash : UserControl
    {
        public UserControlWithSlash()
        {
            InitializeComponent();
        }
    }
}
