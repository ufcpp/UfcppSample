﻿using System.Windows.Controls;

namespace PathTraverseSample
{
    public partial class UserControlWithSlashAndDataType : UserControl
    {
        public UserControlWithSlashAndDataType()
        {
            InitializeComponent();
        }
    }
}
