﻿using System.Collections.Generic;

namespace PathTraverseSample
{
    public class SampleData
    {
        public string Name { get; set; }
        public int X { get; set; }

        /// <summary>
        /// Y は、SampleData にだけ持つ。
        /// X と Name は SampleList に同名のプロパティを作ってしまう。
        /// </summary>
        public int Y { get; set; }
    }

    /// <summary>
    /// こんなことわざわざする人がいるかどうかわからないけども、
    /// 要素の方と同じプロパティを持つ謎のコレクションを作成。
    /// 
    /// データ テンプレートの自動適用で多分、泣く。
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class SampleList<T> : List<T>
    {
        public string Name { get; set; }
        public int X { get; set; }
    }
}
