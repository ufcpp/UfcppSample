﻿using System.Windows.Controls;

namespace PathTraverseSample
{
    public partial class UserControlWithoutSlashNorDataType : UserControl
    {
        public UserControlWithoutSlashNorDataType()
        {
            InitializeComponent();
        }
    }
}
