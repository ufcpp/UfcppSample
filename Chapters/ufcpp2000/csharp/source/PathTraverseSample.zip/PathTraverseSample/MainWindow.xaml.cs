﻿using System.Windows;

namespace PathTraverseSample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var x = new SampleData { Name = "X", X = 1, Y = -1 };
            var y = new SampleData { Name = "Y", X = 2, Y = -2 };

            var Data1 = new[] { x, y };
            var Data2 = new SampleList<SampleData> { x, y };
            Data2.Name = "list";
            Data2.X = 999;

            // Data1 と Data2 の差はコレクションの型だけ。
            // 中身一緒。
            this.DataContext = new { Data1, Data2 };
        }
    }
}
