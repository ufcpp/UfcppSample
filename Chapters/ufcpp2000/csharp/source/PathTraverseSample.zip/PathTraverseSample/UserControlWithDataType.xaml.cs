﻿using System.Windows.Controls;

namespace PathTraverseSample
{
    public partial class UserControlWithDataType : UserControl
    {
        public UserControlWithDataType()
        {
            InitializeComponent();
        }
    }
}
