﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Input;

namespace SlidePresentation
{
    /// <summary>
    /// PowerPoint 的なスライド表示を行うパネル。
    /// </summary>
    /// <remarks>
    /// サブクラスで MeasureOverride と ArrangeOverride をオーバーライドして使う。
    /// </remarks>
    public abstract class SlidePresentationControl : Panel
    {
        public SlidePresentationControl()
        {
            this.Loaded += new RoutedEventHandler(FullScreenSlidePresentationControl_Loaded);
            this.MouseDown += new MouseButtonEventHandler(FullScreenSlidePresentationControl_MouseDown);
        }

        // マウスボタンでスライド切り替え
        void FullScreenSlidePresentationControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            switch (e.ChangedButton)
            {
                case MouseButton.Left:
                case MouseButton.XButton2:
                    this.GoNextPage();
                    break;
                case MouseButton.XButton1:
                    this.GoPreviousPage();
                    break;
            }
        }

        // コンテキストメニューにページ一覧を表示＆クリックでページジャンプ
        void FullScreenSlidePresentationControl_Loaded(object sender, RoutedEventArgs e)
        {
            var contextMenu = new ContextMenu();

            for (int i = 0; i < this.Children.Count; i++)
			{
                var menuItem = new MenuItem
                {
                    Header = string.Format("page {0}", i + 1),
                    Tag = i,
                };
                menuItem.Click += new RoutedEventHandler(menuItem_Click);

                contextMenu.Items.Add(menuItem);
			}

            this.ContextMenu = contextMenu;
        }

        void menuItem_Click(object sender, RoutedEventArgs e)
        {
            var control = sender as Control;
            if (control == null)
                return;
            this.SelectedIndex = (int)control.Tag;
            this.InvalidateArrange();
        }

        /// <summary>
        /// Panel って KeyDown イベントとれないっぽい？
        /// 調べるの面倒だし、上からこのメソッドを呼んでもらうことに。
        /// 
        /// 矢印キー、page down / page up でページ切り替え。
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool OnKeyDown(Key key)
        {
            switch (key)
            {
                case Key.Right:
                case Key.Down:
                case Key.PageDown:
                    this.GoNextPage();
                    return true;
                case Key.Left:
                case Key.Up:
                case Key.PageUp:
                    this.GoPreviousPage();
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 現在選択されているページのインデックス。
        /// </summary>
        public static DependencyProperty SelectedIndexProperty =
            DependencyProperty.Register("SelectedIndex", typeof(int), typeof(FullScreenSlidePresentationControl));

        /// <summary>
        /// 現在選択されているページのインデックス。
        /// SelectedIndexProperty 依存プロパティのラッパー。
        /// </summary>
        public int SelectedIndex
        {
            get
            {
                return (int)this.GetValue(SelectedIndexProperty);
            }
            set
            {
                this.SetValue(SelectedIndexProperty, value);
            }
        }

        /// <summary>
        /// 次のページに移動。
        /// </summary>
        public void GoNextPage()
        {
            var i = this.SelectedIndex + 1;
			if (this.Children.Count <= i)
				//i = 0;
				i = this.Children.Count - 1;
            this.SelectedIndex = i;
            this.InvalidateArrange();
        }

        /// <summary>
        /// 前のページに移動。
        /// </summary>
        public void GoPreviousPage()
        {
            var i = this.SelectedIndex - 1;
			if (i < 0)
				//i = this.Children.Count - 1;
				i = 0;
            this.SelectedIndex = i;
            this.InvalidateArrange();
        }
    }
}
