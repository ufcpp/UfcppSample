﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SlidePresentation
{
    public class AutoScaleControl : ContentControl
    {
        #region フィールド

        ScaleTransform scale = new ScaleTransform(1, 1)
        {
            CenterX = 0,
            CenterY = 0,
        };

        FrameworkElement innerElement = null;
        double initialWidth;
        double initialHeight;

        #endregion
        #region 初期化

        public AutoScaleControl()
        {
            this.Loaded += new RoutedEventHandler(AutoScaleControl_Loaded);
            this.SizeChanged += new SizeChangedEventHandler(AutoScaleControl_SizeChanged);
        }

        #endregion
        #region コンテントの更新

        /// <summary>
        /// 中身をセット。
        /// セット時の ActualWidth, ActualHeight を基準にして今後の拡大・縮小を行う。
        /// </summary>
        /// <param name="elem">中身</param>
        public void SetContent(FrameworkElement elem)
        {
            this.Content = elem;

            this.innerElement = elem;
            this.initialWidth = elem.ActualWidth;
            this.initialHeight = elem.ActualHeight;

            // 依存プロパティ拾って initialWidth 設定できるようにした方がいい？

            this.Rescale();
        }

        #endregion
        #region イベントハンドラー

        void AutoScaleControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            FrameworkElement elem = this.Content as FrameworkElement;

            if (elem == null)
                return;

            this.SetContent(elem);
        }

        void AutoScaleControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.Rescale();
        }

        /// <summary>
        /// コンテントのリサイズ
        /// </summary>
        void Rescale()
        {
            if (this.innerElement == null)
                return;

            var scaleX = this.ActualWidth / this.initialWidth;
            var scaleY = this.ActualHeight / this.initialHeight;

            // アスペクト比は保つ
            if (scaleX >= scaleY)
            {
                this.scale.ScaleX = scaleY;
                this.scale.ScaleY = scaleY;
            }
            else
            {
                this.scale.ScaleX = scaleX;
                this.scale.ScaleY = scaleX;
            }
            this.scale.CenterX = scaleX / 2;
            this.scale.CenterY = scaleY / 2;

            this.innerElement.LayoutTransform = this.scale;
        }

        #endregion
    }
}
