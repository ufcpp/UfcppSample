﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SlidePresentation
{
    /// <summary>
    /// PowerPoint 的なスライド表示を行うパネル。
    /// フルスクリーン時みたいに、選択中の項目のみをPanel 目一杯のサイズで表示。
    /// </summary>
    public class FullScreenSlidePresentationControl : SlidePresentationControl
    {
        #region override

        protected override Size MeasureOverride(Size constraint)
        {
            for (int i = 0; i < this.InternalChildren.Count; i++)
            {
                FrameworkElement elem = this.InternalChildren[i] as FrameworkElement;
                if (elem == null)
                    continue;

                if (i == this.SelectedIndex)
                {
                    elem.Measure(constraint);
                }
                else
                {
                    elem.Measure(new Size(0, 0));
                }
            }

            return constraint;
        }

        protected override Size ArrangeOverride(Size arrangeBounds)
        {
            for (int i = 0; i < this.InternalChildren.Count; i++)
            {
                FrameworkElement elem = this.InternalChildren[i] as FrameworkElement;
                if (elem == null)
                    continue;

                if (i == this.SelectedIndex)
                {
                    elem.Arrange(new Rect(new Point(0, 0), arrangeBounds));
                }
                else
                {
                    elem.Arrange(new Rect(0, 0, 0, 0));
                }
            }

            return arrangeBounds;
        }

        #endregion
    }
}
