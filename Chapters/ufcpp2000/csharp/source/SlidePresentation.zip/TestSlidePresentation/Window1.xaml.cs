﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestSlidePresentation
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            this.PreviewKeyDown += new KeyEventHandler(Window1_PreviewKeyDown);
        }

        void Window1_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F5:
                    this.ChangeStateToMaximize();
                    break;
                case Key.Escape:
                    this.ChangeStateToNormal();
                    break;
            }

            if (this.test.OnKeyDown(e.Key))
            {
                //handled true?
                return;
            }
        }

        enum State
        {
            Normal,
            Maximize,
        }

        State currentState;

        void ChangeStateToMaximize()
        {
            this.WindowState = WindowState.Maximized;
            this.WindowStyle = WindowStyle.None;
            this.currentState = State.Maximize;
        }

        void ChangeStateToNormal()
        {
            this.WindowState = WindowState.Normal;
            this.WindowStyle = WindowStyle.SingleBorderWindow;
            this.currentState = State.Normal;
        }

        void ChangeState()
        {
            if (this.currentState == State.Normal)
                this.ChangeStateToMaximize();
            else
                this.ChangeStateToNormal();
        }
    }
}
