﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestSlidePresentation.Slides
{
    /// <summary>
    /// DataTemplate.xaml の相互作用ロジック
    /// </summary>
    public partial class DataTemplate : Page
    {
        public DataTemplate()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(DataTemplate_Loaded);
        }

        void DataTemplate_Loaded(object sender, RoutedEventArgs e)
        {
            var sampleData = new[]
            {
                new { Name = "マゼラン"  , 腕力 = 18, 器用 = 14, 素早 = 20, 体力 = 17, 魔力 = 13 },
                new { Name = "ハンニバル", 腕力 = 25, 器用 = 12, 素早 = 11, 体力 = 18, 魔力 = 11 },
                new { Name = "スカイア"  , 腕力 = 10, 器用 = 19, 素早 = 21, 体力 = 10, 魔力 = 24 },
                new { Name = "キャット"  , 腕力 = 13, 器用 = 18, 素早 = 22, 体力 = 12, 魔力 = 13 },
                new { Name = "ソウジ"    , 腕力 = 22, 器用 = 12, 素早 = 24, 体力 = 11, 魔力 = 14 },
                new { Name = "コウメイ"  , 腕力 = 10, 器用 = 10, 素早 = 25, 体力 = 10, 魔力 = 25 },
            };

            this.list.ItemsSource = sampleData;
        }
    }
}
