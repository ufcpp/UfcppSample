﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestSlidePresentation.Slides
{
	using Exp = System.Linq.Expressions.Expression;
	using LinqTreeView;

	/// <summary>
	/// TypeBinding.xaml の相互作用ロジック
	/// </summary>
	public partial class TypeTemplate : Page
	{
		public TypeTemplate()
		{
			InitializeComponent();

			this.Loaded += new RoutedEventHandler(TypeTemplate_Loaded);
			this.combo.SelectionChanged += new SelectionChangedEventHandler(combo_SelectionChanged);
		}

		void TypeTemplate_Loaded(object sender, RoutedEventArgs e)
		{
			this.combo.ItemsSource = sampleExpressions.Select(x =>
				new Label
				{
					Content = x.Text,
					ToolTip = x.Description,
				});
			this.combo.SelectedIndex = 0;
			this.ShowSelectedItem();
		}

		void combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			this.ShowSelectedItem();
		}

		private void ShowSelectedItem()
		{
			this.item.Content = sampleExpressions[this.combo.SelectedIndex].Expression;
			//this.status.ItemsSource = new[] { sampleExpressions[this.combo.SelectedIndex].Description };
		}

        #region サンプルデータを準備

        struct Tuple
        {
            public Exp Expression;
            public string Text;
            public string Description;

            public Tuple(Exp exp, string txt, string desc)
            {
                this.Expression = exp;
                this.Text = txt;
                this.Description = desc;
            }
        }

        private static Tuple[] sampleExpressions;

        static TypeTemplate()
        {
			sampleExpressions = new[]
            {
                new Tuple(
                    Make.Expression((int x) => 10 * x * -x),
                    "(int x) => 10 * x * -x",
                    "算術演算のサンプルです。"
                    ),
                new Tuple(
                    Make.Expression((int x) => x > 0 ? 1 : -1),
                    "(int x) => x > 0 ? 1 : -1",
                    "条件演算のサンプルです。"
                    ),
                new Tuple(
                    Make.Expression((Color c) => c.R),
                    "(Color c) => c.R",
                    "プロパティアクセスのサンプルです。"
                    ),
                new Tuple(
                    Make.Expression((Color c) => new SolidColorBrush(c)),
                    "(Color c) => new SolidColorBrush(c)",
                    "引数付きコンストラクタのサンプルです。"
                    ),
                new Tuple(
                    Make.Expression((byte x, byte y, byte z) => new Color { R = x, G = y, B = z }),
                    "(byte x, byte y, byte z) => new Color { R = x, G = y, B = z }",
                    "メンバ初期化付きのコンストラクタのサンプルです。"
                    ),
                new Tuple(
                    Make.Expression(() => new int[] { 1, 2, 3 }),
                    "() => new int[] { 1, 2, 3 }",
                    "配列生成のサンプルです。"
                    ),
                new Tuple(
				    Make.Expression(() => new List<int> { 1, 2, 3 }),
                    "() => new List<int> { 1, 2, 3 }",
                    "リスト初期化のサンプルです。"
                    ),
                new Tuple(
				    Make.Expression(() => new Polyline { ContextMenu = { Width = 10, Height = 10 } }),
                    "() => new Polyline { ContextMenu = { Width = 10, Height = 10 } }",
                    "再帰的なメンバ初期化付きのコンストラクタのサンプルです。"
                    ),
                new Tuple(
				    Make.Expression(() => new Polyline { Points = { new Point(1, 2), new Point(3, 4) } }),
                    "() => new Polyline { Points = { new Point(1, 2), new Point(3, 4) } }",
                    "再帰的なリストメンバ初期化付きのコンストラクタのサンプルです。"
                    ),
                new Tuple(
                    Make.Expression((double x) => Math.Sin(x)),
                    "(double x) => Math.Sin(x)",
                    "メソッド呼び出しのサンプルです。"
                    ),
                new Tuple(
				    Make.Expression((Func<int, int> f, int x) => f(x)),
                    "(Func<int, int> f, int x) => f(x)",
                    "デリゲート呼び出しのサンプルです。"
                    ),
                new Tuple(
				    Make.Expression((IEnumerable<int> l) => from x in l where x > 10 select x * x),
                    "(IEnumerable<int> l) => from x in l where x > 10 select x * x",
                    "クエリ式のサンプルです。"
                    ),
            };
        }

        #endregion
	}
}
