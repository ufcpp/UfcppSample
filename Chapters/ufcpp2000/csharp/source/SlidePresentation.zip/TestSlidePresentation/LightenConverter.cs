﻿using System.Windows.Media;
using System.Windows.Data;

namespace TestSlidePresentation
{
    static class Brighteness
    {
        /// <summary>
        /// 暗くする。
        /// </summary>
        /// <param name="b">元の値</param>
        /// <param name="factor">1より大きければ暗く、小さければ明るくなる</param>
        /// <returns>変換結果</returns>
        public static byte Darken(byte b, double factor)
        {
            double x = b / factor;
            if (x > 255) x = 255;
            return (byte)x;
        }

        /// <summary>
        /// 明るくする。
        /// </summary>
        /// <param name="b">元の値</param>
        /// <param name="factor">1より大きければ明るく、小さければ暗くなる</param>
        /// <returns>変換結果</returns>
        public static byte Lighten(byte b, double factor)
        {
            const int m = byte.MaxValue;

            double x = (m - b) / factor;
            if (x > 255) x = 255;
            return (byte)(m - x);
        }

        public static Color Darken(Color c, double factor)
        {
            c.R = Darken(c.R, factor);
            c.G = Darken(c.G, factor);
            c.B = Darken(c.B, factor);
            return c;
        }

        public static Color Lighten(Color c, double factor)
        {
            c.R = Lighten(c.R, factor);
            c.G = Lighten(c.G, factor);
            c.B = Lighten(c.B, factor);
            return c;
        }
    }

    /// <summary>
    /// 色を明るくする。
    /// </summary>
    [ValueConversion(typeof(Color), typeof(Color))]
    public class LightenConverter : IValueConverter
    {
        public double Factor { set; get; }

        public object Convert(object value, System.Type targetType,
          object parameter, System.Globalization.CultureInfo culture)
        {
            return Brighteness.Lighten((Color)value, this.Factor);
        }

        public object ConvertBack(object value, System.Type targetType,
          object parameter, System.Globalization.CultureInfo culture)
        {
            return Brighteness.Darken((Color)value, 1 / this.Factor);
        }
    }
}
