﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Markup;

namespace TestSlidePresentation
{
    /// <summary>
    /// list item。
    /// </summary>
    [ContentProperty("Items")]
    public class ul : ContentControl
    {
        ItemsControl panel = new ItemsControl();

        public ul()
        {
            this.Loaded += new RoutedEventHandler(li_Loaded);
        }

        void li_Loaded(object sender, RoutedEventArgs e)
        {
            //this.panel.Width = this.ActualWidth;
            //this.panel.Height = this.ActualHeight;

            foreach (var item in this.items.list)
            {
                this.panel.Items.Add(item);
            }

            this.Content = this.panel;
        }

        private li items = new li();

        public li Items
        {
            get { return items; }
            set { items = value; }
        }
    }

    [TypeConverter(typeof(StringToLiConverter))]
    [ContentProperty("Text")]
    public class li
    {
        internal List<FrameworkElement> list = new List<FrameworkElement>();

        public string Text
        {
            get
            {
                return string.Empty;
            }
            set
            {
                StringToLiConverter.Parse(value, this);
            }
        }
    }

    internal class StringToLiConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
            {
                return true;
            }

            return base.CanConvertFrom(context, sourceType);
        }

        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            return base.CanConvertTo(context, destinationType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            string str = value as string;

            if (str != null)
            {
                return Parse(str);
            }

            return base.ConvertFrom(context, culture, value);
        }

        public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
        {
            return base.ConvertTo(context, culture, value, destinationType);
        }

        static void ParseLine(string line, out string content, out int level)
        {
            var settings = new[]
                {
                    new { Start = "-----", Index = 5 },
                    new { Start = "----", Index = 4 },
                    new { Start = "---", Index = 3 },
                    new { Start = "--", Index = 2 },
                    new { Start = "-", Index = 1 },
                };

            foreach (var s in settings)
            {
                if (line.StartsWith(s.Start))
                {
                    level = s.Index - 1;
                    content = line.Substring(s.Index).TrimStart();
                    return;
                }
            }

            level = 0;
            content = line;
        }

        static internal void Parse(string text, li l)
        {
            var settings = new[]
                {
                    new { Indent = 15, Size = 12, Marker = new { Character = "・ ", Color = Colors.Maroon },  },
                    new { Indent = 25, Size = 10, Marker = new { Character = "・ ", Color = Colors.DarkSalmon },  },
                    new { Indent = 35, Size = 9, Marker = new { Character = "・ ", Color = Colors.Maroon },  },
                    new { Indent = 45, Size = 8, Marker = new { Character = "・ ", Color = Colors.DarkSalmon },  },
                    new { Indent = 55, Size = 7, Marker = new { Character = "・ ", Color = Colors.Maroon },  },
                };


            var lines = text.Split('\\', '\n', '\r');

            foreach (var line in lines)
            {
                if (line.Length == 0)
                    continue;

                string content;
                int level;
                ParseLine(line.Trim(), out content, out level);

                int indent = settings[level].Indent;
                int font = settings[level].Size;
                string markerChar = settings[level].Marker.Character;
                var fore = new SolidColorBrush(settings[level].Marker.Color);

                var marker = new ContentControl
                {
                    FontSize = font,
                    Content = markerChar,
                    Foreground = fore,
                };
                marker.SetValue(DockPanel.DockProperty, Dock.Left);

                var item = new DockPanel
                {
                    Margin = new Thickness(indent, 0, 10, 0),
                    Children =
                    {
                        marker,
                        new TextBlock { FontSize = font, Text = content, TextWrapping = TextWrapping.Wrap },
                    }
                };

                l.list.Add(item);
            }
        }

        static li Parse(string text)
        {
            var l = new li();

            Parse(text, l);

            return l;
        }
    }
}
