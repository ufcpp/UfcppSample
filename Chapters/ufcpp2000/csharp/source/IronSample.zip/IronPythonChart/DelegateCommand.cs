﻿using System;
using System.Windows.Input;

namespace IronPythonChart
{
    public class DelegateCommand : ICommand
    {
        private Action _exe;
        Func<bool> _canExe;

        public DelegateCommand(Action exe) : this(exe, null) { }

        public DelegateCommand(Action exe, Func<bool> canExe)
        {
            _exe = exe;
            _canExe = canExe ?? (() => true);
        }

        public bool CanExecute(object parameter)
        {
            return _canExe();
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            _exe();
        }
    }

    public class DelegateCommand<T> : ICommand
    {
        private Action<T> _exe;
        Func<T, bool> _canExe;

        public DelegateCommand(Action<T> exe) : this(exe, null) { }

        public DelegateCommand(Action<T> exe, Func<T, bool> canExe)
        {
            _exe = exe;
            _canExe = canExe ?? (x => true);
        }

        public bool CanExecute(object parameter)
        {
            return _canExe((T)parameter);
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            _exe((T)parameter);
        }
    }
}
