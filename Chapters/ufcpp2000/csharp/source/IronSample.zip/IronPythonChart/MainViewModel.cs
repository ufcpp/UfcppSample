﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.Scripting.Hosting;

namespace IronPythonChart
{
    public class MainViewModel : NotificationObject
    {
        public Point[] Points
        {
            get { return _points; }
            private set { _points = value; RaisePropertyChanged("Points"); }
        }
        private Point[] _points;

        public string SourceCode
        {
            get { return _code; }
            set { _code = value; RaisePropertyChanged("SourceCode"); }
        }
        private string _code;

        public double Max
        {
            get { return _max; }
            set { _max = value; RaisePropertyChanged("Max"); }
        }
        private double _max = 1;

        public double Min
        {
            get { return _min; }
            set { _min = value; RaisePropertyChanged("Min"); }
        }
        private double _min = -1;

        public double Delta
        {
            get { return _delta; }
            set { _delta = value; RaisePropertyChanged("Delta"); }
        }
        private double _delta = 0.05;

        public string Message
        {
            get { return _message; }
            set { _message = value; RaisePropertyChanged("Message"); }
        }
        private string _message;

        private int Count
        {
            get { return (int)((Max - Min) / Delta) + 1; }
        }

        private ScriptEngine _engine = IronPython.Hosting.Python.CreateEngine();

        public void Run()
        {
            try
            {
                var scope = _engine.CreateScope();
                _engine.Execute("from math import *", scope);
                var f = _engine.Execute<Func<double, double>>("lambda x:" + SourceCode, scope);

                var p =
                    from i in Enumerable.Range(0, Count)
                    let x = Delta * i + Min
                    select new Point
                    {
                        X = x,
                        Y = f(x),
                    };

                Points = p.ToArray();
            }
            catch
            {
                Message = "不正な計算をしました";
            }
        }

        public ICommand RunCommand
        {
            get
            {
                if (_run == null) _run = new DelegateCommand(Run);
                return _run;
            }
        }
        private DelegateCommand _run = null;
    }
}
