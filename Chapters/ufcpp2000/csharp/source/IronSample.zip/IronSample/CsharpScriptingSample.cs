﻿using System;

namespace CsharpScriptingSample
{
    class Program
    {
        static void Main(string[] args)
        {
            RunPython();
            RunCSharp();
        }

        private static void RunCSharp()
        {
            var engine = new Roslyn.Scripting.CSharp.ScriptEngine(
                references: new[] { "System", "System.Core" });
            var code = @"
using System.Linq;
var data = new int[] { 1, 2, 3, 4, 5 };
var q = data.Select(x => x * x);
q.Sum()
";

            var x = engine.Execute<int>(code);
            Console.WriteLine(x);

            var f = engine.Execute<Func<double, double>>(@"
using System.Math;
x => Sin(x * x)
");
            Console.WriteLine(f(10));
        }

        private static void RunPython()
        {
            var engine = IronPython.Hosting.Python.CreateEngine();
            var code = @"
data = (1, 2, 3, 4, 5)
q = (x * x for x in data)
sum(q)
";

            var x = engine.Execute<int>(code);
            Console.WriteLine(x);

            var f = engine.Execute<Func<double, double>>(@"
from math import *
lambda x: sin(x * x)
");
            Console.WriteLine(f(10));
        }
    }
}
