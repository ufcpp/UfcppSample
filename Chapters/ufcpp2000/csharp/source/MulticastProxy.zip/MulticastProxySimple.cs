﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;
using System.Reflection;

namespace Multicast.Simple
{
    /// <summary>
    /// マルチキャストデリゲートと同じ要領で、
    /// インターフェースのメソッド呼び出しをマルチキャストするためのプロキシ。
    /// </summary>
    /// <typeparam name="Interface">マルチキャストの対象</typeparam>
    public class MulticastProxy<Interface> : RealProxy
    {
        /// <summary>
        /// マルチキャストの対象となるインターフェース実装クラスのリストを渡して初期化。
        /// </summary>
        /// <param name="interfaces">実装クラスのインスタンスのリスト</param>
        public MulticastProxy(params Interface[] interfaces) : this((IEnumerable<Interface>)interfaces) { }

        public MulticastProxy(IEnumerable<Interface> interfaces)
            : base(typeof(Interface))
        {
            this.interfaces = new List<Interface>(interfaces);
        }

        /// <summary>
        /// 登録されている全インスタンスのメソッドを同時に呼び出す。
        /// </summary>
        /// <param name="msg">メソッド呼び出しに関するメッセージ</param>
        /// <returns>実行結果</returns>
        public override IMessage Invoke(IMessage msg)
        {
            IMethodMessage mm = msg as IMethodMessage;

            MethodInfo method = (MethodInfo)mm.MethodBase;
            object[] args = mm.Args;

            foreach (var i in this.interfaces)
            {
                method.Invoke(i, args);
            }

            return new ReturnMessage(null, null, 0, mm.LogicalCallContext, (IMethodCallMessage)msg);
        }

        /// <summary>
        /// インスタンスを追加。
        /// </summary>
        /// <param name="i">追加するインスタンス。</param>
        public void Add(Interface i)
        {
            this.interfaces.Add(i);
        }

        /// <summary>
        /// インスタンスを削除。
        /// </summary>
        /// <param name="i">削除するインスタンス。</param>
        public void Remove(Interface i)
        {
            this.interfaces.Remove(i);
        }

        /// <summary>
        /// マルチキャストの対象となるインターフェース実装クラスのインスタンスのリスト。
        /// </summary>
        private List<Interface> interfaces;
    }
}
