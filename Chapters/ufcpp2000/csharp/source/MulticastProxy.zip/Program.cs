﻿using System;

namespace Multicast
{
    class Program
    {
        static void Main(string[] args)
        {
            IAnimal[] animals = new IAnimal[] { new Cat(), new Dog(), new Mouse() };

            foreach (var i in animals)
            {
                i.Bark();
            }

            Delegate d = null;

            foreach (var i in animals)
            {
                Delegate di = Delegate.CreateDelegate(typeof(Action), i, "Bark");

                if (d == null) d = di;
                else d = Delegate.Combine(d, di);
            }

            d.DynamicInvoke();

            //Demo.Run();
            //Performance.Run();
        }
    }
}
