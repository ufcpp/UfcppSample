﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Proxies;
using System.Reflection;

namespace Multicast
{
    #region Action

    // CreateDelegate するためにはデリゲートの Type が必要なので、それを用意。
    // 標準の System.Action だと、型引数4つまでしかないので、16個までのを定義。

    delegate void Action();
    delegate void Action<T0>(T0 x0);
    delegate void Action<T0, T1>(T0 x0, T1 x1);
    delegate void Action<T0, T1, T2>(T0 x0, T1 x1, T2 x2);
    delegate void Action<T0, T1, T2, T3>(T0 x0, T1 x1, T2 x2, T3 x3);
    delegate void Action<T0, T1, T2, T3, T4>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4);
    delegate void Action<T0, T1, T2, T3, T4, T5>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta, Tb>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa, Tb xb);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta, Tb, Tc>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa, Tb xb, Tc xc);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta, Tb, Tc, Td>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa, Tb xb, Tc xc, Td xd);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta, Tb, Tc, Td, Te>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa, Tb xb, Tc xc, Td xd, Te xe);
    delegate void Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, Ta, Tb, Tc, Td, Te, Tf>(T0 x0, T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9, Ta xa, Tb xb, Tc xc, Td xd, Te xe, Tf xf);

    #endregion

    /// <summary>
    /// マルチキャストデリゲートと同じ要領で、
    /// インターフェースのメソッド呼び出しをマルチキャストするためのプロキシ。
    /// </summary>
    /// <typeparam name="Interface">マルチキャストの対象</typeparam>
    /// <remarks>
    /// Delegate.CreateDelegate とマルチキャストデリゲートを使って Invoke を高速化。
    /// </remarks>
    public class MulticastProxy<Interface> : RealProxy
    {
        #region フィールド

        /// <summary>
        /// 同時にメソッド呼び出しされるインスタンス一覧。
        /// </summary>
        private List<Interface> interfaces;

        /// <summary>
        /// 毎度 RTTI を読み出しに行くのは重たいので、
        /// 事前にシグネチャの合うデリゲートの型をキャッシュしておく。
        /// </summary>
        private Dictionary<MethodInfo, Type> delType = new Dictionary<MethodInfo, Type>();

        /// <summary>
        /// インスタンスごとに MethodInfo.Invoke するのも重たいので、
        /// 事前にデリゲート化してキャッシュ。
        /// </summary>
        /// <remarks>
        /// インスタンスの追加・削除のタイミングで CreateDelegate とかの重たい処理が入る。
        /// Add/Remove よりも Invoke が呼ばれる回数が圧倒的に多いという前提での最適化。
        /// </remarks>
        private Dictionary<MethodInfo, Delegate> del = new Dictionary<MethodInfo, Delegate>();

        #endregion
        #region 補助関数

        /// <summary>
        /// インターフェースで宣言しているメソッド一覧を取得。
        /// 継承しているインターフェースのものも含めて取得。
        /// </summary>
        /// <returns>メソッド一覧。</returns>
        static IEnumerable<MethodInfo> GetMethods()
        {
            return GetMethods(typeof(Interface));
        }

        /// <summary>
        /// インターフェース t で宣言しているメソッド一覧を取得。
        /// 継承しているインターフェースのものも含めて取得。
        /// </summary>
        /// <param name="t">一覧取得したいインターフェースの型情報。</param>
        /// <returns>メソッド一覧。</returns>
        static IEnumerable<MethodInfo> GetMethods(Type t)
        {
            foreach (var m in t.GetMethods())
            {
                yield return m;
            }

            foreach (var i in t.GetInterfaces())
            {
                foreach (var m in GetMethods(i))
                    yield return m;
            }
        }

        static readonly Assembly assembly = typeof(MulticastProxy<>).Assembly;

        static readonly Type[] actions = new[]
        {
            typeof(Action),
            typeof(Action<>),
            typeof(Action<,>),
            typeof(Action<,,>),
            typeof(Action<,,,>),
            typeof(Action<,,,,>),
            typeof(Action<,,,,,>),
            typeof(Action<,,,,,,>),
            typeof(Action<,,,,,,,>),
            typeof(Action<,,,,,,,,>),
            typeof(Action<,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,,,,,>),
            typeof(Action<,,,,,,,,,,,,,,,>),
        };

        /// <summary>
        /// 与えられた MethodInfo とシグネチャの一致するデリゲートの型を見つける。
        /// </summary>
        /// <param name="m">対象となる MethodInfo。</param>
        /// <returns>デリゲートの型</returns>
        static Type GetActionType(MethodInfo m)
        {
            if (m.ReturnType != typeof(void))
                throw new InvalidOperationException("戻り値のないメソッドにしか対応していません。");

            var signature = m.GetParameters().Select(x => x.ParameterType).ToArray();

            if (signature.Length == 0)
                return typeof(Action);

            if (signature.Length > actions.Length)
                throw new InvalidOperationException(string.Format("引数{0}個までのメソッドしか対応していません", actions.Length + 1));

            var action = actions[signature.Length];

            return action.MakeGenericType(signature);
        }

        #endregion
        #region 初期化

        /// <summary>
        /// 可変長引数版。
        /// </summary>
        /// <param name="interfaces">同時にメソッド呼び出ししたいインスタンス一覧。</param>
        public MulticastProxy(params Interface[] interfaces)
            : this((IEnumerable<Interface>)interfaces)
        {
        }

        /// <summary>
        /// IEnumerable 版。
        /// </summary>
        /// <param name="interfaces">同時にメソッド呼び出ししたいインスタンス一覧。</param>
        public MulticastProxy(IEnumerable<Interface> interfaces)
            : base(typeof(Interface))
        {
            System.Diagnostics.Debug.Assert(typeof(Interface).IsInterface);

            foreach (var m in GetMethods())
            {
                this.delType[m] = GetActionType(m);
            }

            this.interfaces = new List<Interface>(interfaces);
            this.UpdateDelegate();
        }

        /// <summary>
        /// 登録された全インスタンス分のメソッド呼び出しを、
        /// 事前にマルチキャストデリゲート化しておく。
        /// </summary>
        void UpdateDelegate()
        {
            foreach (var del in this.delType)
            {
                Delegate d = null;

                foreach (var i in this.interfaces)
                {
                    Delegate d0 = Delegate.CreateDelegate(del.Value, i, del.Key.Name);

                    if (d == null) d = d0;
                    else d = Delegate.Combine(d, d0);
                }

                this.del[del.Key] = d;
            }
        }

        #endregion
        #region フィールド

        /// <summary>
        /// 登録されている全インスタンスのメソッドを同時に呼び出す。
        /// </summary>
        /// <param name="msg">メソッド呼び出しに関するメッセージ</param>
        /// <returns>実行結果</returns>
        public override IMessage Invoke(IMessage msg)
        {
            IMethodMessage mm = msg as IMethodMessage;

            MethodInfo method = (MethodInfo)mm.MethodBase;
            Delegate d = this.del[method];
            d.DynamicInvoke(mm.Args);

            return new ReturnMessage(
                null, null, 0, mm.LogicalCallContext, (IMethodCallMessage)msg);
        }

        #endregion
        #region インスタンスの追加・削除

        /// <summary>
        /// インスタンスを追加。
        /// </summary>
        /// <param name="i">追加するインスタンス。</param>
        public void Add(Interface i)
        {
            this.interfaces.Add(i);
            this.UpdateDelegate();
        }

        /// <summary>
        /// インスタンスを削除。
        /// </summary>
        /// <param name="i">削除するインスタンス。</param>
        public void Remove(Interface i)
        {
            this.interfaces.Remove(i);
            this.UpdateDelegate();
        }

        #endregion
    }
}
