﻿using System;

namespace Multicast
{
    /// <summary>
    /// 動物。鳴くだけ。
    /// </summary>
    interface IAnimal
    {
        void Bark();
    }

    /// <summary>
    /// 猫はにゃーと鳴く。
    /// </summary>
    class Cat : IAnimal
    {
        public void Bark() { Console.Write("にゃー\n"); }
    }

    /// <summary>
    /// 犬はわんと鳴く。
    /// </summary>
    class Dog : IAnimal
    {
        public void Bark() { Console.Write("わん\n"); }
    }

    /// <summary>
    /// 鼠はちゅーと鳴く。
    /// </summary>
    class Mouse : IAnimal
    {
        public void Bark() { Console.Write("ちゅー\n"); }
    }

    class Demo
    {
        public static void Run()
        {
            // 猫、犬、鼠を1匹ずつ登録。
            var proxy = new MulticastProxy<IAnimal>(
                new Cat(),
                new Dog(),
                new Mouse()
                );

            IAnimal animals = (IAnimal)proxy.GetTransparentProxy();

            animals.Bark(); // ちゃんと3匹とも鳴く。
        }
    }
}
