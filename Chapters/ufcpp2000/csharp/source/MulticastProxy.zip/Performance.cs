﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Multicast
{
    class Performance
    {
        const int N = 100;
        const int LOOP = 1000;

        public static void Run()
        {
            Derived d;

            // テスト用のデータを準備。
            List<Derived> list = PrepareList();

            // マルチキャストデリゲート化する方。
            MulticastProxy<Derived> mp = new MulticastProxy<Derived>(list);
            d = (Derived)mp.GetTransparentProxy();

            var t1 = MesurePerformance(d);

            // 実装シンプルな方。
            Multicast.Simple.MulticastProxy<Derived> mp2 = new Multicast.Simple.MulticastProxy<Derived>(list);

            d = (Derived)mp2.GetTransparentProxy();

            var t2 = MesurePerformance(d);

            // 手動生成した奴。
            d = new MannuallyGenerated(list);

            var t3 = MesurePerformance(d);

            // 結果出力
            Console.Write("{0}, {1}, {2}\n", t1, t2, t3);
        }

        private static List<Derived> PrepareList()
        {
            List<Derived> list = new List<Derived>();

            for (int i = 0; i < N; i++)
            {
                list.Add(new D1());
                list.Add(new D1());
                //list.Add(new D3());
                list.Add(new D2());
                list.Add(new D1());
                list.Add(new D2());
                //list.Add(new D3());
                list.Add(new D2());
            }
            return list;
        }

        private static long MesurePerformance(Derived d)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            for (int i = 0; i < LOOP; i++)
            {
                d.A(0);
                d.A(1, 2);
                d.B();
                d.C("aaa");
                d.D(1, 2, "test");
            }

            sw.Stop();

            return sw.ElapsedMilliseconds;
        }

        #region テスト用に使うクラス

        interface Base
        {
            void A(int x);
            void A(int x, int y);
        }

        interface Derived : Base
        {
            void B();
            void C(string s);
            void D(int x, int y, string s);
        }

        class D1 : Derived
        {
            int a = 0;
            int b = 0;

            public void B() { ++a; }
            public void C(string s) { b += s.Length; }
            public void D(int x, int y, string s) { a += x; b += y; a += s.Length; b += s.GetHashCode(); }
            public void A(int x) { a += x; }
            public void A(int x, int y) { a += x; b += y; }
        }

        class D2 : Derived
        {
            int a = 0;
            int b = 0;

            public void B() { ++b; }
            public void C(string s) { a += s.Length; }
            public void D(int x, int y, string s) { b += x; a += y; b += s.Length; }
            public void A(int x) { b += x; }
            public void A(int x, int y) { b += x; a += y; }
        }

        class D3 : Derived
        {
            public void B() { Console.Write("B()\n"); }
            public void C(string s) { Console.Write("C({0})\n", s); }
            public void D(int x, int y, string s) { Console.Write("D({0}, {1}, {2})\n", x, y, s); }
            public void A(int x) { Console.Write("A({0})\n", x); }
            public void A(int x, int y) { Console.Write("A({0}, {1})\n", x, y); }
        }

        /// <summary>
        /// マルチキャストプロキシ相当のことをするクラスを手動で作ったもの。
        /// パフォーマンス比較用。
        /// </summary>
        class MannuallyGenerated : Derived
        {
            List<Derived> interfaces;

            public MannuallyGenerated(IEnumerable<Derived> interfaces)
            {
                this.interfaces = new List<Derived>(interfaces);
            }

            public void B()
            {
                foreach (var i in this.interfaces)
                {
                    i.B();
                }
            }
            public void C(string s)
            {
                foreach (var i in this.interfaces)
                {
                    i.C(s);
                }
            }

            public void D(int x, int y, string s)
            {
                foreach (var i in this.interfaces)
                {
                    i.D(x, y, s);
                }
            }

            public void A(int x)
            {
                foreach (var i in this.interfaces)
                {
                    i.A(x);
                }
            }

            public void A(int x, int y)
            {
                foreach (var i in this.interfaces)
                {
                    i.A(x, y);
                }
            }
        }

        #endregion
    }
}
