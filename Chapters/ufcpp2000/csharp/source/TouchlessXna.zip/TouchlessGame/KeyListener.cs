﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace TouchlessGame
{
    class KeyListener : GameComponent
    {
        Keys key;
        bool prevPressed;

        public event Action KeyDown;
        public event Action KeyUp;

        public KeyListener(Game game, Keys key)
            : base(game)
        {
            this.key = key;
        }

        public override void Update(GameTime gameTime)
        {
            bool pressed = Keyboard.GetState().IsKeyDown(key);

            if (pressed && !this.prevPressed)
            {
                var handler = this.KeyDown;
                if (handler != null)
                    handler();
            }
            else if (!pressed && this.prevPressed)
            {
                var handler = this.KeyUp;
                if (handler != null)
                    handler();
            }

            this.prevPressed = pressed;

            base.Update(gameTime);
        }

    }
}
