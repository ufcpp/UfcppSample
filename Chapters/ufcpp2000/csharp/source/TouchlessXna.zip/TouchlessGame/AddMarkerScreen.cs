﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TouchlessGame
{
    using Point = System.Drawing.Point;
    using Bitmap = System.Drawing.Bitmap;
    using TouchlessLib;

    class AddMarkerComponent : DrawableGameComponent
    {
        TouchlessMgr touch;
        Camera currentCamera;
        Bitmap capturedBitmap;
        Texture2D capturedImage;
        SpriteBatch spriteBatch;

        Texture2D circlePointer;

        EventHandler<MarkerEventArgs> onMarkerChanged;

        public AddMarkerComponent(Game game, TouchlessMgr touch, EventHandler<MarkerEventArgs> onMarkerChanged)
            : base(game)
        {
            this.touch = touch;
            this.onMarkerChanged = onMarkerChanged;
        }

        void currentCamera_OnImageCaptured(object sender, CameraEventArgs e)
        {
            if (this.GraphicsDevice.IsDisposed)
                return;

            if (this.onCapture)
                return;

            var bmp = e.Image;
            var stream = new System.IO.MemoryStream();
            bmp.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            stream.Position = 0;
            this.capturedImage = Texture2D.FromFile(this.GraphicsDevice, stream);
            this.capturedBitmap = bmp;
        }

        protected override void LoadContent()
        {
            this.currentCamera = this.touch.CurrentCamera;
            this.currentCamera.OnImageCaptured += currentCamera_OnImageCaptured;

            this.spriteBatch = new SpriteBatch(GraphicsDevice);

            this.circlePointer = this.Game.Content.Load<Texture2D>("circle");
        }

        protected override void UnloadContent()
        {
            this.currentCamera.OnImageCaptured -= currentCamera_OnImageCaptured;
        }

        bool prevMousePressed = false;
        bool onCapture = false;
        Vector2 center;
        float radius = 0;

        public override void Update(GameTime gameTime)
        {
            var mouse = Mouse.GetState();
            bool nowPressed = mouse.LeftButton == ButtonState.Pressed;

            if (nowPressed && !this.prevMousePressed)
            {
                // on mouse down
                this.onCapture = true;
                center.X = mouse.X;
                center.Y = mouse.Y;
            }
            else if(!nowPressed && this.prevMousePressed)
            {
                // on mouse up
                this.onCapture = false;

                var x = this.center.X;
                var y = this.center.Y;
                var r = this.radius;

                Point p = new Point((int)x, (int)y);
                var m = this.touch.AddMarker("marker", this.capturedBitmap, p, r);
                m.Highlight = true;
                m.OnChange += this.onMarkerChanged;
            }

            this.prevMousePressed = nowPressed;

            base.Update(gameTime);
        }

        public override void Draw(Microsoft.Xna.Framework.GameTime gameTime)
        {
            var sprite = this.spriteBatch;
            sprite.Begin();

            if (this.capturedImage != null)
            {
                var w = this.Game.Window.ClientBounds.Width;
                var h = this.Game.Window.ClientBounds.Height;
                Rectangle r = new Rectangle(0, 0, w, h);
                sprite.Draw(this.capturedImage, new Vector2(0, 0), Color.White);
            }

            if (this.onCapture)
            {
                var mouse = Mouse.GetState();
                Vector2 p = new Vector2(mouse.X, mouse.Y);
                float d = Vector2.Distance(p, this.center);

                var w1 = this.Game.Window.ClientBounds.Width;
                var h1 = this.Game.Window.ClientBounds.Height;
                var w2 = this.capturedImage.Width;
                var h2 = this.capturedImage.Height;

                var x = this.center.X / w1 * w2;
                var y = this.center.Y / h1 * h2;

                this.radius = d / w1 * w2;
                Rectangle r = new Rectangle((int)(x - d), (int)(y - d), (int)(x + d), (int)(y + d));

                p = this.center;

                var w = this.circlePointer.Width / 2;
                sprite.Draw(this.circlePointer, p, null, Color.White, 0, new Vector2(w, w), d / w, SpriteEffects.None, 0);
            }

            sprite.End();

            base.Draw(gameTime);
        }
    }
}
