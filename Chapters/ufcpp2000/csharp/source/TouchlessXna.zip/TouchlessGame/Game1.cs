using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace TouchlessGame
{
    using TouchlessLib;

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        TouchlessMgr touch = new TouchlessMgr();

        AddMarkerComponent addMarkerComponent;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            var kl = new KeyListener(this, Keys.Space);
            kl.KeyDown += new Action(kl_KeyDown);
            this.Components.Add(kl);

            // Create the screen manager component.
            //screenManager = new ScreenManager(this);
            //Components.Add(screenManager);

            foreach (Camera c in this.touch.Cameras)
            {
                if (c != null)
                {
                    this.touch.CurrentCamera = c;
                }
            }
            this.addMarkerComponent = new AddMarkerComponent(this, this.touch, this.OnMarkerChanged);

            this.IsMouseVisible = true;
        }

        void kl_KeyDown()
        {
            if (this.Components.Contains(this.addMarkerComponent))
            {
                this.Components.Remove(this.addMarkerComponent);
            }
            else
            {
                this.Components.Add(this.addMarkerComponent);
            }
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        float zoomX;
        float zoomY;

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            this.font = this.Content.Load<SpriteFont>("Font");

            this.zoomX = this.Window.ClientBounds.Width / this.touch.CurrentCamera.CaptureWidth;
            this.zoomY = this.Window.ClientBounds.Height / this.touch.CurrentCamera.CaptureHeight;
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.White);

            this.spriteBatch.Begin();

            this.spriteBatch.DrawString(this.font, this.msg, this.position, Color.Black);

            this.spriteBatch.End();

            base.Draw(gameTime);
        }

        string msg = "press 'space' key to add new marker";
        Vector2 position;

        void OnMarkerChanged(object sender, MarkerEventArgs args)
        {
            var x = args.EventData;

            this.msg = string.Format("{0}, {1}, {2}, {3}, {4}, {5}",
                x.Area, x.DX, x.DY, x.Present, x.X, x.Y);

            this.position.X = (this.touch.CurrentCamera.CaptureWidth - x.X) * this.zoomX;
            this.position.Y = x.Y * this.zoomY;
        }
    }
}
