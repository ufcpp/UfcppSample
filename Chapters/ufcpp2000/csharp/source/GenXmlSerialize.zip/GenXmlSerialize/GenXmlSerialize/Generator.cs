﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace GenXmlSerialize
{
    public class Generator
    {
        public static readonly XNamespace ns = "http://ufcpp.net/Types.xsd";

        const string HeaderExt = ".h";
        const string SourceExt = ".cpp";

        const string FileNameFormat = "XmlSerialize{0}{1}";

        static string SourceName(string name)
        {
            return string.Format(FileNameFormat, name, SourceExt);
        }

        static string HeaderName(string name)
        {
            return string.Format(FileNameFormat, name, HeaderExt);
        }

        /// <summary>
        /// 型定義 XML から C++ 用（XmlLite を利用）のシリアライズ関数群を生成。
        /// 全体。
        /// </summary>
        /// <param name="doc">型定義 XML</param>
        /// <param name="baseDir">出力先のフォルダ</param>
        /// <remarks>
        /// 型1つに付き、.h ファイル1つ、.cpp ファイル1つ生成。
        /// </remarks>
        public static void GenerateCpp(XDocument doc, string baseDir)
        {
            string nsName = doc.Root.A("namespace");
            foreach (var type in doc.Root.E("type"))
            {
                GenerateCpp(type, nsName, baseDir);
            }
        }

        /// <summary>
        /// 型定義 XML から C++ 用（XmlLite を利用）のシリアライズ関数群を生成。
        /// 型ごと。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="nsName">名前空間の名前</param>
        /// <param name="baseDir">出力先のフォルダ</param>
        static void GenerateCpp(XElement type, string nsName, string baseDir)
        {
            string id = type.A("id");

            string headerFileName = Path.Combine(baseDir, HeaderName(id));
            using (TextWriter header = new StreamWriter(headerFileName, false, Encoding.UTF8))
            {
                GenerateHeader(type, nsName, header);
            }

            string sourceFileName = Path.Combine(baseDir, SourceName(id));
            using (TextWriter source = new StreamWriter(sourceFileName, false, Encoding.UTF8))
            {
                GenerateSource(type, nsName, source);
            }
        }

        /// <summary>
        /// 型定義 XML から C++ 用（XmlLite を利用）のシリアライズ関数群を生成。
        /// .h ファイル。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="nsName">名前空間の名前</param>
        /// <param name="writer">結果の書き込み先</param>
        static void GenerateHeader(XElement type, string nsName, TextWriter writer)
        {
            writer.WriteLine("#pragma once");
            writer.WriteLine("#include <XmlLite.h>");

            string[] exList = new[] {
                "bool", "int", "short", "long", 
                "char", "float", "double", "UINT",
            };

            var idList =
                from e in type.E("element")
                select e.A("typeId") into typeId
                where !exList.Contains(typeId)
                select typeId;

            foreach (var includeId in idList.Distinct())
            {
                writer.WriteLine("#include \"{0}\"", HeaderName(includeId));
            }

            writer.WriteLine("namespace {0}", nsName);
            writer.WriteLine("{");

            string id = type.A("id");
            string paramName = type.A("param");

            GenerateStruct(type, writer);

            writer.WriteLine("void Save{0}(CComPtr<IXmlWriter>& writer, const {0}& {1});",
                id, paramName);

            writer.WriteLine("void Load{0}(CComPtr<IXmlReader>& reader, {0}* {1});",
                id, paramName);

            writer.WriteLine("}");
        }

        /// <summary>
        /// 型定義 XML から C++ 用（XmlLite を利用）のシリアライズ関数群を生成。
        /// .cpp ファイル。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="nsName">名前空間の名前</param>
        /// <param name="writer">結果の書き込み先</param>
        static void GenerateSource(XElement type, string nsName, TextWriter writer)
        {
            writer.WriteLine("#include \"stdafx.h\"");
            writer.WriteLine("#include \"{0}\"", HeaderName(type.A("id")));

            writer.WriteLine("namespace {0}", nsName);
            writer.WriteLine("{");

            GenerateSaveFunction(type, writer);
            GenerateLoadFunction(type, writer);

            writer.WriteLine("}");
        }

        /// <summary>
        /// 型定義 XML から C++ の sturct を生成。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="writer">結果の書き込み先</param>
        static void GenerateStruct(XElement type, TextWriter writer)
        {
            writer.WriteLine("struct {0}", type.A("id"));
            writer.WriteLine("{");

            foreach (var att in type.E("attribute"))
            {
                writer.WriteLine("\t{0} {1};",
                    att.A("type"),
                    att.A("name"));
            }

            foreach (var att in type.E("element"))
            {
                writer.WriteLine("\t{0} {1};",
                    att.A("typeId"),
                    att.A("name"));
            }

            writer.WriteLine("};");
        }

        /// <summary>
        /// 型定義 XML から C++ の Save 関数を生成。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="writer">結果の書き込み先</param>
        static void GenerateSaveFunction(XElement type, TextWriter writer)
        {
            string paramName = type.A("param");

            writer.WriteLine("void Save{0}(CComPtr<IXmlWriter>& writer, const {0}& {1})",
                type.A("id"),
                paramName);
            writer.WriteLine("{");
            writer.WriteLine("\tCString str;");
            //writer.WriteLine("\twriter->WriteStartElement(0, name, 0);");

            foreach (var att in type.E("attribute"))
            {
                writer.WriteLine("\tstr.Format(_T(\"{2}\"), {0}.{1});",
                    paramName,
                    att.A("name"),
                    TypeNameToFormatString(att.A("type")));

                writer.WriteLine("\twriter->WriteAttributeString(0, _T(\"{0}\"), 0, str);",
                    att.A("name"));
            }

            foreach (var att in type.E("element"))
            {
                writer.WriteLine("\twriter->WriteStartElement(0, _T(\"{0}\"), 0);",
                    att.A("name"));
                writer.WriteLine("\tSave{2}(writer, {0}.{1});",
                    paramName,
                    att.A("name"),
                    att.A("typeId"));
                writer.WriteLine("\twriter->WriteEndElement();");
            }

            //writer.WriteLine("\twriter->WriteEndElement();");
            writer.WriteLine("};");
        }

        /// <summary>
        /// C++ の printf とか CString::Format の、
        /// int なら %d、float なら %f とかの書式を返す。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <returns>書式文字列</returns>
        static string TypeNameToFormatString(string typeName)
        {
            switch (typeName)
            {
                case "double":
                case "float":
                    return "%f";
                case "bool":
                case "int":
                case "UINT":
                    return "%d";
                case "long":
                    return "%l";
                case "CString":
                    return "%s";
            }

            return null;
        }

        /// <summary>
        /// 型定義 XML から C++ の Load 関数を生成。
        /// </summary>
        /// <param name="type">型に関する情報の入った XElement</param>
        /// <param name="writer">結果の書き込み先</param>
        static void GenerateLoadFunction(XElement type, TextWriter writer)
        {
            string paramName = type.A("param");

            writer.WriteLine("void Load{0}(CComPtr<IXmlReader>& reader, {0}* {1})",
                type.A("id"),
                paramName);
            writer.WriteLine("{");
            writer.WriteLine("\tconst TCHAR* strName;");
            writer.WriteLine("\tconst TCHAR* strValue;");
            writer.WriteLine("\tUINT count;");

            // Load Attribute
            writer.WriteLine("\treader->GetAttributeCount(&count);");
            writer.WriteLine("\treader->MoveToFirstAttribute();");
            writer.WriteLine("\tfor(; count != 0; --count)");
            writer.WriteLine("\t{");
            writer.WriteLine("\t\treader->GetLocalName(&strName, 0);");
            writer.WriteLine("\t\treader->GetValue(&strValue, 0);");
            writer.WriteLine("\t\tCString cstrName(strName);");

            foreach (var att in type.E("attribute"))
            {
                writer.WriteLine("\t\tif(cstrName == _T(\"{0}\"))",
                    att.A("name"));
                writer.WriteLine("\t\t{");

                if (att.A("type") == "CString")
                {
                    writer.WriteLine("\t\t\t{0}->{1} = strValue;",
                        paramName,
                        att.A("name"));
                }
                else
                {
                    writer.WriteLine("\t\t\t" + TypeNameToGetValueString(att.A("type")));
                    writer.WriteLine("\t\t\t{0}->{1} = val;",
                        paramName,
                        att.A("name"));
                }

                writer.WriteLine("\t\t}");
            }

            writer.WriteLine("\t\treader->MoveToNextAttribute();");
            writer.WriteLine("\t}");

            // Load Element
            if (type.E("element").Count() != 0)
            {
                writer.WriteLine("\tXmlNodeType t;");
                writer.WriteLine("\tHRESULT hr;");
                writer.WriteLine("\tCString str;");
                writer.WriteLine("\twhile (S_OK == (hr = reader->Read(&t)))");
                writer.WriteLine("\t{");
                writer.WriteLine("\t\tif(t == XmlNodeType_Element)");
                writer.WriteLine("\t\t{");
                writer.WriteLine("\t\t\treader->GetLocalName(&strName, 0);");
                writer.WriteLine("\t\t\tstr = strName;");

                foreach (var elem in type.E("element"))
                {
                    writer.WriteLine("\t\t\tif(str == _T(\"{0}\"))",
                        elem.A("name"));
                    writer.WriteLine("\t\t\t{");

                    writer.WriteLine("\t\t\t\tLoad{2}(reader, &{0}->{1});",
                        paramName,
                        elem.A("name"),
                        elem.A("typeId"));

                    writer.WriteLine("\t\t\t}");
                }
                writer.WriteLine("\t\t\t");

                writer.WriteLine("\t\t}");
                writer.WriteLine("\t\telse if(t == XmlNodeType_EndElement)");
                writer.WriteLine("\t\t\tbreak;");

                writer.WriteLine("\t}");
            }

            writer.WriteLine("}");
        }

        /// <summary>
        /// float なら (float)atof(str); みたいな、文字列から値を得るコードを得る。
        /// CString strValue に文字列が入ってるものとして、
        /// val という名前の変数に値を格納するコードを作る。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <returns>値を得るためのコード</returns>
        static string TypeNameToGetValueString(string typeName)
        {
            const string toCStr = "wcstocs(strValue).c_str()";

            switch (typeName)
            {
                case "double":
                    return "double val = atof(" + toCStr + ");";
                case "float":
                    return "float val = (float)atof(" + toCStr + ");";
                case "int":
                    return "int val = atoi(" + toCStr + ");";
                case "UINT":
                    return "UINT val = (UINT)atoi(" + toCStr + ");";
                case "bool":
                    return "bool val = atoi(" + toCStr + ") != 0;";
                case "long":
                    return "long val = atol(" + toCStr + ");";
            }

            return null;
        }
    }

    /// <summary>
    /// XElement の Attribute とか Elements とかのタイピングが面倒なので、省略形を用意。
    /// </summary>
    static class Extensions
    {
        public static string A(this XElement elem, string name)
        {
            return elem.Attribute(name).Value;
        }

        public static IEnumerable<XElement> E(this XElement elem, string name)
        {
            return elem.Elements(Generator.ns + name);
        }
    }
}
