#include "StdAfx.h"
#include "TestTriangle.h"

#include "util.h"

#include "XmlSerializeGen.h"

static LPCTSTR filename = _T("Debug\\triangle.xml");
static ElementSerializerWrapper(Ufcpp, Triangle, _T("triangle"), triangleSerializer);

static void TestWriteTriangle()
{
	// �f�[�^�쐬
	Ufcpp::Triangle t;

	t.material.ambient = FromArgb(1.0f, 0.5f, 0.5f, 0.5f);
	t.material.diffuse = FromArgb(1.0f, 0.5f, 1.0f, 0.5f);
	t.material.specular = FromArgb(1.0f, 0.5f, 0.5f, 1.0f);
	t.material.shininess = 30.0f;

	t.a = Point(0, 0);
	t.b = Point(1, 0);
	t.c = Point(0, 1);

	// �V���A���C�Y
	triangleSerializer.Value = t;
	triangleSerializer.Save(filename);
}

static void TestReadTriangle()
{
	// �f�V���A���C�Y
	triangleSerializer.Load(filename);

	// �f�[�^�\��
	Ufcpp::Triangle& t = triangleSerializer.Value;
	std::cout << t;
}

void TestTriangle()
{
	TestWriteTriangle();
	TestReadTriangle();
}
