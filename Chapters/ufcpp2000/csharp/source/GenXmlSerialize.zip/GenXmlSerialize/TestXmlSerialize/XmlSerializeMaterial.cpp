﻿#include "stdafx.h"
#include "XmlSerializeMaterial.h"
namespace Ufcpp
{
void SaveMaterial(CComPtr<IXmlWriter>& writer, const Material& m)
{
	CString str;
	str.Format(_T("%f"), m.shininess);
	writer->WriteAttributeString(0, _T("shininess"), 0, str);
	writer->WriteStartElement(0, _T("ambient"), 0);
	SaveColor(writer, m.ambient);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("diffuse"), 0);
	SaveColor(writer, m.diffuse);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("specular"), 0);
	SaveColor(writer, m.specular);
	writer->WriteEndElement();
};
void LoadMaterial(CComPtr<IXmlReader>& reader, Material* m)
{
	const TCHAR* strName;
	const TCHAR* strValue;
	UINT count;
	reader->GetAttributeCount(&count);
	reader->MoveToFirstAttribute();
	for(; count != 0; --count)
	{
		reader->GetLocalName(&strName, 0);
		reader->GetValue(&strValue, 0);
		CString cstrName(strName);
		if(cstrName == _T("shininess"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			m->shininess = val;
		}
		reader->MoveToNextAttribute();
	}
	XmlNodeType t;
	HRESULT hr;
	CString str;
	while (S_OK == (hr = reader->Read(&t)))
	{
		if(t == XmlNodeType_Element)
		{
			reader->GetLocalName(&strName, 0);
			str = strName;
			if(str == _T("ambient"))
			{
				LoadColor(reader, &m->ambient);
			}
			if(str == _T("diffuse"))
			{
				LoadColor(reader, &m->diffuse);
			}
			if(str == _T("specular"))
			{
				LoadColor(reader, &m->specular);
			}
			
		}
		else if(t == XmlNodeType_EndElement)
			break;
	}
}
}
