﻿#include "stdafx.h"
#include "XmlSerializeColor.h"
namespace Ufcpp
{
void SaveColor(CComPtr<IXmlWriter>& writer, const Color& c)
{
	CString str;
	str.Format(_T("%f"), c.r);
	writer->WriteAttributeString(0, _T("r"), 0, str);
	str.Format(_T("%f"), c.g);
	writer->WriteAttributeString(0, _T("g"), 0, str);
	str.Format(_T("%f"), c.b);
	writer->WriteAttributeString(0, _T("b"), 0, str);
	str.Format(_T("%f"), c.a);
	writer->WriteAttributeString(0, _T("a"), 0, str);
};
void LoadColor(CComPtr<IXmlReader>& reader, Color* c)
{
	const TCHAR* strName;
	const TCHAR* strValue;
	UINT count;
	reader->GetAttributeCount(&count);
	reader->MoveToFirstAttribute();
	for(; count != 0; --count)
	{
		reader->GetLocalName(&strName, 0);
		reader->GetValue(&strValue, 0);
		CString cstrName(strName);
		if(cstrName == _T("r"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			c->r = val;
		}
		if(cstrName == _T("g"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			c->g = val;
		}
		if(cstrName == _T("b"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			c->b = val;
		}
		if(cstrName == _T("a"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			c->a = val;
		}
		reader->MoveToNextAttribute();
	}
}
}
