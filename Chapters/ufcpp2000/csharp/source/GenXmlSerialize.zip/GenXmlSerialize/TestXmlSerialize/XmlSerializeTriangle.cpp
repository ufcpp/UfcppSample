﻿#include "stdafx.h"
#include "XmlSerializeTriangle.h"
namespace Ufcpp
{
void SaveTriangle(CComPtr<IXmlWriter>& writer, const Triangle& triangle)
{
	CString str;
	writer->WriteStartElement(0, _T("material"), 0);
	SaveMaterial(writer, triangle.material);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("a"), 0);
	SavePoint(writer, triangle.a);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("b"), 0);
	SavePoint(writer, triangle.b);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("c"), 0);
	SavePoint(writer, triangle.c);
	writer->WriteEndElement();
};
void LoadTriangle(CComPtr<IXmlReader>& reader, Triangle* triangle)
{
	const TCHAR* strName;
	const TCHAR* strValue;
	UINT count;
	reader->GetAttributeCount(&count);
	reader->MoveToFirstAttribute();
	for(; count != 0; --count)
	{
		reader->GetLocalName(&strName, 0);
		reader->GetValue(&strValue, 0);
		CString cstrName(strName);
		reader->MoveToNextAttribute();
	}
	XmlNodeType t;
	HRESULT hr;
	CString str;
	while (S_OK == (hr = reader->Read(&t)))
	{
		if(t == XmlNodeType_Element)
		{
			reader->GetLocalName(&strName, 0);
			str = strName;
			if(str == _T("material"))
			{
				LoadMaterial(reader, &triangle->material);
			}
			if(str == _T("a"))
			{
				LoadPoint(reader, &triangle->a);
			}
			if(str == _T("b"))
			{
				LoadPoint(reader, &triangle->b);
			}
			if(str == _T("c"))
			{
				LoadPoint(reader, &triangle->c);
			}
			
		}
		else if(t == XmlNodeType_EndElement)
			break;
	}
}
}
