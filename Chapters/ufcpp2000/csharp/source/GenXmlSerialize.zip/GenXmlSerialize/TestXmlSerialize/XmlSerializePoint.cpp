﻿#include "stdafx.h"
#include "XmlSerializePoint.h"
namespace Ufcpp
{
void SavePoint(CComPtr<IXmlWriter>& writer, const Point& p)
{
	CString str;
	str.Format(_T("%f"), p.x);
	writer->WriteAttributeString(0, _T("x"), 0, str);
	str.Format(_T("%f"), p.y);
	writer->WriteAttributeString(0, _T("y"), 0, str);
};
void LoadPoint(CComPtr<IXmlReader>& reader, Point* p)
{
	const TCHAR* strName;
	const TCHAR* strValue;
	UINT count;
	reader->GetAttributeCount(&count);
	reader->MoveToFirstAttribute();
	for(; count != 0; --count)
	{
		reader->GetLocalName(&strName, 0);
		reader->GetValue(&strValue, 0);
		CString cstrName(strName);
		if(cstrName == _T("x"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			p->x = val;
		}
		if(cstrName == _T("y"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			p->y = val;
		}
		reader->MoveToNextAttribute();
	}
}
}
