#pragma once

void TestTriangle();
