﻿#pragma once
#include <XmlLite.h>
namespace Ufcpp
{
struct Color
{
	float r;
	float g;
	float b;
	float a;
};
void SaveColor(CComPtr<IXmlWriter>& writer, const Color& c);
void LoadColor(CComPtr<IXmlReader>& reader, Color* c);
}
