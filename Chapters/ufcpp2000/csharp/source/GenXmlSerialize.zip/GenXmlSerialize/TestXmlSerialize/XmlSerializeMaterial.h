﻿#pragma once
#include <XmlLite.h>
#include "XmlSerializeColor.h"
namespace Ufcpp
{
struct Material
{
	float shininess;
	Color ambient;
	Color diffuse;
	Color specular;
};
void SaveMaterial(CComPtr<IXmlWriter>& writer, const Material& m);
void LoadMaterial(CComPtr<IXmlReader>& reader, Material* m);
}
