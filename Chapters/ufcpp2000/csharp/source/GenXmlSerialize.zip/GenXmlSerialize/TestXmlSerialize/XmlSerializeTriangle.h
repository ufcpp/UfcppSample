﻿#pragma once
#include <XmlLite.h>
#include "XmlSerializeMaterial.h"
#include "XmlSerializePoint.h"
namespace Ufcpp
{
struct Triangle
{
	Material material;
	Point a;
	Point b;
	Point c;
};
void SaveTriangle(CComPtr<IXmlWriter>& writer, const Triangle& triangle);
void LoadTriangle(CComPtr<IXmlReader>& reader, Triangle* triangle);
}
