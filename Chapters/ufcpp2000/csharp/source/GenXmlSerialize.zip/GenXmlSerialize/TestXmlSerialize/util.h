#pragma once

#include "XmlSerializeLine.h"
#include "XmlSerializeTriangle.h"

inline Ufcpp::Color FromArgb(float a, float r, float g, float b)
{
	Ufcpp::Color c;
	c.a = a;
	c.r = r;
	c.g = g;
	c.b = b;
	return c;
}

inline Ufcpp::Point Point(float x, float y)
{
	Ufcpp::Point p;
	p.x = x;
	p.y = y;
	return p;
}

inline std::ostream& operator<< (std::ostream& os, const Ufcpp::Point& p)
{
	os << "(" << p.x << ", " << p.y << ")";

	return os;
}

inline std::ostream& operator<< (std::ostream& os, const Ufcpp::Color& c)
{
	os << "("
		<< c.a << ", "
		<< c.r << ", "
		<< c.g << ", "
		<< c.b << ")";

	return os;
}

inline std::ostream& operator<< (std::ostream& os, const Ufcpp::Line& line)
{
	os << "color    : " << line.color << '\n';
	os << "thickness: " << line.thickness << '\n';
	os << "start    : " << line.start << '\n';
	os << "end      : " << line.end << '\n';

	return os;
}

inline std::ostream& operator<< (std::ostream& os, const Ufcpp::Material& m)
{
	os << "\tambient  : " << m.ambient << '\n';
	os << "\tdiffuse  : " << m.diffuse << '\n';
	os << "\tspecular : " << m.specular << '\n';
	os << "\tshininess: " << m.shininess << '\n';

	return os;
}

inline std::ostream& operator<< (std::ostream& os, const Ufcpp::Triangle& t)
{
	os << "material:\n";
	os << t.material;

	os << "vertex a: " << t.a << '\n';
	os << "vertex b: " << t.b << '\n';
	os << "vertex c: " << t.c << '\n';

	return os;
}
