﻿#include "stdafx.h"
#include "XmlSerializeLine.h"
namespace Ufcpp
{
void SaveLine(CComPtr<IXmlWriter>& writer, const Line& line)
{
	CString str;
	str.Format(_T("%f"), line.thickness);
	writer->WriteAttributeString(0, _T("thickness"), 0, str);
	writer->WriteStartElement(0, _T("color"), 0);
	SaveColor(writer, line.color);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("start"), 0);
	SavePoint(writer, line.start);
	writer->WriteEndElement();
	writer->WriteStartElement(0, _T("end"), 0);
	SavePoint(writer, line.end);
	writer->WriteEndElement();
};
void LoadLine(CComPtr<IXmlReader>& reader, Line* line)
{
	const TCHAR* strName;
	const TCHAR* strValue;
	UINT count;
	reader->GetAttributeCount(&count);
	reader->MoveToFirstAttribute();
	for(; count != 0; --count)
	{
		reader->GetLocalName(&strName, 0);
		reader->GetValue(&strValue, 0);
		CString cstrName(strName);
		if(cstrName == _T("thickness"))
		{
			float val = (float)atof(wcstocs(strValue).c_str());
			line->thickness = val;
		}
		reader->MoveToNextAttribute();
	}
	XmlNodeType t;
	HRESULT hr;
	CString str;
	while (S_OK == (hr = reader->Read(&t)))
	{
		if(t == XmlNodeType_Element)
		{
			reader->GetLocalName(&strName, 0);
			str = strName;
			if(str == _T("color"))
			{
				LoadColor(reader, &line->color);
			}
			if(str == _T("start"))
			{
				LoadPoint(reader, &line->start);
			}
			if(str == _T("end"))
			{
				LoadPoint(reader, &line->end);
			}
			
		}
		else if(t == XmlNodeType_EndElement)
			break;
	}
}
}
