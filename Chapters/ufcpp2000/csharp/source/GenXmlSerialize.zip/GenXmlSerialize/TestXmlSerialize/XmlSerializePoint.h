﻿#pragma once
#include <XmlLite.h>
namespace Ufcpp
{
struct Point
{
	float x;
	float y;
};
void SavePoint(CComPtr<IXmlWriter>& writer, const Point& p);
void LoadPoint(CComPtr<IXmlReader>& reader, Point* p);
}
