﻿#pragma once
#include <XmlLite.h>
#include "XmlSerializeColor.h"
#include "XmlSerializePoint.h"
namespace Ufcpp
{
struct Line
{
	float thickness;
	Color color;
	Point start;
	Point end;
};
void SaveLine(CComPtr<IXmlWriter>& writer, const Line& line);
void LoadLine(CComPtr<IXmlReader>& reader, Line* line);
}
