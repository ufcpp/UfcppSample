#pragma once

#define MAX_CHAR 4096

inline std::string wcstocs(const std::wstring &in)
{
	char buf[MAX_CHAR];
	size_t size;
	wcstombs_s<MAX_CHAR>(&size, buf, in.c_str(), sizeof(buf));
	return buf;
}
