#include "StdAfx.h"
#include "TestLine.h"

#include "util.h"

#include "XmlSerializeGen.h"

static LPCTSTR filename = _T("Debug\\line.xml");
static ElementSerializerWrapper(Ufcpp, Line, _T("line"), lineSerializer);

static void TestWriteLine()
{
	// �f�[�^�쐬
	Ufcpp::Line line;

	line.start = Point(0, 1);
	line.end = Point(1, 0);
	line.color = FromArgb(1.0f, 1.0f, 0.5f, 0.5f);
	line.thickness = 1.0f;

	// �V���A���C�Y
	lineSerializer.Value = line;
	lineSerializer.Save(filename);
}

static void TestReadLine()
{
	// �f�V���A���C�Y
	lineSerializer.Load(filename);

	// �f�[�^�\��
	Ufcpp::Line& line = lineSerializer.Value;
	std::cout << line;
}

void TestLine()
{
	TestWriteLine();
	TestReadLine();
}
