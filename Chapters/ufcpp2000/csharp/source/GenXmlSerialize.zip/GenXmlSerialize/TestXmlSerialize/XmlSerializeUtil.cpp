#include "StdAfx.h"
#include "XmlSerializeUtil.h"

namespace Xml
{
	void ElementSerializer::Save(CComPtr<IXmlWriter>& writer)
	{
		writer->WriteStartElement(0, this->ElementName(), 0);

		this->WriteElement(writer);

		writer->WriteEndElement();
	}

	void ElementSerializer::Load(CComPtr<IXmlReader>& reader)
	{
		const TCHAR* strName;
		XmlNodeType t;
		HRESULT hr;
		CString str;
		while (S_OK == (hr = reader->Read(&t)))
		{
			if(t == XmlNodeType_Element)
			{
				reader->GetLocalName(&strName, 0);
				str = strName;
				if(str == this->ElementName())
				{
					this->ReadElement(reader);
				}
				
			}
			else if(t == XmlNodeType_EndElement)
				break;
		}
	}

	void ElementSerializer::Save(const CString& filename)
	{
		CComPtr<IStream> pFileStream;
		SHCreateStreamOnFile(filename, STGM_CREATE | STGM_WRITE, &pFileStream);
		this->Save(pFileStream);
	}

	void ElementSerializer::Load(const CString& filename)
	{
		CComPtr<IStream> pFileStream;
		SHCreateStreamOnFile(filename, STGM_READ, &pFileStream);
		this->Load(pFileStream);
	}

	void ElementSerializer::Save(IStream* pStream)
	{
		CComPtr<IXmlWriter> pWriter;

		CreateXmlWriter(__uuidof(IXmlWriter), (void**) &pWriter, NULL);
		pWriter->SetOutput(pStream);
		pWriter->SetProperty(XmlWriterProperty_Indent, TRUE);
		pWriter->WriteStartDocument(XmlStandalone_Omit);

		this->Save(pWriter);

		pWriter->WriteEndElement();
	}

	void ElementSerializer::Load(IStream* pStream)
	{
		CComPtr<IXmlReader> pReader;

		CreateXmlReader(__uuidof(IXmlReader), (void**) &pReader, NULL);
		pReader->SetInput(pStream);

		this->Load(pReader);
	}

	ElementSerializer::~ElementSerializer() {}

	void CompoundElementSerializer::WriteElement(CComPtr<IXmlWriter>& writer)
	{
		std::list<ElementSerializer*>::iterator p = this->list.begin();
		std::list<ElementSerializer*>::iterator pEnd = this->list.end();

		for(; p != pEnd; ++p)
		{
			(*p)->Save(writer);
		}
	}

	void CompoundElementSerializer::ReadElement(CComPtr<IXmlReader>& reader)
	{
		const TCHAR* strName;
		XmlNodeType t;
		HRESULT hr;
		CString str;
		while (S_OK == (hr = reader->Read(&t)))
		{
			if(t == XmlNodeType_Element)
			{
				reader->GetLocalName(&strName, 0);
				str = strName;

				std::list<ElementSerializer*>::iterator p = this->list.begin();
				std::list<ElementSerializer*>::iterator pEnd = this->list.end();

				for(; p != pEnd; ++p)
				{
					if(str == (*p)->ElementName())
					{
						(*p)->ReadElement(reader);
						break;
					}
				}
			}
			else if(t == XmlNodeType_EndElement)
				break;
		}
	}
}
