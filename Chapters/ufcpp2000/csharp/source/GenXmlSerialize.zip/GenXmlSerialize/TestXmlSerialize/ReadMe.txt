﻿========================================================================
    コンソール アプリケーション : TestXmlSerialize プロジェクトの概要
========================================================================

・内容

XmlLite を使った XML ファイルの読み書きのサンプル。

ライブラリがあっても、C++ で XML の読み書きしたくないなぁ・・・。
XmlLite を直接使うよりも、C# で C++ コードを自動生成する方が楽なんじゃないかという。
というか、やっぱその方が楽だった。


・プロジェクト構成概要

	・GenXmlSerialize（C#）
	型定義 XML ファイルから C++ クラスとシリアライズ用コードを自動生成するライブラリ。

	・TestGenXmlSerialize（C#）
	名前通り、GenXmlSerialize のテスト用。
	型定義 XML ファイル中に Line とか Triangle とかの型を定義して、
	それから C++ コードを生成。

	・TestXmlSerialize（C++）
	TestGenXmlSerialize で生成した C++ コードをテストするコンソールアプリ。
	
	gen フォルダ以下に、TestGenXmlSerialize で自動生成したファイルがあります。

	自動生成した関数は直接使用せず、
	XmlSerializeUtil.h / .cpp にあるラッパークラスを使います。

	このコンソールアプリでは、Line, Triangle を保存→読込→表示をするだけ。
	Debug フォルダの下に XML ファイルが保存されます。


・設定の読み書きに XMLLite 利用。
Vista と XP SP3 には標準で入ってるっぽい。
XP SP2 の場合には更新プログラムが必要。
Windows XP 用 XMLLite
http://www.microsoft.com/downloads/details.aspx?FamilyID=d7b5dc81-ad14-4de2-8ad5-8c4a9aab5992&displaylang=ja
