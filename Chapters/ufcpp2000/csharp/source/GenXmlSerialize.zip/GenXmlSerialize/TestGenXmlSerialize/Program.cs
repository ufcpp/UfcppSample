﻿using System.Xml.Linq;

namespace TestGenXmlSerialize
{
    class Program
    {
        static void Main(string[] args)
        {
            var name = @"data\types.xml";
            var doc = XDocument.Load(name);
            GenXmlSerialize.Generator.GenerateCpp(doc, @"..\..\..\TestXmlSerialize");
        }
    }
}
