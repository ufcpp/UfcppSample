﻿using System;
using System.Collections.Generic;

namespace FourierPlot
{
    /// <summary>
    /// フーリエ級数。
    /// 正確には、n 次までの部分級数和。
    /// </summary>
    public class FourierSeries
    {
        /// <summary>
        /// cos 係数。
        /// </summary>
        public List<double> A { get; private set; }

        /// <summary>
        /// sin 係数。
        /// </summary>
        public List<double> B { get; private set; }

        /// <summary>
        /// 周期。
        /// </summary>
        public double T { get { return this.max - this.min; } }

        /// <summary>
        /// 振幅特性。
        /// </summary>
        public IEnumerable<double> Magnitude
        {
            get
            {
                yield return A[0];

                for (int n = 1; n < A.Count; n++)
                {
                    var mag = A[n] * A[n] + B[n] * B[n];
                    mag /= 4;
                    mag = Math.Sqrt(mag);
                    yield return mag;
                }
            }
        }

        /// <summary>
        /// 位相特性。
        /// </summary>
        public IEnumerable<double> Phase
        {
            get
            {
                yield return 0;

                for (int n = 1; n < A.Count; n++)
                {
                    var p = Math.Atan2(B[n], A[n]);
                    yield return p;
                }
            }
        }

        /// <summary>
        /// t に置ける級数の値を計算。
        /// </summary>
        /// <param name="t">独立変数。</param>
        /// <returns>級数の値。</returns>
        public double GetValue(double t)
        {
            var f = A[0];
            var w = 2 * Math.PI / T;

            for (int n = 1; n < A.Count; n++)
            {
                f += A[n] * Math.Cos(n * w * t);
                f += B[n] * Math.Sin(n * w * t);
            }

            return f;
        }

        double min, max, interval;

        /// <summary>
        /// フーリエ級数展開したい関数を与えて、rank 次までのフーリエ係数を計算。
        /// </summary>
        /// <param name="f">フーリエ級数展開したい関数。</param>
        /// <param name="rank">何次の項まで計算するか。</param>
        /// <param name="min">積分区間の下限。</param>
        /// <param name="max">積分区間の上限。</param>
        /// <param name="interval">数値積分する際の計算間隔。</param>
        public FourierSeries(Func<double, double> f, int rank, double min, double max, double interval)
        {
            this.min = min;
            this.max = max;
            this.interval = interval;

            this.A = new List<double>();
            this.B = new List<double>();

            var a0 = MyMath.FourierCosCoefficient(f, 0, min, max, interval);

            this.A.Add(a0);
            this.B.Add(0);

            for (int n = 1; n < rank; n++)
            {
                var an = MyMath.FourierCosCoefficient(f, n, min, max, interval);
                var bn = MyMath.FourierSinCoefficient(f, n, min, max, interval);

                this.A.Add(an);
                this.B.Add(bn);
            }
        }
    }
}
