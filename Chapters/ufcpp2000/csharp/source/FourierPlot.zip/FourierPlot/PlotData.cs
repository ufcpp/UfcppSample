﻿using System.Windows;
using System.Collections.Specialized;
using System.Collections.Generic;
using System;
using System.Linq;

namespace FourierPlot
{
    /// <summary>
    /// Chart にバインドするためのデータ。
    /// </summary>
    public class PlotData : INotifyCollectionChanged, IEnumerable<Point>
    {
        List<Point> points = new List<Point>();

        /// <summary>
        /// 点を1個追加。
        /// </summary>
        /// <param name="p">点。</param>
        public void Add(Point p) { this.points.Add(p); }

        /// <summary>
        /// いったん全部削除。
        /// </summary>
        public void Clear() { this.points.Clear(); }

        /// <summary>
        /// 数値列から点列を作る。
        /// 入力された値を Y に、インデックスを X に代入。
        /// </summary>
        /// <param name="list"></param>
        public void Copy(IEnumerable<double> list)
        {
            var plist = list.Select((x, i) => new Point(i, x));
            this.Copy(plist);
        }

        /// <summary>
        /// IEnumerable からコピー。
        /// </summary>
        /// <param name="list">コピー元。</param>
        public void Copy(IEnumerable<Point> list)
        {
            this.points.Clear();

            foreach (var p in list)
            {
                this.points.Add(p);
            }

            this.OnCollectionChanged();
        }

        /// <summary>
        /// 関数を与えて、一定間隔で点列化。
        /// </summary>
        /// <param name="f">点列化したい関数。</param>
        /// <param name="min">区間の下限。</param>
        /// <param name="max">区間の上限。</param>
        /// <param name="interval">点列化の間隔。</param>
        public void MakeFrom(Func<double, double> f, double min, double max, double interval)
        {
            this.points.Clear();

            var count = (max - min) / interval;

            for (int i = 0; i < count; i++)
            {
                var x = min + interval * i;
                var y = f(x);

                var point = new Point
                {
                    X = x,
                    Y = y,
                };

                this.points.Add(point);
            }

            this.OnCollectionChanged();
        }

        #region INotifyCollectionChanged Members

        public event NotifyCollectionChangedEventHandler CollectionChanged;

        void OnCollectionChanged()
        {
            var d = this.CollectionChanged;
            if (d != null) d(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        #endregion
        #region IEnumerable<Point> Members

        public IEnumerator<Point> GetEnumerator()
        {
            foreach (var item in this.points)
            {
                yield return item;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
    }
}
