﻿using System;

namespace FourierPlot
{
    /// <summary>
    /// 手抜きな名前でごめんなさい。
    /// </summary>
    public static class MyMath
    {
        /// <summary>
        /// シンプソン公式を使って数値積分。
        /// </summary>
        /// <param name="f">積分したい関数。</param>
        /// <param name="min">積分区間の下限。</param>
        /// <param name="max">積分区間の上限。</param>
        /// <param name="interval">数値積分するための分割区間幅。</param>
        /// <returns>積分値。</returns>
        public static double Integrate(Func<double, double> f, double min, double max, double interval)
        {
            var count = (int)((max - min) / interval);
            if (count % 2 == 1) ++count;

            var delta = (max - min) / count;

            var sum = f(min) + f(max);

            for (int i = 0, j = 1; i < count; i += 2, j += 2)
            {
                sum += 4 * f(delta * i + min);
                sum += 2 * f(delta * j + min);
            }

            return sum * delta / 3;
        }

        /// <summary>
        /// sin に対応する n 次のフーリエ係数 b_n を求める。
        /// </summary>
        /// <param name="f">フーリエ係数を求めたい関数。</param>
        /// <param name="n">次数。</param>
        /// <param name="min">積分区間の下限。</param>
        /// <param name="max">積分区間の上限。</param>
        /// <param name="interval">数値積分するための分割区間幅。</param>
        /// <returns>フーリエ係数 b_n。</returns>
        public static double FourierSinCoefficient(Func<double, double> f, int n, double min, double max, double interval)
        {
            return FourierCoefficient(f, Math.Sin, n, min, max, interval);
        }

        /// <summary>
        /// cos に対応する n 次のフーリエ係数 a_n を求める。
        /// </summary>
        /// <param name="f">フーリエ係数を求めたい関数。</param>
        /// <param name="n">次数。</param>
        /// <param name="min">積分区間の下限。</param>
        /// <param name="max">積分区間の上限。</param>
        /// <param name="interval">数値積分するための分割区間幅。</param>
        /// <returns>フーリエ係数 a_n。</returns>
        public static double FourierCosCoefficient(Func<double, double> f, int n, double min, double max, double interval)
        {
            if (n == 0)
            {
                return FourierCoefficient(f, x => 0.5, n, min, max, interval);
            }

            return FourierCoefficient(f, Math.Cos, n, min, max, interval);
        }

        static double FourierCoefficient(Func<double, double> f, Func<double, double> sinOrCos, int n, double min, double max, double interval)
        {
            var T = max - min;
            Func<double, double> integrant = x => f(x) * sinOrCos(2 * Math.PI * n * x / T);
            var sum = Integrate(integrant, min, max, interval) * 2 / T;
            return sum;
        }
    }
}
