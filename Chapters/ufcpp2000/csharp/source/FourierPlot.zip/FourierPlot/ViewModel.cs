﻿using System;
using System.ComponentModel;
using System.Windows;

namespace FourierPlot
{
    /// <summary>
    /// これも手抜きな名前でごめんなさい。
    /// MainPage 用の view model。
    /// </summary>
    public class ViewModel : INotifyPropertyChanged
    {
        public ViewModel()
        {
            this.MakeFunction();
            this.Update();
        }

        private double minX = -3.14;

        /// <summary>
        /// フーリエ積分かけたい区間の下限。
        /// </summary>
        public double MinimumX
        {
            get { return minX; }
            set { minX = value; this.OnPropertyChanged("MinimumX"); }
        }

        private double maxX = 3.14;

        /// <summary>
        /// フーリエ積分かけたい区間の上限。
        /// </summary>
        public double MaximumX
        {
            get { return maxX; }
            set { maxX = value; this.OnPropertyChanged("MaximumX"); }
        }

        private double intervalX = 0.01;

        /// <summary>
        /// フーリエ積分かける際、数値積分で使う区間幅。
        /// </summary>
        public double IntervalX
        {
            get { return intervalX; }
            set { intervalX = value; this.OnPropertyChanged("IntervalX"); }
        }

        private string expression = "sin(x)";

        /// <summary>
        /// フーリエ変換の対象となる関数を動的に入力するために使う文字列。
        /// </summary>
        public string Expression
        {
            get { return expression; }
            set { expression = value; this.OnPropertyChanged("Expression"); }
        }

        private int rank = 10;

        /// <summary>
        /// 何次の項までフーリエ係数を求めるか。
        /// </summary>
        public int Rank
        {
            get { return rank; }
            set { rank = value; this.OnPropertyChanged("Rank"); }
        }

        private string error;

        /// <summary>
        /// エラーがあるときにはエラーメッセージを表示。
        /// </summary>
        public string ErrorMessage
        {
            get { return error; }
            set { error = value; this.OnPropertyChanged("ErrorMessage"); }
        }

        PlotData original = new PlotData();

        /// <summary>
        /// フーリエ変換をかけたい関数を点列化したもの。
        /// </summary>
        public PlotData OriginalData
        {
            get { return original; }
            set { original = value; }
        }

        PlotData cosCoef = new PlotData();

        /// <summary>
        /// cos 係数。
        /// </summary>
        public PlotData CosCoefficient
        {
            get { return cosCoef; }
            set { cosCoef = value; }
        }

        PlotData sinCoef = new PlotData();

        /// <summary>
        /// sin 係数。
        /// </summary>
        public PlotData SinCoefficient
        {
            get { return sinCoef; }
            set { sinCoef = value; }
        }

        PlotData fdata = new PlotData();

        /// <summary>
        /// rank 次までのフーリエ級数の部分和（を点列化したもの）。
        /// </summary>
        public PlotData FourierData
        {
            get { return fdata; }
            set { fdata = value; }
        }

        private PlotData mag = new PlotData();

        /// <summary>
        /// 振幅特性。
        /// </summary>
        public PlotData Magnitude
        {
            get { return mag; }
            set { mag = value; }
        }

        /// <summary>
        /// Expression をパースした結果を記憶しておく。
        /// </summary>
        Func<double, double> functionCache = null;

        /// <summary>
        /// Expression をパースして、Func を生成。
        /// </summary>
        void MakeFunction()
        {
            try
            {
                this.ErrorMessage = string.Empty;

                this.functionCache = DynamicParser.Parse(this.Expression);
            }
            catch (ParseException e)
            {
                this.ErrorMessage = e.Message;
            }
        }

        /// <summary>
        /// PlotData をアップデート。
        /// </summary>
        void Update()
        {
            var f = this.functionCache;

            this.OriginalData.MakeFrom(f, MinimumX, MaximumX, IntervalX);

            this.fourier = new FourierSeries(f, this.Rank, MinimumX, MaximumX, IntervalX);

            this.CosCoefficient.Copy(this.fourier.A);
            this.SinCoefficient.Copy(this.fourier.B);
            this.Magnitude.Copy(this.fourier.Magnitude);

            this.FourierData.MakeFrom(this.fourier.GetValue, MinimumX, MaximumX, IntervalX);
        }

        FourierSeries fourier;

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (propertyName != "ErrorMessage")
            {
                if (this.functionCache == null || propertyName == "Expression")
                    this.MakeFunction();

                this.Update();
            }

            var d = this.PropertyChanged;
            if (d != null) d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
