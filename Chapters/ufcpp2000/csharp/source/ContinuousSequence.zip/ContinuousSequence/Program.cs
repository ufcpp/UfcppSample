﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] data = { 1, 2, 2, 2, 3, 3, 5, 7, 7, 10, 10, 11, 100, 101, 102, 103 };

            var groups = data.GetContinuousSequence();

            foreach (var g in groups)
            {
                Console.WriteLine("{0}を先頭に{1}個", g.First, g.Count);
            }
        }
    }
}
