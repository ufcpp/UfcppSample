﻿
using System.Collections.Generic;
using System.Linq;
namespace Sequence
{
    /// <summary>
    /// 連続する整数を表すクラス。
    /// 先頭の値と個数のペア。
    /// </summary>
    /// <remarks>
    /// ほんとはこの手の（単純な get only プロパティしか持たない）クラス、いちいち自作したくはないけども。
    /// 「プロパティ名付き Tuple」みたいな機能が超欲しい。
    /// あるいは、「メソッドの戻り値に使える匿名クラス」。
    /// </remarks>
    public class ContinuousSequence : IEnumerable<int>
    {
        public ContinuousSequence(int value, int difference)
        {
            this.first = value;
            this.count = difference;
        }

        private readonly int first;

        /// <summary>
        /// 先頭の値。
        /// </summary>
        public int First
        {
            get { return first; }
        }

        private readonly int count;

        /// <summary>
        /// 連続する個数。
        /// </summary>
        public int Count
        {
            get { return count; }
        }

        #region IEnumerable<int> メンバー

        public IEnumerator<int> GetEnumerator()
        {
            return Enumerable.Range(First, Count).GetEnumerator();
        }

        #endregion
        #region IEnumerable メンバー

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
    }
}
