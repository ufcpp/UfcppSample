﻿
namespace Sequence
{
    /// <summary>
    /// シーケンス中の値と、階差(前の要素との差分)のペア。
    /// </summary>
    /// <remarks>
    /// ほんとはこの手の（単純な get only プロパティしか持たない）クラス、いちいち自作したくはないけども。
    /// 「プロパティ名付き Tuple」みたいな機能が超欲しい。
    /// あるいは、「メソッドの戻り値に使える匿名クラス」。
    /// </remarks>
    public class ValueDifferencePair
    {
        public ValueDifferencePair(int value, int difference)
        {
            this.value = value;
            this.difference = difference;
        }

        private readonly int value;

        /// <summary>
        /// 値。
        /// </summary>
        public int Value
        {
            get { return value; }
        }

        private readonly int difference;

        /// <summary>
        /// 前の要素との差分。
        /// </summary>
        public int Difference
        {
            get { return difference; }
        }
    }
}
