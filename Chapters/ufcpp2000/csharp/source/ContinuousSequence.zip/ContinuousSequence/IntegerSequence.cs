﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sequence
{
    /// <summary>
    /// 整数列向けの拡張メソッド群。
    /// </summary>
    public static partial class IntegerSequence
    {
        /// <summary>
        /// 整数列から、連番になっている部分を、{ 初項, 項数 } のペアで抜き出す。
        /// </summary>
        /// <param name="seq">元整数列。</param>
        /// <returns>{ 初項, 項数 } のペアのデータ列。</returns>
        public static IEnumerable<ContinuousSequence> GetContinuousSequence(this IEnumerable<int> seq)
        {
            return seq
                .DistinctAdjacently()
                .Differences()
                .Split(x => x.Difference != 1)
                .Select(x => new ContinuousSequence(x.First().Value, x.Count()));
        }

        /// <summary>
        /// 隣り合ってる同じ値を1つにまとめてしまう。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="seq">元データ列。</param>
        /// <returns>隣り合った重複を削除したデータ列。</returns>
        public static IEnumerable<T> DistinctAdjacently<T>(this IEnumerable<T> seq)
            where T : struct
        {
            T? prev = null;

            foreach (var x in seq)
            {
                if (prev == null || !prev.Equals(x))
                {
                    yield return x;
                }

                prev = x;
            }
        }

        /// <summary>
        /// 特定の条件を満たすところでデータ列を分割する。
        /// （条件を満たした箇所がサブ データ列の末尾になる。）
        /// 
        /// 例えば、{ 1, 1, 0, 1, 0, 1 } というデータ列を渡して、
        /// 「要素が 0」という条件で分割すると、結果は
        /// { { 1, 1, 0 }, { 1, 0 }, { 1 } }
        /// となる。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="seq">元データ列。</param>
        /// <param name="splitCondition">分割条件。</param>
        /// <returns>分割したサブ データ列群。</returns>
        public static IEnumerable<IEnumerable<T>> Split<T>(this IEnumerable<T> seq, Predicate<T> splitCondition)
        {
            var sub = new List<T>();

            foreach (var x in seq)
            {
                sub.Add(x);

                if (splitCondition(x))
                {
                    yield return sub;
                    sub = new List<T>();
                }
            }

            if (sub.Count != 0)
            {
                yield return sub;
            }
        }

        /// <summary>
        /// 整数列の階差を作る。
        /// </summary>
        /// <param name="seq">整数列。</param>
        /// <returns>値/階差のペアのデータ列。</returns>
        public static IEnumerable<ValueDifferencePair> Differences(this IEnumerable<int> seq)
        {
            int prev = seq.First();
            int diff;

            foreach (var x in seq.Skip(1))
            {
                diff = x - prev;

                yield return new ValueDifferencePair(prev, diff);

                prev = x;
            }

            yield return new ValueDifferencePair(prev, 0);
        }
    }
}
