﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MemoryImage
{
    using S = Statement.Statement;

    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        List<Statement.IStatement> statements;

        HeapEmulator heap;
        Dictionary<string, HeapBlock> variables;
        int current = 0;

        public Window1()
        {
            InitializeComponent();

            this.statements = Parser.Parse(@"
{
    x = 0
    a = new[135]
    {
        b = new [50]
        y = 50
        {
            c = new[22] { a b }
            d = new[150]
        }
        z = 100
        e = new[38]
        {
            f = new[143]
            g = new[5]
            {
                b
                e
            }
        }
        {
            h = new[111]
        }
    }
    i=new[90]
    w=0
}}}
").ToList();

            this.Loaded += new RoutedEventHandler(Window1_Loaded);
            this.heapView.PreviewMouseDown += new MouseButtonEventHandler(Window1_MouseDown);
            this.souceText.SelectionChanged += new SelectionChangedEventHandler(souceText_SelectionChanged);
        }

        void souceText_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var count = this.souceText.SelectedIndex + 1;
            this.heap.Clear();
            this.variables.Clear();

            foreach (var s in this.statements.Take(count))
            {
                s.Action(this.heap, this.variables);
            }

            this.current = count;

            this.heapView.Update();
        }

        void Window1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (this.current >= this.statements.Count)
            {
                // 実行終了
                return;
            }

            var s = this.statements[this.current];
            s.Action(this.heap, this.variables);
            this.current++;

            this.souceText.SelectedIndex++;

            this.heapView.Update();
        }

        void Window1_Loaded(object sender, RoutedEventArgs e)
        {
            this.StatementsToString();

            var blockSize = 30;
            var height = 20;
            var width = 20;

            var stack = new StackEmulator(height);
            this.heap = new HeapEmulator(height * width, stack);
            this.variables = new Dictionary<string, HeapBlock>();
            this.current = 0;

            this.heapView.Initialize(heap, blockSize, width, height);
        }

        void StatementsToString()
        {
            int indentSize = 0;
            int index = 0;

            foreach (var s in this.statements)
            {
                if (s.Indent == -1)
                {
                    indentSize--;
                    if (indentSize < 0)
                        return;
                }

                var str = new string(' ', 2 * indentSize) + s.ToString();
                this.souceText.Items.Add(new ContentControl { Content = str });

                if (s.Indent == 1)
                {
                    indentSize++;
                }
                index++;
            }

        }
    }
}
