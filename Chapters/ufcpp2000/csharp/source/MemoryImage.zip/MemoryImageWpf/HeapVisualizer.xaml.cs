﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MemoryImage
{
    /// <summary>
    /// HeapVisualizer.xaml の相互作用ロジック
    /// </summary>
    public partial class HeapVisualizer : UserControl
    {
        HeapEmulator heap;
        int heapWidth;
        int heapHeight;
        double blockSize;

        public HeapVisualizer()
        {
            InitializeComponent();
        }

        public void Initialize(
            HeapEmulator heap,
            double blockSize, int width, int height)
        {
            this.blockSize = blockSize;
            this.heapWidth = width;
            this.heapHeight = height;
            var heapOffset = 3;

            this.Width = (3 + heapWidth) * blockSize;
            this.Height = height * blockSize;

            this.heap = heap;

            this.stackCanvas.Width = blockSize * 2;
            this.stackCanvas.Height = blockSize * height;

            this.heapCanvas.Width = blockSize * width;
            this.heapCanvas.Height = blockSize * height;
            this.heapCanvas.Clip = new RectangleGeometry
            {
                Rect = new Rect(0, 0, blockSize * width, blockSize * height)
            };
            Canvas.SetLeft(this.heapCanvas, heapOffset * blockSize);

            this.Update();
        }

        private void GetHeapLocation(int location, out double x, out double y)
        {
            var ix = location % this.heapWidth;
            var iy = location / this.heapWidth;

            x = ix * this.blockSize;
            y = iy * this.blockSize;
        }

        private double GetStackLocation(int index)
        {
            return this.blockSize * (this.heapHeight - 1 - index);
        }

        public void Update()
        {
            // stack
            AddStackItems();

            // heap
            AddHeapBlocks();

            // 参照構造
            AddReferenceGraph();
        }

        static readonly Brush graphBrush = new SolidColorBrush(Color.FromArgb(64, 0, 0, 64));

        private void AddReferenceGraph()
        {
            this.graphCanvas.Children.Clear();

            this.CreateGraph(this.heap.Stack.Items);
        }

        private void CreateGraph(IEnumerable<StackItem> stackItems)
        {
            var references = stackItems.OfType<StackReferenceItem>().Select(x => x.Destination);

            double offset = this.blockSize * 0.5;
            double x1 = this.blockSize * 1.5;
            double heapOffset = Canvas.GetLeft(this.heapCanvas);

            int index = 0;
            foreach (var item in stackItems)
            {
                var r = item as StackReferenceItem;
                if (r != null)
                {
                    var y1 = this.GetStackLocation(index) + offset;

                    double x2, y2;
                    this.GetHeapLocation(r.Destination.Location, out x2, out y2);
                    x2 += heapOffset + offset;
                    y2 += offset;

                    AddGraphLine(x1, y1, x2, y2);

                    CreateGraph(r.Destination, offset, heapOffset);
                }
                ++index;
            }
        }

        private void CreateGraph(HeapBlock block, double offset, double heapOffset)
        {
            foreach (var c in block.Children)
            {
                double x1, y1, x2, y2;
                this.GetHeapLocation(block.Location + block.Size, out x1, out y1);
                this.GetHeapLocation(c.Location, out x2, out y2);
                x1 += heapOffset - offset;
                y1 += offset;
                x2 += heapOffset + offset;
                y2 += offset;

                AddGraphLine(x1, y1, x2, y2);
            }
        }

        private void AddGraphLine(double x1, double y1, double x2, double y2)
        {
            var elem = new Line
            {
                X1 = x1,
                Y1 = y1,
                X2 = x2,
                Y2 = y2,
                Stroke = graphBrush,
                StrokeThickness = 2,
            };

            this.graphCanvas.Children.Add(elem);
        }

        private static readonly Color[] colors = new[]
            {
                Color.FromArgb(255, 240, 120, 120),
                Color.FromArgb(255, 210, 150, 120),
                Color.FromArgb(255, 180, 180, 120),
                Color.FromArgb(255, 150, 210, 120),
                Color.FromArgb(255, 120, 240, 120),
                Color.FromArgb(255, 120, 210, 150),
                Color.FromArgb(255, 120, 180, 180),
                Color.FromArgb(255, 120, 150, 210),
                Color.FromArgb(255, 120, 120, 240),
                Color.FromArgb(255, 150, 120, 210),
                Color.FromArgb(255, 180, 120, 180),
                Color.FromArgb(255, 210, 120, 150),
            };

        Dictionary<string, Brush> brushTable = new Dictionary<string, Brush>();

        private static Brush CreateBrush(int i)
        {
            i %= colors.Length;
            var c = colors[i];
            return Design.CreateBrush(c);
        }

        int brushIndex = 0;

        Brush CreateBrush()
        {
            return CreateBrush(this.brushIndex++);
        }

        static readonly Brush heapUnrefBrush = Design.CreateBrush(Colors.Gray);

        private void AddHeapBlocks()
        {
            this.heapCanvas.Children.Clear();
            this.heap.Mark();

            foreach (var item in this.heap.Blocks)
            {
                double x, y;
                GetHeapLocation(item.Location, out x, out y);

                var w = this.blockSize * item.Size;
                var h = this.blockSize;

                var size = item.Size;

                Brush brush;

                var name = item.UserData["name"] as string;

                if (item.Mark)
                {
                    if (this.brushTable.ContainsKey(name))
                    {
                        brush = this.brushTable[name];
                    }
                    else
                    {
                        brush = this.CreateBrush();
                        this.brushTable[name] = brush;
                    }
                }
                else
                    brush = heapUnrefBrush;

                var xxx = item.Location % this.heapWidth;
                xxx += size;

                do
                {
                    var elem = new TextBox
                    {
                        Text = name,
                        Background = brush,
                        Width = w,
                        Height = h,
                    };
                    Canvas.SetLeft(elem, x);
                    Canvas.SetTop(elem, y);
                    this.heapCanvas.Children.Add(elem);

                    x -= this.heapWidth * this.blockSize;
                    y += this.blockSize;
                    xxx -= this.heapWidth;
                }
                while (xxx > 0);
            }
        }

        private void AddStackScopeBound()
        {
            int i = 0;
            foreach (var item in this.heap.Stack.Scopes)
            {
                var y = this.blockSize * (this.heapHeight - i);
                var line = new Line
                {
                    X1 = 0,
                    Y1 = y,
                    X2 = this.blockSize * 2,
                    Y2 = y,
                    Stroke = scopeLineBrush,
                    StrokeThickness = 1,
                };

                i += item;

                this.stackCanvas.Children.Add(line);
            }
        }

        static readonly Brush stackValueBrush = Design.CreateBrushV(Color.FromArgb(255, 230, 210, 210));
        static readonly Brush stackRefBrush = Design.CreateBrushV(Color.FromArgb(255, 210, 230, 210));
        static readonly Brush scopeLineBrush = new SolidColorBrush(Colors.Blue);

        private void AddStackItems()
        {
            this.stackCanvas.Children.Clear();

            int index = 0;

            foreach (var item in this.heap.Stack.Items)
            {
                if (item.GetType() == typeof(StackValueItem))
                {
                    var text = string.Format("{0}: {1}", item.UserData["name"], ((StackValueItem)item).Value);
                    AddStackItem(index, text, stackValueBrush);
                }
                else if (item.GetType() == typeof(StackReferenceItem))
                {
                    var text = item.UserData["name"] as string;
                    AddStackItem(index, text, stackRefBrush);
                }

                index++;
            }

            // stack scope
            AddStackScopeBound();
        }

        private void AddStackItem(int i, string content, Brush brush)
        {
            var elem = new TextBox
            {
                Text = content,
                Background = brush,
                Width = this.blockSize * 2,
                Height = this.blockSize,
            };
            Canvas.SetTop(elem, this.GetStackLocation(i));
            this.stackCanvas.Children.Add(elem);
        }
    }
}
