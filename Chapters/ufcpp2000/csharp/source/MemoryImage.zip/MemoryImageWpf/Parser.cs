﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using MemoryImage.Statement;
using S = MemoryImage.Statement.Statement;

namespace MemoryImage
{
    public class Parser
    {
        class TagPattern
        {
            public string Tag;
            public string Pattern;
            public Func<Match, IStatement> Action;
        }

        static int ParseInt(string str)
        {
            int result;
            if (int.TryParse(str, out result))
                return result;
            else
                return 0;
        }

        static IStatement OpenBrace(Match m)
        {
            return S.EnterScope();
        }

        static IStatement CloseBrace(Match m)
        {
            return S.LeaveScope();
        }

        static IStatement ByValue(Match m)
        {
            var name = m.Groups["name"].Value;
            var value = ParseInt(m.Groups["value"].Value);
            return S.Value(name, value);
        }

        static IStatement ByReference(Match m)
        {
            var name = m.Groups["name"].Value;
            var size = ParseInt(m.Groups["size"].Value);
            var referers = whitespace.Split(m.Groups["referers"].Value).Where(x => !string.IsNullOrEmpty(x)).ToArray();
            return S.Reference(name, size, referers);
        }

        static readonly Regex whitespace = new Regex(@"\s+");

        static readonly TagPattern[] patterns = new[]
        {
            new TagPattern { Tag = "open", Pattern = @"\{", Action = OpenBrace },
            new TagPattern { Tag = "close", Pattern = @"\}", Action = CloseBrace },
            new TagPattern { Tag = "byval", Pattern = @"(?<name>\w+)\s*=\s*(?<value>\d+)", Action = ByValue },
            new TagPattern { Tag = "byref", Pattern = @"(?<name>\w+)\s*=\s*new\s*\[\s*(?<size>\d+)\s*\](\s*\{(?<referers>[\s\w]*)\})?", Action = ByReference},
        };

        static Regex syntax;

        static Parser()
        {

            StringBuilder sb = new StringBuilder();
            bool first = true;
            foreach (var p in patterns)
            {
                if (first) first = false;
                else sb.Append("|");

                sb.AppendFormat("(?<{0}>{1})", p.Tag, p.Pattern);
            }

            syntax = new Regex(sb.ToString(), RegexOptions.Multiline);
        }

        public static IEnumerable<IStatement> Parse(string source)
        {
            var m = syntax.Match(source);

            for (; m.Success; m = m.NextMatch())
            {
                foreach (var p in patterns)
                {
                    if (m.Groups[p.Tag].Success)
                    {
                        yield return p.Action(m);
                    }
                }
            }
        }
    }
}
