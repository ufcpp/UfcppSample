﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MemoryImage.Statement
{
    public class ParseException : Exception
    {
        public ParseException() { }
        public ParseException(string msg) : base(msg) { }
        public ParseException(string msg, Exception inner) : base(msg, inner) { }
    }

    public interface IStatement
    {
        void Action(HeapEmulator heap, Dictionary<string, HeapBlock> variables);
        int Indent { get; }
    }

    public static class Statement
    {
        public static IStatement Value(string name, int value)
        {
            return new ValueStatement { Name = name, Value = value };
        }

        public static IStatement Reference(string name, int size, params string[] children)
        {
            return new ReferenceStatement { Name = name, Size = size, ReferencedFrom = children.ToList() };
        }

        public static IStatement EnterScope()
        {
            return new EnterScopeStatement();
        }

        public static IStatement LeaveScope()
        {
            return new LeaveScopeStatement();
        }
    }

    class ValueStatement : IStatement
    {
        public string Name { set; get; }
        public int Value { set; get; }

        public void Action(HeapEmulator heap, Dictionary<string, HeapBlock> variables)
        {
            var item = new StackValueItem { Value = this.Value };
            item.UserData["name"] = this.Name;
            heap.Stack.Add(item);
        }

        public int Indent { get { return 0; } }

        public override string ToString()
        {
            return string.Format("{0} = {1}", this.Name, this.Value);
        }
    }

    class ReferenceStatement : IStatement
    {
        public string Name { set; get; }
        public int Size { set; get; }
        public List<string> ReferencedFrom { set; get; }

        public void Action(HeapEmulator heap, Dictionary<string, HeapBlock> variables)
        {
            var block = heap.New(this.Size);
            block.UserData["name"] = this.Name;

            foreach (var name in this.ReferencedFrom)
            {
                if (string.IsNullOrEmpty(name)) continue;

                if (!variables.ContainsKey(name))
                {
                    throw new ParseException("存在しない変数からの参照を設定しようとしました");
                }

                var refFrom = variables[name];
                refFrom.Children.Add(block);
            }

            variables[this.Name] = block;
            //todo: ↑変数がすでに存在するときに例外を

            var item = new StackReferenceItem { Destination = block };
            item.UserData["name"] = this.Name;
            heap.Stack.Add(item);
        }

        public int Indent { get { return 0; } }

        public override string ToString()
        {
            return string.Format("{0} = new[{1}]{2}", this.Name, this.Size, this.ChildrenToString());
        }

        string ChildrenToString()
        {
            if (this.ReferencedFrom.Count == 0) return string.Empty;

            var sb = new StringBuilder();
            sb.Append("{ ");
            foreach (var c in this.ReferencedFrom)
            {
                sb.Append(c);
                sb.Append(' ');
            }
            sb.Append('}');
            return sb.ToString();
        }
    }

    class EnterScopeStatement : IStatement
    {
        public void Action(HeapEmulator heap, Dictionary<string, HeapBlock> variables)
        {
            heap.Stack.EnterScope();
        }

        public int Indent { get { return 1; } }

        public override string ToString()
        {
            return "{";
        }
    }

    class LeaveScopeStatement : IStatement
    {
        public void Action(HeapEmulator heap, Dictionary<string, HeapBlock> variables)
        {
            heap.Stack.LeaveScope();
        }

        public int Indent { get { return -1; } }

        public override string ToString()
        {
            return "}";
        }
    }

}
