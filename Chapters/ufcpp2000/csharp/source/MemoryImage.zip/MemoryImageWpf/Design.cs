﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows;

namespace MemoryImage
{
    public class Design
    {
        private const double Rate = 0.8;

        private static Color Brighter(Color c)
        {
            var r = (byte)(255 - Rate * (255 - c.R));
            var g = (byte)(255 - Rate * (255 - c.G));
            var b = (byte)(255 - Rate * (255 - c.B));
            return Color.FromArgb(255, r, g, b);
        }

        private static Color Darker(Color c)
        {
            var r = (byte)(Rate * (c.R));
            var g = (byte)(Rate * (c.G));
            var b = (byte)(Rate * (c.B));
            return Color.FromArgb(255, r, g, b);
        }

        public static Brush CreateBrush(Color c)
        {
            var b = Brighter(c);
            var d = Darker(c);
            return new LinearGradientBrush
                {
                    GradientStops = {
                        new GradientStop { Color = b, Offset = 0 },
                        new GradientStop { Color = b, Offset = 0.1 },
                        new GradientStop { Color = c, Offset = 0.5 },
                        new GradientStop { Color = d, Offset = 0.9 },
                        new GradientStop { Color = d, Offset = 1 },
                    },
                    StartPoint = new Point(0, 0),
                    EndPoint = new Point(1, 1),
                };
        }

        public static Brush CreateBrushV(Color c) // 縦方向のグラデーション
        {
            var b = Brighter(c);
            var d = Darker(c);
            return new LinearGradientBrush
            {
                GradientStops = {
                        new GradientStop { Color = b, Offset = 0 },
                        new GradientStop { Color = b, Offset = 0.1 },
                        new GradientStop { Color = c, Offset = 0.5 },
                        new GradientStop { Color = d, Offset = 0.9 },
                        new GradientStop { Color = d, Offset = 1 },
                    },
                StartPoint = new Point(0, 0),
                EndPoint = new Point(0, 1),
            };
        }
    }
}
