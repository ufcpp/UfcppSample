﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MemoryImage
{
    /// <summary>
    /// スタック要素。
    /// </summary>
    public abstract class StackItem
    {
        Dictionary<string, object> userData = new Dictionary<string, object>();

        /// <summary>
        /// スタックのエミュレーションとは関係なく、
        /// 表示側で使うためのデータを格納しておくためのおまけ領域。
        /// </summary>
        public Dictionary<string, object> UserData
        {
            get { return this.userData; }
        }
    }

    /// <summary>
    /// 値型。
    /// </summary>
    public class StackValueItem : StackItem
    {
        /// <summary>
        /// 保持している値。
        /// </summary>
        public int Value { set; get; }
    }

    /// <summary>
    /// 参照型。
    /// </summary>
    public class StackReferenceItem : StackItem
    {
        /// <summary>
        /// 参照先。
        /// </summary>
        public HeapBlock Destination { set; get; }
    }

    /// <summary>
    /// スタック。
    /// </summary>
    public class StackEmulator
    {
        /// <summary>
        /// スタックに積まれた要素一覧。
        /// </summary>
        List<StackItem> items = new List<StackItem>();

        /// <summary>
        /// 現在のスコープにある要素数。
        /// </summary>
        List<int> scopes = new List<int>();

        /// <summary>
        /// スタックサイズ。
        /// </summary>
        int capacity;

        /// <summary>
        /// 初期化。
        /// </summary>
        public StackEmulator(int capacity)
        {
            this.capacity = capacity;
            this.scopes.Add(0);
        }

        public void Clear()
        {
            this.scopes.Clear();
            this.scopes.Add(0);
            this.items.Clear();
        }

        /// <summary>
        /// 要素一覧。
        /// </summary>
        public IEnumerable<StackItem> Items
        {
            get { return this.items; }
        }

        /// <summary>
        /// スコープ内の要素数を、最上位スコープから順に返す。
        /// </summary>
        public IEnumerable<int> Scopes
        {
            get { return this.scopes; }
        }

        /// <summary>
        /// 現在のスコープ内のスタック要素数。
        /// </summary>
        int ItemsInCurrenScope
        {
            get { return this.scopes[this.scopes.Count - 1]; }
            set { this.scopes[this.scopes.Count - 1] = value; }
        }

        /// <summary>
        /// 新たに要素を積む。
        /// </summary>
        /// <param name="item">新しい要素。</param>
        public void Add(StackItem item)
        {
            if (this.items.Count == this.capacity)
            {
                //todo: throw stack overflow
            }

            this.items.Add(item);
            this.ItemsInCurrenScope++;
        }

        /// <summary>
        /// 新たにスコープを作る。
        /// </summary>
        public void EnterScope()
        {
            this.scopes.Add(0);
        }

        /// <summary>
        /// スコープから抜ける。
        /// </summary>
        public void LeaveScope()
        {
            if (this.scopes.Count == 0)
                return; //todo: 例外投げた方がいい？

            var count = this.ItemsInCurrenScope;
            this.items.RemoveRange(this.items.Count - count, count);
            this.scopes.RemoveAt(this.scopes.Count - 1);
        }
    }
}
