﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MemoryImage
{
    /// <summary>
    /// ヒープに確保したブロック。
    /// </summary>
    public class HeapBlock
    {
        /// <summary>
        /// 先頭アドレス。
        /// </summary>
        public int Location { set; get; }

        /// <summary>
        /// 割り当てサイズ。
        /// </summary>
        public int Size { set; get; }

        /// <summary>
        /// Mark ＆ Sweep ガベコレ用のフラグ。
        /// </summary>
        public bool Mark { set; get; }

        List<HeapBlock> children = new List<HeapBlock>();

        /// <summary>
        /// 子として参照している他のブロック情報。
        /// </summary>
        public List<HeapBlock> Children
        {
            get { return children; }
            set { children = value; }
        }

        Dictionary<string, object> userData = new Dictionary<string, object>();

        /// <summary>
        /// ヒープのエミュレーションとは関係なく、
        /// 表示側で使うためのデータを格納しておくためのおまけ領域。
        /// </summary>
        public Dictionary<string, object> UserData
        {
            get { return this.userData; }
        }
    }

    /// <summary>
    /// ヒープ。
    /// </summary>
    public class HeapEmulator
    {
        /// <summary>
        /// 現在確保中のブロック一覧。
        /// </summary>
        List<HeapBlock> blocks = new List<HeapBlock>();

        /// <summary>
        /// 現在確保中のブロック一覧を取得。
        /// </summary>
        public IEnumerable<HeapBlock> Blocks
        {
            get { return this.blocks; }
        }

        /// <summary>
        /// 現在確保中のブロックの最後尾位置。
        /// </summary>
        int last = 0;

        /// <summary>
        /// ヒープ容量。
        /// </summary>
        int capacity;

        StackEmulator stack;

        public StackEmulator Stack
        {
            get { return stack; }
        }

        public HeapEmulator(int capacity, StackEmulator stack)
        {
            this.capacity = capacity;
            this.stack = stack;
        }

        public void Clear()
        {
            this.stack.Clear();
            this.blocks.Clear();
            this.last = 0;
        }

        /// <summary>
        /// 指定サイズ分の領域を確保。
        /// </summary>
        /// <param name="size">確保したいサイズ。</param>
        /// <returns>確保した領域。</returns>
        public HeapBlock New(int size)
        {
            if (this.capacity < size + this.last)
            {
                this.GabageCollect();

                if (this.capacity < size + this.last)
                {
                    //todo: throw out of memory
                }
            }

            var block = new HeapBlock
            {
                Location = this.last,
                Size = size,
            };

            this.blocks.Add(block);
            this.last += size;

            return block;
        }

        /// <summary>
        /// ガベコレする。
        /// </summary>
        /// <param name="stackItems">スタック中の要素一覧。</param>
        public void GabageCollect()
        {
            Mark();
            RemoveMarked();
            Rearrenge();
        }

        /// <summary>
        /// 再配置。
        /// </summary>
        private void Rearrenge()
        {
            if (this.blocks.Count == 0)
                return;

            var prev = 0;
            foreach (var block in this.blocks)
            {
                block.Location = prev;
                prev += block.Size;
            }

            this.last = prev;
        }

        /// <summary>
        /// マーク済み要素の削除。
        /// </summary>
        private void RemoveMarked()
        {
            var removed = this.blocks.Where(x => !x.Mark).ToList();

            foreach (var x in removed)
            {
                this.blocks.Remove(x);
            }
            //this.blocks.RemoveAll(x => !x.Mark);
        }

        /// <summary>
        /// スタックからたどれるブロックをマーク。
        /// </summary>
        public void Mark()
        {
            ClearMark();
            Mark(this.stack.Items);
        }

        /// <summary>
        /// マークをいったん外す。
        /// </summary>
        private void ClearMark()
        {
            foreach (var x in this.blocks)
            {
                x.Mark = false;
            }
        }

        /// <summary>
        /// スタックからたどれるブロックをマーク。
        /// </summary>
        /// <param name="stackItems">スタック中の要素一覧。</param>
        private static void Mark(IEnumerable<StackItem> stackItems)
        {
            var references = stackItems.OfType<StackReferenceItem>().Select(x => x.Destination);

            foreach (var r in references)
            {
                Mark(r);
            }
        }

        /// <summary>
        /// 自分と参照先をマーク。
        /// </summary>
        /// <param name="block">ブロック。</param>
        private static void Mark(HeapBlock block)
        {
            if (block.Mark)
            {
                return;
            }

            block.Mark = true;

            foreach (var child in block.Children)
            {
                Mark(child);
            }
        }
    }
}
