﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace MemoryImage
{
    using S = Statement.Statement;
    using System.Text;

    public partial class MainPage : UserControl
    {
        const double BlockSize = 24;
        const int HeapHeight = 20;
        const int HeapWidth = 20;

        List<Statement.IStatement> statements;

        HeapEmulator heap;
        Dictionary<string, HeapBlock> variables;
        int current = 0;

        public MainPage()
        {
            InitializeComponent();

            this.statements = Parser.Parse(@"
{
    x = 0
    a = new[135]
    {
        b = new [50]
        y = 50
        {
            c = new[22] { a b }
            d = new[150]
        }azsrxtyguh rcvt yix cvt crvityub ctv
        z = 100
        e = new[38]
        {
            f = new[143]
            g = new[5]
            {
                b
                e
            }
        }
        {
            h = new[111]
        }
    }
    i=new[90]
    w=0
}
").ToList();

            this.Loaded += new RoutedEventHandler(Window1_Loaded);
            //this.heapView.PreviewMouseDown += new MouseButtonEventHandler(Window1_MouseDown);
            this.statementList.SelectionChanged += new SelectionChangedEventHandler(statementList_SelectionChanged);
            this.editButton.Click += new RoutedEventHandler(editButton_Click);
            this.okButton.Click += new RoutedEventHandler(okButton_Click);
            this.cancelButton.Click += new RoutedEventHandler(cancelButton_Click);
        }

        void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.editPane.Visibility = Visibility.Collapsed;
        }

        void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.statements = Parser.Parse(this.sourceText.Text).ToList();
            this.ShowStatementList();
            this.current = 0;
            this.heap.Clear();
            this.variables.Clear();
            this.heapView.Update();

            this.editPane.Visibility = Visibility.Collapsed;
        }

        void editButton_Click(object sender, RoutedEventArgs e)
        {
            this.sourceText.Text = this.StatementsToString();
            this.editPane.Visibility = Visibility.Visible;
            this.sourceText.Focus();
        }

        void statementList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var count = this.statementList.SelectedIndex + 1;
            this.heap.Clear();
            this.variables.Clear();

            foreach (var s in this.statements.Take(count))
            {
                try
                {
                    s.Action(this.heap, this.variables);
                }
                catch (Statement.ParseException)
                {
                    //todo: 何かエラーメッセージを
                }
            }

            this.current = count;

            this.heapView.Update();
        }

        void Window1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (this.current >= this.statements.Count)
            {
                // 実行終了
                return;
            }

            var s = this.statements[this.current];
            try
            {
                s.Action(this.heap, this.variables);
            }
            catch (Statement.ParseException)
            {
                //todo: 何かエラーメッセージを
            }

            this.current++;

            this.statementList.SelectedIndex++;

            this.heapView.Update();
        }

        void Window1_Loaded(object sender, RoutedEventArgs e)
        {
            this.ShowStatementList();

            var stack = new StackEmulator(HeapHeight);
            this.heap = new HeapEmulator(HeapHeight * HeapWidth, stack);
            this.variables = new Dictionary<string, HeapBlock>();
            this.current = 0;

            this.heapView.Initialize(heap, BlockSize, HeapWidth, HeapHeight);
        }

        string StatementsToString()
        {
            StringBuilder sb = new StringBuilder();
            int indentSize = 0;

            foreach (var s in this.statements)
            {
                if (s.Indent == -1)
                {
                    indentSize--;
                    if (indentSize < 0) break;
                }

                sb.AppendFormat("{0}{1}", new string(' ', 2 * indentSize), s);
                sb.AppendLine();

                if (s.Indent == 1)
                {
                    indentSize++;
                }
            }

            return sb.ToString();
        }

        void ShowStatementList()
        {
            this.statementList.Items.Clear();

            int indentSize = 0;

            foreach (var s in this.statements)
            {
                if (s.Indent == -1)
                {
                    indentSize--;
                    if (indentSize < 0) return;
                }

                var str = new string(' ', 2 * indentSize) + s.ToString();
                this.statementList.Items.Add(new ContentControl { Content = str });

                if (s.Indent == 1)
                {
                    indentSize++;
                }
            }
        }
    }
}
