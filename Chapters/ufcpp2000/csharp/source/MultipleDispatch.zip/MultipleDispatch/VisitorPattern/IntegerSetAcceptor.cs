﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.VisitorPattern
{
    public abstract class IntegerSetAcceptor : IntegerSet
    {
        public override bool Equals(IntegerSet other)
        {
            return this.Equals((IntegerSetAcceptor)other);
        }

        public abstract bool Equals(IntegerSetAcceptor other);
        public abstract bool Equals(Element other);
        public abstract bool Equals(Range other);
        public abstract bool Equals(List other);
    }
}
