﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.VisitorPattern
{
    public class Range : IntegerSetAcceptor
    {
        public int Minimum { get; set; }
        public int Maximum { get; set; }

        public Range(int min, int max)
        {
            Minimum = min;
            Maximum = max;
        }

        public override bool Equals(IntegerSetAcceptor other)
        {
            return other.Equals(this);
        }

        public override bool Equals(Element other)
        {
            return false;
        }

        public override bool Equals(Range other)
        {
            return Minimum == other.Minimum && Maximum == other.Maximum;
        }

        public override bool Equals(List other)
        {
            return this.Contains(other) && other.Contains(this);
        }

        public override bool Contains(IntegerSet other)
        {
            if (other is Element) return Contains((Element)other);
            if (other is Range) return Contains((Range)other);
            if (other is List) return Contains((List)other);
            return false;
        }

        public bool Contains(Element other)
        {
            return Minimum <= other.Value && other.Value <= Maximum;
        }

        public bool Contains(Range other)
        {
            return Minimum <= other.Minimum && other.Maximum <= Maximum;
        }

        public bool Contains(List other)
        {
            foreach (var v in other.Values)
            {
                if (Minimum > v || v > Maximum)
                    return false;
            }
            return true;
        }
    }
}
