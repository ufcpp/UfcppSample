﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.VisitorPattern
{
    public class List : IntegerSetAcceptor
    {
        public List<int> Values { get; set; }

        public List(params int[] v) : this((IEnumerable<int>)v) { }
        public List(IEnumerable<int> v) { Values = new List<int>(v); }

        public override bool Equals(IntegerSetAcceptor other)
        {
            return other.Equals(this);
        }

        public override bool Equals(Element other)
        {
            return false;
        }

        public override bool Equals(List other)
        {
            return Values.SequenceEqual(other.Values);
        }

        public override bool Equals(Range other)
        {
            return this.Contains(other) && other.Contains(this);
        }

        public override bool Contains(IntegerSet other)
        {
            if (other is List) return Contains((List)other);
            if (other is Range) return Contains((Range)other);
            if (other is Element) return Contains((Element)other);
            return false;
        }

        public bool Contains(Element other)
        {
            return Values.Contains(other.Value);
        }

        public bool Contains(Range other)
        {
            for (int v = other.Minimum; v <= other.Maximum; v++)
            {
                if (!Values.Contains(v))
                    return false;
            }
            return true;
        }

        public bool Contains(List other)
        {
            foreach (var v in other.Values)
            {
                if (!Values.Contains(v))
                    return false;
            }
            return true;
        }
    }
}
