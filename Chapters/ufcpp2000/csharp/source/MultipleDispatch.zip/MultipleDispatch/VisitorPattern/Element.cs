﻿using System.Collections.Generic;
using System.Linq;

namespace MultipleDispatch.VisitorPattern
{
    public class Element : IntegerSetAcceptor
    {
        public int Value { get; set; }

        public Element(int v) { Value = v; }

        public override bool Equals(IntegerSetAcceptor other)
        {
            return other.Equals(this);
        }

        public override bool Equals(Element other)
        {
            return Value == other.Value;
        }

        public override bool Equals(Range other)
        {
            return false;
        }

        public override bool Equals(List other)
        {
            return false;
        }

        public override bool Contains(IntegerSet other)
        {
            return this.Equals(other);
        }
    }
}
