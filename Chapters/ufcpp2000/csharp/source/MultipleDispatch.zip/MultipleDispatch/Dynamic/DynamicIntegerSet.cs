﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.Dynamic
{
    public class DynamicIntegerSet : IntegerSet
    {
        public override bool Equals(IntegerSet other)
        {
            return DynamicEquals(this, other);
        }

        public override bool Contains(IntegerSet other)
        {
            return DynamicContains(this, other);
        }

        public static bool DynamicEquals(dynamic x, dynamic y)
        {
            return IntegerSetComparer.Equals(x, y);
        }

        public static bool DynamicContains(dynamic x, dynamic y)
        {
            return IntegerSetComparer.Contains(x, y);
        }
    }
}
