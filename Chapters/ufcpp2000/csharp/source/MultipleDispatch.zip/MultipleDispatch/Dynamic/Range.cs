﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.Dynamic
{
    public class Range : DynamicIntegerSet
    {
        public int Minimum { get; set; }
        public int Maximum { get; set; }

        public Range(int min, int max)
        {
            Minimum = min;
            Maximum = max;
        }
    }
}
