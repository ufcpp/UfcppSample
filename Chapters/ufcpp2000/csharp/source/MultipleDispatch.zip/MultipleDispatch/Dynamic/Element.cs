﻿using System.Collections.Generic;
using System.Linq;

namespace MultipleDispatch.Dynamic
{
    public class Element : DynamicIntegerSet
    {
        public int Value { get; set; }

        public Element(int v) { Value = v; }
    }
}
