﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.Dynamic
{
    public class List : DynamicIntegerSet
    {
        public List<int> Values { get; set; }

        public List(params int[] v) : this((IEnumerable<int>)v) { }
        public List(IEnumerable<int> v) { Values = new List<int>(v); }
    }
}
