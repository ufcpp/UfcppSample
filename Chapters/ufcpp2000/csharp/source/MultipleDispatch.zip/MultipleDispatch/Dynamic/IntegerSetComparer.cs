﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.Dynamic
{
    class IntegerSetComparer
    {
        public static bool Equals(Element x, Element y)
        {
            return x.Value == y.Value;
        }
        public static bool Equals(Element x, Range y) { return false; }
        public static bool Equals(Range x, Element y) { return false; }
        public static bool Equals(Element x, List y) { return false; }
        public static bool Equals(List x, Element y) { return false; }

        public static bool Equals(Range x, Range y)
        {
            return x.Minimum == y.Minimum && x.Maximum == y.Maximum;
        }

        public static bool Equals(List x, Range y)
        {
            return Equals(y, x);
        }

        public static bool Equals(Range x, List y)
        {
            return Contains(x, y) && Contains(y, x);
        }

        public static bool Equals(List x, List y)
        {
            return x.Values.SequenceEqual(y.Values);
        }

        public static bool Contains(Element x, Element y)
        {
            return Equals(x, y);
        }

        public static bool Contains(Element x, Range y) { return false; }

        public static bool Contains(Range x, Element y)
        {
            return x.Minimum <= y.Value && y.Value <= x.Maximum;
        }

        public static bool Contains(Element x, List y) { return false; }

        public static bool Contains(List x, Element y)
        {
            return x.Values.Contains(y.Value);
        }

        public static bool Contains(Range x, Range y)
        {
            return x.Minimum <= y.Minimum && y.Maximum <= x.Maximum;
        }

        public static bool Contains(List x, Range y)
        {
            for (int v = y.Minimum; v <= y.Maximum; v++)
            {
                if (!x.Values.Contains(v))
                    return false;
            }
            return true;
        }

        public static bool Contains(Range x, List y)
        {
            foreach (var v in y.Values)
            {
                if (x.Minimum > v || v > x.Maximum)
                    return false;
            }
            return true;
        }

        public static bool Contains(List x, List y)
        {
            foreach (var v in y.Values)
            {
                if (!x.Values.Contains(v))
                    return false;
            }
            return true;
        }
    }
}
