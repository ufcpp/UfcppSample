﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace MultipleDispatch
{
    class Program
    {
        static void Main(string[] args)
        {
            TestIntegerSet(new MultipleDispatch.CastSwitch.Factory());
            TestIntegerSet(new MultipleDispatch.CastOverload.Factory());
            TestIntegerSet(new MultipleDispatch.VisitorPattern.Factory());
            TestIntegerSet(new MultipleDispatch.Dynamic.Factory());
        }

        /// <summary>
        /// テスト用。
        /// Professional 以上のグレードの Visual Studio を持ってるならテストプロジェクトを作ってそっちに書いた方がいいようなコード。
        /// </summary>
        /// <param name="factory">IntegerSet のファクトリ。</param>
        static void TestIntegerSet(Factory factory)
        {
            Debug.Assert(factory.Element(1).Equals(factory.Element(1)));
            Debug.Assert(!factory.Element(1).Equals(factory.Element(2)));
            Debug.Assert(factory.Element(1).Equals(factory.Range(1, 1)));
            Debug.Assert(!factory.Element(1).Equals(factory.Range(1, 2)));
            Debug.Assert(factory.Element(1).Equals(factory.List(1)));
            Debug.Assert(factory.Element(1).Equals(factory.List(1, 1)));
            Debug.Assert(!factory.Element(1).Equals(factory.List(1, 2)));

            Debug.Assert(factory.Element(1).Contains(factory.Element(1)));
            Debug.Assert(!factory.Element(1).Contains(factory.Element(2)));
            Debug.Assert(factory.Element(1).Contains(factory.Range(1, 1)));
            Debug.Assert(!factory.Element(1).Contains(factory.Range(1, 2)));
            Debug.Assert(factory.Element(1).Contains(factory.List(1)));
            Debug.Assert(factory.Element(1).Contains(factory.List(1, 1)));
            Debug.Assert(!factory.Element(1).Contains(factory.List(1, 2)));

            Debug.Assert(factory.Range(1, 4).Equals(factory.Range(1, 4)));
            Debug.Assert(!factory.Range(1, 4).Equals(factory.Range(1, 5)));
            Debug.Assert(!factory.Range(1, 4).Equals(factory.Range(2, 4)));
            Debug.Assert(!factory.Range(1, 4).Equals(factory.Element(1)));
            Debug.Assert(!factory.Range(1, 4).Equals(factory.List(1, 2, 3)));
            Debug.Assert(factory.Range(1, 4).Equals(factory.List(1, 2, 3, 4)));

            Debug.Assert(factory.Range(1, 4).Contains(factory.Range(1, 4)));
            Debug.Assert(!factory.Range(1, 4).Contains(factory.Range(1, 5)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.Range(1, 3)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.Range(2, 3)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.Range(2, 4)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.Element(1)));
            Debug.Assert(!factory.Range(1, 4).Contains(factory.Element(5)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.List(1, 2, 3)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.List(1, 3, 4)));
            Debug.Assert(factory.Range(1, 4).Contains(factory.List(1, 2, 3, 4)));
            Debug.Assert(!factory.Range(1, 4).Contains(factory.List(1, 2, 3, 4, 5)));
            Debug.Assert(!factory.Range(1, 4).Contains(factory.List(1, 4, 5)));

            Debug.Assert(factory.List(1, 2, 3).Equals(factory.List(1, 2, 3)));
            Debug.Assert(!factory.List(1, 2, 3).Equals(factory.List(1, 3)));
            Debug.Assert(!factory.List(1, 2, 3).Equals(factory.Element(1)));
            Debug.Assert(factory.List(1, 2, 3).Equals(factory.Range(1, 3)));

            Debug.Assert(factory.List(1, 2, 3).Contains(factory.List(1, 2, 3)));
            Debug.Assert(factory.List(1, 2, 3, 4).Contains(factory.List(1, 3)));
            Debug.Assert(factory.List(1, 2, 3, 4).Contains(factory.Range(2, 3)));
            Debug.Assert(!factory.List(1, 2, 3, 4).Contains(factory.Range(2, 5)));
            Debug.Assert(factory.List(1, 3, 5).Contains(factory.Element(1)));
            Debug.Assert(factory.List(1, 3, 5).Contains(factory.Element(3)));
            Debug.Assert(factory.List(1, 3, 5).Contains(factory.Element(5)));
            Debug.Assert(!factory.List(1, 3, 5).Contains(factory.Element(2)));
        }
    }
}
