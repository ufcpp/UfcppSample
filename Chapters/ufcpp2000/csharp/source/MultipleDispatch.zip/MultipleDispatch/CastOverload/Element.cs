﻿using System.Collections.Generic;
using System.Linq;

namespace MultipleDispatch.CastOverload
{
    public class Element : IntegerSet
    {
        public int Value { get; set; }

        public Element(int v) { Value = v; }

        public override bool Equals(IntegerSet other)
        {
            if (other is Element) return Equals((Element)other);
            return false;
        }

        public bool Equals(Element other)
        {
            return Value == other.Value;
        }

        public override bool Contains(IntegerSet other)
        {
            return this.Equals(other);
        }
    }
}
