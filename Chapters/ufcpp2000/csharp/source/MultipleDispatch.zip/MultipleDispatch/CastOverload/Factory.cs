﻿using System.Collections.Generic;
using System.Linq;

namespace MultipleDispatch.CastOverload
{
    public class Factory : MultipleDispatch.Factory
    {
        public IntegerSet Element(int v) { return new Element(v); }
        public IntegerSet Range(int min, int max)
        {
            if (min < max)
                return new Range(min, max);
            else if (min > max)
                return new Range(max, min);
            else
                return new Element(min);
        }
        public IntegerSet List(params int[] v)
        {
            return List((IEnumerable<int>)v);
        }
        public IntegerSet List(IEnumerable<int> v)
        {
            v = v.Distinct();
            if (v.Count() == 1)
                return new Element(v.First());
            return new List(v);
        }
    }
}
