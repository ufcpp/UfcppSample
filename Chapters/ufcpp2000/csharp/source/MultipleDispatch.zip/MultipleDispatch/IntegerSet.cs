﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch
{
    /// <summary>
    /// 整数の部分集合。
    /// </summary>
    public abstract class IntegerSet
    {
        public abstract bool Equals(IntegerSet other);
        public abstract bool Contains(IntegerSet other);
    }

    /// <summary>
    /// IntegerSet のファクトリ。
    /// 何パターンか、別の実装を作って比較するので、いったんファクトリを通してインスタンスを生成する。
    /// </summary>
    public interface Factory
    {
        /// <summary>
        /// 1つの元だけを含む集合 { v }。
        /// </summary>
        /// <param name="v">元。</param>
        /// <returns>作った集合。</returns>
        IntegerSet Element(int v);

        /// <summary>
        /// 範囲 { x ∈ Z : min ≦ x ≦ max }。
        /// </summary>
        /// <param name="min">最小値。</param>
        /// <param name="max">最大値。</param>
        /// <returns>作った集合。</returns>
        IntegerSet Range(int min, int max);

        /// <summary>
        /// 複数の元からなる集合 { x ∈ v }。
        /// </summary>
        /// <param name="v">含む元のリスト。</param>
        /// <returns>作った集合。</returns>
        IntegerSet List(params int[] v);

        /// <summary>
        /// 複数の元からなる集合 { x ∈ v }。
        /// </summary>
        /// <param name="v">含む元のリスト。</param>
        /// <returns>作った集合。</returns>
        IntegerSet List(IEnumerable<int> v);
    }
}
