﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.CastSwitch
{
    public class Range : IntegerSet
    {
        public int Minimum { get; set; }
        public int Maximum { get; set; }

        public Range(int min, int max)
        {
            Minimum = min;
            Maximum = max;
        }

        public override bool Equals(IntegerSet other)
        {
            var x = other as Range;
            if (x != null)
                return Minimum == x.Minimum && Maximum == x.Maximum;

            var y = other as List;
            if (y != null)
                return this.Contains(y) && y.Contains(this);

            return false;
        }

        public override bool Contains(IntegerSet other)
        {
            var x = other as Element;
            if (x != null)
                return Minimum <= x.Value && x.Value <= Maximum;

            var y = other as Range;
            if (y != null)
                return Minimum <= y.Minimum && y.Maximum <= Maximum;

            var z = other as List;
            if (z != null)
            {
                foreach (var v in z.Values)
                {
                    if (Minimum > v || v > Maximum)
                        return false;
                }
                return true;
            }

            return false;
        }
    }
}
