﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultipleDispatch.CastSwitch
{
    public class List : IntegerSet
    {
        public List<int> Values { get; set; }

        public List(params int[] v) : this((IEnumerable<int>)v) { }
        public List(IEnumerable<int> v) { Values = new List<int>(v); }

        public override bool Equals(IntegerSet other)
        {
            var x = other as List;
            if (x != null)
                return Values.SequenceEqual(x.Values);

            var y = other as Range;
            if (y != null)
                return this.Contains(y) && y.Contains(this);

            return false;
        }

        public override bool Contains(IntegerSet other)
        {
            var x = other as Element;
            if (x != null)
                return Values.Contains(x.Value);

            var y = other as Range;
            if (y != null)
            {
                for (int v = y.Minimum; v <= y.Maximum; v++)
                {
                    if (!Values.Contains(v))
                        return false;
                }
                return true;
            }

            var z = other as List;
            if (z != null)
            {
                foreach (var v in z.Values)
                {
                    if (!Values.Contains(v))
                        return false;
                }
                return true;
            }

            return false;
        }
    }
}
