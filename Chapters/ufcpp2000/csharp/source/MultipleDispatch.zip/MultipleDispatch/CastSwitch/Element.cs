﻿using System.Collections.Generic;
using System.Linq;

namespace MultipleDispatch.CastSwitch
{
    public class Element : IntegerSet
    {
        public int Value { get; set; }

        public Element(int v) { Value = v; }

        public override bool Equals(IntegerSet other)
        {
            var x = other as Element;
            return x != null && Value == x.Value;
        }

        public override bool Contains(IntegerSet other)
        {
            return this.Equals(other);
        }
    }
}
