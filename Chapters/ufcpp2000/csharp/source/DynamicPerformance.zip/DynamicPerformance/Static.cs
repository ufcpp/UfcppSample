﻿
namespace DynamicPerformance
{
    /// <summary>
    /// 通常版。
    /// コンパイル時に型が確定していればわざわざ動的生成する必要はないわけで。
    /// もちろん性能一番いい。
    /// </summary>
    public class Static
    {
        public static int Sum(Point p)
        {
            return p.X + p.Y;
        }
    }
}
