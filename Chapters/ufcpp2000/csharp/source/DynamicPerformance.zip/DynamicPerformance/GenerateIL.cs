﻿using System;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace DynamicPerformance
{
    /// <summary>
    /// 実行時計算その2。
    /// IL 生成。
    /// 
    /// 毎回リフレクションを使っていたらかなり遅いので、実行時コード生成して、生成したものをキャッシュしておくことになる。
    /// キャッシュさえしてしまえば、Static な実装と比べて数倍程度のペナルティで済むはず。
    /// もちろん、初回実行時が少々遅くなるはずだけど、呼び出し回数が多ければ気にならなくなる。
    /// 
    /// 実行時コード生成の仕組みはいくつかあるけども、まずは 2.0 の頃から使えた ILGenerator クラスの利用。
    /// 
    /// MSIL を直接生成。
    /// アセンブリ言語で書くのと完全に同じ労力なので、正直いうと最後の手段。
    /// 式木や dynamic が使えるようになった今、あえて使う必要もないと思う。
    /// </summary>
    public class GenerateIL
    {
        private static Dictionary<Type, Func<object, int>> cache = new Dictionary<Type,Func<object,int>>();

        public static int Sum(object p)
        {
            var t = p.GetType();
            Func<object, int> d;

            if (!cache.TryGetValue(t, out d))
            {
                d = CreateMethod(t);
                cache[t] = d;
            }

            return d(p);
        }

        private static Func<object, int> CreateMethod(Type t)
        {
            DynamicMethod dm = new DynamicMethod("Sum", typeof(int), new[] { typeof(object) });
            ILGenerator il = dm.GetILGenerator();

            LocalBuilder x = il.DeclareLocal(t);

            // var x = (Point)p;
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, t);
            il.Emit(OpCodes.Stloc, x);

            // p.X
            il.Emit(OpCodes.Ldloc, x);
            il.EmitCall(OpCodes.Callvirt, t.GetProperty("X").GetGetMethod(), null);

            // p.Y
            il.Emit(OpCodes.Ldloc, x);
            il.EmitCall(OpCodes.Callvirt, t.GetProperty("Y").GetGetMethod(), null);

            // +
            // ちなみに、今回の場合は「p.X は必ず int」という前提なのでコード生成は楽だけど、
            // もしこれがユーザー定義型で、 + もユーザー定義の operator+ だったら、OpCodes.Add じゃなくて Call に変えなきゃいけない。
            // かなり面倒。
            il.Emit(OpCodes.Add);

            il.Emit(OpCodes.Ret);

            var f = typeof(Func<,>);
            var gf = f.MakeGenericType(typeof(object), typeof(int));
            var d = (Func<object, int>)dm.CreateDelegate(gf);

            return d;
        }
    }
}
