﻿
namespace DynamicPerformance
{
    /// <summary>
    /// 実行時計算その4。
    /// dynamic の利用。
    /// 
    /// 実行時コード生成とキャッシュの仕組みが標準で提供されました。
    /// コンパイラが頑張ってキャッシュの仕組みを作ってくれます。
    /// 
    /// キャッシュの仕組みが結構優秀なので、自分で頑張らなくても大丈夫。
    /// 
    /// GenerateIL や ExressionTree のと比べると、パフォーマンス的には多少（ほんの数％）不利。
    /// ただ、たった数％のペナルティで、これだけ書くのが楽になると思うとかなり利便性いい。
    /// 
    /// あと、dynamic のキャッシュは、GenerateIL とかでやってる単純なものと比べてずいぶんと高度なことをしてるので、
    /// ひょっとすると、引数に色々な型を渡しだすと、こちらの方が高速になる可能性もあり。
    /// </summary>
    public class Dynamic
    {
        public static int Sum(dynamic p)
        {
            // GenerateIL とか ExpressionTree 版が、「p.X の戻り値は int」みたいな前提でコード書いちゃったので、
            // 以下のように書かないと比較がフェアじゃないかなと。
            // （厳密には、これでもまだこちらの方が不利）
            return (int)p.X + (int)p.Y;
        }
    }
}
