﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.CSharp.RuntimeBinder;

namespace DynamicPerformance
{
    /// <summary>
    /// 実行時計算その5。
    /// dynamic が内部的にどういうことしてるか。
    /// 
    /// 型情報を動的に、（メソッドの引数とかで）明示的に与えて関数生成したい場合、この仕組みを直で使わないとダメ。
    /// まあ、そういう場合は素直に式木を使った方がいい気もする。
    /// 
    /// dynamic からの自動生成コードよりは、多少最適化済み。
    /// （if (site == null) を1つにまとめたり、キャスト用の site が2つあったのを1つにまとめたり。）
    /// </summary>
    public class DynamicInside
    {
        static CallSite<Func<CallSite, object, int>> siteCast;
        static CallSite<Func<CallSite, object, object>> siteGetX, siteGetY;

        public static int Sum(object p)
        {
            if (siteCast == null)
            {
                const CSharpBinderFlags convert = CSharpBinderFlags.ConvertExplicit;
                const CSharpBinderFlags none = CSharpBinderFlags.None;
                var argInfo = new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) };

                siteGetX = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(none, "X", null, argInfo));
                siteGetY = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(none, "Y", null, argInfo));
                siteCast = CallSite<Func<CallSite, object, int>>.Create(Binder.Convert(convert, typeof(int), null));
            }
            return (siteCast.Target(siteCast, siteGetX.Target(siteGetX, p)) + siteCast.Target(siteCast, siteGetY.Target(siteGetY, p)));
        }
    }
}
