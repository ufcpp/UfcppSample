﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace DynamicPerformance
{
    class Program
    {
        static void Main(string[] args)
        {
            CheckPerformance();

            //Test();
        }

        private static void CheckPerformance()
        {
            const int N = 1000000;
            var p = new Point();
            var dic = new Dictionary<string, int> { { "X", 0 }, { "Y", 0 } };
            var sw = new Stopwatch();

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                Static.Sum(p);
            }

            Stop(sw, "普通に実行： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                dic["X"] = i;
                dic["Y"] = i;
                PropertyDictionary.Sum(dic);
            }

            Stop(sw, "辞書利用： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                Refrection.Sum(p);
            }

            Stop(sw, "リフレクション： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                GenerateIL.Sum(p);
            }

            Stop(sw, "IL 生成： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                ExpressionTree.Sum(p);
            }

            Stop(sw, "式木利用： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                Dynamic.Sum(p);
            }

            Stop(sw, "dynamic： ");

            sw.Restart();

            for (int i = 0; i < N; i++)
            {
                p.X = i;
                p.Y = i;
                DynamicInside.Sum(p);
            }

            Stop(sw, "CallSite（dynamic の内部実装）利用： ");
        }

        private static void Stop(Stopwatch sw, string message)
        {
            sw.Stop();
            Console.Write(message);
            Console.WriteLine(sw.Elapsed);
        }

        /// <summary>
        /// テスト用。
        /// テストプロジェクト作ってそっちに移した方がいい気もする。
        /// 結果がおかしければ Debug.Assert に引っかかるはず。
        /// 何もメッセージが出なければ正常動作。
        /// </summary>
        private static void Test()
        {
            const int N = 100000;
            var r = new Random();

            for (int i = 0; i < N; i++)
            {
                var x = r.Next();
                var y = r.Next();
                var p = new Point { X = x, Y = y };

                var z = x + y;
                var z1 = Static.Sum(p);
                var z2 = Refrection.Sum(p);
                var z3 = GenerateIL.Sum(p);
                var z4 = ExpressionTree.Sum(p);
                var z5 = Dynamic.Sum(p);
                var z6 = DynamicInside.Sum(p);

                Debug.Assert(z == z1);
                Debug.Assert(z == z2);
                Debug.Assert(z == z3);
                Debug.Assert(z == z4);
                Debug.Assert(z == z5);
                Debug.Assert(z == z6);
            }

        }
    }
}
