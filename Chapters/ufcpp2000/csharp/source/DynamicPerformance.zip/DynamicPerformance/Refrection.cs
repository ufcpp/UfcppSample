﻿
namespace DynamicPerformance
{
    /// <summary>
    /// 実行時計算その1。
    /// リフレクションを利用。
    /// 
    /// 毎回、型情報を取ってきて、動的プロパティアクセスして、int にダウンキャストして・・・
    /// とやっているのでかなり重たいはず。
    /// 
    /// 一般論として、リフレクションは、static な実装と比べると2～3桁遅くなる。
    /// 「倍」じゃなくて「桁」。文字通り、桁外れに遅い。
    /// </summary>
    public class Refrection
    {
        public static int Sum(object p)
        {
            var t = p.GetType();
            var propX = t.GetProperty("X");
            var propY = t.GetProperty("Y");
            var x = propX.GetValue(p, null);
            var y = propY.GetValue(p, null);
            return (int)x + (int)y;
        }
    }
}
