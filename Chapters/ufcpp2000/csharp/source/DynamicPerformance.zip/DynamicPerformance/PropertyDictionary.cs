﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynamicPerformance
{
    /// <summary>
    /// 参考実装。
    /// 
    /// 動的にやるんであれば、CLI オブジェクトとか使わず最初から辞書にでもすりゃいいんじゃね？
    /// という短絡的実装。
    /// 
    /// これだけシンプルなメソッドですら、dynamic よりちょっと遅い。
    /// プロパティの数が増えたり、文字数が長くなるとみるみるパフォーマンスが落ちるおまけ付き。
    /// 
    /// さすがに毎回リフレクション呼ぶよりは1桁速いけれども。
    /// </summary>
    public class PropertyDictionary
    {
        public static int Sum(Dictionary<string, int> p)
        {
            return p["X"] + p["Y"];
        }
    }
}
