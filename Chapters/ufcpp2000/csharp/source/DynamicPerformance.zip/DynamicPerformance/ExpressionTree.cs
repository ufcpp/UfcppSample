﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace DynamicPerformance
{
    /// <summary>
    /// 実行時計算その3。
    /// 式木の利用。
    /// 
    /// GenerateIL 同様、実行時コード生成＋キャッシュ。
    /// .NET Framework 3.0 で導入された式木を利用。
    /// （ただし、Expression.Body のように、.NET 4 から追加されたものもあるので、このコードは .NET 4 が必須。）
    /// 
    /// IL 生成と比べるとずいぶん楽に。
    /// </summary>
    public class ExpressionTree
    {
        private static Dictionary<Type, Func<object, int>> cache = new Dictionary<Type, Func<object, int>>();

        public static int Sum(object p)
        {
            var t = p.GetType();
            Func<object, int> d;

            if (!cache.TryGetValue(t, out d))
            {
                d = CreateMethod(t);
                cache[t] = d;
            }

            return d(p);
        }

        private static Func<object, int> CreateMethod(Type t)
        {
            var x = Expression.Parameter(typeof(object));
            var p = Expression.Parameter(t);

            /*
             * {
             *     T p;
             *     p = (T)x;
             *     return p.X + p.Y;
             * }
             */
            var exp = Expression.Lambda(
                // { T p;
                Expression.Block(
                    new[] { p },
                    // p = (T)x;
                    Expression.Assign(p, Expression.Convert(x, t)),
                    // p.X + p.Y
                    // IL 生成と違って、ユーザー定義の operator+ でも正しくコード生成してくれる。
                    Expression.Add(
                        Expression.Property(p, "X"),
                        Expression.Property(p, "Y"))),
                x
                );

            var d = (Func<object, int>)exp.Compile();
            return d;
        }
    }
}
