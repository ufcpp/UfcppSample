﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その6。
    /// 
    /// 「奇数の二乗」とか「偶数の絶対値」とか、データの加工方法が変わるたびにメソッド作るの？
    /// 「奇数の絶対値」とか、微妙に組み合わせが変わっただけでも新しいメソッド？
    /// 
    /// ということで、加工の条件を外から与えるように変更。
    /// まず、匿名メソッド（ラムダ式）のなかった頃の書き方を示します。
    /// 
    /// 柔軟性は出たものの、かえって見づらく。
    /// あと、いちいち「奇数」とかのメソッドを書くのが面倒。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //表示1行1個(Select(Where(new ConsoleInput(), 奇数), 二乗));
            表示1行1個(Select(Where(array, 奇数), 二乗));
            表示1行1個(Select(Where(list, 奇数), 二乗));
            //表示1行1個(Select(Where(new ConsoleInput(), 偶数), 絶対値));
            表示1行1個(Select(Where(array, 偶数), 絶対値));
            表示1行1個(Select(Where(list, 偶数), 絶対値));
            //表示1行1個(Select(Where(new ConsoleInput(), _3以下), 符号反転));
            表示1行1個(Select(Where(array, _3以下), 符号反転));
            表示1行1個(Select(Where(list, _3以下), 符号反転));
            //表示スペース区切り(Select(Where(new ConsoleInput(), 奇数), 二乗));
            表示スペース区切り(Select(Where(array, 奇数), 二乗));
            表示スペース区切り(Select(Where(list, 奇数), 二乗));
            //表示スペース区切り(Select(Where(new ConsoleInput(), 偶数), 絶対値));
            表示スペース区切り(Select(Where(array, 偶数), 絶対値));
            表示スペース区切り(Select(Where(list, 偶数), 絶対値));
            //表示スペース区切り(Select(Where(new ConsoleInput(), _3以下), 符号反転));
            表示スペース区切り(Select(Where(array, _3以下), 符号反転));
            表示スペース区切り(Select(Where(list, _3以下), 符号反転));
            //表示コンマ区切り(Select(Where(new ConsoleInput(), 奇数), 二乗));
            表示コンマ区切り(Select(Where(array, 奇数), 二乗));
            表示コンマ区切り(Select(Where(list, 奇数), 二乗));
            //表示コンマ区切り(Select(Where(new ConsoleInput(), 偶数), 絶対値));
            表示コンマ区切り(Select(Where(array, 偶数), 絶対値));
            表示コンマ区切り(Select(Where(list, 偶数), 絶対値));
            //表示コンマ区切り(Select(Where(new ConsoleInput(), _3以下), 符号反転));
            表示コンマ区切り(Select(Where(array, _3以下), 符号反転));
            表示コンマ区切り(Select(Where(list, _3以下), 符号反転));
        }

        private static bool 奇数(int x) { return (x % 2) == 1; }
        private static bool 偶数(int x) { return (x % 2) == 0; }
        private static bool _3以下(int x) { return x <= 3; }

        private static int 二乗(int x) { return x * x; }
        private static int 絶対値(int x) { return Math.Abs(x); }
        private static int 符号反転(int x) { return -x; }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        #region 加工

        /// <summary>
        /// データ列から一定の条件を満たしたものだけを残す。
        /// </summary>
        /// <param name="source">元のデータ列。</param>
        /// <param name="predicate">条件。</param>
        /// <returns>条件を満たしたものだけ残したもの。</returns>
        private static IEnumerable<int> Where(IEnumerable<int> source, Func<int, bool> predicate)
        {
            foreach (var x in source)
            {
                if (predicate(x))
                    yield return x;
            }
        }

        /// <summary>
        /// データ列を要素ごとに加工。
        /// </summary>
        /// <param name="source">元のデータ列。</param>
        /// <param name="selector">要素を加工。</param>
        /// <returns>加工済みのデータ列。</returns>
        private static IEnumerable<int> Select(IEnumerable<int> source, Func<int, int> selector)
        {
            foreach (var x in source)
            {
                yield return selector(x);
            }
        }

        #endregion
        #region 表示

        private static void 表示1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                Console.WriteLine(x);
            }
        }

        private static void 表示スペース区切り(IEnumerable<int> list)
        {
            var line = string.Join(" ", list);
            Console.Write(line);
        }

        private static void 表示コンマ区切り(IEnumerable<int> list)
        {
            var line = string.Join(",", list);
            Console.Write(line);
        }

        #endregion
    }
}
