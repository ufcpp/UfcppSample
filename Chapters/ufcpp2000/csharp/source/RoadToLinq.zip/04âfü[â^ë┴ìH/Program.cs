﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その4。
    /// 
    /// その3でデータ取得の部分が分離できたところで、次はデータの加工も分離することを考えます。
    /// 分離によって、3×3個書いていた処理を、3+3 に減らすことが可能。
    /// 
    /// ここも、まず、イテレーターブロックがなかったころ、
    /// IEnumerable の実装が面倒な時にやりがちだった「1度リストにコピーする」という実装方法を示します。
    /// 
    /// 毎度コピーが作られるので、メモリの利用効率がかなり悪い。
    /// また、コンソールからの入力に対して、全部打ち切るまで表示が全く出ません。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //表示1行1個(奇数の二乗(new ConsoleInput()));
            表示1行1個(奇数の二乗(array));
            表示1行1個(奇数の二乗(list));
            //表示1行1個(偶数の絶対値(new ConsoleInput()));
            表示1行1個(偶数の絶対値(array));
            表示1行1個(偶数の絶対値(list));
            //表示1行1個(_3以下符号反転(new ConsoleInput()));
            表示1行1個(_3以下符号反転(array));
            表示1行1個(_3以下符号反転(list));
            //表示スペース区切り(奇数の二乗(new ConsoleInput()));
            表示スペース区切り(奇数の二乗(array));
            表示スペース区切り(奇数の二乗(list));
            //表示スペース区切り(偶数の絶対値(new ConsoleInput()));
            表示スペース区切り(偶数の絶対値(array));
            表示スペース区切り(偶数の絶対値(list));
            //表示スペース区切り(_3以下符号反転(new ConsoleInput()));
            表示スペース区切り(_3以下符号反転(array));
            表示スペース区切り(_3以下符号反転(list));
            //表示コンマ区切り(奇数の二乗(new ConsoleInput()));
            表示コンマ区切り(奇数の二乗(array));
            表示コンマ区切り(奇数の二乗(list));
            //表示コンマ区切り(偶数の絶対値(new ConsoleInput()));
            表示コンマ区切り(偶数の絶対値(array));
            表示コンマ区切り(偶数の絶対値(list));
            //表示コンマ区切り(_3以下符号反転(new ConsoleInput()));
            表示コンマ区切り(_3以下符号反転(array));
            表示コンマ区切り(_3以下符号反転(list));
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        #region 加工

        private static IEnumerable<int> 奇数の二乗(IEnumerable<int> source)
        {
            var results = new List<int>();

            foreach (var x in source)
            {
                if ((x % 2) == 1)
                {
                    results.Add(x * x);
                }
            }

            return results;
        }

        private static IEnumerable<int> 偶数の絶対値(IEnumerable<int> source)
        {
            var results = new List<int>();

            foreach (var x in source)
            {
                if ((x % 2) == 0)
                {
                    results.Add(Math.Abs(x));
                }
            }

            return results;
        }

        private static IEnumerable<int> _3以下符号反転(IEnumerable<int> source)
        {
            var results = new List<int>();

            foreach (var x in source)
            {
                if (x <= 3)
                {
                    results.Add(-x);
                }
            }

            return results;
        }

        #endregion
        #region 表示

        private static void 表示1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                Console.WriteLine(x);
            }
        }

        private static void 表示スペース区切り(IEnumerable<int> list)
        {
            var line = string.Join(" ", list);
            Console.Write(line);
        }

        private static void 表示コンマ区切り(IEnumerable<int> list)
        {
            var line = string.Join(",", list);
            Console.Write(line);
        }

        #endregion
    }
}
