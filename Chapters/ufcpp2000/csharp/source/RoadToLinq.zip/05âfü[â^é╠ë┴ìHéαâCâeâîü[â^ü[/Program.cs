﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その5。
    /// 
    /// データの加工もイテレーター ブロックを使って書き換え。
    /// 
    /// これで、毎度コピーが作られる問題は解消。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //表示1行1個(奇数の二乗(new ConsoleInput()));
            表示1行1個(奇数の二乗(array));
            表示1行1個(奇数の二乗(list));
            //表示1行1個(偶数の絶対値(new ConsoleInput()));
            表示1行1個(偶数の絶対値(array));
            表示1行1個(偶数の絶対値(list));
            //表示1行1個(_3以下符号反転(new ConsoleInput()));
            表示1行1個(_3以下符号反転(array));
            表示1行1個(_3以下符号反転(list));
            //表示スペース区切り(奇数の二乗(new ConsoleInput()));
            表示スペース区切り(奇数の二乗(array));
            表示スペース区切り(奇数の二乗(list));
            //表示スペース区切り(偶数の絶対値(new ConsoleInput()));
            表示スペース区切り(偶数の絶対値(array));
            表示スペース区切り(偶数の絶対値(list));
            //表示スペース区切り(_3以下符号反転(new ConsoleInput()));
            表示スペース区切り(_3以下符号反転(array));
            表示スペース区切り(_3以下符号反転(list));
            //表示コンマ区切り(奇数の二乗(new ConsoleInput()));
            表示コンマ区切り(奇数の二乗(array));
            表示コンマ区切り(奇数の二乗(list));
            //表示コンマ区切り(偶数の絶対値(new ConsoleInput()));
            表示コンマ区切り(偶数の絶対値(array));
            表示コンマ区切り(偶数の絶対値(list));
            //表示コンマ区切り(_3以下符号反転(new ConsoleInput()));
            表示コンマ区切り(_3以下符号反転(array));
            表示コンマ区切り(_3以下符号反転(list));
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        #region 加工

        private static IEnumerable<int> 奇数の二乗(IEnumerable<int> source)
        {
            foreach (var x in source)
            {
                if ((x % 2) == 1)
                {
                    yield return x * x;
                }
            }
        }

        private static IEnumerable<int> 偶数の絶対値(IEnumerable<int> source)
        {
            foreach (var x in source)
            {
                if ((x % 2) == 0)
                {
                    yield return Math.Abs(x);
                }
            }
        }

        private static IEnumerable<int> _3以下符号反転(IEnumerable<int> source)
        {
            foreach (var x in source)
            {
                if (x <= 3)
                {
                    yield return -x;
                }
            }
        }

        #endregion
        #region 表示

        private static void 表示1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                Console.WriteLine(x);
            }
        }

        private static void 表示スペース区切り(IEnumerable<int> list)
        {
            var line = string.Join(" ", list);
            Console.Write(line);
        }

        private static void 表示コンマ区切り(IEnumerable<int> list)
        {
            var line = string.Join(",", list);
            Console.Write(line);
        }

        #endregion
    }
}
