﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その7。
    /// 
    /// その6で、データの加工に柔軟性ができたものの、2点ほど問題が:
    /// 
    /// •見づらい
    /// •「奇数」とかのメソッド書くのが面倒
    /// 
    /// 見づらい原因は何かというと、
    /// 
    /// Select(Where(source, Whereの条件), Selectの変換関数)
    /// 
    /// というように、述語（Where, Select）と補語（条件や変換関数）が離れることです。
    /// そこでこれを、
    /// 
    /// source.Where(条件).Select(変換関数)
    /// 
    /// という語順で書けるようにするのが「拡張メソッド」。
    /// 
    /// 奇数とかのメソッドを書くのが面倒なのは、
    /// 
    /// source.Where(x => (x % 2) == 1).Select(x => x * x);
    /// 
    /// とかその場にメソッドを埋め込めれる「ラムダ式」で解消。
    /// </summary>
    static class Program
    {
        static void Main(string[] args)
        {
            表示(表示1行1個);
            表示(表示スペース区切り);
            表示(表示コンマ区切り);
        }

        /// <summary>
        /// ついでに、表示方法も汎用化。
        /// </summary>
        /// <param name="表示方法">外から与える表示用のデリゲート。</param>
        private static void 表示(Action<IEnumerable<int>> 表示方法)
        {
            表示(表示方法, source => source.Where(x => (x % 2) == 1).Select(x => x * x));
            表示(表示方法, source => source.Where(x => (x % 2) == 0).Select(x => Math.Abs(x)));
            表示(表示方法, source => source.Where(x => x <= 3).Select(x => -x));
        }

        /// <summary>
        /// ついでに、表示方法も汎用化。
        /// </summary>
        /// <param name="表示方法">外から与える表示用のデリゲート。</param>
        /// <param name="加工方法">データの加工方法を表すデリゲート。</param>
        private static void 表示(Action<IEnumerable<int>> 表示方法, Func<IEnumerable<int>, IEnumerable<int>> 加工方法)
        {
            //表示方法(加工方法(new ConsoleInput()));
            表示方法(加工方法(array));
            表示方法(加工方法(list));
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        #region 加工

        /// <summary>
        /// データ列から一定の条件を満たしたものだけを残す。
        /// </summary>
        /// <param name="source">元のデータ列。</param>
        /// <param name="predicate">条件。</param>
        /// <returns>条件を満たしたものだけ残したもの。</returns>
        private static IEnumerable<int> Where(this IEnumerable<int> source, Func<int, bool> predicate)
        {
            foreach (var x in source)
            {
                if (predicate(x))
                    yield return x;
            }
        }

        /// <summary>
        /// データ列を要素ごとに加工。
        /// </summary>
        /// <param name="source">元のデータ列。</param>
        /// <param name="selector">要素を加工。</param>
        /// <returns>加工済みのデータ列。</returns>
        private static IEnumerable<int> Select(this IEnumerable<int> source, Func<int, int> selector)
        {
            foreach (var x in source)
            {
                yield return selector(x);
            }
        }

        #endregion
        #region 表示

        private static void 表示1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                Console.WriteLine(x);
            }
        }

        private static void 表示スペース区切り(IEnumerable<int> list)
        {
            var line = string.Join(" ", list);
            Console.Write(line);
        }

        private static void 表示コンマ区切り(IEnumerable<int> list)
        {
            var line = string.Join(",", list);
            Console.Write(line);
        }

        #endregion
    }
}
