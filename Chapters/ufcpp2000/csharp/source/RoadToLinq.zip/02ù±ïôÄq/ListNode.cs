﻿using System.Collections.Generic;

namespace RoadToLinq
{
    public class ListNode : IEnumerable<int>
    {
        public int Value { get; set; }
        public ListNode Next { get; set; }

        // こいつの実装が超めんどくさい。
        class NodeEmumerator : IEnumerator<int>
        {
            ListNode dummyNode;
            ListNode currentNode;

            public NodeEmumerator(ListNode first) { this.dummyNode = first; }

            public int Current
            {
                get { return currentNode.Value; }
            }

            public void Dispose()
            {
            }

            object System.Collections.IEnumerator.Current
            {
                get { return this.Current; }
            }

            public bool MoveNext()
            {
                if (dummyNode != null)
                {
                    currentNode = dummyNode;
                    dummyNode = null;
                    return true;
                }
                else
                {
                    currentNode = currentNode.Next;
                    return currentNode != null;
                }
            }

            public void Reset()
            {
                throw new System.NotImplementedException();
            }
        }


        public IEnumerator<int> GetEnumerator()
        {
            return new NodeEmumerator(this);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
