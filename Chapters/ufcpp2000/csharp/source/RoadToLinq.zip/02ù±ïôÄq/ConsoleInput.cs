﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    public class ConsoleInput : IEnumerable<int>
    {
        // こいつの実装が超めんどくさい。
        class Reader : IEnumerator<int>
        {
            public int Current { get; private set; }

            public void Dispose()
            {
            }

            object System.Collections.IEnumerator.Current
            {
                get { return this.Current; }
            }

            public bool MoveNext()
            {
                int x;
                if (int.TryParse(Console.ReadLine(), out x))
                {
                    this.Current = x;
                    return true;
                }
                return false;
            }

            public void Reset()
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerator<int> GetEnumerator()
        {
            return new Reader();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
