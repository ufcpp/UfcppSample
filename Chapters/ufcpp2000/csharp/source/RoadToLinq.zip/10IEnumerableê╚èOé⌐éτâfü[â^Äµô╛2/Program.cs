﻿using System;
using System.Linq;

namespace _10IEnumerable以外からデータ取得2
{
    /// <summary>
    /// 今回は IQueryable について。
    /// 
    /// プログラムのメモリ中にあるデータの加工・表示は IEnumerable でいいけども、
    /// 外にあるデータ、例えば、データベース サーバーからデータを取ってくる場合、
    /// IEnumerable では無理。
    /// 
    /// こういう場合に必要なのは、
    /// Equal(Parameter("Id"), Constant(100)) というような「式」のデータ構造（式ツリーと呼ぶ）から、
    /// WHERE Id = 100 というような SQL 文を生成する仕組み。
    /// 
    /// こういう、式ツリーから SQL 文（に限らず、外部データにアクセスするためのプロトコル）を生成するために使うのが
    /// IQueryable というインターフェイス。
    /// 
    /// あと、式ツリーの構築はめんどくさいものだけども、
    /// C# 3.0 以降では、
    /// x =&gt; x.ID == 100
    /// というようなラムダ式から、
    /// Expression.Equal(Expression.Parameter("x"), Expression.Constant(100))
    /// というような式ツリーを生成してくれる機能を持っている。
    /// 
    /// これのおかげで、
    /// var q = db.Table.Where(x =&gt; x.Id == 10);
    /// というような、IEnumerable と全く同じ記述で、データベース アクセスが可能に。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //↓初回に1回だけ実行。
            //CreateData();

            using (var context = new SampleDataContext())
            {
                Console.WriteLine("まず普通に一覧取得");

                foreach (var x in context.Parents)
                {
                    Console.WriteLine("{0}: {1}", x.Name, x.Value);

                    foreach (var y in x.Children)
                    {
                        Console.WriteLine("\t{0}: {1}", y.Name, y.Value);
                    }
                }

                Console.WriteLine("例えば、子要素の Value 値の合計が500以上の要素の名前だけを取得");

                // 見ての通り、IEnumerable に対する書き方と全く一緒にできる。
                // でも、ちゃんと SQL 文になって、データベース サーバー上でクエリが実行される。
                var q = context.Parents
                    .Where(x => x.Children.Sum(y => y.Value) >= 500)
                    .Select(x => x.Name);

                foreach (var x in q)
                {
                    Console.WriteLine(x);
                }
            }
        }

        /// <summary>
        /// サンプル データの作成。
        /// Entity Framework 4.1 の DbContext は、デフォルトだとローカルのデータベースに
        /// 「名前空間名（プロジェクト名）.クラス名」
        /// という名前のデータベースを作るので、この例の場合、
        /// _10IEnumerable以外からデータ取得2.SampleDataContext というデータベースができるはず。
        /// </summary>
        private static void CreateData()
        {
            using (var context = new SampleDataContext())
            {
                context.Database.CreateIfNotExists();

                context.Parents.Add(new Parent
                {
                    Name = "aaa",
                    Value = 1,
                    Children = new[]
                    {
                        new Child { Name = "あああ", Value = 100 },
                        new Child { Name = "いいい", Value = 200 },
                    }
                });
                context.Parents.Add(new Parent
                {
                    Name = "bbb",
                    Value = 2,
                    Children = new[]
                    {
                        new Child { Name = "ううう", Value = 300 },
                        new Child { Name = "えええ", Value = 400 },
                    }
                });
                context.Parents.Add(new Parent
                {
                    Name = "ccc",
                    Value = 3,
                    Children = new[]
                    {
                        new Child { Name = "おおお", Value = 500 },
                    }
                });

                context.SaveChanges();
            }
        }
    }
}
