﻿using System.Collections.Generic;
using System.Data.Entity;

namespace _10IEnumerable以外からデータ取得2
{
    /// <summary>
    /// Entity Framework 4.1 Code First の仕組みを利用。
    /// Parent や Child のような、何も継承しないただのクラス（POCO: Plain Old CLR Object）から
    /// データベースのテーブルを生成したり、テーブルの内容を取得できる。
    /// </summary>
    public class SampleDataContext : DbContext
    {
        /// <summary>
        /// データベースに Parents テーブルを作って読み書き。
        /// </summary>
        public DbSet<Parent> Parents { get; set; }

        /// <summary>
        /// データベースに Children テーブルを作って読み書き。
        /// </summary>
        public DbSet<Child> Children { get; set; }
    }

    /// <summary>
    /// Parents テーブルの列定義 ＝ Parent クラス定義。
    /// </summary>
    public class Parent
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Value { get; set; }

        /// <summary>
        /// こうやって、単にリストを持つだけで、
        /// Children テーブルに Parent_Id という列を自動生成して、Join してくれる。
        /// </summary>
        public virtual IList<Child> Children { get; set; }
    }

    /// <summary>
    /// Children テーブルの列定義 ＝ Child クラス定義。
    /// </summary>
    public class Child
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Value { get; set; }
    }
}
