﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadToLinq
{
    class DelegateObserver<T> : IObserver<T>
    {
        Action<T> onNext;
        Action onCompleted;
        Action<Exception> onError;

        public DelegateObserver(Action<T> next, Action completed = null, Action<Exception> error = null)
        {
            this.onNext = next;
            this.onCompleted = completed;
            this.onError = error;
        } 

        public void OnNext(T value)
        {
            onNext(value);
        }

        public void OnCompleted()
        {
            if (onCompleted != null)
                onCompleted();
        }

        public void OnError(Exception error)
        {
            if (onError != null)
                onError(error);
        }
    }
}
