﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadToLinq
{
    public static partial class ObservableExtensions
    {
        /// <summary>
        /// いちいち IObserver を作るのも面倒なので、Action デリゲートを使って Subscribe する。
        /// </summary>
        /// <typeparam name="T">push 通知で受け取るデータの型。</typeparam>
        /// <param name="source">観測対象。</param>
        /// <param name="observer">push 通知を処理するデリゲート。</param>
        /// <returns>Unsubscribe 用の IDispose。</returns>
        public static IDisposable Subscribe<T>(this IObservable<T> source, Action<T> observer)
        {
            return source.Subscribe(new DelegateObserver<T>(observer));
        }

        /// <summary>
        /// 特定条件を満たしたときだけ push 通知が来るようにする。
        /// </summary>
        /// <typeparam name="T">push 通知で受け取るデータの型。</typeparam>
        /// <param name="source">観測対象。</param>
        /// <param name="predicate">条件。</param>
        /// <returns>source を、特定条件を満たしたときだけ push 通知するようにしたもの。</returns>
        public static IObservable<T> Where<T>(this IObservable<T> soruce, Func<T, bool> predicate)
        {
            var observable = new ObservableBase<T>();
            soruce.Subscribe(new WhereObserver<T>(observable, predicate));
            return observable;
        }

        class WhereObserver<T> : ObserverBase<T>
        {
            Func<T, bool> predicate;

            public WhereObserver(ObservableBase<T> observable, Func<T, bool> predicate)
                : base(observable)
            {
                this.predicate = predicate;
            }

            public override void OnNext(T value)
            {
                if (predicate(value))
                {
                    foreach (var o in Observable.Observers)
                    {
                        o.OnNext(value);
                    }
                }
            }
        }

        /// <summary>
        /// push 通知を加工してから通知しなおす。
        /// </summary>
        /// <typeparam name="T">push 通知で受け取るデータの型。</typeparam>
        /// <param name="source">観測対象。</param>
        /// <param name="selector">加工用のデリゲート。</param>
        /// <returns>source から来た push 通知を加工してから通知しなおすもの。</returns>
        public static IObservable<T> Select<T>(this IObservable<T> soruce, Func<T, T> selector)
        {
            var observable = new ObservableBase<T>();
            soruce.Subscribe(new SelectObserver<T>(observable, selector));
            return observable;
        }

        class SelectObserver<T> : ObserverBase<T>
        {
            Func<T, T> selector;

            public SelectObserver(ObservableBase<T> observable, Func<T, T> selector)
                : base(observable)
            {
                this.selector = selector;
            }

            public override void OnNext(T value)
            {
                foreach (var o in Observable.Observers)
                {
                    o.OnNext(selector(value));
                }
            }
        }

    }
}
