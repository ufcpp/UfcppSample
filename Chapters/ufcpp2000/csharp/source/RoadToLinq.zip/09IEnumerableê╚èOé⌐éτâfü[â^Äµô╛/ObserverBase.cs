﻿using System;

namespace RoadToLinq
{
    abstract class ObserverBase<T> : IObserver<T>
    {
        ObservableBase<T> observable;
        public ObservableBase<T> Observable { get { return observable; } }

        public ObserverBase(ObservableBase<T> observable) { this.observable = observable; }

        public void OnCompleted()
        {
            foreach (var o in observable.Observers)
            {
                o.OnCompleted();
            }
        }

        public void OnError(Exception error)
        {
            foreach (var o in observable.Observers)
            {
                o.OnError(error);
            }
        }

        public abstract void OnNext(T value);
    }
}
