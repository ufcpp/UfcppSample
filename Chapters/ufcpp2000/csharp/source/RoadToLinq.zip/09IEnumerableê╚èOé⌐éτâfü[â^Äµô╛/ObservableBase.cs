﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    class ObservableBase<T> : IObservable<T>
    {
        private List<IObserver<T>> observers = new List<IObserver<T>>();

        public List<IObserver<T>> Observers { get { return observers; } }

        public IDisposable Subscribe(IObserver<T> observer)
        {
            observers.Add(observer);
            return new Unsubscriber(this, observer);
        }

        class Unsubscriber : IDisposable
        {
            ObservableBase<T> observable;
            IObserver<T> observer;

            public Unsubscriber(ObservableBase<T> observable, IObserver<T> observer)
            {
                this.observable = observable;
                this.observer = observer;
            }

            public void Dispose()
            {
                observable.Observers.Remove(observer);
            }
        }

        protected void RaiseNext(T value)
        {
            foreach (var x in observers)
            {
                x.OnNext(value);
            }
        }
    }
}
