﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RoadToLinq
{
    /// <summary>
    /// ここから新章。
    /// 
    /// いままでは、データの取得元を IEnumerable に統一することで、
    /// そのあとの加工や表示を共通化してた。
    /// 
    /// でも、データの取得方法は IEnumerable だけとは限らない。
    /// IEnumerable は、すでにどこかに蓄積済みのデータを pull 型で引き出すとか、
    /// データが徐々にやってくるのなら、全部が来終わるまで待つとか、同期的な動きしかできない。
    /// 
    /// 一方で、データってのは非同期にもやってくるんで、
    /// データが来た瞬間にイベント通知してもらう場合もある。
    /// こういう、push 通知に基づくデータ処理には IObservable を使う。
    /// 
    /// IObservable に対する LINQ は、今のところ Reactive Extensions っていう拡張ライブラリ
    /// （※ http://msdn.microsoft.com/en-us/devlabs/ee794896.aspx ）にしか入ってない。
    /// （将来的には .NET Framework 標準に入りそう。）
    /// 
    /// ここでは、IObservable に対する Where と Select の実装例を提示。
    /// （IObservable 自体は .NET Framework 4 に標準で入っている。）
    /// 
    /// IEnumerable の場合と同名のメソッドにすることで、利用者の学習コストを下げる。
    /// IEnumerable に対するデータ加工が書ける人なら、IObservable に対するデータ加工も書ける。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // 別スレッドで 500 ミリ秒間隔でデータを push 通知する。
            var t = new TimerObservable(500, new[] { 1, 2, 3, 4, 5, 6, 7, 8 });

            // 別スレッドから来た push 通知を受け取って、LINQ でデータ加工。
            // IEnumerable 版と同じ形式の拡張メソッドを用意することで利用者の学習コストを下げる。
            var o = t.Where(x => (x % 2) == 1).Select(x => x * x);

            // 加工結果を購読して、コンソールに表示。
            o.Subscribe(x => { Console.WriteLine(x); });

            // 別スレッドに処理が移ってるので、待たないと Main メソッドを抜けてしまう。
            System.Threading.Thread.Sleep(5000);
        }
    }

    /// <summary>
    /// スレッドを立てて、
    /// interval [ミリ秒]ごとにデータを push する Observable。
    /// </summary>
    class TimerObservable : ObservableBase<int>
    {
        /// <summary>
        /// データの push 間隔と、データの取得元を与えて初期化。
        /// </summary>
        /// <param name="interval">push 間隔。</param>
        /// <param name="list">データの取得元。</param>
        public TimerObservable(int interval, IEnumerable<int> list)
        {
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    foreach (var x in list)
                    {
                        System.Threading.Thread.Sleep(interval);
                        RaiseNext(x);
                    }
                }
            });
        }
    }

}
