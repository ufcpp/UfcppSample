﻿using System;
using System.Linq; // New!
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その8。
    /// 
    /// その7で作った Where とか Select、汎用的な関数だしライブラリ化しておけばいいんじゃないの？
    /// 
    /// というのが、C# 3.0、.NET Framework 3.0 で導入された LINQ。
    /// 
    /// その7は、LINQ と同じメソッド名で作ってあるので、
    /// ここでは
    /// 
    /// •その7で作った Where と Select の定義を消す
    /// •using System.Linq; を追加
    /// 
    /// するだけ。
    /// 標準で定義されている IEnumerable 向けの Where や Select が使われます。
    /// </summary>
    static class Program
    {
        static void Main(string[] args)
        {
            表示(表示1行1個);
            表示(表示スペース区切り);
            表示(表示コンマ区切り);
        }

        /// <summary>
        /// ついでに、表示方法も汎用化。
        /// </summary>
        /// <param name="表示方法">外から与える表示用のデリゲート。</param>
        private static void 表示(Action<IEnumerable<int>> 表示方法)
        {
            表示(表示方法, source => source.Where(x => (x % 2) == 1).Select(x => x * x));
            表示(表示方法, source => source.Where(x => (x % 2) == 0).Select(x => Math.Abs(x)));
            表示(表示方法, source => source.Where(x => x <= 3).Select(x => -x));
        }

        /// <summary>
        /// ついでに、表示方法も汎用化。
        /// </summary>
        /// <param name="表示方法">外から与える表示用のデリゲート。</param>
        /// <param name="加工方法">データの加工方法を表すデリゲート。</param>
        private static void 表示(Action<IEnumerable<int>> 表示方法, Func<IEnumerable<int>, IEnumerable<int>> 加工方法)
        {
            //表示方法(加工方法(new ConsoleInput()));
            表示方法(加工方法(array));
            表示方法(加工方法(list));
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        #region 表示

        private static void 表示1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                Console.WriteLine(x);
            }
        }

        private static void 表示スペース区切り(IEnumerable<int> list)
        {
            var line = string.Join(" ", list);
            Console.Write(line);
        }

        private static void 表示コンマ区切り(IEnumerable<int> list)
        {
            var line = string.Join(",", list);
            Console.Write(line);
        }

        #endregion
    }
}
