﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その3。
    /// 
    /// その2では、IEnumerable に統一することでデータの取得の部分が分離できたものの、
    /// 「IEnumerable の実装超面倒です。勘弁してください。」状態。
    /// 
    /// そこで、C# 2.0 で導入されたイテレーター ブロック。
    /// IEnumerable の実装側が非常にすっきりします。
    /// 
    /// （Program クラスの中身はその2から変化なし。）
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //奇数の二乗_1行1個(new ConsoleInput());
            奇数の二乗_1行1個(array);
            奇数の二乗_1行1個(list);
            //偶数の絶対値_1行1個(new ConsoleInput());
            偶数の絶対値_1行1個(array);
            偶数の絶対値_1行1個(list);
            //_3以下符号反転_1行1個(new ConsoleInput());
            _3以下符号反転_1行1個(array);
            _3以下符号反転_1行1個(list);
            //奇数の二乗_スペース区切り(new ConsoleInput());
            奇数の二乗_スペース区切り(array);
            奇数の二乗_スペース区切り(list);
            //偶数の絶対値_スペース区切り(new ConsoleInput());
            偶数の絶対値_スペース区切り(array);
            偶数の絶対値_スペース区切り(list);
            //_3以下符号反転_スペース区切り(new ConsoleInput());
            _3以下符号反転_スペース区切り(array);
            _3以下符号反転_スペース区切り(list);
            //奇数の二乗_コンマ区切り(new ConsoleInput());
            奇数の二乗_コンマ区切り(array);
            奇数の二乗_コンマ区切り(list);
            //偶数の絶対値_コンマ区切り(new ConsoleInput());
            偶数の絶対値_コンマ区切り(array);
            偶数の絶対値_コンマ区切り(list);
            //_3以下符号反転_コンマ区切り(new ConsoleInput());
            _3以下符号反転_コンマ区切り(array);
            _3以下符号反転_コンマ区切り(list);
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode
        {
            Value = 1,
            Next = new ListNode
            {
                Value = 2,
                Next = new ListNode
                {
                    Value = 3,
                    Next = new ListNode
                    {
                        Value = 4,
                        Next = new ListNode
                        {
                            Value = 5,
                            Next = new ListNode
                            {
                                Value = 6,
                                Next = new ListNode
                                {
                                    Value = 7,
                                }
                            }
                        }
                    }
                }
            }
        };

        private static void 奇数の二乗_1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 1)
                {
                    Console.WriteLine(x * x);
                }
            }
        }

        private static void 偶数の絶対値_1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 0)
                {
                    Console.WriteLine(Math.Abs(x));
                }
            }
        }

        private static void _3以下符号反転_1行1個(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if (x <= 3)
                {
                    Console.WriteLine(-x);
                }
            }
        }

        private static void 奇数の二乗_スペース区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 1)
                {
                    Console.Write("{0} ", x * x);
                }
            }
        }

        private static void 偶数の絶対値_スペース区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 0)
                {
                    Console.Write("{0} ", Math.Abs(x));
                }
            }
        }

        private static void _3以下符号反転_スペース区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if (x <= 3)
                {
                    Console.Write("{0} ", -x);
                }
            }
        }

        private static void 奇数の二乗_コンマ区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 1)
                {
                    Console.Write("{0},", x * x);
                }
            }
        }

        private static void 偶数の絶対値_コンマ区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if ((x % 2) == 0)
                {
                    Console.Write("{0},", Math.Abs(x));
                }
            }
        }

        private static void _3以下符号反転_コンマ区切り(IEnumerable<int> list)
        {
            foreach (var x in list)
            {
                if (x <= 3)
                {
                    Console.Write("{0},", -x);
                }
            }
        }
    }
}
