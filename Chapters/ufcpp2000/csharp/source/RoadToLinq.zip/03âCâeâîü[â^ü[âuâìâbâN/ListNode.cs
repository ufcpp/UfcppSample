﻿using System.Collections.Generic;

namespace RoadToLinq
{
    public class ListNode : IEnumerable<int>
    {
        public int Value { get; set; }
        public ListNode Next { get; set; }

        // yield を使うと、自動的に IEnumerator を作ってくれる。
        public IEnumerator<int> GetEnumerator()
        {
            for (ListNode node = this; node != null; node = node.Next)
            {
                yield return node.Value;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
