﻿using System;
using System.Collections.Generic;

namespace RoadToLinq
{
    public class ConsoleInput : IEnumerable<int>
    {
        // yield を使うと、自動的に IEnumerator を作ってくれる。
        public IEnumerator<int> GetEnumerator()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) yield break;
                yield return x;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
