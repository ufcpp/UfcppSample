﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _11クエリ式
{
    /// <summary>
    /// 08～10 辺りの説明の通り、LINQ は基本的に、
    /// source.Where(x =&gt; (x % 2) == 1).Select(x =&gt; x * x)
    /// というような、メソッドの連鎖（method chaind）で書ける。
    /// 
    /// 何だけども、いくつか、メソッド連鎖だと書きにくいものが:
    /// 2重ループ的なデータ加工: SelectMany メソッドを使えばできるが…
    /// 一時変数を定義する: Select でできることはできるが…
    /// 
    /// LINQ の追加にあたって、C# チームがユーザビリティ調査を行った結果、
    /// この手の操作をすぐ書ける人がかなり少なかったらしい。
    /// 
    /// ということで導入されたのがクエリ式。
    /// メソッド連鎖の代わりに、以下のような、SQL 文的な式を C# に埋め込むことができる。
    /// 
    /// from x in data1
    /// from y in data2
    /// select x * y;
    /// 
    /// これをメソッド形式で書くと、以下のようになる。
    /// 
    /// data1.SelectMany(x => data2, (x, y) => x * y);
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            var data = new SampleData();

            Letメソッド形式(data);
            Letクエリ式(data);
            SelectManyメソッド形式(data);
            SelectManyクエリ式(data);
            JoinWメソッド形式(data);
            Joinクエリ式(data);
        }

        /// <summary>
        /// データ加工の途中で、一時変数を定義したい時。
        /// Select を通すことで一時変数を作れるけども、いまいち一時変数に見えない。
        /// </summary>
        private static void Letメソッド形式(SampleData data)
        {
            // 途中の式に出て来る余計な x が嫌な感じ。
            var q = data.Orders
                .Join(data.Products, o => o.ProductId, p => p.Id, (o, p) => new { o, p })
                .Select(x => new { x, TotalPrice = x.p.Price * x.o.Quantity }) // 一時変数を作るための Select
                .Where(x => x.TotalPrice > 500)
                .Select(x => new { x.x.p.Name, x.TotalPrice });

            foreach (var x in q)
            {
                Console.WriteLine("{0} の総売り上げ: {1}", x.Name, x.TotalPrice);
            }
        }
        // ↑↓結果は同じ

        /// <summary>
        /// そういうときは、let 句を使う。
        /// </summary>
        private static void Letクエリ式(SampleData data)
        {
            var q =
                from o in data.Orders
                join p in data.Products on o.ProductId equals p.Id
                let TotalPrice = p.Price * o.Quantity // 一時変数
                where TotalPrice > 500
                select new { p.Name, TotalPrice };

            foreach (var x in q)
            {
                Console.WriteLine("{0} の総売り上げ: {1}", x.Name, x.TotalPrice);
            }
        }

        /// <summary>
        /// いわゆる「2重ループ」的なデータ加工をしたい時、SelectMany を使えばできるのだけども、
        /// ユーザビリティ調査の結果、これを正しく書いてくれる人はあまりいなかったらしい。
        /// </summary>
        private static void SelectManyメソッド形式(SampleData data)
        {
            var q = data.MajorCategories
                .SelectMany(mj => data.MinorCategories, (mj, mn) => new { mj, mn })
                .Where(x => x.mj.Id == x.mn.MajorCategoryId) // やっぱりこの余計な x が嫌な感じ。
                .Select(x => new { Major = x.mj, Minor = x.mn });

            foreach (var x in q)
            {
                var line = string.Join(", ", x.Major.Name, x.Minor.Name);
                Console.WriteLine(line);
            }
        }
        // ↑↓結果は同じ

        /// <summary>
        /// そういう時は from を2重に重ねる。
        /// </summary>
        private static void SelectManyクエリ式(SampleData data)
        {
            var q =
                from mj in data.MajorCategories
                from mn in data.MinorCategories
                where mj.Id == mn.MajorCategoryId
                select new { Major = mj, Minor = mn };

            foreach (var x in q)
            {
                var line = string.Join(", ", x.Major.Name, x.Minor.Name);
                Console.WriteLine(line);
            }
        }

        /// <summary>
        /// いわゆる join。2つのデータ列を結合。
        /// Join メソッドでできる。
        /// これくらいなら書けるか。
        /// </summary>
        private static void JoinWメソッド形式(SampleData data)
        {
            var q = data.Products
                .Join(data.MajorCategories,
                    p => p.MajorCategoryId,
                    mj => mj.Id,
                    (p, mj) => new { Product = p, Major = mj })
                .Join(data.MinorCategories,
                    x => new { x.Product.MajorCategoryId, x.Product.MinorCategoryId },
                    mn => new { mn.MajorCategoryId, MinorCategoryId = mn.Id },
                    (x, mn) => new { x.Product, x.Major, Minor = mn });

            foreach (var x in q)
            {
                var line = string.Join(", ", x.Product.Name, x.Major.Name, x.Minor.Name, x.Product.Price);
                Console.WriteLine(line);
            }
        }
        // ↑↓結果は同じ

        /// <summary>
        /// そういう時は join 句を使う。
        /// </summary>
        private static void Joinクエリ式(SampleData data)
        {
            var q =
                from p in data.Products
                join mj in data.MajorCategories on p.MajorCategoryId equals mj.Id
                join mn in data.MinorCategories on new { p.MajorCategoryId, p.MinorCategoryId } equals new { mn.MajorCategoryId, MinorCategoryId = mn.Id }
                select new { Product = p, Major = mj, Minor = mn };

            foreach (var x in q)
            {
                var line = string.Join(", ", x.Product.Name, x.Major.Name, x.Minor.Name, x.Product.Price);
                Console.WriteLine(line);
            }
        }
    }
}
