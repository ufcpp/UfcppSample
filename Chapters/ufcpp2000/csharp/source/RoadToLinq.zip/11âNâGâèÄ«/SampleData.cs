﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _11クエリ式
{
    class SampleData
    {
        public IEnumerable<Order> Orders = new[]
        {
            new Order { ProductId = 1, Quantity = 2 },
            new Order { ProductId = 2, Quantity = 5 },
            new Order { ProductId = 3, Quantity = 3 },
        };

        public IEnumerable<Product> Products = new[]
        {
            new Product { Id = 1, Name = "A", MajorCategoryId = 1, MinorCategoryId = 1, Price = 500},
            new Product { Id = 2, Name = "B", MajorCategoryId = 1, MinorCategoryId = 2, Price = 125},
            new Product { Id = 3, Name = "C", MajorCategoryId = 1, MinorCategoryId = 3, Price = 89},
            new Product { Id = 4, Name = "D", MajorCategoryId = 1, MinorCategoryId = 3, Price = 129},
            new Product { Id = 5, Name = "E", MajorCategoryId = 2, MinorCategoryId = 1, Price = 350},
            new Product { Id = 6, Name = "F", MajorCategoryId = 2, MinorCategoryId = 1, Price = 320},
            new Product { Id = 7, Name = "G", MajorCategoryId = 2, MinorCategoryId = 2, Price = 59},
            new Product { Id = 8, Name = "H", MajorCategoryId = 2, MinorCategoryId = 2, Price = 70},
            new Product { Id = 9, Name = "I", MajorCategoryId = 2, MinorCategoryId = 3, Price = 110},
        };

        public IEnumerable<MajorCategory> MajorCategories = new[]
        {
            new MajorCategory { Id = 1, Name = "食品" },
            new MajorCategory { Id = 2, Name = "飲料" },
        };

        public IEnumerable<MinorCategory> MinorCategories = new[]
        {
            new MinorCategory { MajorCategoryId = 1, Id = 1, Name = "米" },
            new MinorCategory { MajorCategoryId = 1, Id = 2, Name = "麺類" },
            new MinorCategory { MajorCategoryId = 1, Id = 3, Name = "パン" },
            new MinorCategory { MajorCategoryId = 2, Id = 1, Name = "酒" },
            new MinorCategory { MajorCategoryId = 2, Id = 2, Name = "水" },
            new MinorCategory { MajorCategoryId = 2, Id = 3, Name = "ジュース" },
        };
    }

    public class Order
    {
        public int Quantity { get; set; }
        public int ProductId { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }

        public int MajorCategoryId { get; set; }
        public int MinorCategoryId { get; set; }
    }

    public class MajorCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class MinorCategory
    {
        public int MajorCategoryId { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
