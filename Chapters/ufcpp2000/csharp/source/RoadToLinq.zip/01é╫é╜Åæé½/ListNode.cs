﻿
namespace RoadToLinq
{
    public class ListNode
    {
        public int Value { get; set; }
        public ListNode Next { get; set; }
    }
}
