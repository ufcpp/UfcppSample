﻿using System;

namespace RoadToLinq
{
    /// <summary>
    /// LINQ ができるまで その1。
    /// 
    /// データ処理には、
    /// •データ列の取得
    /// •加工
    /// •表示
    /// 
    /// と3段階あります。ここでは、
    /// 
    /// •取得元: コンソール、配列、連結リスト
    /// •加工: 奇数だけ取り出してその二乗を計算、偶数だけ取り出してその絶対値を計算、3以下だけ取り出して符号反転
    /// •表示: 1行に1個、スペース区切り、コンマ区切り
    /// 
    /// などを考えてみます。
    /// 
    /// まず、最も原始的な書き方だとどうなるかの例。
    /// 似て非なるコードが3種×3種×3種の27個並んだ状態。
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // コンソールからの読み込みは実行するのがうっとおしいのでコメントアウト。

            //コンソール_奇数の二乗_1行1個();
            配列_奇数の二乗_1行1個();
            連結リスト_奇数の二乗_1行1個();
            //コンソール_偶数の絶対値_1行1個();
            配列_偶数の絶対値_1行1個();
            連結リスト_偶数の絶対値_1行1個();
            //コンソール_3以下符号反転_1行1個();
            配列_3以下符号反転_1行1個();
            連結リスト_3以下符号反転_1行1個();
            //コンソール_奇数の二乗_スペース区切り();
            配列_奇数の二乗_スペース区切り();
            連結リスト_奇数の二乗_スペース区切り();
            //コンソール_偶数の絶対値_スペース区切り();
            配列_偶数の絶対値_スペース区切り();
            連結リスト_偶数の絶対値_スペース区切り();
            //コンソール_3以下符号反転_スペース区切り();
            配列_3以下符号反転_スペース区切り();
            連結リスト_3以下符号反転_スペース区切り();
            //コンソール_奇数の二乗_コンマ区切り();
            配列_奇数の二乗_コンマ区切り();
            連結リスト_奇数の二乗_コンマ区切り();
            //コンソール_偶数の絶対値_コンマ区切り();
            配列_偶数の絶対値_コンマ区切り();
            連結リスト_偶数の絶対値_コンマ区切り();
            //コンソール_3以下符号反転_コンマ区切り();
            配列_3以下符号反転_コンマ区切り();
            連結リスト_3以下符号反転_コンマ区切り();
        }

        private static int[] array = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static ListNode list = new ListNode { Value = 1,
                Next = new ListNode { Value = 2,
                Next = new ListNode { Value = 3,
                Next = new ListNode { Value = 4,
                Next = new ListNode { Value = 5,
                Next = new ListNode { Value = 6,
                Next = new ListNode { Value = 7,
                }}}}}}};

        private static void コンソール_奇数の二乗_1行1個()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 1)
                {
                    Console.WriteLine(x * x);
                }
            }
        }

        private static void 配列_奇数の二乗_1行1個()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 1)
                {
                    Console.WriteLine(x * x);
                }
            }
        }

        private static void 連結リスト_奇数の二乗_1行1個()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 1)
                {
                    Console.WriteLine(x * x);
                }
            }
        }

        private static void コンソール_偶数の絶対値_1行1個()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 0)
                {
                    Console.WriteLine(Math.Abs(x));
                }
            }
        }

        private static void 配列_偶数の絶対値_1行1個()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 0)
                {
                    Console.WriteLine(Math.Abs(x));
                }
            }
        }

        private static void 連結リスト_偶数の絶対値_1行1個()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 0)
                {
                    Console.WriteLine(Math.Abs(x));
                }
            }
        }

        private static void コンソール_3以下符号反転_1行1個()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if (x <= 3)
                {
                    Console.WriteLine(-x);
                }
            }
        }

        private static void 配列_3以下符号反転_1行1個()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if (x <= 3)
                {
                    Console.WriteLine(-x);
                }
            }
        }

        private static void 連結リスト_3以下符号反転_1行1個()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if (x <= 3)
                {
                    Console.WriteLine(-x);
                }
            }
        }

        private static void コンソール_奇数の二乗_スペース区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 1)
                {
                    Console.Write("{0} ", x * x);
                }
            }
        }

        private static void 配列_奇数の二乗_スペース区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 1)
                {
                    Console.Write("{0} ", x * x);
                }
            }
        }

        private static void 連結リスト_奇数の二乗_スペース区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 1)
                {
                    Console.Write("{0} ", x * x);
                }
            }
        }

        private static void コンソール_偶数の絶対値_スペース区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 0)
                {
                    Console.Write("{0} ", Math.Abs(x));
                }
            }
        }

        private static void 配列_偶数の絶対値_スペース区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 0)
                {
                    Console.Write("{0} ", Math.Abs(x));
                }
            }
        }

        private static void 連結リスト_偶数の絶対値_スペース区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 0)
                {
                    Console.Write("{0} ", Math.Abs(x));
                }
            }
        }

        private static void コンソール_3以下符号反転_スペース区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if (x <= 3)
                {
                    Console.Write("{0} ", -x);
                }
            }
        }

        private static void 配列_3以下符号反転_スペース区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if (x <= 3)
                {
                    Console.Write("{0} ", -x);
                }
            }
        }

        private static void 連結リスト_3以下符号反転_スペース区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if (x <= 3)
                {
                    Console.Write("{0} ", -x);
                }
            }
        }

        private static void コンソール_奇数の二乗_コンマ区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 1)
                {
                    Console.Write("{0},", x * x);
                }
            }
        }

        private static void 配列_奇数の二乗_コンマ区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 1)
                {
                    Console.Write("{0},", x * x);
                }
            }
        }

        private static void 連結リスト_奇数の二乗_コンマ区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 1)
                {
                    Console.Write("{0},", x * x);
                }
            }
        }

        private static void コンソール_偶数の絶対値_コンマ区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if ((x % 2) == 0)
                {
                    Console.Write("{0},", Math.Abs(x));
                }
            }
        }

        private static void 配列_偶数の絶対値_コンマ区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if ((x % 2) == 0)
                {
                    Console.Write("{0},", Math.Abs(x));
                }
            }
        }

        private static void 連結リスト_偶数の絶対値_コンマ区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if ((x % 2) == 0)
                {
                    Console.Write("{0},", Math.Abs(x));
                }
            }
        }

        private static void コンソール_3以下符号反転_コンマ区切り()
        {
            while (true)
            {
                int x;
                if (!int.TryParse(Console.ReadLine(), out x)) break;
                if (x <= 3)
                {
                    Console.Write("{0},", -x);
                }
            }
        }

        private static void 配列_3以下符号反転_コンマ区切り()
        {
            for (int i = 0; i < array.Length; i++)
            {
                var x = array[i];
                if (x <= 3)
                {
                    Console.Write("{0},", -x);
                }
            }
        }

        private static void 連結リスト_3以下符号反転_コンマ区切り()
        {
            for (ListNode node = list; node != null; node = node.Next)
            {
                var x = node.Value;
                if (x <= 3)
                {
                    Console.Write("{0},", -x);
                }
            }
        }
    }
}
