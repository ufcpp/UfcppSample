﻿using System;
using System.Xml.Linq;

namespace Reflection
{
	class Program
	{
		static void Main(string[] args)
		{
			Load(
@"
<Triangle xmlns='Shape'>
	<P1><Point><X>0</X><Y>0</Y></Point></P1>
	<P2><Point><X>1</X><Y>0</Y></Point></P2>
	<P3><Point><X>0</X><Y>2</Y></Point></P3>
</Triangle>
");

			Load(
@"
<Rectangle xmlns='Shape'>
	<Width>3</Width>
	<Height>4</Height>
</Rectangle>
");

			Load(
@"
<Circle xmlns='Shape'>
	<Radius>2</Radius>
</Circle>
");
		}

		static void Load(string xml)
		{
			var doc = XDocument.Parse(xml);
			var p = (Shape.IShape)Loader.LoadFromXml(doc);
			Console.Write("{0}, {1}\n", p, p.GetArea());
		}
	}
}
