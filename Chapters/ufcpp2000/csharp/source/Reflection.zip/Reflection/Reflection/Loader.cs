﻿using System;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace Reflection
{
	public class Loader
	{
		/// <summary>
		/// XML ファイルから、リフレクション機能を使ってインスタンスを生成する。
		/// </summary>
		/// <param name="doc">XML</param>
		/// <returns>生成したインスタンス</returns>
		/// <remarks>
		/// あくまでサンプルなので適当。制約多い。
		/// - 引数なしのコンストラクタを持ってないと駄目
		/// - プロパティ or public フィールドを持ってないと駄目
		/// </remarks>
		public static object LoadFromXml(XDocument doc)
		{
			var root = doc.Root;
			return LoadElement(root);
		}

		/// <summary>
		/// XML エレメントからインスタンスを生成。
		/// </summary>
		/// <param name="root">XML エレメント</param>
		/// <returns>得られたインスタンス</returns>
		static object LoadElement(XElement root)
		{
			var ns = root.Name.Namespace.NamespaceName;
			var assemblyName = ns;

			var className = assemblyName + "." + root.Name.LocalName;

			Assembly asm = Assembly.LoadWithPartialName(assemblyName);
			object o = asm.CreateInstance(className);

			if (o == null)
				throw new InvalidOperationException("引数なしのコンストラクタを持っている必要有り");

			foreach (var elem in root.Elements())
			{
				if (elem.Nodes().Count() != 1)
					throw new NotSupportedException("まだコレクションに未対応");

				var node = elem.Nodes().First();

				Type type = o.GetType();

				var property = type.GetProperty(elem.Name.LocalName);
				if (property != null)
				{
					var propType = property.PropertyType;
					var val = LoadNode(node, propType);
					property.SetValue(o, val, null);
					continue;
				}

				var field = type.GetField(elem.Name.LocalName);
				if (field != null)
				{
					var propType = field.FieldType;
					var val = LoadNode(node, propType);
					field.SetValue(o, val);
					continue;
				}
			}

			return o;
		}

		/// <summary>
		/// テキストノードかエレメントからインスタンスを生成。
		/// テキストノードなら、int.Parse などをコールしてインスタンス化。
		/// エレメントなら、LoadElement を再帰呼び出し。
		/// </summary>
		/// <param name="node">XML ノード</param>
		/// <param name="t">期待される型</param>
		/// <returns>得られたインスタンス</returns>
		static object LoadNode(XNode node, Type t)
		{
			if (node.NodeType == System.Xml.XmlNodeType.Text)
			{
				var text = (XText)node;
				var val = t.InvokeMember("Parse",
					BindingFlags.Static | BindingFlags.Public | BindingFlags.InvokeMethod,
					null, null, new object[] { text.Value }
					);

				return val;
			}

			if (node.NodeType == System.Xml.XmlNodeType.Element)
			{
				var val = LoadElement((XElement)node);
				if (val.GetType() != t)
					throw new InvalidCastException("型が合わない");
				return val;
			}

			throw new NotSupportedException("サポート外");
		}
	}
}
