﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shape
{
	public class Circle : IShape
	{
		public double Radius { get; set; }

		public override string ToString()
		{
			return string.Format("circle ({0})", this.Radius);
		}

		public double GetArea()
		{
			return Math.PI * this.Radius * this.Radius;
		}
	}
}
