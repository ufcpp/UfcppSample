﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shape
{
	class Triangle : IShape
	{
		public Point P1 { get; set; }
		public Point P2 { get; set; }
		public Point P3 { get; set; }

		public override string ToString()
		{
			return string.Format("triangle ({0}, {1}, {2})", this.P1, this.P2, this.P3);
		}

		public double GetArea()
		{
			var x1 = this.P2.X - this.P1.X;
			var y1 = this.P2.Y - this.P1.Y;
			var x2 = this.P3.X - this.P1.X;
			var y2 = this.P3.Y - this.P1.Y;
			var det = x1 * y2 - y2 * x2;

			return Math.Abs(det) / 2;
		}
	}
}
