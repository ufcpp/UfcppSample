﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shape
{
	public class Rectangle : IShape
	{
		public double Width { get; set; }
		public double Height { get; set; }

		public override string ToString()
		{
			return string.Format("rectangle ({0}, {1})", this.Width, this.Height);
		}

		public double GetArea()
		{
			return this.Width * this.Height;
		}
	}
}
