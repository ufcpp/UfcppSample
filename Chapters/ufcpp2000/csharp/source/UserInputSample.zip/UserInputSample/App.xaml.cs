﻿using System.Windows;

namespace UserInputSample
{
    public partial class App : Application
    {
    }
}
