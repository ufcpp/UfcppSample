﻿using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;

#region 多重ディスパッチ ダックタイプインターフェース
/*
ほんとにやりたいことは・・・

interface SetComparer<T, U>
{
    func (x T, y U) AreEqual() bool;
    func (x T) Contains(y U) bool;
}

var x = new Range { Min = 1, Max = 4 };
var y = new List { Values = { 1, 2, 3, 4 } };
(x, y).AreEqual();
x.Contains(y);

みたいな記法。

実際にできるのは・・・

interface SetComparer
{
    bool Equal();
    bool Contain();
}

var x = new Range { Min = 1, Max = 4 };
var y = new List { Values = { 1, 2, 3, 4 } };
SetComparer c = AsComparer(x, y);
c.Equal();
c.Contain();
 */

/// <summary>
/// SetComparer。
/// C# 用の interface。
/// </summary>
interface ISetComparer
{
    bool Equal();
    bool Contain();
}

/// <summary>
/// いわゆる仮想メソッドテーブル。
/// </summary>
class SetComparerDispatchTable
{
    public Delegate Equal;
    public Delegate Contain;
}

/// <summary>
/// 動的ディスパッチ用のアダプター。
/// 仮想メソッドテーブル ＋ インスタンスを抱えてる感じ。
/// </summary>
/// <typeparam name="T">U と合わせて、ISetComparer に Duck Typing したい型。</typeparam>
/// <typeparam name="U">T 同様。</typeparam>
class SetComparerDispatcher<T, U> : ISetComparer
{
    public T X;
    public U Y;
    public SetComparerDispatchTable VTable;

    #region C# の仕様とつなぎこむためのの部分
    // 本来は、コンパイラのコード生成で IShape を介さずに呼び出したい。

    public bool Equal()
    {
        return ((Func<T, U, bool>)VTable.Equal)(X, Y);
    }

    public bool Contain()
    {
        return ((Func<T, U, bool>)VTable.Contain)(X, Y);
    }

    #endregion
}

static partial class Methods
{
    /// <summary>
    /// 任意の型を ISetComparer に Duck Typing するためのキャスト関数。
    /// </summary>
    /// <remarks>
    /// めんどくさかったんで、ジェネリクス ＋ リフレクションを使ったものだけ定義。
    /// キャッシュ機構も未実装。
    /// きっと遅そう。
    /// </remarks>
    /// <typeparam name="T">U と合わせて、ISetComparer に Duck Typing したい型。</typeparam>
    /// <typeparam name="U">T 同様。</typeparam>
    /// <param name="x">インスタンス1。</param>
    /// <param name="y">インスタンス2。</param>
    /// <returns>ISetComparer 化したもの。</returns>
    public static ISetComparer AsSetComparer<T, U>(T x, U y)
    {
        return new SetComparerDispatcher<T, U>
        {
            X = x,
            Y = y,
            VTable = new SetComparerDispatchTable
            {
                Equal = Create("Equals", typeof(Func<T, U, bool>), new[] { typeof(T), typeof(U) }),
                Contain = Create("Contains", typeof(Func<T, U, bool>), new[] { typeof(T), typeof(U) }),
            }
        };
    }
}

#endregion
#region 型定義

/// <summary>
/// 1要素だけからなる集合。
/// </summary>
class Element
{
    public int Value;

    public override string ToString()
    {
        return string.Format("{{ {0} }}", Value);
    }
}

/// <summary>
/// 区間集合。
/// </summary>
class Range
{
    public int Minimum;
    public int Maximum;

    public override string ToString()
    {
        return string.Format("({0}, {1})", Minimum, Maximum);
    }
}

/// <summary>
/// いくつかの要素からなる集合。
/// </summary>
class List
{
    List<int> v = new List<int>();
    public List<int> Values { get { return v; } }

    public override string ToString()
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("{ ");
        foreach (var x in Values)
        {
            sb.Append(x);
            sb.Append(" ");
        }
        sb.Append("}");
        return sb.ToString();
    }
}

#endregion
#region 比較関数

static partial class Methods
{
    public static bool Equals(Element x, Element y)
    {
        return x.Value == y.Value;
    }
    public static bool Equals(Element x, Range y) { return false; }
    public static bool Equals(Range x, Element y) { return false; }
    public static bool Equals(Element x, List y) { return false; }
    public static bool Equals(List x, Element y) { return false; }

    public static bool Equals(Range x, Range y)
    {
        return x.Minimum == y.Minimum && x.Maximum == y.Maximum;
    }

    public static bool Equals(List x, Range y)
    {
        return Equals(y, x);
    }

    public static bool Equals(Range x, List y)
    {
        return Contains(x, y) && Contains(y, x);
    }

    public static bool Equals(List x, List y)
    {
        return x.Values.SequenceEqual(y.Values);
    }

    public static bool Contains(Element x, Element y)
    {
        return Equals(x, y);
    }

    public static bool Contains(Element x, Range y) { return false; }

    public static bool Contains(Range x, Element y)
    {
        return x.Minimum <= y.Value && y.Value <= x.Maximum;
    }

    public static bool Contains(Element x, List y) { return false; }

    public static bool Contains(List x, Element y)
    {
        return x.Values.Contains(y.Value);
    }

    public static bool Contains(Range x, Range y)
    {
        return x.Minimum <= y.Minimum && y.Maximum <= x.Maximum;
    }

    public static bool Contains(List x, Range y)
    {
        for (int v = y.Minimum; v <= y.Maximum; v++)
        {
            if (!x.Values.Contains(v))
                return false;
        }
        return true;
    }

    public static bool Contains(Range x, List y)
    {
        foreach (var v in y.Values)
        {
            if (x.Minimum > v || v > x.Maximum)
                return false;
        }
        return true;
    }

    public static bool Contains(List x, List y)
    {
        foreach (var v in y.Values)
        {
            if (!x.Values.Contains(v))
                return false;
        }
        return true;
    }
}

#endregion

/// <summary>
/// 利用例。
/// </summary>
class TestIntegerSet
{
    /// <summary>
    /// 上で書いたコードの利用例。
    /// </summary>
    public static void Test()
    {
        var a = new Element { Value = 1 };
        var b = new Element { Value = 7 };
        var c = new Range { Minimum = 0, Maximum = 10 };
        var d = new Range { Minimum = 5, Maximum = 8 };
        var e = new List { Values = { 1, 7 } };
        var f = new List { Values = { 5, 6, 7, 8 } };
        var g = new List { Values = { 2, 7 } };

        Output(a, a); Output(a, b); Output(a, c); Output(a, d); Output(a, e); Output(a, f); Output(a, g);
        Output(b, a); Output(b, b); Output(b, c); Output(b, d); Output(b, e); Output(b, f); Output(b, g);
        Output(c, a); Output(c, b); Output(c, c); Output(c, d); Output(c, e); Output(c, f); Output(c, g);
        Output(d, a); Output(d, b); Output(d, c); Output(d, d); Output(d, e); Output(d, f); Output(d, g);
        Output(e, a); Output(e, b); Output(e, c); Output(e, d); Output(e, e); Output(e, f); Output(e, g);
        Output(f, a); Output(f, b); Output(f, c); Output(f, d); Output(f, e); Output(f, f); Output(f, g);
        Output(g, a); Output(g, b); Output(g, c); Output(g, d); Output(g, e); Output(g, f); Output(g, g);
    }

    static void Output<T, U>(T x, U y)
    {
        // 形上はダックタイプインターフェースになってるけど、静的型チェック効かないのがなんとも。
        var pair = Methods.AsSetComparer(x, y);

        // 通常の dynamic 使った実装と比べて利点というと、利用時に IntelliSense が利くことくらい。
        var equal = pair.Equal() ? "" : "not ";
        var contain = pair.Contain() ? "" : "not ";

        Console.WriteLine("{0} {2}equal {1}", x, y, equal);
        Console.WriteLine("{0} {2}contain {1}", x, y, contain);
    }
}
