﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Trial
{
    class Program
    {
        static void Main(string[] args)
        {
            TestIntegerSet.Test();
            TestShape.Test();
        }
    }
}
