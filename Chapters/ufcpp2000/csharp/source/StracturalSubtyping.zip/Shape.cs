﻿using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;

#region type Shape interface { func Area() double; func Perimeter() double; }

/// <summary>
/// Shape。
/// C# 用の interface。
/// </summary>
interface IShape
{
    /// <summary>
    /// 面積を求める。
    /// </summary>
    /// <returns>面積。</returns>
    double Area();

    /// <summary>
    /// 周長を求める。
    /// </summary>
    /// <returns>周長。</returns>
    double Perimeter();
}

/// <summary>
/// いわゆる仮想メソッドテーブル。
/// </summary>
class ShapeDispatchTable
{
    public Delegate Area;
    public Delegate Perimeter;
}

/// <summary>
/// 動的ディスパッチ用のアダプター。
/// 仮想メソッドテーブル ＋ インスタンスを抱えてる感じ。
/// </summary>
/// <typeparam name="T">IShape に Duck Typing したい型。</typeparam>
class ShapeDispatcher<T> : IShape
{
    public T Instance;
    public ShapeDispatchTable VTable;

    #region C# の仕様とつなぎこむためのの部分
    // 本来は、コンパイラのコード生成で IShape を介さずに呼び出したい。

    public double Area()
    {
        return ((Func<T, double>)VTable.Area)(Instance);
    }

    public double Perimeter()
    {
        return ((Func<T, double>)VTable.Perimeter)(Instance);
    }

    #endregion
}

static partial class Methods
{
#if DYNAMIC
    /// <summary>
    /// 任意の型を IShape に Duck Typing するためのキャスト関数。
    /// リフレクションを使った動的生成版。
    /// </summary>
    /// <remarks>
    /// 毎度リフレクションしてると重たいけど、キャッシュ機構も組み込んでるしそれなりにパフォーマンス出ると思う。
    /// </remarks>
    /// <typeparam name="T">IShape にキャストしたい型。</typeparam>
    /// <param name="x">そのインスタンス。</param>
    /// <returns>IShape 化したもの。</returns>
    public static IShape AsShape(this object x)
    {
        var t = x.GetType();

        Func<object, IShape> factory;

        if (shapeFactoryChache.ContainsKey(t))
        {
            factory = shapeFactoryChache[t];
        }
        else
        {
            factory = MakeShapeFactoryT(t);

            if (factory == null)
            {
                var message = string.Format("{0} を IShape に変換できません", t.Name);
                throw new InvalidCastException(message);
            }
        }

        return factory(x);
    }

    /// <summary>
    /// 生成メソッドのキャッシュ機構用の辞書。
    /// </summary>
    static Dictionary<Type, Func<object, IShape>> shapeFactoryChache = new Dictionary<Type, Func<object, IShape>>();

    /// <summary>
    /// リフレクション面倒なんで1段ラッピング。
    /// MakeShapeFactory&lt;T&gt; を呼び出すだけの簡単なお仕事。
    /// </summary>
    /// <param name="t">呼び出したい型。</param>
    /// <returns>生成メソッド。</returns>
    /// <see cref="MakeShapeFactory"/>
    private static Func<object, IShape> MakeShapeFactoryT(Type t)
    {
        var g = methods.GetMethod("MakeShapeFactory", BindingFlags.NonPublic | BindingFlags.Static);
        var m = g.MakeGenericMethod(t);
        return (Func<object, IShape>)m.Invoke(null, new object[0]);
    }

    /// <summary>
    /// T 型用の IShape 生成メソッドを作る。
    /// T 型用の ShapeDispatchTable を作って、ShapeDispatcher<T> を new する匿名メソッドを生成。
    /// </summary>
    /// <remarks>
    /// new ShapeDispatcher&lt;T&gt; とかをリフレクション使って呼び出すのが面倒だったんで、
    /// 一度ジェネリックメソッドで実装。
    /// こいつをリフレクションで呼ぶだけなら比較的簡単。
    /// </remarks>
    /// <typeparam name="T">IShape 化したい型。</typeparam>
    /// <returns>生成メソッド。</returns>
    private static Func<object, IShape> MakeShapeFactory<T>()
    {
        var t = typeof(T);

        var area = (Func<T, double>)Create("Area", typeof(Func<T, double>), new Type[] { typeof(T) });
        if (area == null) return null;

        var perimeter = (Func<T, double>)Create("Perimeter", typeof(Func<T, double>), new Type[] { typeof(T) });
        if (perimeter == null) return null;

        var vtable = new ShapeDispatchTable
        {
            Area = area,
            Perimeter = perimeter,
        };

        Func<object, IShape> f =
            o => new ShapeDispatcher<T>
            {
                Instance = (T)o,
                VTable = vtable,
            };

        shapeFactoryChache[t] = f;
        return f;
    }

    static readonly Type methods = typeof(Methods);

    static Delegate Create(string name, Type delegateType, Type[] parameterTypes)
    {
        // Methods クラスのメンバーの静的メソッドを探す
        var info = methods.GetMethod(name, BindingFlags.Public | BindingFlags.Static, Type.DefaultBinder, parameterTypes, null);
        if (info != null)
            return Delegate.CreateDelegate(delegateType, info);

        // リフレクション使って呼び出されてる中で例外投げると、
        // リフレクションの外から try-catch できなくなるみたいなんで
        // しょうがなくいったん null を返す。
        return null;
    }
#endif
}

#endregion
#region type Rectangle struct { var Width double; var Height double; }
// func (x Rectangle) Area () double { return x.Width * x.Height; }
// func (x Rectangle) Perimeter () double { return 2 * (x.Width + x.Height); }

/// <summary>
/// 長方形。
/// </summary>
/// <remarks>
/// クラス/構造体本体にはフィールドしか定義しない。
/// 当然、IShape も継承しない。
/// </remarks>
struct Rectangle
{
    public double Width;
    public double Height;
}

/// <summary>
/// メソッドは全部、拡張メソッド（static メソッド）として定義する。
/// </summary>
static partial class Methods
{
    /// <summary>
    /// Rectangle 向けの Area 実装。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>面積。</returns>
    public static double Area(this Rectangle x)
    {
        return x.Width * x.Height;
    }

    /// <summary>
    /// Rectangle 向けの Perimeter 実装。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>周長。</returns>
    public static double Perimeter(this Rectangle x)
    {
        return 2 * (x.Width + x.Height);
    }

#if !DYNAMIC
    /// <summary>
    /// Rectangle 型を IShape に Duck Typing するためのキャスト関数。
    /// リフレクション使わない（コンパイル時解決が可能）ならこうやる。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>IShape 化したもの。</returns>
    public static IShape AsShape(this Rectangle x)
    {
        return new ShapeDispatcher<Rectangle>
        {
            Instance = x,
            VTable = new ShapeDispatchTable
            {
                Area = new Func<Rectangle, double>(Area),
                Perimeter = new Func<Rectangle, double>(Perimeter),
            },
        };
    }
#endif
}

#endregion
#region type Circle struct { var Radius double; }
// func (x Circle) Area () double { return PI * x.Radius * x.Radius; }
// func (x Circle) Perimeter () double { return 2 * Math.PI * x.Radius); }

/// <summary>
/// 円。
/// </summary>
/// <remarks>
/// Rectangle 同様、フィールドしか定義しない。
/// </remarks>
struct Circle
{
    public double Radius;
}

static partial class Methods
{
    /// <summary>
    /// Circle 向けの Area 実装。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>面積。</returns>
    public static double Area(this Circle x)
    {
        return Math.PI * x.Radius * x.Radius;
    }

    /// <summary>
    /// Circle 向けの Perimeter 実装。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>周長。</returns>
    public static double Perimeter(this Circle x)
    {
        return 2 * Math.PI * x.Radius;
    }

#if !DYNAMIC
    /// <summary>
    /// Circle 型を IShape に Duck Typing するためのキャスト関数。
    /// Shape 同様、コンパイル時解決用。
    /// </summary>
    /// <param name="x">インスタンス。</param>
    /// <returns>IShape 化したもの。</returns>
    public static IShape AsShape(this Circle x)
    {
        return new ShapeDispatcher<Circle>
        {
            Instance = x,
            VTable = new ShapeDispatchTable
            {
                Area = new Func<Circle, double>(Area),
                Perimeter = new Func<Circle, double>(Perimeter),
            },
        };
    }
#endif
}

#endregion

/// <summary>
/// 利用例。
/// </summary>
class TestShape
{
    /// <summary>
    /// 上で書いたコードの利用例。
    /// </summary>
    public static void Test()
    {
        var rect = new Rectangle { Width = 2, Height = 3 };
        var circle = new Circle { Radius = 1.41421356 };

        Console.WriteLine("長方形");
        Output(rect.AsShape());
        Output(new Rectangle { Width = 1, Height = 1 }.AsShape());
        Output(new Rectangle { Width = 1.5, Height = 0.8 }.AsShape());

        Console.WriteLine("円");
        Output(circle.AsShape());
        Output(new Circle { Radius = 1 }.AsShape());
        Output(new Circle { Radius = 2 }.AsShape());

        try
        {
            // 不正な型変換してみる
            var x = 10.AsShape();
        }
        catch (InvalidCastException)
        {
            Console.WriteLine("変換失敗したはず");
        }
    }

    /// <summary>
    /// よくある interface のサンプルコード。
    /// 図形の面積と周長を Console 出力。
    /// </summary>
    /// <param name="s"></param>
    static void Output(IShape s)
    {
        Console.WriteLine("面積: {0}", s.Area());
        Console.WriteLine("周長: {0}", s.Perimeter());
    }
}
