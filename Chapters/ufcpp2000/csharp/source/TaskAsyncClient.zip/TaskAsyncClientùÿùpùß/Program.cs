﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TaskAsyncClient利用例
{
    class Program
    {
        static void Main(string[] args)
        {
            var path = @"..\..\..\SampleService\Service References\ServiceReference1\Reference.cs";
            var source = File.ReadAllText(path);

            var definition = TaskAsyncClient.Extractor.Extract(source);

            ShowDefinition(definition);

            var generated = TaskAsyncClient.Generator.Generate(definition);
            File.WriteAllText("test.cs", generated);
        }

        private static void ShowDefinition(TaskAsyncClient.ServiceClient definition)
        {

            Console.WriteLine(definition.Namespace);
            Console.WriteLine(definition.Class);

            foreach (var m in definition.Methods)
            {
                Console.WriteLine(m.Name);
                Console.WriteLine(m.ReturnType);
                Console.WriteLine(m.ParameterList);
                Console.WriteLine(m.ArgumentList);
            }
        }
    }
}
