﻿using System.Linq;
using System.Text.RegularExpressions;

namespace TaskAsyncClient
{
    /// <summary>
    /// OperationContract なメソッドの情報。
    /// </summary>
    public class Method
    {
        /// <summary>
        /// メソッド名。
        /// Async の部分は除く。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 戻り値の型。
        /// </summary>
        public string ReturnType { get; set; }

        string parameters;
        string arguments;

        /// <summary>
        /// 引数リスト。
        /// "int x, int y" みたいな文字列。
        /// </summary>
        public string ParameterList
        {
            get { return parameters; }
            set
            {
                parameters = value;
                arguments = RemoveTypeName(value);
            }
        }

        /// <summary>
        /// ParameterList から型名を抜いたもの。
        /// ParameterList が "int x, int y" なら、こっちは "x, y" に。
        /// </summary>
        public string ArgumentList { get { return arguments; } }

        static readonly Regex regParameter = new Regex(@"\s(?<name>[^\)\s,]*)(,|$)", RegexOptions.Compiled);
        private string RemoveTypeName(string value)
        {
            return string.Join(", ",
                regParameter.Matches(value).OfType<Match>().Select(x => x.Groups["name"].Value).Where(x => !string.IsNullOrEmpty(x)));
        }
    }
}
