﻿using System.Collections.Generic;

namespace TaskAsyncClient
{
    /// <summary>
    /// ServiceContract に対するクライアント クラスの情報。
    /// </summary>
    public class ServiceClient
    {
        /// <summary>
        /// 名前空間。
        /// </summary>
        public string Namespace { get; set; }

        /// <summary>
        /// クラス名。
        /// 末尾の Client は除く。
        /// </summary>
        public string Class { get; set; }

        private IList<Method> methods = new List<Method>();

        /// <summary>
        /// OperationContract なメソッド一覧。
        /// </summary>
        public IList<Method> Methods
        {
            get { return methods; }
            set { methods = value; }
        }
    }
}
