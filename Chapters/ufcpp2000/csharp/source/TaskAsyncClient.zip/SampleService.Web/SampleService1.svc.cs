﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;

namespace SampleService.Web
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class SampleService1
    {
        [OperationContract]
        public void DoWork()
        {
        }

        [OperationContract]
        public int Calculate(int x)
        {
            return x;
        }

        [OperationContract]
        public IEnumerable<TestData> GetData()
        {
            for (int i = 0; i < 10; i++)
            {
                yield return new TestData
                {
                    Name = i.ToString(),
                    Value = i,
                };
            }
        }

        [OperationContract]
        public IEnumerable<TestData> GetDataConditional(int x, int y, List<string> conds)
        {
            for (int i = x; i < y; i++)
            {
                yield return new TestData
                {
                    Name = i.ToString(),
                    Value = i,
                };
            }
        }
    }

    [DataContract]
    public class TestData
    {
        public String Name { get; set; }
        public int Value { get; set; }
    }
}
