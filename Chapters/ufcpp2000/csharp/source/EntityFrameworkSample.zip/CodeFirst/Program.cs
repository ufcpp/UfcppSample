﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeFirst.Models;

namespace CodeFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            //SampleData.Data.Create();

using (var db = new ComicDatabase())
{
    var q =
        from s in db.Series
        where s.Name.Contains("先生")
        select new { Title = s.Name, Author = s.Author.Name };

    foreach (var s in q)
    {
        Console.Write("{0}, {1}\n", s.Title, s.Author);
    }

    Console.Write("\n{0}\n", q);
}

            //簡単な例();
            //タイトルに先生という文字が入ったシリーズ一覧();
            //テーブル結合の例_作者ごとにシリーズ一覧を詳細表示();
            //クエリ発行タイミングの例1();
            //クエリ発行タイミングの例2();
            //メソッド呼び出しの例();
        }

        private static void メソッド呼び出しの例()
        {
            using (var db = new ComicDatabase())
            {
                var q =
                  from s in db.Series
                  where s.Name.Contains("先生")
                    || s.Name.StartsWith("吼")
                    || s.Name.EndsWith("社長")
                  select s;

                foreach (var s in q)
                {
                    Console.Write("{0}\n", s.Name);
                }
            }
        }

        private static void クエリ発行タイミングの例2()
        {
            using (var db = new ComicDatabase())
            {
                Console.Write("begin query expression\n");
                // この時点ではクエリは発行されない？
                // EF だと DataSet にキャッシュ持ってて、リロードを明示しないとクエリ1回きりっぽい？
                var q =
                  from s in db.Series
                  where s.Name.Contains("先生")
                  select s;
                Console.Write("end query expression\n");

                Console.Write("begin foreach\n");
                for (int i = 0; i < 2; ++i)
                {
                    foreach (var s in q) // ここで毎回クエリ発行
                    {
                        Console.Write("  - {0}\n", s.Name);
                    }
                }
                Console.Write("end foreach\n");
            }
        }

        private static void クエリ発行タイミングの例1()
        {
            using (var db = new ComicDatabase())
            {
                foreach (var a in db.Authors) // ここと
                {
                    Console.Write("・{0}\n", a.Name);
                    foreach (var s in a.Series) // ここでクエリ発行
                    {
                        Console.Write("  - {0}\n", s.Name);
                    }
                }
            }
        }

        private static void テーブル結合の例_作者ごとにシリーズ一覧を詳細表示()
        {
            using (var db = new ComicDatabase())
            {
                var q =
                  from a in db.Authors
                  from s in a.Series
                  select new
                  {
                      Title = s.Name,
                      Author = a.Name,
                      Publisher = s.Publisher.Name,
                      Num = s.Books.Count
                  };

                foreach (var s in q)
                {
                    Console.Write("{0} ({2}), {1} 作, 全 {3} 巻\n",
                      s.Title, s.Author, s.Publisher, s.Num);
                }
            }
        }

        private static void タイトルに先生という文字が入ったシリーズ一覧()
        {
            using (var db = new ComicDatabase())
            {
                var q =
                    from s in db.Series
                    where s.Name.Contains("先生")
                    select new { Title = s.Name, Author = s.Author.Name };

                foreach (var s in q)
                {
                    Console.Write("{0}, {1}\n", s.Title, s.Author);
                }
            }
        }

        private static void 簡単な例()
        {
            using (var db = new ComicDatabase())
            {
                var q =
                    from a in db.Authors
                    where a.Name == "島本和彦" || a.Name == "赤松健"
                    select a;

                foreach (var a in q)
                {
                    Console.Write("{0}, {1:yyyy/M/d}, {2}\n", a.Name, a.Birthday, a.Url);
                }
            }
        }
    }
}
