﻿using System.Data.Entity;

namespace CodeFirst.Models
{
    public class ComicDatabase : DbContext
    {
        public DbSet<Author> Authors { get; set; }
        public DbSet<Publisher> Publishers { get; set; }
        public DbSet<Series> Series { get; set; }
        public DbSet<Book> Books { get; set; }
    }
}
