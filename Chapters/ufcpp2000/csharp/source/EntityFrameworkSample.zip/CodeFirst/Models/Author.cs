﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace CodeFirst.Models
{
    public class Author
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(100)]
        public string Kana { get; set; }

        public DateTime? Birthday { get; set; }

        [StringLength(512)]
        public string Url { get; set; }

        public virtual IList<Series> Series { get; set; }
    }
}
