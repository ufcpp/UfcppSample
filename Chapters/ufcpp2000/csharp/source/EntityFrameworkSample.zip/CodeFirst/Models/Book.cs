﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Models
{
    public class Book
    {
        public int Id { get; set; }

        public int? Volume { get; set; }

        public DateTime? ReleaseDate { get; set; }

        public int? Price { get; set; }

        public Series Series { get; set; }
    }
}
