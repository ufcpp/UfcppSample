﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Models
{
    public class Series
    {
        public int Id { get; set; }

        [Required]
        [StringLength(512)]
        public string Name { get; set; }

        public Author Author { get; set; }

        public Publisher Publisher { get; set; }

        public virtual IList<Book> Books { get; set; }
    }
}
