﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace CodeFirst.Models
{
    public class Publisher
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        public virtual IList<Series> Series { get; set; }
    }
}
