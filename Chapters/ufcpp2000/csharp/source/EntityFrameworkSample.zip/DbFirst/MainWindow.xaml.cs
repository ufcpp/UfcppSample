﻿using System.Linq;
using System.Windows;

namespace DbFirst
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new Entities())
            {
                var q =
                  from a in db.Authors
                  from s in a.Series
                  select new
                  {
                      シリーズ名 = s.Name,
                      作者 = a.Name,
                      出版社 = s.Publisher.Name,
                      巻数 = s.Books.Count
                  };

                this.Data.ItemsSource = q;
            }
        }
    }
}
