﻿using System;

namespace CodeFirstInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create();

            Query();
        }

        /// <summary>
        /// 問い合わせの例。
        /// </summary>
        private static void Query()
        {
            Console.WriteLine("Table Per Hierarchy");
            using (var db = new TablePerHierarchyContext())
            {
                Query(db.Shapes);
            }

            // ↑↓見ての通り、コンテキストが違う以外は全く一緒。

            Console.WriteLine("Table Per Type");
            using (var db = new TablePerTypeContext())
            {
                Query(db.Shapes);
            }
        }

        private static void Query(System.Data.Entity.DbSet<Shape> shapes)
        {
            foreach (var x in shapes)
            {
                Console.WriteLine("{0}: {1}", x.GetType().Name, x.GetArea());
            }
        }

        /// <summary>
        /// サンプル データを作る。
        /// </summary>
        private static void Create()
        {
            using (var db = new TablePerHierarchyContext())
            {
                Create(db.Shapes);
                db.SaveChanges();
            }

            // ↑↓見ての通り、コンテキストが違う以外は全く一緒。

            using (var db = new TablePerTypeContext())
            {
                Create(db.Shapes);
                db.SaveChanges();
            }
        }

        private static void Create(System.Data.Entity.DbSet<Shape> shapes)
        {
            shapes.Add(new Rectangle { Width = 10, Height = 20 });
            shapes.Add(new Rectangle { Width = 15, Height = 12 });
            shapes.Add(new Circle { Radius = 1.5f });
            shapes.Add(new Circle { Radius = 3 });
        }
    }
}
