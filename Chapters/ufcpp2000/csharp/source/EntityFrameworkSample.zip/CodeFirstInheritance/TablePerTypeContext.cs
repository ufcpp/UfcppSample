﻿using System.Data.Entity;

namespace CodeFirstInheritance
{
    /// <summary>
    /// table-per-type 版のデータベース コンテキスト。
    /// </summary>
    public class TablePerTypeContext : DbContext
    {
        public DbSet<Shape> Shapes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Rectangle>().ToTable("Rectangle");
            modelBuilder.Entity<Circle>().ToTable("Circle");
        }
    }
}
