﻿using System;

namespace CodeFirstInheritance
{
    public abstract class Shape
    {
        public int Id { get; set; }

        public abstract float GetArea();
    }

    public class Rectangle : Shape
    {
        public float Width { get; set; }

        public float Height { get; set; }

        public override float GetArea()
        {
            return this.Width * this.Height;
        }
    }

    public class Circle : Shape
    {
        public float Radius { get; set; }

        public override float GetArea()
        {
            return (float)(Math.PI * this.Radius * this.Radius);
        }
    }
}
