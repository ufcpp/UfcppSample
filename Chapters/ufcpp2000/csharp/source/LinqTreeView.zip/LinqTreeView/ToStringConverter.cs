﻿using System.Windows.Media;
using System.Windows.Data;
using System.Linq.Expressions;

namespace LinqTreeView
{
	[ValueConversion(typeof(Expression), typeof(string))]
	class ToStringConverter : IValueConverter
	{
		public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			var exp = value as Expression;
            if (exp != null)
            {
                return string.Format("{0}\nNodeType: {1}\nclass: {2}",
                    value.ToString(),
                    exp.NodeType,
                    exp.GetType().Name);
            }

            var bind = value as MemberBinding;
            if (bind != null)
            {
                return string.Format("{0}\nBindingType: {1}\nclass: {2}",
                    bind.ToString(),
                    bind.BindingType,
                    bind.GetType().Name);
            }

            throw new System.NotImplementedException();
        }

		public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new System.NotImplementedException();
		}
	}
}
