using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Exp = System.Linq.Expressions.Expression;

namespace LinqTreeView
{
    /// <summary>
    /// Window1.xaml �̑��ݍ�p���W�b�N
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Window1_Loaded);
        }

        #region �T���v���f�[�^������

        struct Tuple
        {
            public Exp Expression;
            public string Text;
            public string Description;

            public Tuple(Exp exp, string txt, string desc)
            {
                this.Expression = exp;
                this.Text = txt;
                this.Description = desc;
            }
        }

        private static Tuple[] sampleExpressions;

        static Window1()
        {
            sampleExpressions = new[]
            {
                new Tuple(
                    Make.Expression((int x) => 10 * x * -x),
                    "(int x) => 10 * x * -x",
                    "�Z�p���Z�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression((int x) => x > 0 ? 1 : -1),
                    "(int x) => x > 0 ? 1 : -1",
                    "�������Z�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression((Color c) => c.R),
                    "(Color c) => c.R",
                    "�v���p�e�B�A�N�Z�X�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression((Color c) => new SolidColorBrush(c)),
                    "(Color c) => new SolidColorBrush(c)",
                    "�����t���R���X�g���N�^�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression((byte x, byte y, byte z) => new Color { R = x, G = y, B = z }),
                    "(byte x, byte y, byte z) => new Color { R = x, G = y, B = z }",
                    "�����o�������t���̃R���X�g���N�^�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression(() => new int[] { 1, 2, 3 }),
                    "() => new int[] { 1, 2, 3 }",
                    "�z�񐶐��̃T���v���ł��B"
                    ),
                new Tuple(
				    Make.Expression(() => new List<int> { 1, 2, 3 }),
                    "() => new List<int> { 1, 2, 3 }",
                    "���X�g�������̃T���v���ł��B"
                    ),
                new Tuple(
				    Make.Expression(() => new Polyline { ContextMenu = { Width = 10, Height = 10 } }),
                    "() => new Polyline { ContextMenu = { Width = 10, Height = 10 } }",
                    "�ċA�I�ȃ����o�������t���̃R���X�g���N�^�̃T���v���ł��B"
                    ),
                new Tuple(
				    Make.Expression(() => new Polyline { Points = { new Point(1, 2), new Point(3, 4) } }),
                    "() => new Polyline { Points = { new Point(1, 2), new Point(3, 4) } }",
                    "�ċA�I�ȃ��X�g�����o�������t���̃R���X�g���N�^�̃T���v���ł��B"
                    ),
                new Tuple(
                    Make.Expression((double x) => Math.Sin(x)),
                    "(double x) => Math.Sin(x)",
                    "���\�b�h�Ăяo���̃T���v���ł��B"
                    ),
                new Tuple(
				    Make.Expression((Func<int, int> f, int x) => f(x)),
                    "(Func<int, int> f, int x) => f(x)",
                    "�f���Q�[�g�Ăяo���̃T���v���ł��B"
                    ),
                new Tuple(
				    Make.Expression((IEnumerable<int> l) => from x in l where x > 10 select x * x),
                    "(IEnumerable<int> l) => from x in l where x > 10 select x * x",
                    "�N�G�����̃T���v���ł��B"
                    ),
            };
        }

        #endregion

        private void UpdateTree()
        {
            try
            {
                Exp exp = CodeDom.GetExpressionFrom(this.expression.Text);
                this.item.Content = exp;
                this.status.ItemsSource = new[] { string.Empty };
            }
            catch (ExpressionCodeDomException exc)
            {
                this.status.ItemsSource = new[] { exc.Message };
            }
        }

        private void ShowSelectedItem()
        {
            this.item.Content = sampleExpressions[this.combo.SelectedIndex].Expression;
            this.status.ItemsSource = new[] { sampleExpressions[this.combo.SelectedIndex].Description };
        }

        void Window1_Loaded(object sender, RoutedEventArgs e)
        {
            this.combo.ItemsSource = sampleExpressions.Select(x =>
                new Label
                {
                    Content = x.Text,
                    ToolTip = x.Description,
                });
            this.combo.SelectedIndex = 0;
            this.ShowSelectedItem();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.UpdateTree();
        }

        private void expression_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                this.UpdateTree();
            }
        }

        private void combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.ShowSelectedItem();
        }
    }
}
