﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.CSharp;
using System.Reflection;
using System.CodeDom.Compiler;

namespace LinqTreeView
{
    public class CodeDom
    {
        const string TYPE_NAME = "TemporaryNamespace.Temporary";
        const string METHOD_NAME = "Get";
        const string CODE_HEADER = @"
namespace TemporaryNamespace
{
	using System;
	using System.Linq.Expressions;

    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Shapes;
    using System.Windows.Controls;

	using Expression = System.Linq.Expressions.Expression;

    public delegate TR Func<T1, T2, T3, T4, T5, TR>(T1 x1, T2 x2, T3 x3, T4 x4, T5 x5);
    public delegate TR Func<T1, T2, T3, T4, T5, T6, TR>(T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6);
    public delegate TR Func<T1, T2, T3, T4, T5, T6, T7, TR>(T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7);
    public delegate TR Func<T1, T2, T3, T4, T5, T6, T7, T8, TR>(T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8);
    public delegate TR Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, TR>(T1 x1, T2 x2, T3 x3, T4 x4, T5 x5, T6 x6, T7 x7, T8 x8, T9 x9);

	public class Temporary
	{
		public Expression Get()
		{
			return New(
";
        const string CODE_FOOTER = @"
				);
		}

		static Expression New(Expression<Func<double>> e) { return e; }
		static Expression New(Expression<Func<double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double, double, double, double, double>> e) { return e; }
		static Expression New(Expression<Func<double, double, double, double, double, double, double, double, double, double>> e) { return e; }
		static Expression New<T1>(Expression<Func<T1>> e) { return e; }
		static Expression New<T1, T2>(Expression<Func<T1, T2>> e) { return e; }
		static Expression New<T1, T2, T3>(Expression<Func<T1, T2, T3>> e) { return e; }
		static Expression New<T1, T2, T3, T4>(Expression<Func<T1, T2, T3, T4>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5>(Expression<Func<T1, T2, T3, T4, T5>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5, T6>(Expression<Func<T1, T2, T3, T4, T5, T6>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5, T6, T7>(Expression<Func<T1, T2, T3, T4, T5, T6, T7>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5, T6, T7, T8>(Expression<Func<T1, T2, T3, T4, T5, T6, T7, T8>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5, T6, T7, T8, T9>(Expression<Func<T1, T2, T3, T4, T5, T6, T7, T8, T9>> e) { return e; }
		static Expression New<T1, T2, T3, T4, T5, T6, T7, T8, T9, T0>(Expression<Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T0>> e) { return e; }
	}
}
";

        static CompilerResults Compile(string source)
        {
            CodeDomProvider provider = new CSharpCodeProvider(
                new Dictionary<string, string>() { { "CompilerVersion", "v3.5" } });

            CompilerParameters cp = new CompilerParameters();
            cp.GenerateInMemory = true;
            cp.ReferencedAssemblies.Add("System.Core.dll");
            cp.ReferencedAssemblies.Add("WindowsBase.dll");
            cp.ReferencedAssemblies.Add("PresentationCore.dll");
            cp.ReferencedAssemblies.Add("PresentationFramework.dll");

            CompilerResults cr = provider.CompileAssemblyFromSource(
                cp,
                CODE_HEADER + source + CODE_FOOTER
                );

            return cr;
        }

        static Expression Execute(CompilerResults cr)
        {
            Assembly asm = cr.CompiledAssembly;
            Type myClass = asm.GetType(TYPE_NAME);
            Object o = Activator.CreateInstance(myClass);
            MethodInfo mi = myClass.GetMethod(METHOD_NAME);
            return (Expression)mi.Invoke(o, null);
        }

        public static Expression GetExpressionFrom(string source)
        {
            CompilerResults cr = Compile(source);

            if (cr.Errors.HasErrors)
            {
                StringBuilder sb = new StringBuilder();
                Regex reg = new Regex(@":\serror\s(?<reason>.*)$");

                foreach (var error in cr.Errors)
                {
                    Match m = reg.Match(error.ToString());
                    if (m.Success)
                    {
                        sb.Append(m.Groups["reason"]);
                        sb.Append('\n');
                    }
                }
                throw new ExpressionCodeDomException(sb.ToString());
            }

            return Execute(cr);
        }
    }

    public class ExpressionCodeDomException : Exception
    {
        public ExpressionCodeDomException(string msg) : base(msg, null) { }
        public ExpressionCodeDomException(string msg, Exception innerException) :
            base(msg, innerException) { }
    }
}
