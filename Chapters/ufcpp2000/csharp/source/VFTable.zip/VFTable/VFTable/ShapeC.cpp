#include "ShapeC.h"

//----------------------------------------------------------------
// class Shape �ɑ���

void ShapeCtor(Shape* this)
{
	this->vftable = ShapeVftable;
}

void ShapeDtor(Shape* this)
{
}

void* ShapeVftable[] = 
{
	"class Shape",
	0,
	0
};

//----------------------------------------------------------------
// class Rectangle �ɑ���

void RectangleCtor(Rectangle* this, double w, double h)
{
	ShapeCtor(&this->base);

	this->base.vftable = RectangleVftable;

	this->width = w;
	this->height = h;
}

void RectangleDtor(Rectangle* this)
{
	ShapeDtor(&this->base);
}

double RectangleGetArea(Rectangle* this)
{
	return this->width * this->height;
}

double RectangleGetPerimeter(Rectangle* this)
{
	return 2 * (this->width + this->height);
}

void* RectangleVftable[] =
{
	"class Rectangle",
	RectangleGetArea,
	RectangleGetPerimeter
};


//----------------------------------------------------------------
// class Circle �ɑ���

void CircleCtor(Circle* this, double r)
{
	ShapeCtor(&this->base);

	this->base.vftable = CircleVftable;

	this->radius = r;
}

void CircleDtor(Circle* this)
{
	ShapeDtor(&this->base);
}

double CircleGetArea(Circle* this)
{
	return 3.14159265358979 * this->radius * this->radius;
}

double CircleGetPerimeter(Circle* this)
{
	return 2 * 3.14159265358979 * this->radius;
}

void* CircleVftable[] =
{
	"class Circle",
	CircleGetArea,
	CircleGetPerimeter
};
