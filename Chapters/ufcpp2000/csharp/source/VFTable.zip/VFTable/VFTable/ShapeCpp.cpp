#include "ShapeCpp.h"

Rectangle::Rectangle(double w, double h)
{
	this->width = w;
	this->height = h;
}

double Rectangle::GetArea()
{
	return this->width * this->height;
}

double Rectangle::GetPerimeter()
{
	return 2 * (this->width + this->height);
}

Circle::Circle(double r)
{
	this->radius = r;
}

double Circle::GetArea()
{
	return 3.14159265358979 * this->radius * this->radius;
}

double Circle::GetPerimeter()
{
	return 2 * 3.14159265358979 * this->radius;
}
