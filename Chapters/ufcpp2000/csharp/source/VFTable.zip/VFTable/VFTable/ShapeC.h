#pragma once

//----------------------------------------------------------------
// class Shape �ɑ���
typedef struct TagShape
{
	void** vftable;
} Shape;

#define VF_GetArea 1
#define VF_GetPerimeter 2

typedef double TypeGetArea(Shape* this);
typedef double TypeGetPerimeter(Shape* this);

extern void* ShapeVftable[];
void ShapeCtor(Shape* this);
void ShapeDtor(Shape* this);

//----------------------------------------------------------------
// class Rectangle �ɑ���
typedef struct TagRectangle
{
	Shape base;

	double width;
	double height;
} Rectangle;

extern void* RectangleVftable[];
void RectangleCtor(Rectangle* this, double w, double h);
void RectangleDtor(Rectangle* this);
double RectangleGetArea(Rectangle* this);
double RectangleGetPerimeter(Rectangle* this);

//----------------------------------------------------------------
// class Circle �ɑ���
typedef struct TagCircle
{
	Shape base;

	double radius;
} Circle;

extern void* CircleVftable[];
void CircleCtor(Circle* this, double r);
void CircleDtor(Circle* this);
double CircleGetArea(Circle* this);
double CircleGetPerimeter(Circle* this);
