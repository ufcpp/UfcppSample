#include "ShapeC.h"

#include <stdio.h>

void print(Shape* s)
{
	printf("%s\n%f\n%f\n\n",
		(char*)s->vftable[0],
		((TypeGetArea*)s->vftable[VF_GetArea])(s),
		((TypeGetPerimeter*)s->vftable[VF_GetPerimeter])(s));
}

void TestC(void)
{
	Shape* s;

	//s = (Shape*)malloc(sizeof(Shape));
	//ShapeCtor(s);
	//ShapeDtor(s);
	//free(s);

	s = (Shape*)malloc(sizeof(Rectangle));
	RectangleCtor((Rectangle*)s, 2, 3);
	print(s);
	RectangleDtor((Rectangle*)s);
	free(s);

	s = (Shape*)malloc(sizeof(Circle));
	CircleCtor((Circle*)s, 1.41421356);
	CircleDtor((Circle*)s);
	print(s);
	free(s);
}
