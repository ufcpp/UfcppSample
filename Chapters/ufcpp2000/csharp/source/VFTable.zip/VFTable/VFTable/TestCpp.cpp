#include "ShapeCpp.h"

#include <typeinfo.h>
#include <stdio.h>

void print(Shape* s)
{
	printf("%s\n%f\n%f\n\n",
		typeid(*s).name(),
		s->GetArea(),
		s->GetPerimeter());
}

void TestCpp()
{
	Shape* s;

	//s = new Shape();
	//delete s;
	
	s = new Rectangle(2, 3);
	print(s);
	delete s;

	s = new Circle(1.41421356);
	print(s);
	delete s;
}
