#include "stdafx.h"

void TestCpp();

extern "C"
{
	void TestC(void);
}

int _tmain(int argc, _TCHAR* argv[])
{
	TestCpp();
	TestC();
	return 0;
}

