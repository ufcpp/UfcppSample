#pragma once

class Shape
{
public:
  virtual double GetArea() = 0;
  virtual double GetPerimeter() = 0;
};

class Rectangle : public Shape
{
public:
	Rectangle(double w, double h);
  virtual double GetArea();
  virtual double GetPerimeter();

private:
	double width;
	double height;
};

class Circle : public Shape
{
public:
	Circle(double r);
  virtual double GetArea();
  virtual double GetPerimeter();

private:
	double radius;
};
