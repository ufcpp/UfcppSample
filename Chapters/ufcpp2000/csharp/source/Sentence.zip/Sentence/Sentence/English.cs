﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sentence.English
{
    /// <summary>
    /// 体言リスト。
    /// </summary>
    /// <remarks>
    /// 英語の文法にあわせて、前置詞を伴わない主語・目的語を表すために Subject, Object もあった方がいい？
    /// 本来、語順を自由にできる言語の体言には何らかの前置詞・後置詞がつくものなんだけど。
    /// 日本語の助詞しかり。
    /// </remarks>
    public class Nominals
    {
        public Variant by = new Variant();
        public Variant By { get { return this.by; } set { this.by = value; } }

        public Variant of = new Variant();
        public Variant Of { get { return this.of; } set { this.of = value; } }

        public Variant @for = new Variant();
        public Variant For { get { return this.@for; } set { this.@for = value; } }

        public Variant to = new Variant();
        public Variant To { get { return this.to; } set { this.to = value; } }

        public Variant from = new Variant();
        public Variant From { get { return this.from; } set { this.from = value; } }

        public Variant with = new Variant();
        public Variant With { get { return this.with; } set { this.with = value; } }

        public Variant @as = new Variant();
        public Variant As { get { return this.@as; } set { this.@as = value; } }
    }

    public static partial class NominalsExtensions
    {
        public static Nominals By(this Nominals nominals, object val)
        {
            nominals.By.Add(val);
            return nominals;
        }

        public static Nominals Of(this Nominals nominals, object val)
        {
            nominals.Of.Add(val);
            return nominals;
        }

        public static Nominals For(this Nominals nominals, object val)
        {
            nominals.For.Add(val);
            return nominals;
        }

        public static Nominals To(this Nominals nominals, object val)
        {
            nominals.To.Add(val);
            return nominals;
        }

        public static Nominals From(this Nominals nominals, object val)
        {
            nominals.From.Add(val);
            return nominals;
        }

        public static Nominals With(this Nominals nominals, object val)
        {
            nominals.With.Add(val);
            return nominals;
        }

        public static Nominals As(this Nominals nominals, object val)
        {
            nominals.As.Add(val);
            return nominals;
        }
    }

    public static class Sentence
    {
        public static Nominals By(object val)
        {
            return new Nominals { By = new Variant(val) };
        }

        public static Nominals Of(object val)
        {
            return new Nominals { Of = new Variant(val) };
        }

        public static Nominals For(object val)
        {
            return new Nominals { For = new Variant(val) };
        }

        public static Nominals To(object val)
        {
            return new Nominals { To = new Variant(val) };
        }

        public static Nominals From(object val)
        {
            return new Nominals { From = new Variant(val) };
        }

        public static Nominals With(object val)
        {
            return new Nominals { With = new Variant(val) };
        }

        public static Nominals As(object val)
        {
            return new Nominals { As = new Variant(val) };
        }
    }
}
