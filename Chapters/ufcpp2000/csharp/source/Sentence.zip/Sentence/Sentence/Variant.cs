﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sentence
{
    /// <summary>
    /// Variant といいつつ、単なる object のラッパ。
    /// 値が1つだけのときと、値が複数あるときがある。
    /// 値が1つだけの時には v.Cast&lt;T&gt; で T 型の値を取り出し。
    /// 値が複数の時には、foreach (object obj in v) で値を取り出し。
    /// </summary>
    public class Variant
    {
        public object Value { set; get; }
        public int Count { set; get; }

        public Variant()
        {
            this.Count = 0;
        }

        public Variant(object val)
        {
            this.Value = val;
            this.Count = 1;
        }

        public Variant(Variant val)
        {
            foreach (var obj in val)
                this.Add(obj);
        }

        public void Assign(object val)
        {
            this.Value = val;
        }

        public void Add(object val)
        {
            if (this.Count == 0)
            {
                this.Value = val;
                ++this.Count;
                return;
            }

            if (this.Count == 1)
            {
                List<object> list = new List<object>();
                list.Add(this.Value);
                this.Value = list;
            }

            ((List<object>)this.Value).Add(val);
            ++this.Count;
        }

        public void Add(Variant val)
        {
            foreach (var obj in val)
                this.Add(obj);
        }

        public T Cast<T>()
            where T : class
        {
            return this.Value as T;
        }

        public IEnumerator<object> GetEnumerator()
        {
            if (this.Count == 0)
                yield break;

            if (this.Count == 1)
            {
                yield return this.Value;
                yield break;
            }

            foreach (var obj in (List<object>)this.Value)
            {
                yield return obj;
            }
        }
    }
}
