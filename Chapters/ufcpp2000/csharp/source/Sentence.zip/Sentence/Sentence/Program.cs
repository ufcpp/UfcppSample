﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sentence
{
    class Program
    {
        static void Main(string[] args)
        {
            Test日本語.Test();
            //TestEnglish.Test();
        }
    }
}

namespace Sentence
{
    using Sentence.日本語;

    public static class NominalsExtensions2
    {
        public static void 出力(this Nominals n)
        {
            var writer = n.に.Cast<System.IO.TextWriter>();
            writer.Write(n.を.Value);
        }

        public static string 置換(this Nominals n)
        {
            var input = n.の.Cast<string>();
            var pattern = n.を.Cast<string>();
            var replacement = n.に.Cast<string>();

            var reg = new System.Text.RegularExpressions.Regex(pattern);

            return reg.Replace(input, replacement);
        }

        public static string 繋ぐ(this Nominals n)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var s in n.と)
            {
                sb.Append(s.ToString());
            }

            foreach (var s in n.を)
            {
                sb.Append(s.ToString());
            }

            return sb.ToString();
        }
    }

    public class Test日本語
    {
        public static void Test()
        {
            Nominals.Make(
                "Hello World!\n".を(),
                Console.Out.に()
            ).出力();

            string 置換結果 =
            Nominals.Make(
                "置換前の文字列\n".の(),
                "置換前".を(),
                "置換後".に()
                ).置換();

            Nominals.Make(
                置換結果.を(),
                Console.Out.に()
            ).出力();

            string 繋いだ結果 =
            Nominals.Make(
                "abc".と(),
                "def".と(),
                "ghi".を()
                ).繋ぐ();

            Nominals.Make(
                繋いだ結果.を(),
                Console.Out.に()
            ).出力();
        }
    }
}

namespace Sentence
{
    using Sentence.English;

    public static class NominalsExtensions1
    {
        public static void Write(this Nominals n)
        {
            var writer = n.To.Cast<System.IO.TextWriter>();
            writer.Write(n.With.Value);
        }

        public static string Replace(this Nominals n)
        {
            var input = n.With.Cast<string>();
            var pattern = n.From.Cast<string>();
            var replacement = n.To.Cast<string>();

            var reg = new System.Text.RegularExpressions.Regex(pattern);

            return reg.Replace(input, replacement);
        }
    }

    public class TestEnglish
    {
        public static void Test()
        {
            Sentence
                .With("Hello World!\n")
                .To(Console.Out)
                .Write();

            string result =
                Sentence
                .With("置換前の文字列\n")
                .From("置換前")
                .To("置換後")
                .Replace();

            Sentence
                .With(result)
                .To(Console.Out)
                .Write();
        }
    }
}
