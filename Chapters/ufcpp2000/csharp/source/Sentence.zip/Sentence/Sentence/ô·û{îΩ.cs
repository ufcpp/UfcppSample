﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sentence.日本語
{
    /// <summary>
    /// 体言リスト。
    /// </summary>
    public class Nominals
    {
        public Variant は_ = new Variant();
        public Variant は { get { return this.は_; } set { this.は_ = value; } }

        public Variant が_ = new Variant();
        public Variant が { get { return this.が_; } set { this.が_ = value; } }

        public Variant を_ = new Variant();
        public Variant を { get { return this.を_; } set { this.を_ = value; } }

        public Variant の_ = new Variant();
        public Variant の { get { return this.の_; } set { this.の_ = value; } }

        public Variant へ_ = new Variant();
        public Variant へ { get { return this.へ_; } set { this.へ_ = value; } }

        public Variant から_ = new Variant();
        public Variant から { get { return this.から_; } set { this.から_ = value; } }

        public Variant と_ = new Variant();
        public Variant と { get { return this.と_; } set { this.と_ = value; } }

        public Variant に_ = new Variant();
        public Variant に { get { return this.に_; } set { this.に_ = value; } }

        public Variant で_ = new Variant();
        public Variant で { get { return this.で_; } set { this.で_ = value; } }

        public Nominals() { }

        private Nominals(IList<Nominals> merge)
        {
            foreach (var nominal in merge)
            {
                this.は.Add(nominal.は);
                this.が.Add(nominal.が);
                this.を.Add(nominal.を);
                this.の.Add(nominal.の);
                this.へ.Add(nominal.へ);
                this.から.Add(nominal.から);
                this.と.Add(nominal.と);
                this.に.Add(nominal.に);
                this.で.Add(nominal.で);
            }
        }

        public static Nominals Make(params Nominals[] merge)
        {
            return new Nominals(merge);
        }
    }

    public static partial class NominalsExtensions
    {
        public static Nominals は(this object val)
        {
            return new Nominals { は = new Variant(val) };
        }
        public static Nominals が(this object val)
        {
            return new Nominals { が = new Variant(val) };
        }
        public static Nominals を(this object val)
        {
            return new Nominals { を = new Variant(val) };
        }
        public static Nominals の(this object val)
        {
            return new Nominals { の = new Variant(val) };
        }
        public static Nominals へ(this object val)
        {
            return new Nominals { へ = new Variant(val) };
        }
        public static Nominals から(this object val)
        {
            return new Nominals { から = new Variant(val) };
        }
        public static Nominals と(this object val)
        {
            return new Nominals { と = new Variant(val) };
        }
        public static Nominals に(this object val)
        {
            return new Nominals { に = new Variant(val) };
        }
        public static Nominals で(this object val)
        {
            return new Nominals { で = new Variant(val) };
        }
    }
}
