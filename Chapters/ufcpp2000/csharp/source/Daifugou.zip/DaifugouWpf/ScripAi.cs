﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Scripting.Hosting;

namespace DaifugouWpf
{
    /// <summary>
    /// DLRを使ったスクリプトAI。
    /// </summary>
    public class ScripAi : Daifugou.IArtificialIntelligence
    {
        public ScripAi()
        {
        }

        ScriptScope scope;
        //ScriptEngine engine;
        CompiledCode code;
        string filename;

        public void Init(string filename)
        {
            this.filename = filename;

            var ext = System.IO.Path.GetExtension(filename).Replace(".", "");

            ScriptRuntime env = ScriptRuntime.CreateFromConfiguration();
            env.LoadAssembly(typeof(Daifugou.Game).Assembly);
            env.LoadAssembly(typeof(System.Math).Assembly);
            env.LoadAssembly(typeof(System.Linq.Enumerable).Assembly);


            this.scope = env.CreateScope();
            //this.engine = env.GetEngine(ext);
            var engine = env.GetEngine(ext);
            var script = engine.CreateScriptSourceFromFile(filename);
            this.code = script.Compile();

            // 事前に渡しておきたいものを登録
            this.scope.SetVariable("rand", new Random());
        }

        #region IArtificialIntelligence メンバ

        public IEnumerable<CardGame.Card> Play(IEnumerable<CardGame.Card> hand, IEnumerable<CardGame.Card> table, int rank, CardGame.Suit suit, Daifugou.Mode mode, bool revolution, Daifugou.History history)
        {
            // 引数の登録
            this.scope.SetVariable("hand", hand.ToArray());
            this.scope.SetVariable("table", table.ToArray());
            this.scope.SetVariable("rank", rank);
            this.scope.SetVariable("suit", suit);
            this.scope.SetVariable("mode", mode);
            this.scope.SetVariable("revolution", revolution);
            this.scope.SetVariable("history", history);

            // スクリプトの実行
            this.code.Execute(this.scope);
            //this.engine.ExecuteFile(this.filename, this.scope);

            // 結果の取得
            var result = this.scope.GetVariable("result") as System.Collections.IEnumerable;

            if (result == null)
                return null;

            var r = result.Cast<CardGame.Card>().ToArray();


            //try
            //{
            //    this.code.Execute(this.scope);

            //    var x = this.scope.GetVariable("test");

            //    int xx = 0;
            //    ++xx;
            //}
            //catch (Exception)
            //{
            //    int xx = 0;
            //    ++xx;
            //}


            return r;
        }

        #endregion
    }
}
