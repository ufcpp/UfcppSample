﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DaifugouWpf
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            this.aiSetting.Click += new RoutedEventHandler(aiSetting_Click);
        }

        void aiSetting_Click(object sender, RoutedEventArgs e)
        {
            AiSettingWindow setting = new AiSettingWindow(this.daifugou.AI.Length);

            if (setting.ShowDialog() ?? false)
            {
                string filename = setting.Path;
                int index = setting.SelectedIndex;

                //@"C:\Users\iwanaga\Documents\Visual Studio 2008\Projects\Daifugou\ScriptSample\random.py";

                var ai = new ScripAi();
                ai.Init(filename);

                this.daifugou.AI[index] = ai;
            }
        }
    }
}
