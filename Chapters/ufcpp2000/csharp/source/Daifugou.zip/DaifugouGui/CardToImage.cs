﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace DaifugouGui
{
    using Suit = CardGame.Suit;
    using Card = CardGame.Card;

    [ValueConversion(typeof(Card), typeof(UIElement))]
    public class CardToImage : IValueConverter
    {
        static Color SuitToColor(Suit suit)
        {
            switch(suit)
            {
                case Suit.Diamond: return Colors.Red;
                case Suit.Heart:   return Colors.HotPink;
                case Suit.Spade:   return Colors.Black;
                case Suit.Club:    return Colors.Green;
                default: return Colors.Blue;
            }
        }

        static string RankToChar(int rank)
        {
            if (rank == 1) return "A";
            if (rank == 10) return "10";
            if (rank == 11) return "J";
            if (rank == 12) return "Q";
            if (rank == 13) return "K";

            return new string(new[] { (char)('0' + rank) });
        }

        static char SuitToChar(Suit suit)
        {
            switch (suit)
            {
                case Suit.Spade:   return '\x2660';
                case Suit.Diamond: return '\x2666';
                case Suit.Heart:   return '\x2665';
                case Suit.Club:    return '\x2663';
                default: return '\0';
            }
        }

        static string CardToString(Card card)
        {
            if (card.Suit == Suit.Joker)
                return "Joker";

            return string.Format("{0} {1}", SuitToChar(card.Suit), RankToChar(card.Rank));
        }

        public object Convert(object value, System.Type targetType,
          object parameter, System.Globalization.CultureInfo culture)
        {
            Card card = value as Card;
            if (card == null) return null;
            string str = CardToString(card);
            Color color = SuitToColor(card.Suit);

            var image = new Label
            {
                Content = str,
                Foreground = new SolidColorBrush(color),
            };

            return image;
        }

        public object ConvertBack(object value, System.Type targetType,
          object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }
}
