﻿using CardGame;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;

namespace DaifugouTest
{
    
    
    /// <summary>
    ///CardTest のテスト クラスです。すべての
    ///CardTest 単体テストをここに含めます
    ///</summary>
    [TestClass()]
    public class CardTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///現在のテストの実行についての情報および機能を
        ///提供するテスト コンテキストを取得または設定します。
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region 追加のテスト属性
        // 
        //テストを作成するときに、次の追加属性を使用することができます:
        //
        //クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //各テストを実行する前にコードを実行するには、TestInitialize を使用
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //各テストを実行した後にコードを実行するには、TestCleanup を使用
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///ShuffledDeck のテスト
        ///</summary>
        [TestMethod()]
        public void ひとつのデッキに同じカードがあっちゃダメだよ()
        {
            var deck1 = Card.ShuffledDeck(false);
            Assert.AreEqual(deck1.Distinct().Count(), 53);

            long s1 = Card.Serialize(deck1);
            Assert.AreEqual(s1, (1L << 53) - 1);

            var deck2 = Card.ShuffledDeck(true);
            Assert.AreEqual(deck2.Distinct().Count(), 54);

            long s2 = Card.Serialize(deck2);
            Assert.AreEqual(s2, (1L << 54) - 1);
        }
    }
}
