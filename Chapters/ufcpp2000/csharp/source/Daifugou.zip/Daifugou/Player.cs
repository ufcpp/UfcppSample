﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Daifugou
{
    using CardGame;

    /// <summary>
    /// プレイヤーの状態。
    /// </summary>
    public class Player
    {
        /// <summary>
        /// プレイヤーID。
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// プレイヤーの手札。
        /// </summary>
        public CardSet Hand
        {
            get { return this.hand; }
            set { this.hand = value; }
        }

        CardSet hand = new CardSet();

        /// <summary>
        /// プレイヤーが前回出したカード。
        /// </summary>
        public CardSet Previous
        {
            get { return this.prev; }
            set { this.prev = value; }
        }

        CardSet prev = new CardSet();
    }
}
