﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Daifugou
{
    using CardGame;

    [Flags]
    public enum Mode
    {
        /// <summary>
        /// 初手。
        /// なんでも出せる状態。
        /// </summary>
        First = 0,

        /// <summary>
        /// 通常。
        /// </summary>
        Normal = 1,

        /// <summary>
        /// 同ランク複数枚。
        /// </summary>
        Multiple = 2,

        /// <summary>
        /// 同スイート連番。
        /// </summary>
        Sequence = 4,

        /// <summary>
        /// スイート縛り。
        /// 初手の人と2番目の人が同じスイートのカードを出したら次からそのスイートしか出せなくなるやつ。
        /// </summary>
        SuitBound = 8,

        /// <summary>
        /// いわゆる「階段」状態。
        /// 初手 { 3, 4 } の直後に { 5, 6 } が出たら次は { 7, 8 } しか出せないってやつ。
        /// </summary>
        SequenceBound = 16,
    }

    public static class ModeExtensions
    {
        /// <summary>
        /// subject が flag フラグを含んでいるかどうかを判定。
        /// </summary>
        /// <param name="subject">主語</param>
        /// <param name="flag">比較したいフラグ</param>
        /// <returns>フラグが立っていたらtrue。</returns>
        public static bool Match(this Mode subject, Mode flag)
        {
            if (subject == Mode.First && flag == Mode.First)
                return true;

            bool r = (subject & flag) != 0;
            return r;
        }
    }

    enum Turn
    {
        /// <summary>
        /// 初手。
        /// 場が流れた直後。
        /// </summary>
        First,

        /// <summary>
        /// 2手目。
        /// 縛りとか階段の判定する。
        /// </summary>
        Second,

        /// <summary>
        /// 3番目以降。
        /// </summary>
        Other,
    }

    /// <summary>
    /// 大富豪のゲームの状態。
    /// これをデータベースアクセスするように書き換えればネットゲーにもできると思う。
    /// </summary>
    struct GameState
    {
        /// <summary>
        /// 今、どのモードになっているか。
        /// </summary>
        public Mode Mode;

        /// <summary>
        /// 今、場に出ているカードのランク。
        /// </summary>
        public int Rank;

        /// <summary>
        /// 今、場に出ているカードのスイート。
        /// </summary>
        public Suit Suit;

        /// <summary>
        /// 今、場に出ているカードの枚数。
        /// </summary>
        public int Count;

        /// <summary>
        /// 今、どのターンか。
        /// </summary>
        public Turn Turn;

        /// <summary>
        /// 参加プレーヤーのリスト。
        /// </summary>
        public List<Player> Players;

        /// <summary>
        /// 勝ちぬけた人のIDリスト。
        /// </summary>
        public List<int> Winners;

        /// <summary>
        /// 現在手番を持っているプレーヤーのインデックス。
        /// </summary>
        public int CurrentPlayerIndex;

        /// <summary>
        /// 最後にカードを出したプレーヤーのインデックス。
        /// </summary>
        public int LastPlayer;

        /// <summary>
        /// 場に出ているカード。
        /// </summary>
        public CardSet CardsOnTable;

        /// <summary>
        /// 革命が起きているかどうか。
        /// </summary>
        public bool Revolution;

        public void Clear()
        {
            this.CurrentPlayerIndex = 0;
            this.Mode = Mode.First;
            this.Turn = Turn.First;
            this.CardsOnTable.Clear();
            this.Revolution = false;
            if (this.Winners == null)
                this.Winners = new List<int>();
            else
                this.Winners.Clear();
        }

        public Player CurrentPlayer
        {
            get { return this.Players[this.CurrentPlayerIndex]; }
        }
    }

}
