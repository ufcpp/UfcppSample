﻿using System;
using System.Collections.Generic;

namespace ShowDialogAsyncSample
{
	public partial class MainWindow
	{
		/// <summary>
		/// 確認作業。
		/// イテレーター ブロックを使って await と似たようなことをする例。
		/// 処理本体は CheckIterator で、こっちはラッパー。
		/// 
		/// Task クラス / await 演算子を使えない環境でのごまかしとして。
		/// というか、かつて、await 演算子導入前によくやった手段。
		/// </summary>
		/// <param name="onComplete">確認結果を受け取るためのコールバック。</param>
		private void BeginCheckWithIterator(Action<bool> onComplete)
		{
			var e = CheckIterator(onComplete).GetEnumerator();

			Action a = null;

			a = () =>
			{
				if (!e.MoveNext()) return;
				e.Current(a);
			};

			a();
		}

		/// <summary>
		/// 確認作業。
		/// イテレーター ブロックを使って await と似たようなことをする例。
		/// こっちが処理本体。
		/// </summary>
		/// <param name="onComplete">確認結果を受け取るためのコールバック。</param>
		/// <returns>Awaitable 的なものを返す。</returns>
		private IEnumerable<Action<Action>> CheckIterator(Action<bool> onComplete)
		{
			if (this.Check1.IsChecked ?? false)
			{
				bool result = false;
				yield return callback => Dialog.BeginShowDialog("確認 1", "1つ目の確認作業", r => { result = r; callback(); });

				if (!result)
				{
					onComplete(false);
					yield break;
				}
			}

			if (this.Check2.IsChecked ?? false)
			{
				bool result = false;
				yield return callback => Dialog.BeginShowDialog("確認 2", "2つ目の確認作業", r => { result = r; callback(); });

				if (!result)
				{
					onComplete(false);
					yield break;
				}
			}

			if (this.Check3.IsChecked ?? false)
			{
				bool result = false;
				yield return callback => Dialog.BeginShowDialog("確認 3", "3つ目の確認作業", r => { result = r; callback(); });

				if (!result)
				{
					onComplete(false);
					yield break;
				}
			}

			onComplete(true);
		}
	}
}
