﻿using System.Threading.Tasks;

namespace ShowDialogAsyncSample
{
	public partial class MainWindow
	{
		/// <summary>
		/// 確認作業。
		/// Task クラスと await 演算子利用版。
		/// 
		/// C# 5.0 の await 演算子ありがたいなー。
		/// </summary>
		/// <returns>確認結果</returns>
		private async Task<bool> CheckAsync()
		{
			if (this.Check1.IsChecked ?? false)
			{
				var result = await Dialog.ShowDialogAsync("確認 1", "1つ目の確認作業");
				if (!result) return false;
			}

			if (this.Check2.IsChecked ?? false)
			{
				var result = await Dialog.ShowDialogAsync("確認 2", "2つ目の確認作業");
				if (!result) return false;
			}

			if (this.Check3.IsChecked ?? false)
			{
				var result = await Dialog.ShowDialogAsync("確認 3", "3つ目の確認作業");
				if (!result) return false;
			}

			return true;
		}
	}
}
