﻿using ShowDialogAsyncSample.Views;
using System;
using System.Threading.Tasks;

namespace ShowDialogAsyncSample
{
	public static class Dialog
	{
		/// <summary>
		/// ブロッキング型のダイアログ表示。
		/// 
		/// これを呼ぶと、呼び出し元のウィンドウは応答しなくなる。
		/// </summary>
		/// <param name="title">ダイアログのタイトル文字列。</param>
		/// <param name="message">ダイアログの本文。</param>
		/// <returns>OK が押されたら true、Cancel が押されたら false。</returns>
		public static bool ShowDialog(string title, string message)
		{
			var dialog = new SampleDialog(title, message);
			dialog.ShowDialog();
			return dialog.Ok;
		}

		/// <summary>
		/// コールバック型の非同期ダイアログ表示。
		/// 
		/// Wait でブロッキング待ちしたり、キャンセルしたりするつもりはないので、IAsyncResult とかすら返さない。
		/// </summary>
		/// <param name="title">ダイアログのタイトル文字列。</param>
		/// <param name="message">ダイアログの本文。</param>
		/// <param name="onClose">コールバック（OK が押されたら true、Cancel が押されたら false を渡す）。</param>
		public static void BeginShowDialog(string title, string message, Action<bool> onClose)
		{
			var dialog = new SampleDialog(title, message);
			dialog.Closed += (sender, e) =>
			{
				onClose(dialog.Ok);
			};
			dialog.Show();
		}

		/// <summary>
		/// Task-Asyncronous-Patterm 型の非同期ダイアログ表示。
		/// </summary>
		/// <param name="title">ダイアログのタイトル文字列。</param>
		/// <param name="message">ダイアログの本文。</param>
		/// <returns>OK が押されたら true、Cancel が押されたら false。</returns>
		public static Task<bool> ShowDialogAsync(string title, string message)
		{
			var tcs = new TaskCompletionSource<bool>();
			BeginShowDialog(title, message, result => { tcs.TrySetResult(result); });
			return tcs.Task;
		}
	}
}
