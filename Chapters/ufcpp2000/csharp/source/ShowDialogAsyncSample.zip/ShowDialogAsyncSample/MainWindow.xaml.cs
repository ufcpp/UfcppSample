﻿using System.Threading.Tasks;
using System.Windows;

namespace ShowDialogAsyncSample
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			if (Radio1Async.IsChecked ?? false)
			{
				AsyncSample();
			}
			else if (Radio1Iterator.IsChecked ?? false)
			{
				IteratorSample();
			}
			else if (Radio1Callback.IsChecked ?? false)
			{
				CallbackSample();
			}
			else
			{
				BlockingSample();
			}
		}

		private void CallbackSample()
		{
			BeginCheck(result => ShowResult(result));
		}

		private async void AsyncSample()
		{
			var result = await CheckAsync();
			ShowResult(result);
		}

		private void IteratorSample()
		{
			BeginCheckWithIterator(result => ShowResult(result));
		}

		private void BlockingSample()
		{
			var result = CheckBlocking();
			ShowResult(result);
		}

		private static void ShowResult(bool result)
		{
			var message = result ? "確認 成功" : "確認 【失敗】";
			MessageBox.Show(message);
		}
	}
}
