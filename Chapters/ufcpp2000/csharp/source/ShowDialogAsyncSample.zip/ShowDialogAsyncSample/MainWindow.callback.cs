﻿using System;

namespace ShowDialogAsyncSample
{
	public partial class MainWindow
    {
		/// <summary>
		/// 確認作業。
		/// コールバック型の非同期処理で制御フローを書くのがいかに大変かという例。
		/// 
		/// 非常にクソコード。
		/// ネスト深いわ、コピペコードひどいわ。
		/// ダイアログ3つだからまだ書くだけ書けるけども、仕様追加に対応できない。
		/// </summary>
		/// <param name="onComplete">確認結果を受け取るためのコールバック。</param>
		private void BeginCheck(Action<bool> onComplete)
		{
			if (this.Check1.IsChecked ?? false)
			{
				Dialog.BeginShowDialog("確認 1", "1つ目の確認作業", result =>
				{
					if (!result)
					{
						onComplete(false);
						return;
					}

					if (this.Check2.IsChecked ?? false)
					{
						Dialog.BeginShowDialog("確認 2", "2つ目の確認作業", result2 =>
						{
							if (!result2)
							{
								onComplete(false);
								return;
							}

							if (this.Check3.IsChecked ?? false)
							{
								Dialog.BeginShowDialog("確認 3", "3つ目の確認作業", result3 =>
								{
									onComplete(result3);
								});
							}
							else
								onComplete(true);
						});
					}
					else if (this.Check3.IsChecked ?? false)
					{
						Dialog.BeginShowDialog("確認 3", "3つ目の確認作業", result3 =>
						{
							onComplete(result3);
						});
					}
					else
						onComplete(true);
				});
			}
			else if (this.Check2.IsChecked ?? false)
			{
				Dialog.BeginShowDialog("確認 2", "2つ目の確認作業", result =>
				{
					if (!result)
					{
						onComplete(false);
						return;
					}

					if (this.Check3.IsChecked ?? false)
					{
						Dialog.BeginShowDialog("確認 3", "3つ目の確認作業", result3 =>
						{
							onComplete(result);
						});
					}
					else
						onComplete(true);
				});
			}
			else if (this.Check3.IsChecked ?? false)
			{
				Dialog.BeginShowDialog("確認 3", "3つ目の確認作業", result3 =>
				{
					onComplete(result3);
				});
			}
			else
				onComplete(true);
		}
	}
}
