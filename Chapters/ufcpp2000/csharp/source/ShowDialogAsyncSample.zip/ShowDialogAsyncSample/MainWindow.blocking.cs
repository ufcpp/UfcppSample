﻿
namespace ShowDialogAsyncSample
{
	public partial class MainWindow
	{
		/// <summary>
		/// 確認作業。
		/// ブロック版。
		/// ダイアログを表示している間、MainWindow がフリーズするタイプ。
		/// 
		/// WPF の場合はこれでも特に問題はないものの、Silverlight とか WinRT ではそもそも同期ダイアログ表示がないので無理。
		/// あと、ダイアログ表示の途中で、MainWindow 側のチェックボックスの値を変更するとかも無理。
		/// </summary>
		/// <returns>確認結果。</returns>
		private bool CheckBlocking()
		{
			if (this.Check1.IsChecked ?? false)
			{
				var result = Dialog.ShowDialog("確認 1", "1つ目の確認作業");
				if (!result) return false;
			}

			if (this.Check2.IsChecked ?? false)
			{
				var result = Dialog.ShowDialog("確認 2", "2つ目の確認作業");
				if (!result) return false;
			}

			if (this.Check3.IsChecked ?? false)
			{
				var result = Dialog.ShowDialog("確認 3", "3つ目の確認作業");
				if (!result) return false;
			}

			return true;
		}
	}
}
