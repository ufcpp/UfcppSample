﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShowDialogAsyncSample.Views
{
	/// <summary>
	/// SampleDialog.xaml の相互作用ロジック
	/// </summary>
	public partial class SampleDialog : Window
	{
		public SampleDialog(string title, string message)
		{
			InitializeComponent();
			Message.Text = message;
			this.Title = title;
		}

		private void OkButton_Click(object sender, RoutedEventArgs e)
		{
			Ok = true;
			Close();
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			Ok = false;
			Close();
		}

		public bool Ok { get; private set; }
	}
}
