﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApp
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void buttonRun_Click(object sender, EventArgs e)
    {
      // テキストボックス A ～ E に入力した値は、
      // それぞれ、変数 a ～ e に格納されます。
      double a, b, c, d, e;
      double.TryParse(this.textBoxA.Text, out a);
      double.TryParse(this.textBoxB.Text, out b);
      double.TryParse(this.textBoxC.Text, out c);
      double.TryParse(this.textBoxD.Text, out d);
      double.TryParse(this.textBoxE.Text, out e);

      string result = string.Empty; // a ～ e の値以外に出力したい結果があればこの変数に格納。

      //TODO: ↓ここに演習問題の回答コードを書いてください


      //TODO: ↑ここに演習問題の回答コードを書いてください

      // 計算終了後、変数 a ～ e の値を
      // テキストボックス A ～ E に表示します。
      this.textBoxA.Text = a.ToString();
      this.textBoxB.Text = b.ToString();
      this.textBoxC.Text = c.ToString();
      this.textBoxD.Text = d.ToString();
      this.textBoxE.Text = e.ToString();
      this.textBoxResult = result;
    }
  }
}