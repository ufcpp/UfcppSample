﻿namespace WindowsApp
{
  partial class Form1
  {
    /// <summary>
    /// 必要なデザイナ変数です。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// 使用中のリソースをすべてクリーンアップします。
    /// </summary>
    /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows フォーム デザイナで生成されたコード

    /// <summary>
    /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
    /// コード エディタで変更しないでください。
    /// </summary>
    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.textBoxA = new System.Windows.Forms.TextBox();
      this.textBoxB = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.textBoxC = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.buttonRun = new System.Windows.Forms.Button();
      this.textBoxE = new System.Windows.Forms.TextBox();
      this.label4 = new System.Windows.Forms.Label();
      this.textBoxD = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.textBoxResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(11, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(13, 12);
      this.label1.TabIndex = 0;
      this.label1.Text = "A";
      // 
      // textBoxA
      // 
      this.textBoxA.Location = new System.Drawing.Point(31, 12);
      this.textBoxA.Name = "textBoxA";
      this.textBoxA.Size = new System.Drawing.Size(197, 19);
      this.textBoxA.TabIndex = 1;
      // 
      // textBoxB
      // 
      this.textBoxB.Location = new System.Drawing.Point(31, 37);
      this.textBoxB.Name = "textBoxB";
      this.textBoxB.Size = new System.Drawing.Size(197, 19);
      this.textBoxB.TabIndex = 3;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(11, 41);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(13, 12);
      this.label2.TabIndex = 2;
      this.label2.Text = "B";
      // 
      // textBoxC
      // 
      this.textBoxC.Location = new System.Drawing.Point(31, 62);
      this.textBoxC.Name = "textBoxC";
      this.textBoxC.Size = new System.Drawing.Size(197, 19);
      this.textBoxC.TabIndex = 5;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(11, 66);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(13, 12);
      this.label3.TabIndex = 4;
      this.label3.Text = "C";
      // 
      // buttonRun
      // 
      this.buttonRun.Location = new System.Drawing.Point(234, 12);
      this.buttonRun.Name = "buttonRun";
      this.buttonRun.Size = new System.Drawing.Size(46, 23);
      this.buttonRun.TabIndex = 6;
      this.buttonRun.Text = "Run";
      this.buttonRun.UseVisualStyleBackColor = true;
      this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
      // 
      // textBoxE
      // 
      this.textBoxE.Location = new System.Drawing.Point(31, 112);
      this.textBoxE.Name = "textBoxE";
      this.textBoxE.Size = new System.Drawing.Size(197, 19);
      this.textBoxE.TabIndex = 10;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(11, 116);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(12, 12);
      this.label4.TabIndex = 9;
      this.label4.Text = "E";
      // 
      // textBoxD
      // 
      this.textBoxD.Location = new System.Drawing.Point(31, 87);
      this.textBoxD.Name = "textBoxD";
      this.textBoxD.Size = new System.Drawing.Size(197, 19);
      this.textBoxD.TabIndex = 8;
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(11, 91);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(13, 12);
      this.label5.TabIndex = 7;
      this.label5.Text = "D";
      // 
      // textBoxResult
      // 
      this.textBoxResult.Location = new System.Drawing.Point(13, 137);
      this.textBoxResult.Name = "textBoxResult";
      this.textBoxResult.Size = new System.Drawing.Size(267, 19);
      this.textBoxResult.TabIndex = 10;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 167);
      this.Controls.Add(this.textBoxResult);
      this.Controls.Add(this.textBoxE);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.textBoxD);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.buttonRun);
      this.Controls.Add(this.textBoxC);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.textBoxB);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.textBoxA);
      this.Controls.Add(this.label1);
      this.Name = "Form1";
      this.Text = "演習問題用雛形";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textBoxA;
    private System.Windows.Forms.TextBox textBoxB;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox textBoxC;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Button buttonRun;
    private System.Windows.Forms.TextBox textBoxE;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.TextBox textBoxD;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.TextBox textBoxResult;
  }
}

