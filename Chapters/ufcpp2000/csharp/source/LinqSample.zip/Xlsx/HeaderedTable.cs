﻿using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xlsx
{
    /// <summary>
    /// <![CDATA[
    /// ヘッダ1 ヘッダ2 ヘッダ3
    /// 値11    値12    値13
    /// 値21    値22    値23
    /// 値31    値32    値33
    /// ・・・
    /// ]]>
    /// みたいになっている OOXML ワークシートから、
    /// row["ヘッダ1"] みたいにして値を取り出すためのヘルパ。
    /// </summary>
    public class HeaderedTable : IEnumerable<HeaderedTableRow>
    {
        #region 初期化

        /// <summary>
        /// XlsxTable を指定して初期化。
        /// </summary>
        /// <param name="table">XlsxTable</param>
        public HeaderedTable(Table table)
        {
            this.Load(table);
        }

        /// <summary>
        /// ワークシートと共有文字列一覧を指定して初期化。
        /// </summary>
        /// <param name="sheet">ワークシート</param>
        /// <param name="ssTable">共有文字列一覧</param>
        public HeaderedTable(PackagePart sheet, IList<string> ssTable)
            : this(new Table(sheet, ssTable))
        {
        }

        /// <summary>
        /// テーブルを読み込む。
        /// </summary>
        /// <param name="table">テーブル</param>
        public void Load(Table table)
        {
            this.table = table;
            this.index = new Dictionary<string, int>();

            for (int c = this.table.ColMin; c <= this.table.ColMax; c++)
            {
                this.index[this.table[1, c]] = c;
            }
        }

        #endregion
        #region ヘッダタグ一覧

        public IEnumerable<string> Keys
        {
            get
            {
                return this.index.Keys;
            }
        }

        #endregion
        #region XML 化

        /// <summary>
        /// HeaderedTable を XElement 化します。
        /// </summary>
        /// <param name="tableTagName">テーブルの XML 要素名</param>
        /// <param name="rowTagName">行の XML 要素名</param>
        /// <returns>XElement 化したもの</returns>
        /// <remarks>
        /// <![CDATA[
        /// A   B   C
        /// 1   2   3
        /// 4   5   6
        /// ]]>
        /// 
        /// とかだと、this.ToXElement("List", "Elem") で、
        /// 
        /// <![CDATA[
        /// <List>
        ///     <Elem A="1" B="2" C="3" />
        ///     <Elem A="4" B="5" C="6" />
        /// </List>
        /// ]]>
        /// 
        /// みたいな XML 要素に変換します。
        /// </remarks>
        public XElement ToXElement(string tableTagName, string rowTagName)
        {
            var rows =
                from row in this
                select new XElement(rowTagName, ToXAttributeList(row).Cast<object>().ToArray());

            return new XElement(tableTagName, rows.Cast<object>().ToArray());
        }

        /// <summary>
        /// 行の各要素を XAttribute のリストに変換。
        /// </summary>
        /// <param name="row">行</param>
        /// <returns>変換結果</returns>
        private IEnumerable<XAttribute> ToXAttributeList(HeaderedTableRow row)
        {
            var att =
                from tag in this.Keys
                let cell = row[tag]
                where !string.IsNullOrEmpty(cell)
                select new XAttribute(tag, cell);

            return att;
        }

        #endregion
        #region IEnumerable

        /// <summary>
        /// テーブル中の行の一覧を取得。
        /// </summary>
        /// <returns>行一覧</returns>
        public IEnumerator<HeaderedTableRow> GetEnumerator()
        {
            for (int r = this.table.RowMin; r <= this.table.RowMax; ++r)
            {
                if(r == 1)
                    continue;

                yield return new HeaderedTableRow(this.table, r, this.index);
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
        #region フィールド

        /// <summary>
        /// .xlsx ワークシート本体。
        /// </summary>
        private Table table;

        /// <summary>
        /// ヘッダ名 → 列番号の変換辞書。
        /// </summary>
        private Dictionary<string, int> index;

        #endregion
    }
}
