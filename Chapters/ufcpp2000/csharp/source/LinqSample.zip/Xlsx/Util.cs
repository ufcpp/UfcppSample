﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO.Packaging;
using System.Xml;
using System.Xml.Linq;

namespace Xlsx
{
    /// <summary>
    /// Office Open XML のスプレッドシート（要するに .xlsx）を読み込むするための補助関数群。
    /// </summary>
    public class Util
    {
        const string ContentTypeWorkbook = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml";
        const string ContentTypeSharedStrings = "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml";
        const string ContentTypeWorksheet = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml";

        /// <summary>
        /// OOXML のスプレッドシートの XML 名前空間。
        /// </summary>
        public static readonly XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        /// <summary>
        /// OOXML のリレーションシップの XML 名前空間。
        /// </summary>
        public static readonly XNamespace nsR = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

        /// <summary>
        /// スプレッドシートから共有文字列一覧を取得。
        /// </summary>
        /// <param name="package">パッケージ</param>
        /// <returns>共有文字列一覧</returns>
        /// <remarks>
        /// Excel 2007 の仕様では、
        /// セルの中の文字列は、全部共有文字列への参照になっています。
        /// 
        /// パッケージ中から共有文字列の格納された xml ファイルを探すには、
        /// ContentType が sharedStrings+xml なものを見つければ OK。
        /// </remarks>
        public static IList<string> GetSharedStringTable(Package package)
        {
            var parts = package.GetParts();
            var ssPart = parts.Single(x => x.ContentType == ContentTypeSharedStrings);
            var ssDoc = XDocument.Load(XmlReader.Create(ssPart.GetStream()));
            var ss = ssDoc.Root.Es("si").Select(x => x.E("t").Value);
            return ss.ToList();
        }

        /// <summary>
        /// ワークブック（スプレッドシートの大本の要素）を取得。
        /// </summary>
        /// <param name="package">パッケージ</param>
        /// <returns>workbook</returns>
        /// <remarks>
        /// パッケージ中からワークブックの xml ファイルを探すには、
        /// ContentType が sheet.main+xml なものを見つければ OK。
        /// </remarks>
        public static PackagePart GetWorkbook(Package package)
        {
            var parts = package.GetParts();
            var wbPart = parts.Single(x => x.ContentType == ContentTypeWorkbook);
            return wbPart;
        }

        /// <summary>
        /// ワークブックから、
        /// シート名を指定してワークシートを取得。
        /// </summary>
        /// <param name="workbook">ワークブック</param>
        /// <param name="name">シート名</param>
        /// <returns>ワークシート</returns>
        /// <remarks>
        /// ワークシートは、ワークブック中の sheet タグに、
        /// 名前とリレーション ID が入っているので、その情報を元にパーツを探します。
        /// 
        /// リレーション ID からのパーツの取得は GetRelationship で取得した Uri を使って GetPart します。
        /// 
        /// ワークブックからの相対 URI になっているので、ResolvePartUri が必要。
        /// </remarks>
        public static PackagePart GetSheetFromName(PackagePart workbook, string name)
        {
            var wbDoc = XDocument.Load(XmlReader.Create(workbook.GetStream()));

            var sheetTag = wbDoc.Root.E("sheets").Es("sheet").Single(x => x.A("name").Value == name);
            var sheetId = sheetTag.Attribute(nsR + "id").Value;
            var sheetUri = workbook.GetRelationship(sheetId).TargetUri;

            var wbUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), workbook.Uri);
            var absoluteUri = PackUriHelper.ResolvePartUri(wbUri, sheetUri);

            return workbook.Package.GetPart(absoluteUri);
        }
    }

    /// <summary>
    /// 頻出するので、
    /// XElement.Element, Elements, Attribute の短縮形を作る。
    /// </summary>
    static class XlsxExtensions
    {
        /// <summary>
        /// e.Element(ns + name) → e.E(name) に短縮。
        /// </summary>
        /// <param name="elem">サブエレメントを取得したいエレメント</param>
        /// <param name="name">サブエレメントのタグ名</param>
        /// <returns>サブエレメント</returns>
        public static XElement E(this XElement elem, string name)
        {
            return elem.Element(Util.ns + name);
        }

        /// <summary>
        /// e.Elements(ns + name) → e.Es(name) に短縮。
        /// </summary>
        /// <param name="elem">サブエレメントを取得したいエレメント</param>
        /// <param name="name">サブエレメントのタグ名</param>
        /// <returns>サブエレメント一覧</returns>
        public static IEnumerable<XElement> Es(this XElement elem, string name)
        {
            return elem.Elements(Util.ns + name);
        }

        /// <summary>
        /// e.Attribute(name) → e.A(name) に短縮。
        /// </summary>
        /// <param name="elem">属性を取得したいエレメント</param>
        /// <param name="name">属性名</param>
        /// <returns>属性</returns>
        public static XAttribute A(this XElement elem, string name)
        {
            return elem.Attribute(name);
        }
    }
}
