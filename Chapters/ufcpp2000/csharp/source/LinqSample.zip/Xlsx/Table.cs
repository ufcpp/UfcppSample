﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO.Packaging;
using System.Xml;
using System.Xml.Linq;

namespace Xlsx
{
    /// <summary>
    /// <![CDATA[
    /// 値11    値12    値13
    /// 値21    値22    値23
    /// 値31    値32    値33
    /// ・・・
    /// ]]>
    /// みたいになっている OOXML ワークシートから値を取り出すためのヘルパ。
    /// </summary>
    public class Table
    {
        #region 初期化

        /// <summary>
        /// ワークシートと共有文字列一覧を指定して初期化。
        /// </summary>
        /// <param name="sheet">ワークシート</param>
        /// <param name="ssTable">共有文字列一覧</param>
        public Table(PackagePart sheet, IList<string> ssTable)
        {
            this.Load(sheet, ssTable);
        }

        /// <summary>
        /// ワークシートを読み込む。
        /// </summary>
        /// <param name="sheet">ワークシート</param>
        /// <param name="ssTable">共有文字列一覧</param>
        /// <remarks>
        /// ワークシート XML の中身は以下のような感じになっています。
        /// 
        /// <![CDATA[
        /// <worksheet 中略>
        ///     中略
        ///     <sheetData>
        ///         <row r="行番号" spans="列番号最小値:列番号最大値">
        ///             <c r="タグ" t="タイプ">
        ///                 <v>値</v>
        ///             </c>
        ///             以下、c が続く
        ///         </row>
        ///         以下、row が続く
        ///     <sheetData>
        ///     中略
        /// </worksheet>
        /// ]]>
        /// </remarks>
        public void Load(PackagePart sheet, IList<string> ssTable)
        {
            var doc = XDocument.Load(XmlReader.Create(sheet.GetStream()));
            var rows = doc.Root.E("sheetData").Es("row");

            this.rowMin = int.MaxValue;
            this.rowMax = int.MinValue;
            this.colMin = int.MaxValue;
            this.colMax = int.MinValue;

            foreach (var row in rows)
            {
                int nRow = int.Parse(row.A("r").Value);
                string colRange = row.A("spans").Value;
                var colMinMax = colRange.Split(':');
                int minCol = int.Parse(colMinMax[0]);
                int maxCol = int.Parse(colMinMax[1]);

                if (nRow < this.rowMin) this.rowMin = nRow;
                if (nRow > this.rowMax) this.rowMax = nRow;
                if (minCol < this.colMin) this.colMin = minCol;
                if (maxCol > this.colMax) this.colMax = maxCol;

                var cs =
                    from cell in row.Es("c")
                    let x = new { Tag = cell.A("r").Value, Type = cell.A("t"), Value = cell.E("v").Value }
                    select new
                    {
                        x.Tag,
                        Value = x.Type == null ? x.Value :
                        x.Type.Value == "s" ? ssTable[int.Parse(x.Value)] :
                        string.Empty
                    };

                foreach (var c in cs)
                {
                    this.cells[c.Tag] = c.Value;
                }
            }
        }

        #endregion
        #region セルの値の取得

        /// <summary>
        /// this["A1"] で A1 セルの値を取得。
        /// </summary>
        /// <param name="tag">セルのタグ（A1 みたいなの）</param>
        /// <returns>セルの値</returns>
        public string this[string tag]
        {
            get
            {
                if (this.cells.ContainsKey(tag))
                    return this.cells[tag];
                else
                    return null;
            }
        }

        /// <summary>
        /// 行・列番号を指定してセルの値を取得。
        /// </summary>
        /// <param name="row">1から始まる行番号</param>
        /// <param name="col">1ならA列、2ならB列・・・</param>
        /// <returns>セルの値</returns>
        public string this[int row, int col]
        {
            get
            {
                if(!this.CheckRange(row, col))
                    throw new ArgumentOutOfRangeException();

                string colstr = ToColString(col);
                string tag = string.Format("{0}{1}", colstr, row);

                return this[tag];
            }
        }

        #endregion
        #region 行数・列数

        /// <summary>
        /// シート中に含まれる行番号の最小値
        /// </summary>
        public int RowMin
        {
            get { return rowMin; }
        }

        /// <summary>
        /// シート中に含まれる行番号の最大値
        /// </summary>
        public int RowMax
        {
            get { return rowMax; }
        }

        /// <summary>
        /// シート中に含まれる列番号の最小値
        /// </summary>
        public int ColMin
        {
            get { return colMin; }
        }

        /// <summary>
        /// シート中に含まれる列番号の最大値
        /// </summary>
        public int ColMax
        {
            get { return colMax; }
        }

        #endregion
        #region private メソッド

        private static string ToColString(int n)
        {
            --n;
            int high = n / 26;
            int low = n % 26;

            char lowS = (char)((int)'A' + low);

            if (high == 0)
                return new string(lowS, 1);

            --high;

            if (high >= 26)
                throw new ArgumentOutOfRangeException();

            char highS = (char)((int)'A' + high);

            return new string(new char[] { highS, lowS });
        }

        private bool CheckRange(int row, int col)
        {
            return row >= rowMin
                && row <= rowMax
                && col >= colMin
                && col <= colMax;
        }

        #endregion
        #region フィールド

        /// <summary>
        /// cells["A1"] で A1 セルの値を取得。
        /// </summary>
        Dictionary<string, string> cells = new Dictionary<string,string>();

        int rowMin;
        int rowMax;
        int colMin;
        int colMax;

        #endregion
    }
}
