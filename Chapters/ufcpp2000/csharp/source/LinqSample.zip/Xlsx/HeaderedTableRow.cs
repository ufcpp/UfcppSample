﻿using System;
using System.Collections.Generic;

namespace Xlsx
{
    /// <summary>
    /// XlsxHeaderedTable の行。
    /// OOXML ワークシートから、
    /// row["ヘッダ1"] みたいにして値を取り出すためのヘルパ。
    /// </summary>
    public class HeaderedTableRow
    {
        internal HeaderedTableRow(Table table, int rowNumber, Dictionary<string, int> index)
        {
            this.table = table;
            this.rowNumber = rowNumber;
            this.index = index;
        }

        /// <summary>
        /// this["ヘッダ"] でそのヘッダ名の付いてる列の値を取り出す。
        /// </summary>
        /// <param name="headerName">ヘッダ名</param>
        /// <returns>セルの値</returns>
        public string this[string headerName]
        {
            get
            {
                if (!this.index.ContainsKey(headerName))
                    throw new ArgumentOutOfRangeException();

                return this.table[this.rowNumber, this.index[headerName]];
            }
        }

        #region フィールド

        private Xlsx.Table table;
        private int rowNumber;
        private Dictionary<string, int> index;

        #endregion
    };
}
