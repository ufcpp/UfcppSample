﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml;
using System.Text;

namespace LinqToXml
{
    class Program
    {
        static void Main(string[] args)
        {
            var doc = XDocument.Load(XmlReader.Create("zetsubou.xml"));

            var characters = doc.Root.Element("Characters").Elements("Character");
            var cvList = doc.Root.Element("CvList").Elements("CV");

            // LintToObject の方とほぼ同じ書き方ができますよ、というデモ。
            //
            // VB9 は XML を言語内に統合しちゃったんで、
            // もっと LINQ to Object と同じ記法（cv.ID みたいな）で書けるんだけど。
            var q =
                from c in characters
                join cv in cvList on c.A("CV") equals cv.A("ID")
                select new
                {
                    Name = c.A("姓") + c.A("名"),
                    Info = c.A("出席番号等"),
                    Supplement = c.A("補足"),
                    CharacterVoice = cv.A("姓") + cv.A("名"),
                };

            foreach (var c in q)
            {
                Console.Write("{0} (CV: {1})\t … {2}, {3}\n",
                    c.Name.PadRight(6, '　'),
                    c.CharacterVoice.PadRight(5, '　'),
                    c.Info,
                    c.Supplement);
            }
        }
    }

    static class Extensions
    {
        public static string A(this XElement elem, string name)
        {
            var att = elem.Attribute(name);
            return att == null ? string.Empty : att.Value;
        }
    }
}
