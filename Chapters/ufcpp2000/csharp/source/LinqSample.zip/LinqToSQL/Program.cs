﻿using System;
using System.Linq;

namespace LinqToSQL
{
    /// <summary>
    /// LINQ to SQL のデモ。
    /// 
    /// ・LINQ to Object とほぼ同じ書き方できる
    /// ・OOP 的に階層型のプロパティアクセスすれば、自動でテーブル結合してくれる
    /// 
    /// OOP と RDB の間の溝を埋める技術です。
    /// </summary>
    class Program
    {
        public const string connectionString = "characters.sdf";

        static void Main(string[] args)
        {
            var context = new CharacterContext(Program.connectionString);

            if (!context.DatabaseExists())
            {
                Data.CreateTable(context);
            }

            // デモ用。
            // LintToObject の方とほぼ同じ書き方。
            var q =
                from c in context.Characters
                join cv in context.CvList on c.CharacterVoiceId equals cv.ID
                select new
                {
                    Name = c.姓 + c.名,
                    Info = c.Infomation,
                    Supplement = c.Supplement,
                    CharacterVoice = cv.姓 + cv.名,
                };

            foreach (var c in q.AsEnumerable().Take(5))
            {
                Console.Write("{0} (CV: {1})\t … {2}, {3}\n",
                    c.Name.PadRight(6, '　'),
                    c.CharacterVoice.PadRight(5, '　'),
                    c.Info,
                    c.Supplement);
            }

            // LINQ to SQL の場合、Association をきちんと設定すれば、
            // join を書かなくても自動でテーブルの結合をしてくれます。

            // Characters テーブルしか読んでないように見えて・・・
            foreach (var c in context.Characters.AsEnumerable().Take(5))
            {
                var 姓名 = c.姓 + c.名;
                var cv = c.CharacterVoice; // ここで CvList テーブルが読みだされる
                var cv姓名 = cv.姓 + cv.名;

                Console.Write("{0} (CV: {1})\t … {2}, {3}\n",
                    姓名.PadRight(6, '　'),
                    cv姓名.PadRight(5, '　'),
                    c.Infomation,
                    c.Supplement);
            }

            // 同じく、CvList しか参照していないように見えて・・・
            var 神谷 = context.CvList.Single(x => x.姓 == "神谷");

            Console.Write("{0} {1} 担当キャラ: \n", 神谷.姓, 神谷.名);

            foreach (var c in 神谷.Characters) // ここで Characters テーブルが読みだされる
            {
                Console.Write("  {0} {1}\n", c.姓, c.名);
            }
        }
    }
}
