﻿using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace LinqToSQL
{
    public class CharacterContext : DataContext
    {
        public CharacterContext(string connectionString) : base(connectionString) { }
        public Table<Character> Characters;
        public Table<CharacterVoice> CvList;
    }

    [Table(Name = "Characters")]
    public class Character
    {
        [Column(AutoSync = AutoSync.OnInsert, IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id;
        [Column]
        public string 姓;
        [Column]
        public string 名;
        [Column(Name = "学籍番号等")]
        public string Infomation;
        [Column(Name = "補足")]
        public string Supplement;
        [Column(Name = "cv")]
        public int CharacterVoiceId;

        [Association(Storage = "_CharacterVoice", ThisKey = "CharacterVoiceId")]
        public CharacterVoice CharacterVoice
        {
            get { return this._CharacterVoice.Entity; }
            set { this._CharacterVoice.Entity = value; }
        }
        private EntityRef<CharacterVoice> _CharacterVoice;
    }

    [Table(Name = "CvList")]
    public class CharacterVoice
    {
        [Column(IsPrimaryKey = true)]
        public int ID;
        [Column]
        public string 姓;
        [Column]
        public string 名;
        [Column]
        public string かばね;
        [Column]
        public string な;

        [Association(Storage = "_Characters", OtherKey = "CharacterVoiceId")]
        public EntitySet<Character> Characters
        {
            get { return this._Characters; }
            set { this._Characters.Assign(value); }
        }
        private EntitySet<Character> _Characters = new EntitySet<Character>();
    }
}
