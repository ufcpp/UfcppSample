﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyMath.Numeric;
using Lambda = MyMath.Symbolic.Lambda;
using Func4 = System.Func<double, double, double, double, double>;

namespace TestMyMath
{
	class TestDynamics
	{
		public static void Test()
		{
			TestSurface1();
			//TestSurface2();
		}

		public static void TestSurface1()
		{
			const double InitialQ1 = 0;
			const double InitialQ2 = Math.PI / 2;
			const double InitialP1 = 0.1;
			const double InitialP2 = 0;

			SurfaceDynamics dynamics = new SurfaceDynamics(
				(q1, q2) => Math.Sin(q2) * Math.Cos(q1),
				(q1, q2) => Math.Sin(q2) * Math.Sin(q1),
				(q1, q2) => -Math.Cos(q2),
				(q1, q2) => -Math.Cos(q2),
				InitialQ1, InitialQ2, InitialP1, InitialP2, 1);

			var f1 = new Lambda((q1, q2, p1, p2) => p1 / (Math.Sin(q2) * Math.Sin(q2)));
			var f2 = new Lambda((q1, q2, p1, p2) => p2);
			var f3 = new Lambda((q1, q2, p1, p2) => 0);
			var f4 = new Lambda((q1, q2, p1, p2) => p1 * p1 * Math.Cos(q2) / (Math.Sin(q2) * Math.Sin(q2) * Math.Sin(q2)) - Math.Sin(q2));

			Function4D f = new Function4D(
				(Func4)f1.Compile(),
				(Func4)f2.Compile(),
				(Func4)f3.Compile(),
				(Func4)f4.Compile());

			NumericCheck(
				(Function4D)dynamics.Function, f,
				-0.1, Math.PI, 5000, 1e-12);
		}

		static void NumericCheck(
			Function4D f, Function4D g,
			double min, double max, int num, double epsilon)
		{
			Random rnd = new Random();

			for (; num > 0; --num)
			{
				Vector4D x = new Vector4D(
					(max - min) * rnd.NextDouble() + min,
					(max - min) * rnd.NextDouble() + min,
					(max - min) * rnd.NextDouble() + min,
					(max - min) * rnd.NextDouble() + min);

				Vector4D fx = f.GetValue(x);
				Vector4D gx = g.GetValue(x);

				double x0 = Math.Abs(fx.X0 - gx.X0);
				if(x0 > 1e-7)
					Console.Write("0: {0}, {1}\n", x0, x);
				double x1 = Math.Abs(fx.X1 - gx.X1);
				if(x1 > 1e-7)
					Console.Write("1: {0}, {1}\n", x1, x);
				double x2 = Math.Abs(fx.X2 - gx.X2);
				if(x2 > 1e-7)
					Console.Write("2: {0}, {1}\n", x2, x);
				double x3 = Math.Abs(fx.X3 - gx.X3);
				if(x3 > 1e-7)
					Console.Write("3: {0}, {1}\n", x3, x);

				//if (delta > epsilon)
				//{
				//	Console.Write("x = {0} (δ = {3})\n", x, fx, gx, delta);
				//}
			}
		}

		public static void TestSurface2()
		{
			const double InitialQ1 = 0;
			const double InitialQ2 = 0.8;
			const double InitialP1 = 0.1;
			const double InitialP2 = -0.2;

			const double M = 1; // 質量

			SurfaceDynamics dynamics = new SurfaceDynamics(
				(q1, q2) => 1.5 * q2 * Math.Cos(q1),
				(q1, q2) => 0.8 * q2 * Math.Sin(q1),
				(q1, q2) => Math.Exp(q2) + 0.2 * Math.Cos((5 * Math.PI) * q2) - 2,
				(q1, q2) => M * (Math.Exp(q2) + 0.2 * Math.Cos((5 * Math.PI) * q2) - 2),
				InitialQ1, InitialQ2, InitialP1, InitialP2, M
				);
		}
	}
}
