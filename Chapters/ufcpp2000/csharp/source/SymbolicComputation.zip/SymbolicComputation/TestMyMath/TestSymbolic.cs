﻿#define Verbose

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

using My = MyMath.Symbolic;

namespace TestMyMath
{
	class TestSymbolic
	{
		public static void Test()
		{
			//TestPolynomial();
			//TestIdentical();
			//TestCall();
			//TestMultiVariable();
			//TestDifferentialOperator();
			//TestPartial();
			//TestCompile();
			//Demo();
			//TestArithmetic();

			var f = new My.Lambda(x => Math.Sin(x) * Math.Sin(x) + Math.Cos(x) * Math.Cos(x));
			f = f.Simplify();

			ShowDerivative();
			NumericDeriveCheck();
		}

		static void TestArithmetic()
		{
			var x2 = new My.Lambda(x => x * x);
			var x1 = new My.Lambda(x => x);
			var f = 2 * x2 + 3 * x1 + 1;
			Console.Write("{0}\n", f);

			x2 = new My.Lambda((x, y) => x * x);
			x1 = new My.Lambda((x, y) => x);
			var y2 = new My.Lambda((x, y) => y * y);
			var y1 = new My.Lambda((x, y) => y);
			var xy = new My.Lambda((x, y) => x * y);

			f = x2 + y2 + 2 * x1 + 2 * y1 + 2 * xy + 1;
			Console.Write("{0}\n", f);
			Console.Write("{0}\n", f.Derive("x"));
			Console.Write("{0}\n", f.Derive("y"));

			f = new My.Lambda(x => Math.Log(Math.Sin(x)));
			Console.Write("{0}\n", f);
			Console.Write("{0}\n", f.Derive("x"));
		}

		static void NumericDeriveCheck()
		{
			const int NUM = 5000;
			const double EPSILON = 1e-12;

			NumericDeriveCheck(
				"x * x * ... -> x",
				x => (x * x * (Math.Sin(x) * x * x) * Math.Sin(x)) / (x * Math.Sin(x) * Math.Sin(x) * x * x),
				x => 1,
				-500, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"sin - sin",
				x => x * x + Math.Sin(x) + x * x + 5 - Math.Sin(x) + x + 5 + x,
				x => 4 * x + 2,
				- 500, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"(x^2 + x) / (x + 1)",
				x => (x * x + x) / (1 + x),
				x => 1,
				1, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"sin^2 + cos^2",
				x => Math.Cos(x) * Math.Cos(x) + Math.Sin(x) * Math.Sin(x),
				x => 0,
				-500, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"x sin x^2 + e^x / x",
				x => x * Math.Sin(x * x) + Math.Exp(x) / x,
				x => Math.Sin(x * x) + 2 * x * x * Math.Cos(x * x) + Math.Exp(x) / x - Math.Exp(x) / (x * x),
				1, 100, NUM, EPSILON);

			NumericDeriveCheck(
				"x + sin^2 + cos^2",
				x => x * x * x * x * x * x + Math.Cos(x) * Math.Cos(x) + Math.Sin(x) * Math.Sin(x),
				x => 6 * x * x * x * x * x,
				-500, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"composition",
				x => Math.Exp(Math.Log(Math.Sin(Math.Cos(x * x * x)))),
				x => -3 * x * x * Math.Sin(x * x * x) * Math.Cos(Math.Cos(x * x * x)),
				-500, 500, NUM, EPSILON);

			NumericDeriveCheck(
				"reduce",
				x => x * 2 / x * 3 / x * x * 4 * x / 48 / x * x * x,
				x => x,
				-1000, 1000, NUM, EPSILON);//0);

			NumericDeriveCheck(
				"neg",
				x => -(-x) + (x + (-x * -x) - x * -x) + -2 * (x),
				x => 4 * x,
				-1000, 1000, NUM, EPSILON);//0);

			NumericDeriveCheck(
				"neg2",
				x => 1 + x + (x - 1 - x + 1) - x,
				x => 0,
				-1000, 1000, NUM, EPSILON);//0);

			Console.Write("done.\n");
		}

		static void NumericDeriveCheck(
			string debugID,
			Expression<Func<double, double>> f,
			Func<double, double> df,
			double min, double max, int num, double epsilon)
		{
			var f_ = new My.Lambda(f);
			var df_e = f_.Derive();
			var df_c = (Func<double, double>)df_e.Compile();

#if Verbose
			Console.Write("{0}\n",df_e);
#endif
			NumericCheck(debugID, df_c, df, min, max, num, epsilon);
		}

		static void NumericCheck(
			string debugID,
			Func<double, double> f, Func<double, double> g,
			double min, double max, int num, double epsilon)
		{
			Random rnd = new Random();

			for (; num > 0; --num)
			{
				double x = (max - min) * rnd.NextDouble() + min;

				double fx = f(x);
				double gx = g(x);
				double scale = Math.Abs(fx);
				double delta = Math.Abs(fx - gx);
				if (scale > 1e-7)
					delta /= scale;

				if (delta > epsilon)
				{
					Console.Write("{0} does not match at x = {1}, f({1}) = {2}, g({1}) = {3}, (δ = {4})\n", debugID, x, fx, gx, delta);
				}
			}
		}

		static void Demo()
		{
			var f = new My.Lambda(x => x * x);
			var df = f.Derive();
			var df_ = (Func<double, double>)df.Compile();

			Console.Write("f  = {0}\n", f);
			Console.Write("df = {0}\n", df);

			for (int i = -2; i <= 2; ++i)
				Console.Write("df({0}) = {1}\n", i, df_(i));
		}

		/*
		static void TestPartial()
		{
			TestPartial((x, y) => x * x * y + 2 * x * y);
		}

		static void TestPartial(Expression<Func<double, double, double>> f)
		{
			var dx = new DifferentialOperator("x");
			var dy = new DifferentialOperator("y");
			var laplacian = dx * dx + dy * dy;

			Console.Write("f     = {0}\n", f);
			Console.Write("df/dx = {0}\n", dx.Apply(f));
			Console.Write("Δf   = {0}\n", laplacian.Apply(f));
		}
		 * */

		static void TestCompile()
		{
			TestCompile(x => x * Math.Log(x));
		}

		static void TestCompile(Expression<Func<double, double>> e)
		{
			var f_ = new My.Lambda(e);
			var f = (Func<double, double>)f_.Compile();
			Console.Write("f = {0}\n", e);

			for (int i = 1; i <= 3; ++i)
			{
				Console.Write("f({0}) = {1}\n", i, f(i));
			}

			var df_ = f_.Derive();
			var df = (Func<double, double>)df_.Compile();
			Console.Write("df = {0}\n", df_);

			for (int i = 1; i <= 3; ++i)
			{
				Console.Write("df({0}) = {1}\n", i, df(i));
			}
		}

		/*
		static void TestDifferentialOperator()
		{
			//TestDifferentialOperator((x, y) => x * x + y * x + 2 * y * y);
			//TestDifferentialOperator((x, y) => x * x * y + 2 * x * y * y * y);
			TestDifferentialOperator((x, y) => x * Math.Log(y) + y * Math.Exp(x));
		}

		static void TestDifferentialOperator(
			Expression<Func<double, double, double>> f)
		{
			DifferentialOperator dx = new DifferentialOperator("x");
			DifferentialOperator dy = new DifferentialOperator("y");

			Console.Write("f = {0}\n", f);
			Console.Write("df/dx = {0}\n", dx.Apply(f));
			Console.Write("df/dy = {0}\n", dy.Apply(f));

			var laplacian = new DifferentialOperator((x, y) => x * x + y * y);
			Console.Write("Δf = {0}\n", laplacian.Apply(f));

			laplacian = dx * dx + dy * dy;
			Console.Write("Δf = {0}\n", laplacian.Apply(f));

			DifferentialOperator communicator = dx * dy - dy * dx;
			Console.Write("[d/dx, d/dy]f = {0}\n", communicator.Apply(f));
		}
		 */

		static void TestPolynomial()
		{
			var f = new My.Lambda(x => 4 * x * -x * x * -x + 5 * -x * x * x + 3 * x * x + 2 * x + 1);

			Console.Write(f);
			Console.Write('\n');

			Console.Write(f.Derive());
			Console.Write('\n');
		}

		static void TestMultiVariable()
		{
			var f = new My.Lambda(
				(x, y) => x * x * x + 3 * x * x * y + 2 * x * y * y + y * y * y
				);

			Console.Write("f = {0}\n", f);
			Console.Write("df/dx = {0}\n", f.Derive("x"));
			Console.Write("df/dy = {0}\n", f.Derive("y"));
		}

		/*
		static void TestIdentical()
		{
			var f1 = new My.Lambda(x => 3 - 2 * x + 1 / x);
			var f2 = new My.Lambda(x => 3 - x * 2 + 1 / x);

			Console.Write("{0}\n", f1.IsIdenticalTo(f2));
			Console.Write("{0}\n", f1.Derive().IsIdenticalTo(f2.Derive()));

			Expression<Func<double, double>> f3 = x => Math.Exp(Math.Sin(x));
			Expression<Func<double, double>> f4 = x => Math.Exp(Math.Cos(x));

			Console.Write("{0}\n", f3.IsIdenticalTo(f4));

			Expression<Func<double, double, double>> f5 = (x, y) => x + 1 + y;
			Expression<Func<double, double, double>> f6 = (x, y) => y + 1 + x;

			Console.Write("{0}\n", f5.IsIdenticalTo(f6));
		}
		 * */

		static void TestCall()
		{
			ShowDerivative<Func<double, double>>(x => Math.Log(Math.Exp(x)));
			ShowDerivative<Func<double, double>>(x => Math.Exp(Math.Log(x)));
			ShowDerivative<Func<double, double>>(x => Math.Tan(x) * Math.Cos(x));
			ShowDerivative<Func<double, double>>(x => Math.Tan(x) / Math.Sin(x));
			ShowDerivative<Func<double, double>>(x => 2 * Math.Cos(x) * Math.Sin(x));
			ShowDerivative<Func<double, double>>(x => Math.Sin(x) * Math.Cos(x));
			ShowDerivative<Func<double, double>>(x => Math.Cos(Math.Sin(x)));
			ShowDerivative<Func<double, double>>(x => Math.Exp(Math.Sin(x)));
			ShowDerivative<Func<double, double>>(x => Math.Log(Math.Sin(x)));
		}

		static void TestPower()
		{
			ParameterExpression pX = Expression.Parameter(typeof(double), "x");
			ParameterExpression pY = Expression.Parameter(typeof(double), "y");
			Expression<Func<double, double, double>> le = Expression.Lambda<Func<double, double, double>>(
				Expression.Power(pX, pY),
				pX, pY);
			Func<double, double, double> fle = le.Compile();
			Console.Write(le);
			Console.Write('\n');
			Console.Write(fle(2, 3));
			Console.Write('\n');
		}

		static void ShowDerivative()
		{
			ShowDerivative(new My.Lambda(
				x => (x + 4) * (x + 1) * (x + 2) / (x + 3) / (x + 1) / ((x + 2) / (x + 3)) * ((x + 5) / (x + 4))
				));
			ShowDerivative(new My.Lambda(
				x => Math.Cos(x) * Math.Cos(x) + Math.Sin(x) * Math.Sin(x)
				));
			ShowDerivative(new My.Lambda(
				x => (x * x * (Math.Sin(x) * x * x) * Math.Sin(x)) / (x * Math.Sin(x) * Math.Sin(x) * x * x)
				));
			ShowDerivative(new My.Lambda(
				x => x * x + Math.Sin(x) + x * x + 5 + x * Math.Cos(x) + x + 5 + x
				));
			ShowDerivative(new My.Lambda(
				x => (x * x + x) / 2 + x
				));
			ShowDerivative(new My.Lambda(
				x => (x * x + x) / (1 + x)
				));
			ShowDerivative(new My.Lambda(
				x => Math.Sin(x * x) / Math.Sin(x) - Math.Sin(x) + Math.Sin(x * x) + Math.Sin(x)
				));

			const double p1 = 1;
			const double p2 = 1;
			ShowDerivative(new My.Lambda(
				//x => (x * x + x) / 2 + x
				q2 => ((-((((1 / (0.5 + (-0.5 * Math.Cos((2 * q2))))) * (p1 * p1)) + (0 * ((2 * p1) * p2))) + (1 * (p2 * p2))) / 2) - (-Math.Cos(q2) * 1))
				));
		}

		static void ShowDerivative<T>(Expression<T> e)
		{
			ShowDerivative(new My.Lambda(e));
		}

		static void ShowDerivative(My.Lambda f)
		{
			f = f.Simplify();
			Console.Write(" f = {0}\n", f);
			Console.Write("df = {0}\n\n", f.Derive());
		}
	}
}
