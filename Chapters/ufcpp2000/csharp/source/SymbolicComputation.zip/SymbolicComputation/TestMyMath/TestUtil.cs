﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestMyMath
{
	class TestUtil
	{
		public static void Test()
		{
			var x = new List<IComparable> { 1, 3, 6, 8, 3, 4, 5, 3, 1 };
			var y = new List<IComparable> { 2, 4, 9, 7, 3, 2, 5, 3, 1 };
			x.Sort();
			y.Sort();
			var z = MyMath.Util.Intersect(x, y);
			Show(z);

			Console.Write("{0} - {1} = ", ToString(x), ToString(z));
			MyMath.Util.Remove(x, z);
			Console.Write("{0}\n", ToString(x));

			Console.Write("{0} - {1} = ", ToString(y), ToString(z));
			MyMath.Util.Remove(y, z);
			Console.Write("{0}\n", ToString(y));
		}

		static string ToString<T>(List<T> l)
		{
			StringBuilder sb = new StringBuilder();

			if (l.Count == 0)
				sb.Append("()");

			sb.Append(string.Format("({0}", l[0]));
			for (int i = 1; i < l.Count; ++i)
			{
				sb.Append(string.Format(", {0}", l[i]));
			}
			sb.Append(")");
			return sb.ToString();
		}

		static void Show<T>(List<T> l)
		{
			foreach (var x in l)
			{
				Console.Write("{0}, ", x);
			}
			Console.Write('\n');
		}
	}
}
