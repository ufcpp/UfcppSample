﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace TestMyMath
{
	class Program
	{
		static void Main(string[] args)
		{
			//TestUtil.Test();
			TestSymbolic.Test();
			//TestDynamics.Test();
		}
	}
}
