﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Media.Animation;

namespace Plot3D
{
  /// <summary>
  /// 曲面の方程式を表す関数。
  /// </summary>
  /// <param name="u">座標変数1</param>
  /// <param name="v">座標変数2</param>
  /// <returns>3次元上の点</returns>
  public delegate Point3D SurfaceFunction(double u, double v);

  /// <summary>
  /// 三次元空間上に浮かぶ曲面と、
  /// その曲面上の1点を表示する。
  /// </summary>
  public partial class Plot3DControl : System.Windows.Controls.UserControl
  {
    #region フィールド

    /// <summary>
    /// 拘束面の表示の仕方。
    /// </summary>
    public enum SurfaceType
    {
      Solid, // 全面表示
      Dotted, // 格子点付近のみ表示
      Lattice, // 格子状に表示
    }

    #endregion
    #region 初期化

    /// <summary>
    /// 詳しくはもう一方のコンストラクタ参照。
    /// 全面表示。
    /// </summary>
    /// <param name="s">曲面の方程式を表す関数</param>
    /// <param name="u0">u の表示範囲の最小値</param>
    /// <param name="u1">u の表示範囲の最大値</param>
    /// <param name="v0">v の表示範囲の最小値</param>
    /// <param name="v1">v の表示範囲の最大値</param>
    /// <param name="separations">格子の分割数</param>
    public Plot3DControl(
      SurfaceFunction s,
      double u0, double u1,
      double v0, double v1,
      int separations)
      : this(s, u0, u1, v0, v1, separations, SurfaceType.Solid)
    {
    }

    /// <summary>
    /// 曲面の方程式、表示範囲、表示の仕方などを指定して初期化。
    /// </summary>
    /// <param name="s">曲面の方程式を表す関数</param>
    /// <param name="u0">u の表示範囲の最小値</param>
    /// <param name="u1">u の表示範囲の最大値</param>
    /// <param name="v0">v の表示範囲の最小値</param>
    /// <param name="v1">v の表示範囲の最大値</param>
    /// <param name="separations">格子の分割数</param>
    /// <param name="t">曲面の表示方式</param>
    public Plot3DControl(
      SurfaceFunction s,
      double u0, double u1,
      double v0, double v1,
      int separations,
      SurfaceType t)
			: this()
    {
      this.SetLoation(s(0, 0));
      this.SetSurface(s, 0, u1, v0, v1, separations, t);
    }

		public Plot3DControl()
		{
			InitializeComponent();
		}

    #endregion
		#region 値の更新

		/// <summary>
    /// 曲面上の点の位置を更新。
    /// </summary>
    /// <param name="p">新しい位置。</param>
    public void SetLoation(Point3D p)
    {
      this.objectPosition.OffsetX = p.X;
      this.objectPosition.OffsetY = p.Y;
      this.objectPosition.OffsetZ = p.Z;
    }

    /// <summary>
    /// 拘束面を表す方程式/表示範囲の更新。
    /// </summary>
    /// <param name="s">曲面の方程式を表す関数</param>
    /// <param name="u0">u の表示範囲の最小値</param>
    /// <param name="u1">u の表示範囲の最大値</param>
    /// <param name="v0">v の表示範囲の最小値</param>
    /// <param name="v1">v の表示範囲の最大値</param>
    /// <param name="separations">格子の分割数</param>
    /// <param name="t">曲面の表示方式</param>
    public void SetSurface(
      SurfaceFunction s,
      double u0, double u1,
      double v0, double v1,
      int separations,
      SurfaceType t)
    {
			MeshGeometry3D geometry = (MeshGeometry3D)this.FindResource("RestraintSurface");
			geometry.Positions.Clear();
			geometry.TriangleIndices.Clear();

			switch (t)
      {
        case SurfaceType.Solid:
          this.MakeRestraintSurface(s, u0, u1, v0, v1, separations);
          break;
        case SurfaceType.Dotted:
          this.MakeRestraintSurfaceDotted(s, u0, u1, v0, v1, separations);
          break;
        case SurfaceType.Lattice:
          this.MakeRestraintSurfaceLattice(s, u0, u1, v0, v1, separations);
          break;
      }
    }

    #endregion
    #region 拘束面の表示

    /// <summary>
    /// 拘束面を表す関数 (x(u, v), y(u, v), z(u, v)) を元に、
    /// MeshGeometry3D を作成。
    /// 全面表示。
    /// </summary>
    /// <param name="qu">変数 u</param>
    /// <param name="qv">変数 v</param>
    /// <param name="x">関数 x</param>
    /// <param name="y">関数 y</param>
    /// <param name="z">関数 z</param>
    /// <param name="u0">u の最小値</param>
    /// <param name="u1">u の最大値</param>
    /// <param name="v0">v の最小値</param>
    /// <param name="v1">v の最大値</param>
    /// <param name="N">u, v の格子間隔数</param>
    void MakeRestraintSurface(
			SurfaceFunction s,
			double u0, double u1,
      double v0, double v1,
      int N)
    {

      double du = (u1 - u0) / N;
      double dv = (v1 - v0) / N;

      MeshGeometry3D geometry = (MeshGeometry3D)this.FindResource("RestraintSurface");

      double v = v0;
      for (int j = 0; j <= N; ++j, v += dv)
      {
        double u = u0;
        for (int i = 0; i <= N; ++i, u += du)
        {
          Point3D p = s(u, v);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用
        }
      }

      for (int j = 0; j < N; ++j)
        for (int i = 0; i < N; ++i)
        {
          int ii = i + 1;
          int jj = j + 1;

          int i0 = i + j * (N + 1);
          int i1 = i + jj * (N + 1);
          int i2 = ii + j * (N + 1);
          int i3 = ii + jj * (N + 1);

          geometry.TriangleIndices.Add(2 * i0);
          geometry.TriangleIndices.Add(2 * i1);
          geometry.TriangleIndices.Add(2 * i2);

          geometry.TriangleIndices.Add(2 * i3);
          geometry.TriangleIndices.Add(2 * i2);
          geometry.TriangleIndices.Add(2 * i1);

          geometry.TriangleIndices.Add(2 * i3 + 1);
          geometry.TriangleIndices.Add(2 * i1 + 1);
          geometry.TriangleIndices.Add(2 * i2 + 1);

          geometry.TriangleIndices.Add(2 * i0 + 1);
          geometry.TriangleIndices.Add(2 * i2 + 1);
          geometry.TriangleIndices.Add(2 * i1 + 1);
        }
    }

    /// <summary>
    /// 拘束面を表す関数 (x(u, v), y(u, v), z(u, v)) を元に、
    /// MeshGeometry3D を作成。
    /// 格子点周辺のみ表示。
    /// </summary>
    /// <param name="qu">変数 u</param>
    /// <param name="qv">変数 v</param>
    /// <param name="x">関数 x</param>
    /// <param name="y">関数 y</param>
    /// <param name="z">関数 z</param>
    /// <param name="u0">u の最小値</param>
    /// <param name="u1">u の最大値</param>
    /// <param name="v0">v の最小値</param>
    /// <param name="v1">v の最大値</param>
    /// <param name="N">u, v の格子間隔数</param>
    void MakeRestraintSurfaceDotted(
			SurfaceFunction s,
			double u0, double u1,
      double v0, double v1,
      int N)
    {
      const double FACTOR = 0.1;

      double du = (u1 - u0) / N;
      double dv = (v1 - v0) / N;

      MeshGeometry3D geometry = (MeshGeometry3D)this.FindResource("RestraintSurface");

      double v = v0;
      for (int j = 0; j <= N; ++j, v += dv)
      {
        double u = u0;
        for (int i = 0; i <= N; ++i, u += du)
        {
          Point3D p;

          p = s(u - FACTOR * du, v - FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u + FACTOR * du, v - FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u - FACTOR * du, v + FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u + FACTOR * du, v + FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用
        }
      }

      for (int j = 0; j < N; ++j)
        for (int i = 0; i < N; ++i)
        {
          int ii = i + 1;
          int jj = j + 1;

          int k = i + j * (N + 1);
          k *= 8;

          geometry.TriangleIndices.Add(k + 0);
          geometry.TriangleIndices.Add(k + 4);
          geometry.TriangleIndices.Add(k + 6);

          geometry.TriangleIndices.Add(k + 0);
          geometry.TriangleIndices.Add(k + 6);
          geometry.TriangleIndices.Add(k + 2);

          geometry.TriangleIndices.Add(k + 1);
          geometry.TriangleIndices.Add(k + 7);
          geometry.TriangleIndices.Add(k + 5);

          geometry.TriangleIndices.Add(k + 1);
          geometry.TriangleIndices.Add(k + 3);
          geometry.TriangleIndices.Add(k + 7);
        }
    }

    /// <summary>
    /// 拘束面を表す関数 (x(u, v), y(u, v), z(u, v)) を元に、
    /// MeshGeometry3D を作成。
    /// 格子点周辺のみ表示。
    /// </summary>
    /// <param name="qu">変数 u</param>
    /// <param name="qv">変数 v</param>
    /// <param name="x">関数 x</param>
    /// <param name="y">関数 y</param>
    /// <param name="z">関数 z</param>
    /// <param name="u0">u の最小値</param>
    /// <param name="u1">u の最大値</param>
    /// <param name="v0">v の最小値</param>
    /// <param name="v1">v の最大値</param>
    /// <param name="N">u, v の格子間隔数</param>
    void MakeRestraintSurfaceLattice(
			SurfaceFunction s,
			double u0, double u1,
      double v0, double v1,
      int N)
    {
      const double FACTOR = 0.1;

      double du = (u1 - u0) / N;
      double dv = (v1 - v0) / N;

      MeshGeometry3D geometry = (MeshGeometry3D)this.FindResource("RestraintSurface");

      double v = v0;
      for (int j = 0; j <= N; ++j, v += dv)
      {
        double u = u0;
        for (int i = 0; i <= N; ++i, u += du)
        {
          Point3D p;

          p = s(u, v);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u + FACTOR * du, v);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u, v + FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用

          p = s(u + FACTOR * du, v + FACTOR * dv);
          geometry.Positions.Add(p);
          geometry.Positions.Add(p); // 裏面用
        }
      }

      for (int j = 0; j < N; ++j)
        for (int i = 0; i < N; ++i)
        {
          int ii = i + 1;
          int jj = j + 1;

          int k = i + j * (N + 1);
          k *= 8;
          int LINE = 8 * (N + 1);

          geometry.TriangleIndices.Add(k + 1);
          geometry.TriangleIndices.Add(k + 8 + 1);
          geometry.TriangleIndices.Add(k + 8 + 5);

          geometry.TriangleIndices.Add(k + 1);
          geometry.TriangleIndices.Add(k + 8 + 5);
          geometry.TriangleIndices.Add(k + 5);

          geometry.TriangleIndices.Add(k + 5);
          geometry.TriangleIndices.Add(k + 7);
          geometry.TriangleIndices.Add(k + LINE + 3);

          geometry.TriangleIndices.Add(k + 5);
          geometry.TriangleIndices.Add(k + LINE + 3);
          geometry.TriangleIndices.Add(k + LINE + 1);

          geometry.TriangleIndices.Add(k + 0);
          geometry.TriangleIndices.Add(k + 8 + 4);
          geometry.TriangleIndices.Add(k + 8 + 0);

          geometry.TriangleIndices.Add(k + 0);
          geometry.TriangleIndices.Add(k + 4);
          geometry.TriangleIndices.Add(k + 8 + 4);

          geometry.TriangleIndices.Add(k + 4);
          geometry.TriangleIndices.Add(k + LINE + 2);
          geometry.TriangleIndices.Add(k + 6);

          geometry.TriangleIndices.Add(k + 4);
          geometry.TriangleIndices.Add(k + LINE + 0);
          geometry.TriangleIndices.Add(k + LINE + 2);
        }
    }

    #endregion
    #region イベント関係

    void OnMouseLeftDown(
      Object sender,
      MouseEventArgs e
      )
    {
      Point p = e.GetPosition(this.viewport);
      Size s = this.viewport.RenderSize;

      double x = s.Width / 2;
      double y = -p.X + s.Width / 2;
      double z = p.Y - s.Height / 2;

      Vector3D v = new Vector3D(x, y, z);
      v.Normalize();

      this.camera.Position = (Point3D)(Vector3D.Multiply(15, v));
      this.camera.LookDirection = -v;
    }

    void OnMouseMove(
      Object sender,
      MouseEventArgs e
      )
    {
      if (e.LeftButton == MouseButtonState.Released)
        return;

      this.OnMouseLeftDown(sender, e);
    }

    void OnMouseRightDown(
      Object sender,
      MouseEventArgs e
      )
    {
      Storyboard sb = (Storyboard)this.viewport.FindResource("objectsStoryboard");
      sb.Pause(this.viewport);

      if (sb.GetIsPaused(this.viewport))
        sb.Resume(this.viewport);
      else
        sb.Pause(this.viewport);
    }

    #endregion
  }
}
