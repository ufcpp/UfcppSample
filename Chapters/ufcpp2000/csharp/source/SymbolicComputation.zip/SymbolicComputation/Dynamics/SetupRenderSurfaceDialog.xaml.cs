﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using SurfaceType = Plot3D.Plot3DControl.SurfaceType;

namespace Dynamics
{
	public delegate void SetRenderRange(double s1, double s2, double t1, double t2, int intervals, SurfaceType type);

	/// <summary>
	/// SetupRenderSurfaceDialog.xaml の相互作用ロジック
	/// </summary>
	public partial class SetupRenderSurfaceDialog : Window
	{
		public SetupRenderSurfaceDialog()
		{
			InitializeComponent();
		}

		public event ShowErrorMessage OnError;
		public event SetRenderRange OnOk;

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			double s1, s2, t1, t2;
			int intervals;
			SurfaceType type;

			switch (this.comboType.SelectedIndex)
			{
				case 0: type = SurfaceType.Dotted; break;
				case 1: type = SurfaceType.Solid; break;
				case 2: type = SurfaceType.Lattice; break;
				default: type = 0; break;
			}

			if (!double.TryParse(this.textMinS.Text, out s1))
			{
				this.ShowError("error: Min S does not a number");
				return;
			}
			if (!double.TryParse(this.textMaxS.Text, out s2))
			{
				this.ShowError("error: Max S does not a number");
				return;
			}
			if (!double.TryParse(this.textMinT.Text, out t1))
			{
				this.ShowError("error: Min T does not a number");
				return;
			}
			if (!double.TryParse(this.textMaxT.Text, out t2))
			{
				this.ShowError("error: Max T does not a number");
				return;
			}
			if (!int.TryParse(this.textN.Text, out intervals))
			{
				this.ShowError("error: N does not a number");
				return;
			}

			SetRenderRange onOk = this.OnOk;
			if (onOk != null)
			{
				onOk(s1, s2, t1, t2, intervals, type);
			}
		}

		void ShowError(string msg)
		{
			ShowErrorMessage onError = this.OnError;
			if (onError != null)
				onError(msg);
		}
	}
}
