﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Media.Media3D;
using System.Threading;

using MyMath.Numeric;
using Ex2 = System.Linq.Expressions.Expression<System.Func<double, double, double>>;
using SurfaceType = Plot3D.Plot3DControl.SurfaceType;

namespace Dynamics
{
  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>

  public partial class Window1 : Window
  {
    public Window1()
    {
      InitializeComponent();

			this.dynmics = new SurfaceDynamics();

			this.plotArea = new Plot3D.Plot3DControl();
			this.dock.Children.Add(this.plotArea);

			this.Loaded += new RoutedEventHandler(Window1_Loaded);

			CompositionTarget.Rendering += this.Callback;
		}

		void Window1_Loaded(object sender, RoutedEventArgs e)
		{
			this.equationDlg = new SetupSurfaceEquationDialog();
			this.equationDlg.Owner = this;
			this.equationDlg.OnOk += this.RenewDynamics;
			this.equationDlg.OnError += this.OnErrer;
			this.equationDlg.Show();

			this.renderDlg = new SetupRenderSurfaceDialog();
			this.renderDlg.Owner = this;
			this.renderDlg.OnOk += this.RenderSurface;
			this.renderDlg.OnError += this.OnErrer;
			this.renderDlg.Show();

			this.valueDlg = new SetupCurrentValueDialog();
			this.valueDlg.Owner = this;
			this.valueDlg.OnOk += this.SetCurrent;
			this.valueDlg.OnError += this.OnErrer;
			this.valueDlg.Show();

			/* テスト用
      this.InitDynamics();

      this.plotArea =
        new Plot3D.Plot3DControl(
          Surface, U0, U1, V0, V1, N,
          Plot3D.Plot3DControl.SurfaceType.Dotted);

      this.dock.Children.Add(this.plotArea);
			 * */
		}

		void RenderSurface(double s1, double s2, double t1, double t2, int intervals, SurfaceType type)
		{
			if (!this.dynmics.IsRead)
				return;
			this.plotArea.SetSurface(
				this.Surface,
				s1, s2, t1, t2, intervals, type);
		}

		void RenewDynamics(Ex2 x, Ex2 y, Ex2 z, Ex2 phi, double m)
		{
			lock (this)
			{
				this.dynmics.M = m;
				this.dynmics.SetFunctions(x, y, z, phi);
			}
		}

		void SetCurrent(double q1, double q2, double p1, double p2)
		{
			lock (this)
			{
				this.dynmics.Current = new Vector4D(q1, q2, p1, p2);
			}
		}

    #region フィールド

    Plot3D.Plot3DControl plotArea;
		SurfaceDynamics dynmics;

		SetupSurfaceEquationDialog equationDlg;
		SetupRenderSurfaceDialog renderDlg;
		SetupCurrentValueDialog valueDlg;

		const double dt = 0.01;

    #endregion
#if false
		// テスト用 その1 ちょっと複雑な曲面

    // 拘束面の表示関係
    const double U0 = 0;
    const double U1 = 2 * Math.PI;
    const double V0 = 0;
    const double V1 = 1;
    const int N = 100;

    // Dynamics の初期値
    const double InitialQ1 = 0;
    const double InitialQ2 = 0.8;
    const double InitialP1 = 0.1;
		const double InitialP2 = -0.2;
		const double M = 1;

    // 数値計算用
    const double dt = 0.01;

    void InitDynamics()
    {
      this.dynmics = new SurfaceDynamics(
				(q1, q2) => 1.5 * q2 * Math.Cos(q1),
				(q1, q2) => 0.8 * q2 * Math.Sin(q1),
				(q1, q2) => Math.Exp(q2) + 0.2 * Math.Cos((5 * Math.PI) * q2) - 2,
				(q1, q2) => M * (Math.Exp(q2) + 0.2 * Math.Cos((5 * Math.PI) * q2) - 2),
				InitialQ1, InitialQ2, InitialP1, InitialP2, M
				);
    }
#elif false
		// テスト用 その2 球面（曲座標）
		
		// 拘束面の表示関係
    const double U0 = 0;
    const double U1 = 2 * Math.PI;
    const double V0 = 0;
    const double V1 = Math.PI / 2;
    const int N = 30;

    // Dynamics の初期値
    const double InitialQ1 = 0;
    const double InitialQ2 = Math.PI / 2;
    const double InitialP1 = 0.1;
    const double InitialP2 = 0;

    const double M = 0.1; // 質量
    const double G = 10; // 重力定数

    // 数値計算用
    const double dt = 0.005;

    void InitDynamics()
    {
      this.dynmics = new SurfaceDynamics(
				(s, t) => Math.Sin(t) * Math.Cos(s),
				(s, t) => Math.Sin(t) * Math.Sin(s),
				(s, t) => -Math.Cos(t),
				(s, t) => -G * M * Math.Cos(t),
				InitialQ1, InitialQ2, InitialP1, InitialP2, M);
		}
#elif false
		// テスト用 その3 球面（直交座標）
		
		// 拘束面の表示関係
    const double U0 = -0.707;
		const double U1 = 0.707;
		const double V0 = -0.707;
		const double V1 = 0.707;
    const int N = 30;

    // Dynamics の初期値
    const double InitialQ1 = 0;
    const double InitialQ2 = 0.5;
		const double InitialP1 = 0.1;
    const double InitialP2 = 0.1;

    const double M = 0.1; // 質量
    const double G = 10; // 重力定数

    // 数値計算用
    const double dt = 0.005;

    void InitDynamics()
    {
      this.dynmics = new SurfaceDynamics(
				(q1, q2) => q1,
				(q1, q2) => q2,
				(q1, q2) => -Math.Sqrt(1 - (q1 * q1 + q2 * q2)),
				(q1, q2) => -G * M * Math.Sqrt(1 - (q1 * q1 + q2 * q2)),
				InitialQ1, InitialQ2, InitialP1, InitialP2, M);
    }
#endif

		Point3D Surface(double u, double v)
    {
			double x = this.dynmics.X(u, v);
			double y = this.dynmics.Y(u, v);
			double z = this.dynmics.Z(u, v);

      return new Point3D(x, y, z);
    }

    void Callback(object sender, EventArgs ea)
    {
			if (this.dynmics == null || !this.dynmics.IsRead)
				return;

			double x, y, z;

			lock (this)
			{
				this.dynmics.Update(dt);
				x = this.dynmics.CurrentX;
				y = this.dynmics.CurrentY;
				z = this.dynmics.CurrentZ;
			}

      this.plotArea.SetLoation(new Point3D(x, y, z));
    }

		void OnErrer(String msg)
		{
			MessageBox.Show(msg);
		}
  }
}
