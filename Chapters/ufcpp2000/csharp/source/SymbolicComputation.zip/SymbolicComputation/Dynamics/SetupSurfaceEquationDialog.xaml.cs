﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using Ex2 = System.Linq.Expressions.Expression<System.Func<double, double, double>>;

namespace Dynamics
{
	public delegate void ShowErrorMessage(string msg);
	public delegate void SetExpressions(Ex2 x, Ex2 y, Ex2 z, Ex2 phi, double m);

	/// <summary>
	/// SetupSurfaceEquationDialog.xaml の相互作用ロジック
	/// </summary>
	public partial class SetupSurfaceEquationDialog : Window
	{
		public SetupSurfaceEquationDialog()
		{
			InitializeComponent();
		}

		public event ShowErrorMessage OnError;
		public event SetExpressions OnOk;

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			SetExpressions onOk = this.OnOk;
			if (onOk == null)
				return;

			double m;

			if (!double.TryParse(this.textM.Text, out m))
			{
				this.ShowError("error: Mass m does not a number");
				return;
			}

			try
			{
				var ex = (Ex2)MyMath.CodeDom.GetExpressionFrom("(s, t) =>" + this.textX.Text);
				var ey = (Ex2)MyMath.CodeDom.GetExpressionFrom("(s, t) =>" + this.textY.Text);
				var ez = (Ex2)MyMath.CodeDom.GetExpressionFrom("(s, t) =>" + this.textZ.Text);
				var ep = (Ex2)MyMath.CodeDom.GetExpressionFrom("(s, t) =>" + this.textPhi.Text);

				onOk(ex, ey, ez, ep, m);
			}
			catch (MyMath.ExpressionCodeDomException ece)
			{
				this.ShowError(ece.Message);
			}
			catch (InvalidCastException)
			{
				this.ShowError("type of lambda is invalid, the expression must have just two parameters\n");
			}
		}

		void ShowError(string msg)
		{
			ShowErrorMessage onError = this.OnError;
			if (onError != null)
				onError(msg);
		}
	}
}
