﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dynamics
{
	public delegate void SetCurrentValue(double q1, double q2, double p1, double p2);

	/// <summary>
	/// SetupInitialValueDialog.xaml の相互作用ロジック
	/// </summary>
	public partial class SetupCurrentValueDialog : Window
	{
		public SetupCurrentValueDialog()
		{
			InitializeComponent();
		}

		public event ShowErrorMessage OnError;
		public event SetCurrentValue OnOk;

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			SetCurrentValue onOk = this.OnOk;
			if (onOk == null)
				return;

			double q1, q2, p1, p2;

			if (!double.TryParse(this.textQ1.Text, out q1))
			{
				this.ShowError("error: Value q1 does not a number");
				return;
			}
			if (!double.TryParse(this.textQ2.Text, out q2))
			{
				this.ShowError("error: Value q2 does not a number");
				return;
			}
			if (!double.TryParse(this.textP1.Text, out p1))
			{
				this.ShowError("error: Value p1 does not a number");
				return;
			}
			if (!double.TryParse(this.textP2.Text, out p2))
			{
				this.ShowError("error: Value p2 does not a number");
				return;
			}

			onOk(q1, q2, p1, p2);
		}

		void ShowError(string msg)
		{
			ShowErrorMessage onError = this.OnError;
			if (onError != null)
				onError(msg);
		}
	}
}
