﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Projection
{
	/// <summary>
	/// Window1.xaml の相互作用ロジック
	/// </summary>
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();

			this.normal =
				//new Vector3D(1, 0, 0);
				//new Vector3D(1, 1, 1);
				//new Vector3D(1, 3, 7);
				new Vector3D(1, Math.Sqrt(2), Math.Sqrt(3));
				//new Vector3D(1, (1 - Math.Sqrt(5)) / 2, 2);
				//new Vector3D(1, (1 - Math.Sqrt(5)) / 2, (1 + Math.Sqrt(5)) / 2);
				//new Vector3D(1, Math.Cos(Math.PI / 5), Math.Sin(Math.PI / 5));
			normal.Normalize();

			this.camera.Position = (Point3D)Vector3D.Multiply(15, this.normal);
			this.camera.LookDirection = -this.normal;

			this.geometry = (MeshGeometry3D)this.FindResource("PointMesh");
			this.material = (DiffuseMaterial)this.FindResource("SolidMaterial");

			this.threadShowPointsOnPlane = new System.Threading.Thread(
				this.ShowPointsOnPlane
				);
			this.threadShowPointsOnPlane.Start();

			this.threadShowPoints3D = new System.Threading.Thread(
				this.ShowPoints3D
				);
			this.threadShowPoints3D.Start();
		}

		Geometry3D geometry;
		Material material;
		ScaleTransform3D pointScale = new ScaleTransform3D(0.01, 0.01, 0.01);

		System.Threading.Thread threadShowPointsOnPlane;
		System.Threading.Thread threadShowPoints3D;

		Vector3D normal;

		const int M = 30; // 探索範囲
		const double WIDTH = 10; // 表示幅
		const double THICKNESS = 10; // 厚み
		const int N = (int)WIDTH;

		void ShowPoints3D()
		{
			var points3d =
				from x in Enumerable.Range(-N, 2 * N)
				from y in Enumerable.Range(-N, 2 * N)
				from z in Enumerable.Range(-N, 2 * N)
				select new Vector3D(x, y, z);

			foreach (var p in points3d)
			{
				double x = p.X / (N + 0.1);
				double y = p.Y / (N + 0.1);
				double z = p.Z / (N + 0.1);

				Action action = () =>
				{
					GeometryModel3D model = new GeometryModel3D(this.geometry, this.material);
					Transform3DGroup t3d = new Transform3DGroup();
					t3d.Children.Add(this.pointScale);
					t3d.Children.Add(new TranslateTransform3D(x, y, z));
					model.Transform = t3d;
					this.latice3d.Children.Add(model);
				};

				Dispatcher.BeginInvoke(
					System.Windows.Threading.DispatcherPriority.Normal,
					action
				);
				System.Threading.Thread.Sleep(10);
			}
		}

		void ShowPointsOnPlane()
		{
			var points3d = (
				from x in Enumerable.Range(-M, 2 * M)
				from y in Enumerable.Range(-M, 2 * M)
				from z in Enumerable.Range(-M, 2 * M)
				select new Vector3D(x, y, z) into p
				let distance = Math.Abs(Vector3D.DotProduct(p, normal))
				where distance < THICKNESS
				select p
				).ToArray();

			Vector3D i1, i2;
			GetOrthogonalBase(normal, out i1, out i2);

			var projectedPoints =
				from p in points3d
				let x = Vector3D.DotProduct(p, i1)
				let y = Vector3D.DotProduct(p, i2)
				where -WIDTH <= x && x <= WIDTH
					&& -WIDTH <= y && y <= WIDTH
				select new Point(x, y);

			foreach (var p in projectedPoints)
			{
				double x = (p.X + WIDTH) / (2 * WIDTH);
				double y = (p.Y + WIDTH) / (2 * WIDTH);

				Action action = () =>
				{
					Shape e = new Rectangle()
					{
						Fill = new SolidColorBrush(Colors.Red),
						Width = 1,
						Height = 1
					};
					e.SetValue(Canvas.LeftProperty, x * this.plane.Width);
					e.SetValue(Canvas.TopProperty, y * this.plane.Height);
					this.plane.Children.Add(e);
				};

				Dispatcher.BeginInvoke(
					System.Windows.Threading.DispatcherPriority.Normal,
					action
				);
				System.Threading.Thread.Sleep(10);
			}
		}

		/// <summary>
		/// 入力 i1 を直交基底の1つとして、
		/// 残り2つの直交基底 i2, i3 を求める。
		/// </summary>
		/// <param name="i1">基底1</param>
		/// <param name="i2">基底2</param>
		/// <param name="i3">基底3</param>
		static void GetOrthogonalBase(
			Vector3D normal, out Vector3D i1, out Vector3D i2)
		{
			Vector3D temp;

			if (normal.X > normal.Y)
				if (normal.X > normal.Z) temp = new Vector3D(0, 1, 0);
				else temp = new Vector3D(1, 0, 0);
			else
				if (normal.Y > normal.Z) temp = new Vector3D(0, 0, 1);
				else temp = new Vector3D(1, 0, 0);

			i1 = Vector3D.CrossProduct(normal, temp); i1.Normalize();
			i2 = Vector3D.CrossProduct(normal, i1); i2.Normalize();
		}

		private void Window_Closed(object sender, EventArgs e)
		{
			this.threadShowPointsOnPlane.Abort();
			this.threadShowPoints3D.Abort();
		}
	}
}
