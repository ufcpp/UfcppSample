﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace MicroThread
{
	/// <summary>
	/// MainWindow 内の Canvas に描画される UpdatableObject。
	/// </summary>
	public abstract class Element : MicroThreadObject
	{
		UIElement shape;
		public UIElement Shape
		{
			get { return this.shape; }
			set
			{
				this.shape = value;
				this.mainWindow.AddUIElement(value);
				this.Dispose += () => { mainWindow.RemoveUIElement(this.Shape); };
			}
		}
		public double X
		{
			get
			{
				return 
					this.Shape == null ? 0.0 :
					(double)this.Shape.GetValue(Canvas.LeftProperty);
			}
			set
			{
				if (this.Shape != null)
					this.Shape.SetValue(Canvas.LeftProperty, value);
			}
		}
		public double Y
		{
			get
			{
				return 
					this.Shape == null ? 0.0 :
					(double)this.Shape.GetValue(Canvas.TopProperty);
			}
			set
			{
				if (this.Shape != null)
					this.Shape.SetValue(Canvas.TopProperty, value);
			}
		}

		public Element(MainWindow mainWindow)
		{
			this.mainWindow = mainWindow;
		}

		protected MainWindow mainWindow;

		protected bool IsFrameOut()
		{
			return this.X < 0 || this.X > this.mainWindow.CanvasWidth
					|| this.Y < 0 || this.Y > this.mainWindow.CanvasHeight;
		}
	}
}
