﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MicroThread
{
	/// <summary>
	/// アクションゲームの類の要領で、
	/// 1フレーム毎に Update メソッドが呼ばれる形で
	/// 更新処理を行うオブジェクト。
	/// </summary>
	public abstract class UpdatableObject
	{
		internal UpdatableObjectManager Manager { set; get; }

		/// <summary>
		/// オブジェクトが寿命を迎えたときに呼ばれるイベントハンドラ。
		/// </summary>
		public event Action Dispose;

		/// <summary>
		/// 毎フレーム実行される処理の本体。
		/// </summary>
		/// <returns>オブジェクトがまだ生きてるなら true</returns>
		protected abstract bool Task();

		/// <summary>
		/// 1フレーム毎にオブジェクトマネージャーから呼ばれるメソッド。
		/// </summary>
		/// <remarks>
		/// Task 実行 ＋ オブジェクトが寿命を迎えた場合の削除処理。
		/// </remarks>
		public void Update()
		{
			if (!this.Task())
			{
				if (this.Dispose != null)
					this.Dispose();

				if (this.Manager != null)
					this.Manager.Remove(this);
			}
		}
	}
}
