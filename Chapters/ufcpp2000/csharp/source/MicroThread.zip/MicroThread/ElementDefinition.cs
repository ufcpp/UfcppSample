﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Media;

namespace MicroThread
{
	/// <summary>
	/// 一定速度で直進するだけの弾。
	/// </summary>
	class StraitBullet : Element
	{
		double vx, vy;

		public StraitBullet(MainWindow mw, double vx, double vy)
			: base(mw)
		{
			this.vx = vx;
			this.vy = vy;
		}

		protected override IEnumerator GetUpdater()
		{
			for (; ; )
			{
				this.X += this.vx;
				this.Y += this.vy;

				if (this.IsFrameOut()) yield break;

				yield return null;
			}
		}
	}

	/// <summary>
	/// 一定速度で直進しながら弾を撒き散らす敵。
	/// </summary>
	class StraitEnemy : Element
	{
		double vx, vy;

		public StraitEnemy(MainWindow mw, double x, double y, double vx, double vy)
			: base(mw)
		{
			this.vx = vx;
			this.vy = vy;

			this.Shape = new Ellipse()
			{
				Fill = new SolidColorBrush(Colors.Blue),
				Width = 10,
				Height = 10
			};
			this.X = x;
			this.Y = y;
		}

		Random rnd = new Random();

		protected override IEnumerator GetUpdater()
		{
			for (int i = 0; ; ++i)
			{
				this.X += this.vx;
				this.Y += this.vy;

				if (this.IsFrameOut()) yield break;

				if (i % 8 == 0)
				{
					this.CreateBullet();
				}

				yield return null;
			}
		}

		void CreateBullet()
		{
			double x = 3 * rnd.NextDouble() - 1.5;
			double y = 3 * rnd.NextDouble() - 1.5;
			StraitBullet bullet = new StraitBullet(this.mainWindow, x, y)
			{
				Shape = new Ellipse()
				{
					Fill = new SolidColorBrush(Colors.Gray),
					Width = 5,
					Height = 5
				},
				X = this.X,
				Y = this.Y
			};
			this.Manager.Add(bullet);
		}
	}

	/// <summary>
	/// ちょっと変な動きをする弾。
	/// </summary>
	class ComplexBullet : Element
	{
		double vx, vy;

		public ComplexBullet(MainWindow mw, double vx, double vy)
			: base(mw)
		{
			this.vx = vx;
			this.vy = vy;
		}

		protected override IEnumerator GetUpdater()
		{
			for (; ; )
			{
				for (int i = 0; i < 128; ++i)
				{
					this.X += this.vx;
					this.Y += this.vy;

					if (this.IsFrameOut()) yield break;

					yield return null;
				}
				for (int i = 0; i < 128; ++i)
				{
					double ax = this.vy * 0.2;
					double ay = -this.vx * 0.2;
					this.vx += ax;
					this.vy += ay;
					this.X += this.vx;
					this.Y += this.vy;

					if (this.IsFrameOut()) yield break;

					yield return null;
				}
				for (int i = 0; i < 128; ++i)
				{
					double ax = -this.vy * 0.2;
					double ay = this.vx * 0.2;
					this.vx += ax;
					this.vy += ay;
					this.X += this.vx;
					this.Y += this.vy;

					if (this.IsFrameOut()) yield break;

					yield return null;
				}
			}
		}
	}

	/// <summary>
	/// ちょっと変な動きをする敵。
	/// </summary>
	class ComplexEnemy : Element
	{
		double vx, vy;

		public ComplexEnemy(MainWindow mw, double x, double y, double vx, double vy)
			: base(mw)
		{
			this.vx = vx;
			this.vy = vy;

			this.Shape = new Ellipse()
			{
				Fill = new SolidColorBrush(Colors.Red),
				Width = 10,
				Height = 10,
				Opacity = 0
			};
			this.X = x;
			this.Y = y;
		}

		Random rnd = new Random();

		protected override IEnumerator GetUpdater()
		{
			const int FRAME_FADEIN = 128;
			// フェードイン
			for (int i = 1; i <= FRAME_FADEIN; ++i)
			{
				Ellipse el = (Ellipse)this.Shape;
				el.Opacity = i / (double)FRAME_FADEIN;

				yield return null;
			}

			// 移動開始
			for (int i = 0; ; ++i)
			{
				this.X += this.vx;
				this.Y += this.vy;

				if (this.IsFrameOut()) yield break;

				if (i % 8 == 0)
				{
					this.CreateBullet();
				}

				yield return null;
			}
		}

		void CreateBullet()
		{
			double x = 3 * rnd.NextDouble() - 1.5;
			double y = 3 * rnd.NextDouble() - 1.5;
			ComplexBullet bullet = new ComplexBullet(this.mainWindow, x, y)
			{
				Shape = new Ellipse()
				{
					Fill = new SolidColorBrush(Colors.Violet),
					Width = 5,
					Height = 5
				},
				X = this.X,
				Y = this.Y
			};
			this.Manager.Add(bullet);
		}
	}
}
