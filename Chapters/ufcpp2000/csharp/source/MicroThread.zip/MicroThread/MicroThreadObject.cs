﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MicroThread
{
	/// <summary>
	/// C# のイテレータ構文を使って、
	/// マイクロスレッド（microthraed, coroutine, fiber）的な
	/// 更新処理を行うことを想定した UpdatableObject。
	/// </summary>
	public abstract class MicroThreadObject : UpdatableObject
	{
		public MicroThreadObject()
		{
			this.updater = this.GetUpdater();
		}

		/// <summary>
		/// マイクロスレッド本体を取得。
		/// イテレータを使って実装することを想定。
		/// </summary>
		/// <returns>マイクロスレッド本体</returns>
		protected abstract IEnumerator GetUpdater();

		IEnumerator updater;

		#region UpdatableObject メンバ

		protected override bool Task()
		{
			return this.updater.MoveNext();
		}

		#endregion
	}
}
