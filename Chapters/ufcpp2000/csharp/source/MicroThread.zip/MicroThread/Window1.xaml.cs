﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MicroThread
{
	/// <summary>
	/// Window1.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();

			this.Init();

			CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
		}

		public double CanvasWidth
		{
			get { return this.mainCanvas.Width; }
		}

		public double CanvasHeight
		{
			get { return this.mainCanvas.Height; }
		}

		UpdatableObjectManager manager = new UpdatableObjectManager();

		#region エレメント操作関係

		public void AddUIElement(UIElement el)
		{
			this.mainCanvas.Children.Add(el);
		}

		public void RemoveUIElement(UIElement el)
		{
			this.mainCanvas.Children.Remove(el);
		}

		#endregion
		#region エレメントの初期化と更新

		void Init()
		{
			Element el1 = new StraitEnemy(this, 30, 30, 2, 1.3);
			Element el2 = new ComplexEnemy(this, 150, 80, -1.3, 1.5);
			Element el3 = new StraitEnemy(this, 120, 270, 1.8, -2);

			this.manager.Add(el1);
			this.manager.Add(el2);
			this.manager.Add(el3);
		}

		void CompositionTarget_Rendering(object sender, EventArgs e)
		{
			this.manager.Update();
		}

		#endregion
	}
}
