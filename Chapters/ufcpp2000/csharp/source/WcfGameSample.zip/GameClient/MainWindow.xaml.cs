﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Threading;
using System.ServiceModel;

using WcfGameSample;

namespace GameClient
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        IGameCharacter game;

        Thread mainLoop;

        const int WEIGHT = 10;

        public MainWindow()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainWindow_Loaded);
            this.Closed += new EventHandler(MainWindow_Closed);
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            GameCharacterCallback callback = new GameCharacterCallback();
            callback.LocationChanged += this.SetLocation;

            /* 実装その1: 単なるdll参照
            GameCharacter game = new GameCharacter();
            game.Callback = callback;
            this.game = game;
            //*/

            //* 実装その2: WCF サービスを参照
            InstanceContext context = new InstanceContext(callback);

            DuplexChannelFactory<IGameCharacter> fact
              = new DuplexChannelFactory<IGameCharacter>(context,
                  //"GameCharacterIis"); // IIS にホストされた WCF サービス
                  "GameCharacterSelf"); // セルフホストのサービス
                  //"GameCharacterDebug"); // デバッグホストされた WCR サービス

            this.game = fact.CreateChannel();

            var client = this.game as IClientChannel;
            client.Faulted += new EventHandler(client_Faulted);
            //*/

            try
            {
                client.Open();
                game.Move(new System.Windows.Vector(0, 0));
            }
            catch (EndpointNotFoundException)
            {
                MessageBox.Show("EndPointが見つかりませんでした。");
                this.Invoke(() =>
                {
                    this.Close();
                });
            }

            this.mainLoop = new Thread(this.MainLoop);
            this.mainLoop.Start();
        }

        void client_Faulted(object sender, EventArgs e)
        {
            MessageBox.Show("サーバ側で問題があったっぽい");
            this.Invoke(() =>
            {
                this.Close();
            });
        }

        void MainWindow_Closed(object sender, EventArgs e)
        {
            var client = this.game as IClientChannel;
            if (client != null && client.State == CommunicationState.Opened)
                client.Close();
        }

        void MainLoop()
        {
            System.Windows.Vector movement = new System.Windows.Vector();

            for (; ; )
            {
                movement.X = 0;
                movement.Y = 0;

                if (Dispatcher.HasShutdownStarted) return;
                if (Dispatcher.HasShutdownFinished) return;

                Invoke(() =>
                {
                    if (Keyboard.IsKeyDown(Key.Up))
                        movement.Y = -1;
                    if (Keyboard.IsKeyDown(Key.Down))
                        movement.Y = 1;
                    if (Keyboard.IsKeyDown(Key.Left))
                        movement.X = -1;
                    if (Keyboard.IsKeyDown(Key.Right))
                        movement.X = 1;

                    if (movement.X != 0 || movement.Y != 0)
                    {
                        try
                        {
                            game.Move(movement);
                        }
                        catch (Exception exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                });

                Thread.Sleep(WEIGHT);
            }
        }

        void SetLocation(System.Windows.Point p)
        {
            if (Dispatcher.HasShutdownStarted) return;
            if (Dispatcher.HasShutdownFinished) return;

            double w = this.gameCanves.ActualWidth - this.playerObject.Width;
            double h = this.gameCanves.ActualHeight - this.playerObject.Height;

            if (p.X < 0) p.X = 0;
            if (p.Y < 0) p.Y = 0;
            if (p.X > w) p.X = w;
            if (p.Y > h) p.Y = h;

            Invoke(() =>
            {
                this.Title = string.Format("{0:##0}, {1:##0}", p.X, p.Y);
                this.playerObject.SetValue(Canvas.LeftProperty, p.X);
                this.playerObject.SetValue(Canvas.TopProperty, p.Y);
            });
        }

        void Invoke(Action action)
        {
            Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Normal, action);
        }
    }
}
