﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;

using WcfGameSample;

namespace GameServerSelf
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Uri address = new Uri("net.pipe://localhost/GameService/GameCharacter");
                NetNamedPipeBinding binding = new NetNamedPipeBinding();
                Type contract = typeof(IGameCharacter);

                var game = new GameCharacter();
                game.Log += Console.Write;

                // ベース・アドレスを提供し、ServiceHostをインスタンス化
                using (ServiceHost serviceHost = new ServiceHost(game))
                {
                    serviceHost.AddServiceEndpoint(contract, binding, address);
                    serviceHost.Faulted += new EventHandler(serviceHost_Faulted);
                    serviceHost.Open();

                    Console.WriteLine("リスナーのURIを表示：");
                    foreach (ChannelDispatcher channeldispatcher
                        in serviceHost.ChannelDispatchers)
                    {
                        Console.WriteLine("\t{0}",
                          channeldispatcher.Listener.Uri.ToString());
                    }

                    Console.WriteLine("サービス実行中");
                    Console.WriteLine("ENTERキーでサービス終了");
                    Console.ReadLine();

                    // ServiceHostをCloseし、サービスをシャットダウン
                    serviceHost.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void serviceHost_Faulted(object sender, EventArgs e)
        {
            Console.Write("error {0}\n", sender);
        }

        //static int numClients = 0;

        //static void channeldispatcher_Opened(object sender, EventArgs e)
        //{
        //    ++numClients;

        //    Console.Write("channel opend, #clients = {0}\n", numClients);
        //}

        //static void channeldispatcher_Closed(object sender, EventArgs e)
        //{
        //    --numClients;

        //    Console.Write("channel closed, #clients = {0}\n", numClients);
        //}
    }
}
