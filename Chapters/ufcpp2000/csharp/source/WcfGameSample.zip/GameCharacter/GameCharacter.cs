﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;

namespace WcfGameSample
{
    /// <summary>
    /// ログ吐き用のデリゲート。
    /// </summary>
    /// <param name="format">書式文字列。</param>
    /// <param name="args">引数。</param>
    public delegate void Format(string format, params object[] args);

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
	public class GameCharacter : IGameCharacter
	{
		public GameCharacter()
		{
			this.currentLocation = new System.Windows.Point();
            this.callbacks = new List<IGameCharacterCallback>();
		}

		/// <summary>
		/// キャラの位置を更新＆それをコールバック通知。
		/// </summary>
		/// <param name="movement">移動量。</param>
		public void Move(System.Windows.Vector movement)
		{
            int index = -1;

            this.currentLocation += movement;

            if (OperationContext.Current != null)
            {
                var callback = OperationContext.Current.GetCallbackChannel<IGameCharacterCallback>();
                if (callback != null)
                {
                    if (!this.callbacks.Contains(callback))
                        this.callbacks.Add(callback);

                    index = this.callbacks.IndexOf(callback);
                }
            }

            foreach (var callback in this.callbacks)
            {
                try
                {
                    callback.SetLocation(this.currentLocation);
                }
                catch (Exception)
                {
                    this.toBeRemoved.Add(callback);
                }
            }

            foreach (var x in this.toBeRemoved)
            {
                this.callbacks.Remove(x);
            }
            this.toBeRemoved.Clear();

            Format log = this.Log;
            if (log != null)
                log("movement ({0: ##0}, {1: ##0}) from client {2} (total clients = {3})\n",
                    movement.X, movement.Y, index, this.callbacks.Count());
        }

		/// <summary>
		/// キャラが移動した際のコールバック。
		/// </summary>
		public IGameCharacterCallback Callback
		{
			get { return this.callbacks.First(); }
			set { this.callbacks.Add(value); }
		}

        public event Format Log;

		private System.Windows.Point currentLocation;
        private List<IGameCharacterCallback> callbacks;
        private List<IGameCharacterCallback> toBeRemoved = new List<IGameCharacterCallback>();
    }

	public class GameCharacterCallback : IGameCharacterCallback
	{
		public void SetLocation(System.Windows.Point location)
		{
			var f = this.LocationChanged;
			if (f != null)
				f(location);
		}

		public event Action<System.Windows.Point> LocationChanged;
	}
}
