﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfGameSample
{
    [ServiceContract(
        CallbackContract = typeof(IGameCharacterCallback),
        SessionMode = SessionMode.Required)]
    public interface IGameCharacter
    {
        /// <summary>
        /// キャラを動かします。
        /// </summary>
        /// <param name="movement">移動量。</param>
        [OperationContract(IsOneWay = true)]
        void Move(System.Windows.Vector movement);
    }

    [ServiceContract]
    public interface IGameCharacterCallback
    {
        /// <summary>
        /// キャラの現在位置を設定します。
        /// </summary>
        /// <param name="location">キャラの現在位置。</param>
        [OperationContract(IsOneWay = true)]
        void SetLocation(System.Windows.Point location);
    }
}
