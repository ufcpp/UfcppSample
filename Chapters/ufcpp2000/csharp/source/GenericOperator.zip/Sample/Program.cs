﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using GenericOperator;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            ShowFourOperations(
                4 .I(5),
                2 .I(4));

            ShowFourOperations(
                4.0 .I(5.0),
                2.0 .I(4.0));

            ShowFourOperations(
                1.Over(2) .I(1.Over(3)),
                2.Over(3) .I(3.Over(4)));
        }

        static void ShowFourOperations<T>(Complex<T> x, Complex<T> y)
            where T: IComparable<T>
        {
            Console.WriteLine(typeof(T).Name);
            Console.WriteLine("({0}) + ({1}) = {2}", x, y, x + y);
            Console.WriteLine("({0}) - ({1}) = {2}", x, y, x - y);
            Console.WriteLine("({0}) * ({1}) = {2}", x, y, x * y);
            Console.WriteLine("({0}) / ({1}) = {2}", x, y, x / y);
        }
    }
}
