﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

using Differential;

namespace ConsoleCodeDom
{
	class Program
	{
		static void Main(string[] args)
		{
			string line;
			while ((line = Console.ReadLine()) != null)
			{
				if (line.Length == 0)
				{
					Console.Write("please type a lambda espression\nor type Ctrl+C to exit\n");
					continue;
				}
				Execute(line);
			}
		}

		static void Execute(string lambda)
		{
			try
			{
				var f = (Expression<Func<double, double>>)CodeDom.GetExpressionFrom(lambda);
				Console.Write("function  : {0}\n", f);
				Console.Write("derivative: {0}\n", f.Derive());
			}
			catch (ExpressionCodeDomException ece)
			{
				Console.Write("compilation failed:\n{0}\n", ece.Message);
			}
			catch (ExpressionExtensionsException eee)
			{
				Console.Write("invalid lambda:\n{0}\n", eee.Message);
			}
			catch (InvalidCastException)
			{
				Console.Write("type of lambda is invalid, the expression must have only one parameter\n");
			}
		}
	}
}
