﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicroThread
{
	public class UpdatableObjectManager
	{
		List<UpdatableObject> objects = new List<UpdatableObject>();
		Queue<UpdatableObject> added = new Queue<UpdatableObject>();
		Queue<UpdatableObject> removed = new Queue<UpdatableObject>();

		/// <summary>
		/// 更新処理を行う。
		/// </summary>
		/// <remarks>
		/// UpdatableObject の Upate メソッド内からも
		/// 自身の削除や新しいオブジェクトの追加することを想定していて、
		/// 追加や削除は一旦「追加/削除待ちキュー」に格納してから、
		/// （次のフレーム）Update 処理の前に実際の追加/削除を行う。
		/// </remarks>
		public void Update()
		{
			while (this.added.Count != 0)
			{
				UpdatableObject obj = this.added.Dequeue();
				this.objects.Add(obj);
			}

			while (this.removed.Count != 0)
			{
				UpdatableObject obj = this.removed.Dequeue();
				this.objects.Remove(obj);
			}

			foreach (UpdatableObject obj in this.objects)
			{
				obj.Update();
			}
		}

		/// <summary>
		/// オブジェクトの追加。
		/// </summary>
		/// <param name="obj">追加するオブジェクト</param>
		/// <remarks>
		/// オブジェクトは一旦「追加待ちキュー」に格納されて、
		/// 実際に追加されるのは Update 処理の直後。
		/// </remarks>
		public void Add(UpdatableObject obj)
		{
			obj.Manager = this;
			this.added.Enqueue(obj);
		}

		/// <summary>
		/// オブジェクトの削除。
		/// </summary>
		/// <param name="obj">削除するオブジェクト</param>
		/// <remarks>
		/// オブジェクトは一旦「削除待ちキュー」に格納されて、
		/// 実際に削除されるのは Update 処理の直後。
		/// </remarks>
		public void Remove(UpdatableObject obj)
		{
			this.removed.Enqueue(obj);
		}
	}
}
