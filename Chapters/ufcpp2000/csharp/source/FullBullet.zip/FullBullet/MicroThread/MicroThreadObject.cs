﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace MicroThread
{
	/// <summary>
	/// C# のイテレータ構文を使って、
	/// マイクロスレッド（microthraed, coroutine, fiber）的な
	/// 更新処理を行うことを想定した UpdatableObject。
	/// </summary>
	public abstract class MicroThreadObject : UpdatableObject
	{
		public MicroThreadObject()
		{
			this.updater = this.GetUpdater();
		}

		/// <summary>
		/// マイクロスレッド本体を取得。
		/// イテレータを使って実装することを想定。
		/// </summary>
		/// <returns>マイクロスレッド本体</returns>
		protected abstract IEnumerator GetUpdater();

		IEnumerator updater;

		#region UpdatableObject メンバ

		protected override bool Task()
		{
			return this.updater.MoveNext();
		}

		#endregion
		#region static メソッド

		/// <summary>
		/// 複数のマイクロスレッドを並行実行。
		/// 全マイクロスレッドが終了するまで実行。
		/// </summary>
		/// <param name="threads">並行実行したいマイクロスレッド</param>
		/// <returns>並行化したもの</returns>
		public static IEnumerator DoUntilAllEnd(params IEnumerator[] threads)
		{
			for (; ; )
			{
				bool flag = false;
				for (int i = 0; i < threads.Length; ++i)
				{
					if (threads[i] != null)
					{
						flag = true;

						if (threads[i].MoveNext())
							yield return null;
						else
							threads[i] = null;
					}
				}

				// 全要素 null（＝ 全部実行終了）
				if (!flag)
				{
					yield break;
				}
			}
		}

		/// <summary>
		/// 複数のマイクロスレッドを並行実行。
		/// 1つでもマイクロスレッドが終了した時点で全体を終了。
		/// </summary>
		/// <param name="threads">並行実行したいマイクロスレッド</param>
		/// <returns>並行化したもの</returns>
		public static IEnumerator DoUntilOneEnd(params IEnumerator[] threads)
		{
			for (; ; )
			{
				for (int i = 0; i < threads.Length; ++i )
				{
					if (threads[i].MoveNext())
						yield return null;
					else
						yield break;
				}
			}
		}

		/// <summary>
		/// 並列化はせずに、直列実行。
		/// </summary>
		/// <param name="thread">直列実行したいマイクロスレッド</param>
		/// <returns>連結したもの</returns>
		public static IEnumerator Serial(params IEnumerator[] threads)
		{
			foreach (IEnumerator thread in threads)
			{
				while (thread.MoveNext())
					yield return null;
			}
		}

		/// <summary>
		/// 何もしないフレームを作るマイクロスレッド。
		/// </summary>
		/// <param name="frame">何もしないフレーム数</param>
		/// <returns>作ったマイクロスレッド</returns>
		public static IEnumerator Blank(int frame)
		{
			for (int i = 0; i < frame; ++i)
				yield return null;
		}

		#endregion
	}
}
