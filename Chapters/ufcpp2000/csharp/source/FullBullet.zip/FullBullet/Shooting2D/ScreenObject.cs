using System;
using System.Collections.Generic;
using System.Text;

using MicroThread;

namespace Shooting2D
{
	/// <summary>
	/// Screen ���̃I�u�W�F�N�g�B
	/// </summary>
	public abstract class ScreenObject : MicroThreadObject
	{
		public ScreenObject(Screen screen)
		{
			this.screen = screen;
		}

		protected Screen screen;
	}
}
