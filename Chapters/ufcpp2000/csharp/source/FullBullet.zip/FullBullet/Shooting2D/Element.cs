﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

using MicroThread;

namespace Shooting2D
{
	/// <summary>
	/// Screen 内の Canvas に描画される UpdatableObject。
	/// </summary>
	public abstract class Element : ScreenObject
	{
		public Element(Screen screen) : base(screen) { }

		UIElement shape;
		public UIElement Shape
		{
			get { return this.shape; }
			set
			{
				this.shape = value;
				this.screen.AddUIElement(value);
				this.Dispose += delegate() { screen.RemoveUIElement(this.Shape); };
			}
		}

		public Point Position
		{
			set
			{
				this.X = value.X;
				this.Y = value.Y;
			}
			get
			{
				return new Point(this.X, this.Y);
			}
		}

		public double X
		{
			get
			{
				return 
					this.Shape == null ? 0.0 :
					(double)this.Shape.GetValue(Canvas.LeftProperty);
			}
			set
			{
				if (this.Shape != null)
					this.Shape.SetValue(Canvas.LeftProperty, value);
			}
		}
		public double Y
		{
			get
			{
				return 
					this.Shape == null ? 0.0 :
					(double)this.Shape.GetValue(Canvas.TopProperty);
			}
			set
			{
				if (this.Shape != null)
					this.Shape.SetValue(Canvas.TopProperty, value);
			}
		}

		protected bool IsFrameOut()
		{
			return this.X < 0 || this.X > this.screen.Width
					|| this.Y < 0 || this.Y > this.screen.Height;
		}
	}
}
