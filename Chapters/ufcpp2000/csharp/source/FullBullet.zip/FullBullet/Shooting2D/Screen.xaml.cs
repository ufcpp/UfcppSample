using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using MicroThread;

namespace Shooting2D
{
	/// <summary>
	/// Interaction logic for UserControl1.xaml
	/// </summary>

	public partial class Screen : System.Windows.Controls.UserControl
	{
		public Screen()
		{
			InitializeComponent();

			CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
		}

		public void SetMainThread(ScreenObject mainThread)
		{
			this.manager.Add(mainThread);
		}

		UpdatableObjectManager manager = new UpdatableObjectManager();

		#region �G�������g����֌W

		public void AddUIElement(UIElement el)
		{
			this.mainCanvas.Children.Add(el);
		}

		public void RemoveUIElement(UIElement el)
		{
			this.mainCanvas.Children.Remove(el);
		}

		#endregion
		#region �G�������g�̏������ƍX�V

		void CompositionTarget_Rendering(object sender, EventArgs e)
		{
			this.manager.Update();
		}

		#endregion
		#region �v���p�e�B

		public Brush Background
		{
			set { this.mainCanvas.Background = value; }
			get { return this.mainCanvas.Background; }
		}

		#endregion
	}
}