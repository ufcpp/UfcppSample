using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Shooting2D;

namespace FullBullet
{
	class MainThread : ScreenObject
	{
		public MainThread(Screen screen) : base(screen) { }

		protected override IEnumerator GetUpdater()
		{
			return Serial(
				this.Phase1(),
				Blank(64),
				this.Phase2(),
				Blank(32),
				this.Phase3()
			);
		}

		IEnumerator Phase3()
		{
			const int M = 96;
			const double MARGIN = 60;

			Random rnd = new Random();

			for (int n = 0; n < 6; ++n)
			{
				double x = (this.screen.Width - 2 * MARGIN) * rnd.NextDouble() + MARGIN;
				double y = (this.screen.Height - 2 * MARGIN) * rnd.NextDouble() + MARGIN;
				this.Manager.Add(new Enemy3(this.screen, x, y));

				for (int i = 0; i < M; ++i) yield return null;
			}
		}

		IEnumerator Phase2()
		{
			const int M = 128;

			this.Manager.Add(new Enemy2(this.screen, 200));
			for (int i = 0; i < M; ++i) yield return null;

			this.Manager.Add(new Enemy2(this.screen, 100));
			for (int i = 0; i < M; ++i) yield return null;

			this.Manager.Add(new Enemy2(this.screen, 300));
			for (int i = 0; i < M; ++i) yield return null;

			this.Manager.Add(new Enemy2(this.screen, 250));
			for (int i = 0; i < M; ++i) yield return null;

			this.Manager.Add(new Enemy2(this.screen, 150));
			for (int i = 0; i < M; ++i) yield return null;
		}

		IEnumerator Phase1()
		{
			// Enemy1 �������ς��o�Ă���B

			const int M = 16; // �O���[�v���̃��j�b�g�̏o�Ă���Ԋu
			const int N = 64; // �O���[�v�ƃO���[�v�̊Ԋu

			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, true));
			for (int i = 0; i < N; ++i) yield return null;

			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < M; ++i) yield return null;
			this.Manager.Add(new Enemy1(this.screen, false));
			for (int i = 0; i < N; ++i) yield return null;
		}
	}

	/// <summary>
	/// �t�F�[�h�C�� �� 360�x�e�� �� �t�F�[�h�A�E�g�B
	/// </summary>
	class Enemy3 : Element
	{
		const double W = 20;
		const double H = 15;
		const int APPEAR_FRAME = 32;
		const int NUM_BULLET = 80;
		const int WAIT_BULLET = 3;
		const double BULLET_SPEED = 1.5;

		public Enemy3(Screen screen, double x, double y)
			: base(screen)
		{
			Ellipse s = new Ellipse();
			s.Fill = new SolidColorBrush(Colors.Gold);
			s.Width = W;
			s.Height = H;
			s.Opacity = 0;
			this.Shape = s;

			this.X = x;
			this.Y = y;
		}

		protected override IEnumerator GetUpdater()
		{
			// �t�F�[�h�C��
			for (int i = 1; i <= APPEAR_FRAME; ++i)
			{
				yield return null;
				this.Shape.Opacity = i / (double)APPEAR_FRAME;
			}

			Random rnd = new Random();
			double angle = 2 * Math.PI * rnd.NextDouble();

			// �e������
			for (int i = 0; i < NUM_BULLET; ++i)
			{
				double vx = -BULLET_SPEED * Math.Sin(angle);
				double vy = BULLET_SPEED * Math.Cos(angle);
				this.Manager.Add(new WedgeBullet(this.screen, Colors.MediumPurple, this.X + W / 2, this.Y + H / 2, vx, vy));
				this.Manager.Add(new WedgeBullet(this.screen, Colors.MediumPurple, this.X + W / 2, this.Y + H / 2, -vx, -vy));
				angle += 2 * Math.PI / NUM_BULLET;

				for (int j = 0; j < WAIT_BULLET; ++j) yield return null;
			}

			// �t�F�[�h�A�E�g
			for (int i = APPEAR_FRAME; i >= 0; --i)
			{
				this.Shape.Opacity = i / (double)APPEAR_FRAME;
				yield return null;
			}
		}
	}

	/// <summary>
	/// �E�[����o�Ă��āA�e�������āA�����Ă��G�B
	/// </summary>
	class Enemy2 : Element
	{
		const double SIZE = 16;
		public Enemy2(Screen screen, double initY)
			: base(screen)
		{
			const double W = SIZE;
			const double H = SIZE;
			Rectangle s = new Rectangle();
			s.Fill = new SolidColorBrush(Colors.Red);
			s.Width = W;
			s.Height = H;
			this.Shape = s;

			this.X = this.screen.Width;
			this.Y = initY;
		}

		const double BULLET_SPEED = 2;

		protected override IEnumerator GetUpdater()
		{
			const int APPEAR_FRAME = 12;
			const double APPEAR_FACTOR = 0.1;
			const int NUM_BULLET = 32;
			const int WAIT_BULLET = 4;

			// �o��
			for (int i = APPEAR_FRAME - 1; i >= 0; --i)
			{
				double vx = i * i * APPEAR_FACTOR;
				this.X -= vx;
				yield return null;
			}

			// �e������
			for (int i = 0; i < NUM_BULLET; ++i)
			{
				double t = Math.PI * i / NUM_BULLET;
				double vx = -BULLET_SPEED * Math.Sin(t);
				double vy = BULLET_SPEED * Math.Cos(t);
				this.Manager.Add(new WedgeBullet(this.screen, Colors.Green, this.X + SIZE / 2, this.Y + SIZE / 2, vx, vy));
				this.Manager.Add(new WedgeBullet(this.screen, Colors.Green, this.X + SIZE / 2, this.Y + SIZE / 2, vx, -vy));

				for (int j = 0; j < WAIT_BULLET; ++j) yield return null;
			}

			// ����
			for (int i = 0; i < APPEAR_FRAME; ++i)
			{
				double vx = i * i * APPEAR_FACTOR;
				this.X += vx;
				yield return null;
			}
		}
	}

	/// <summary>
	/// �O���f�B�E�X�̊e�ʂ̍ŏ��ɏo�Ă��邠��݂����ȓ���������G�B
	/// </summary>
	class Enemy1 : Element
	{
		bool top; // �ォ��o�Ă��邩������o�Ă��邩

		const double INIT_Y = 30;
		const double LAST_Y = 120;
		const double VX = 3;
		const double VY = 3;

		public Enemy1(Screen screen, bool top)
			: base(screen)
		{
			Ellipse shape = new Ellipse();
			shape.Fill = new SolidColorBrush(Colors.Blue);
			shape.Width = 12;
			shape.Height = 12;
			this.Shape = shape;

			this.X = screen.Width;
			this.Y = top ?
			INIT_Y :
			screen.Height - INIT_Y;

			this.top = top;
		}

		protected override IEnumerator GetUpdater()
		{
			//return this.Move();
			return DoUntilOneEnd(this.Move(), this.Shoot());
		}

		IEnumerator Move()
		{
			while (this.X >= 0)
			{
				this.X -= VX;
				yield return null;
			}

			while (this.X < screen.Width
				&& (top ? this.Y < this.screen.Height - LAST_Y : this.Y > LAST_Y))
			{
				this.X += VX;
				if (top)
					this.Y += VY;
				else
					this.Y -= VY;
				yield return null;
			}

			while (this.X >= 0)
			{
				this.X -= VX;
				yield return null;
			}
		}

		Random rnd = new Random();
		const double BULLET_SPEED = 1;

		IEnumerator Shoot()
		{
			for (int i = 0; ; ++i)
			{
				if (i % 32 == 0)
				{
					double t = 2 * Math.PI * this.rnd.NextDouble();
					double vx = BULLET_SPEED * Math.Cos(t);
					double vy = BULLET_SPEED * Math.Sin(t);
					this.Manager.Add(new SimpleBullet(this.screen, this.X, this.Y, vx, vy));
				}
				yield return null;
			}
		}
	}

	/// <summary>
	/// ���i���邾���̒e�B
	/// </summary>
	class SimpleBullet : Element
	{
		Vector velocity;

		public SimpleBullet(Screen screen, double x, double y, double vx, double vy)
			: this(screen, Colors.Gray, new Point(x, y), new Vector(vx, vy))
		{ }

		public SimpleBullet(Screen screen, Color c, double x, double y, double vx, double vy)
			: this(screen, c, new Point(x, y), new Vector(vx, vy))
		{}

		public SimpleBullet(Screen screen, Color c, Point position, Vector velocity)
			: base(screen)
		{
			Ellipse shape = new Ellipse();
			shape.Fill = new SolidColorBrush(Colors.Gray);
			shape.Width = 5;
			shape.Height = 5;
			this.Shape = shape;

			this.Position = position;
			this.velocity = velocity;
		}

		protected override IEnumerator GetUpdater()
		{
			for (; ; )
			{
				this.Position += this.velocity;

				if (this.IsFrameOut()) yield break;

				yield return null;
			}
		}
	}

	/// <summary>
	/// ���i���邾���̞��`�̒e�i�O���� SimpleBullet �ƈꏏ�j�B
	/// �i���`�Ƃ����A����͑ȉ~�B�j
	/// </summary>
	class WedgeBullet : Element
	{
		Vector velocity;

		public WedgeBullet(Screen screen, Color c, double x, double y, double vx, double vy)
			: this(screen, c, new Point(x, y), new Vector(vx, vy))
		{ }

		public WedgeBullet(Screen screen, Color c, Point position, Vector velocity)
			: base(screen)
		{
			double angle = Math.Atan2(-velocity.X, velocity.Y) / Math.PI * 180;

			Ellipse shape = new Ellipse();
			shape.Fill = new SolidColorBrush(c);
			shape.Width = 4;
			shape.Height = 8;
			shape.RenderTransform = new RotateTransform(angle, 2, 4);
			this.Shape = shape;

			this.Position = position;
			this.velocity = velocity;
		}

		protected override IEnumerator GetUpdater()
		{
			for (; ; )
			{
				this.Position += this.velocity;

				if (this.IsFrameOut()) yield break;

				yield return null;
			}
		}
	}
}
