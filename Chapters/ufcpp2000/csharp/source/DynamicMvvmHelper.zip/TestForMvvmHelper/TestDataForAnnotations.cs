﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace TestForMvvmHelper
{
    [MetadataType(typeof(RecordForValidation))]
    public class RecordForMetadataValidation
    {
        public int Num0to10 { get; set; }
        public string StrShorterThan10 { get; set; }
        public string Str5to10 { get; set; }
        public string StrRequired { get; set; }
    }

    public class RecordForValidation
    {
        [Range(0, 10)]
        public int Num0to10 { get; set; }

        [StringLength(10)]
        public string StrShorterThan10 { get; set; }

        [StringLength(10, MinimumLength = 5)]
        public string Str5to10 { get; set; }

        [Required]
        public string StrRequired { get; set; }
    }
}
