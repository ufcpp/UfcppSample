﻿using DynamicMvvmHelper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Dynamic;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Input;

namespace TestForMvvmHelper
{
    
    
    /// <summary>
    ///ObservableProxyTest のテスト クラスです。すべての
    ///ObservableProxyTest 単体テストをここに含めます
    ///</summary>
    [TestClass()]
    public class ObservableProxyTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///現在のテストの実行についての情報および機能を
        ///提供するテスト コンテキストを取得または設定します。
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region 追加のテスト属性
        // 
        //テストを作成するときに、次の追加属性を使用することができます:
        //
        //クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //各テストを実行する前にコードを実行するには、TestInitialize を使用
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //各テストを実行した後にコードを実行するには、TestCleanup を使用
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod]
        public void TestForValidation()
        {
            TestForValidation(DynamicMvvmHelper.Proxy.New(new RecordForValidation()));
            TestForValidation(DynamicMvvmHelper.Proxy.New(new RecordForMetadataValidation()));
        }

        private void TestForValidation(dynamic proxy)
        {
            Validate(
                proxy,
                A(value => { proxy.Num0to10 = value; }),
                successCases: new object[] { 1, 5, 0, 10, 3 },
                failCases: new object[] { -1, -5, 11, 20, 100 },
                formatErrors: new object[] { "test", "10f", "ac" }
                );

            Validate(
                proxy,
                A(value => { proxy.StrShorterThan10 = value; }),
                successCases: new object[] { "123456", "abcdefg", "0987654321", "" },
                failCases: new object[] { "wsedfrtghyujiwsedfrtghyuji", "0987654321a" }
                );

            Validate(
                proxy,
                A(value => { proxy.Str5to10 = value; }),
                successCases: new object[] { "12345", "abcdefg", "0987654321" },
                failCases: new object[] { "", "asdf", "wsedfrtghyujiwsedfrtghyuji", "0987654321a" }
                );

            Validate(
                proxy,
                A(value => { proxy.StrRequired = value; }),
                successCases: new object[] { "12345", "abcdefg", "0987654321" },
                failCases: new object[] { "" }
                );
        }


        private void Validate(
            dynamic proxy,
            Action<object> action,
            object[] successCases = null,
            object[] failCases = null,
            object[] formatErrors = null)
        {
            if(successCases != null)
                foreach (var item in successCases)
                    ValidateToSuccess(proxy, A(() => { action(item); }));

            if (failCases != null)
                foreach (var item in failCases)
                    ValidateToFail(proxy, A(() => { action(item); }), typeof(System.ComponentModel.DataAnnotations.ValidationException));

            if (formatErrors != null)
                foreach (var item in formatErrors)
                    ValidateToFail(proxy, A(() => { action(item); }), typeof(FormatException));
        }

        static Action A(Action a) { return a; }
        static Action<object> A(Action<object> a) { return a; }

        /// <summary>
        /// 検証成功例。
        /// </summary>
        /// <param name="proxy">検証対象。</param>
        /// <param name="action">検証成功するはずの操作。</param>
        private static void ValidateToSuccess(dynamic proxy, Action action)
        {
            try
            {
                action();
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
            {
                Assert.Fail();
            }
        }

        /// <summary>
        /// わざと検証失敗。
        /// もしくは、文字列からのデータ変換に失敗。
        /// FormatException か ValidationException が出れば正常。
        /// 例外が出ないとか、他の例が出ると失敗。
        /// </summary>
        /// <param name="proxy">検証対象。</param>
        /// <param name="action">検証失敗するはずの操作。</param>
        private static void ValidateToFail(dynamic proxy, Action action, Type exceptionType)
        {
            try
            {
                action();

                Assert.Fail();
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
            {
                var l = proxy.LastError as DynamicErrorInfo;

                Assert.AreEqual(l.Error.GetType(), exceptionType);
            }
        }

        /// <summary>
        ///TrySetMember のテスト
        ///</summary>
        [TestMethod()]
        public void TrySetMemberTest()
        {
            var instance = DataUtil.GetTestData();
            dynamic proxy = new ObservableProxy<Group>(instance);

            CheckSetEntity(instance.Id, proxy.Id);

            Shop shop = instance.Shops.First();
            dynamic pshop = Enumerable.First(proxy.Shops);

            CheckSetEntity(shop.Id, pshop.Id);

            CheckShopAddCommands(shop, pshop);
            CheckSetShop(shop, pshop);
            CheckShopRemoveCommands(shop, pshop);
        }

        private static void CheckShopRemoveCommands(Shop shop, dynamic pshop)
        {
            int count = shop.Logs.Count;

            // Add
            var remove = pshop.Logs.RemoveCommand as ICommand;

            remove.Execute(5);
            remove.Execute(3);
            remove.Execute(1);

            SequenceEqual(shop.Logs, pshop.Logs);

            Assert.AreEqual(shop.Logs.Count, count - 3);
        }

        private static void CheckShopAddCommands(Shop shop, dynamic pshop)
        {
            const int N = 5;

            int count = shop.Logs.Count;

            // Add
            var add = pshop.Logs.AddCommand as ICommand;

            for (int i = 0; i < N; i++)
            {
                add.Execute(null);
            }

            Assert.AreEqual(shop.Logs.Count, count + N);

            foreach (var item in shop.Logs.Skip(count))
            {
                Assert.AreEqual(item, string.Empty);
            }

            SequenceEqual(shop.Logs, pshop.Logs);
        }

        private static void SequenceEqual<T>(IEnumerable<T> instance, dynamic proxy)
        {
            var en = proxy as IEnumerable<object>;
            Assert.AreEqual(instance.Count(), en.Count());

            foreach (var t in Zip(instance, (object)proxy))
            {
                var e = (T)t.Item2.Value;

                Assert.AreEqual(t.Item1, e);
            }
        }

        private static void CheckSetShop(Shop shop, dynamic pshop)
        {
            const string logMessage = "log test";
            var countBefore = shop.Logs.Count;

            int i;

            i = 0;
            foreach (var item in pshop.Logs)
            {
                item.Value = logMessage + i;
                ++i;
            }

            i = 0;
            foreach (var item in shop.Logs)
            {
                Assert.AreEqual(item, logMessage + i);
                ++i;
            }

            Assert.AreEqual(shop.Logs.Count, countBefore);
        }

        private static void CheckSetEntity(Entity instance, dynamic proxy)
        {
            proxy.Code = 10;
            Assert.AreEqual(instance.Code, 10);

            proxy.Code = "20";
            Assert.AreEqual(instance.Code, 20);

            proxy.Name = "test";
            Assert.AreEqual(instance.Name, "test");
        }

        /// <summary>
        ///TryGetMember のテスト
        ///</summary>
        [TestMethod()]
        public void TryGetMemberTest()
        {
            var instance = DataUtil.GetTestData();
            dynamic proxy = new ObservableProxy<Group>(instance);

            CheckType(proxy.Id, typeof(ObservableProxy<Entity>));

            CheckGetId(instance.Id, proxy.Id);

            CheckGetShops(instance, proxy);
        }

        private void CheckGetProducts(Shop instance, dynamic proxy)
        {
            CheckType(proxy.Products, typeof(ObservableListProxy<Product>));

            foreach (var t in Zip(instance.Products, (object)proxy.Products))
            {
                CheckType(t.Item2, typeof(ObservableProxy<Product>));

                CheckGetId(t.Item1.Id, t.Item2.Id);
            }
        }

        private void CheckGetLogs(Shop instance, dynamic proxy)
        {
            CheckType(proxy.Logs, typeof(ObservableListProxy<string>));

            foreach (var t in Zip(instance.Logs, (object)proxy.Logs))
            {
                CheckType(t.Item2, typeof(ObservableElementProxy<string>));

                Assert.AreEqual(t.Item1, (string)t.Item2.Value);
            }
        }

        private void CheckGetShops(Group instance, dynamic proxy)
        {
            CheckType(proxy.Shops, typeof(ObservableListProxy<Shop>));

            foreach (var t in Zip(instance.Shops, (object)proxy.Shops))
            {
                CheckType(t.Item2, typeof(ObservableProxy<Shop>));

                CheckGetId(t.Item1.Id, t.Item2.Id);

                CheckGetProducts(t.Item1, t.Item2);
                CheckGetLogs(t.Item1, t.Item2);
            }
        }

        private void CheckGetId(Entity iid, dynamic pid)
        {
            CheckType(pid.Code, typeof(int));
            Assert.IsTrue(iid.Code == pid.Code);

            CheckType(pid.Name, typeof(string));
            Assert.IsTrue(iid.Name == pid.Name);
        }

        static void CheckType(dynamic obj, Type t)
        {
            Assert.AreEqual(((object)obj).GetType(), t);
        }

        static IEnumerable<Tuple<T, dynamic>> Zip<T>(IEnumerable<T> x, object y)
        {
            dynamic dy = y;

            using (x as IDisposable)
            using (dy as IDisposable)
            {
                var e1 = x.GetEnumerator();
                var e2 = dy.GetEnumerator();

                while (e1.MoveNext() && e2.MoveNext())
                {
                    yield return Tuple.Create<T, dynamic>(e1.Current, e2.Current);
                }
            }
        }
    }
}
