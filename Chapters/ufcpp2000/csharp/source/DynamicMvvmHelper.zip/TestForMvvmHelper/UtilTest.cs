﻿using DynamicMvvmHelper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestForMvvmHelper
{
    
    
    /// <summary>
    ///UtilTest のテスト クラスです。すべての
    ///UtilTest 単体テストをここに含めます
    ///</summary>
    [TestClass()]
    public class UtilTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///現在のテストの実行についての情報および機能を
        ///提供するテスト コンテキストを取得または設定します。
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region 追加のテスト属性
        // 
        //テストを作成するときに、次の追加属性を使用することができます:
        //
        //クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //各テストを実行する前にコードを実行するには、TestInitialize を使用
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //各テストを実行した後にコードを実行するには、TestCleanup を使用
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///GetProperty のテスト
        ///</summary>
        [TestMethod()]
        public void GetPropertyTest()
        {
            const int code = 1;
            const string name = "test";
            var instance = new Entity(code, name);

            Assert.AreEqual(Util.GetProperty(instance, "Code"), code);
            Assert.AreEqual(Util.GetProperty(instance, "Name"), name);

            var p = new DateTime(1, 2, 3, 4, 5, 6);

            Assert.AreEqual(Util.GetProperty(p, "Year"), 1);
            Assert.AreEqual(Util.GetProperty(p, "Month"), 2);
            Assert.AreEqual(Util.GetProperty(p, "Day"), 3);
            Assert.AreEqual(Util.GetProperty(p, "Hour"), 4);
            Assert.AreEqual(Util.GetProperty(p, "Minute"), 5);
            Assert.AreEqual(Util.GetProperty(p, "Second"), 6);
        }

        /// <summary>
        ///SetProperty のテスト
        ///</summary>
        [TestMethod()]
        public void SetPropertyTest()
        {
            const int code = 1;
            const string name = "test";
            var instance = new Entity(0, null);

            Util.SetProperty(instance, "Code", code);
            Util.SetProperty(instance, "Name", name);

            Assert.AreEqual(instance.Code, code);
            Assert.AreEqual(instance.Name, name);
        }

        /// <summary>
        ///Parse のテスト
        ///</summary>
        [TestMethod()]
        public void ParseTest()
        {
            Assert.AreEqual(Util.Parse(typeof(int), "1"), 1);
            Assert.AreEqual(Util.Parse(typeof(int), "2"), 2);
            Assert.AreEqual(Util.Parse(typeof(int), "3"), 3);
            Assert.AreEqual(Util.Parse(typeof(int), "4"), 4);
            Assert.AreEqual(Util.Parse(typeof(double), "1.15"), 1.15);
        }
    }
}
