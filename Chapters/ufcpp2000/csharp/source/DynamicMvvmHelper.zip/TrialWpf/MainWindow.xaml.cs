﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TrialWpf
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// 同じモデルをプロキシ通して参照する、2つのウィンドウを作るだけ。
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainWindow_Loaded);
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var data = TestForMvvmHelper.DataUtil.GetTestData();
            var proxy = DynamicMvvmHelper.Proxy.New(data);

            NewWindow(proxy);
            NewWindow(proxy);
        }

        private void NewWindow(object proxy)
        {
            var w = new Window1();
            w.Owner = this;
            w.DataContext = proxy;
            w.Show();
        }
    }
}
