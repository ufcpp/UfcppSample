﻿
namespace DynamicMvvmHelper
{
    public interface IProxy<T>
    {
        T Instance { get; }
    }
}
