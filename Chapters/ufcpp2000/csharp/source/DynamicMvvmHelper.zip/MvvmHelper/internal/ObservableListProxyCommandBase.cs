﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace DynamicMvvmHelper
{
    abstract class ObservableListProxyCommandBase<T> : ICommand
    {
        protected ObservableListProxy<T> List { get; private set; }

        public ObservableListProxyCommandBase(ObservableListProxy<T> list)
        {
            this.List = list;
        }

        #region ICommand Members

        public virtual bool CanExecute(object parameter)
        {
            return !List.IsReadOnly;
        }

        public event EventHandler CanExecuteChanged;

        protected void RaiseCanExecuteChanged()
        {
            var d = this.CanExecuteChanged;
            if (d != null)
                d(this, new EventArgs());
        }

        public abstract void Execute(object parameter);

        #endregion
    }
}
