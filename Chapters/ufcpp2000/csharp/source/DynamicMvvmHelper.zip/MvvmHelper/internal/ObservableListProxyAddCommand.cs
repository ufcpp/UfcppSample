﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace DynamicMvvmHelper
{
    class ObservableListProxyAddCommand<T> : ObservableListProxyCommandBase<T>
    {
        public ObservableListProxyAddCommand(ObservableListProxy<T> list)
            : base(list)
        {
        }

        static readonly Func<T> New = GetNewFunction();

        public override void Execute(object parameter)
        {
            List.Add(New());
        }

        public static Func<T> GetNewFunction()
        {
            if (typeof(T) == typeof(string))
                return () => (T)(object)string.Empty;

            if (typeof(T).IsValueType)
            {
                return () => default(T);
            }

            return () => Activator.CreateInstance<T>();
        }
    }
}
