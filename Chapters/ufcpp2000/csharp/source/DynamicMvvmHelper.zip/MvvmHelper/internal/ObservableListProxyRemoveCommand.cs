﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynamicMvvmHelper
{
    class ObservableListProxyRemoveCommand<T> : ObservableListProxyCommandBase<T>
    {
        public ObservableListProxyRemoveCommand(ObservableListProxy<T> list)
            : base(list)
        {
        }

        //public override bool CanExecute(object parameter)
        //{
        //    if (parameter is int)
        //    {
        //        var i = (int)parameter;
        //        return i >= 0 && !List.IsReadOnly && i < List.Count;
        //    }

        //    return false;
        //}

        public override void Execute(object parameter)
        {
            List.RemoveAt((int)parameter);
        }
    }
}
