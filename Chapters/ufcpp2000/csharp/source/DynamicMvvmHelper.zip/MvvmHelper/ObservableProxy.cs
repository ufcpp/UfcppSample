﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Dynamic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace DynamicMvvmHelper
{
    /// <summary>
    /// M-V-VM パターンで使うための INotifyPropertyChanged 実装ラッパー。
    /// とりあえず TryGetMember と TrySetMember にだけ対応。
    /// 
    /// 簡単なものであれば、ViewModel 一切書かずに、
    /// View.DataContext = Proxy.New(model);
    /// ってやるだけで M-V-VM 的なプログラムが作れる。
    /// </summary>
    /// <remarks>
    /// DynamicObject 利用。
    /// リフレクションの塊。
    /// 
    /// T 型に結構いろいろ制約あり（動的にやってるんで実行時エラーになるので注意）。
    /// 
    /// ・要素の型にはデフォルトコンストラクターがないとダメ。
    /// ・コレクションはジェネリックな IList 実装クラス以外不可。
    /// 
    /// あと、例外回りにちょっと癖が。
    /// DynamicObject の仕様的な問題で、例外を直接上位に伝えられないので、
    /// Try××で例外が起きた場合、
    /// 一度 return false した上で、LastError に起きた例外を保持しておく。
    /// </remarks>
    /// <typeparam name="T">元インスタンスの型。</typeparam>
    public class ObservableProxy<T> : DynamicObject, IProxy<T>, INotifyPropertyChanged, IDataErrorInfo
    {
        static ObservableProxy()
        {
            RegisterMetadata();
        }

        /// <summary>
        /// 元インスタンス。
        /// </summary>
        public T Instance { get; private set; }

        /// <summary>
        /// 元インスタンスの ToString() 結果をそのまま返す。
        /// </summary>
        /// <returns>元インスタンスを文字列化したもの。</returns>
        public override string ToString()
        {
#if DEBUG
            return "dynamic " + this.Instance.ToString();
#else
            return this.Instance.ToString();
#endif
        }

        /// <summary>
        /// 元インスタンスを与えて初期化。
        /// </summary>
        /// <param name="instance">元インスタンス。</param>
        public ObservableProxy(T instance)
        {
            this.Instance = instance;
        }

        #region Get

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            var name = binder.Name;

            if (name == "LastError")
            {
                result = LastError;
                return true;
            }

            try
            {
                result = GetProxyObject(name);
                return true;
            }
            catch (Exception exc)
            {
                SetLastError(OperationType.GetMember, name, exc);

                result = null;
                return false;
            }
        }

        #region 作ったプロキシの保存

        /// <summary>
        /// プロキシのキャッシュ。
        /// </summary>
        readonly Dictionary<string, object> proxies = new Dictionary<string, object>();

        /// <summary>
        /// プロパティアクセス用のプロキシ取得。
        /// </summary>
        /// <param name="propertyName">プロパティ名。</param>
        /// <returns>プロキシ。</returns>
        object GetProxyObject(string propertyName)
        {
            // まずキャッシュを見る。
            if (proxies.ContainsKey(propertyName))
            {
                return proxies[propertyName];
            }

            var value = Util.GetProperty(this.Instance, propertyName);
            var ptype = GetPropertyType(propertyName);

            // 値型の場合と文字列の場合は仕組みがうまく動かないし、プロキシ介さない。
            if (Util.IsNoProxy(ptype))
            {
                return value;
            }

            // 値が null なもののプロキシを作るとまずいのでインスタンスを新規作成。
            if (value == null)
            {
                value = Activator.CreateInstance(ptype);
                Util.SetProperty(this.Instance, propertyName, value);
            }

            // プロキシ取得。
            var proxy = Util.MakeProxy(ptype, value);

            proxies[propertyName] = proxy;

            return proxy;
        }

        static Dictionary<string, Type> propertyTypeCache = new Dictionary<string, Type>();

        /// <summary>
        /// T のプロパティの型を取得する。
        /// </summary>
        /// <param name="propertyName">プロパティ名。</param>
        /// <returns>プロパティの型。</returns>
        static Type GetPropertyType(string propertyName)
        {
            Type ptype;

            if (propertyTypeCache.TryGetValue(propertyName, out ptype))
            {
                return ptype;
            }

            var t = typeof(T);
            var p = t.GetProperty(propertyName);
            ptype = p.PropertyType;
            propertyTypeCache[propertyName] = ptype;
            return ptype;
        }

        #endregion

        #endregion
        #region Set

        /// <summary>
        /// プロパティに値を set。
        /// </summary>
        /// <remarks>
        /// 検証属性がついていた場合、値の代入前に検証。
        /// 検証エラーがあった場合、値は更新せず例外発生させる。
        /// </remarks>
        public override bool  TrySetMember(SetMemberBinder binder, object value)
        {
            var name = binder.Name;

            try
            {
                if (value.GetType() == typeof(string))
                {
                    var c = GetConverterFunction(name);
                    value = c((string)value);
                }

                ValidateProperty(name, value);

                Util.SetProperty(this.Instance, name, value);
                RaisePropertyChanged(name);
                return true;
            }
            catch (Exception exc)
            {
                SetLastError(OperationType.SetMember, name, exc);

                return false;
            }
        }
        #region データ検証（DataAnnotations 前提）

        /// <summary>
        /// 検証用メタデータの登録。
        /// </summary>
        /// <remarks>
        /// 自分で TypeDescriptor.AddProviderTransparent してやらないと
        /// [MetadataType()] 属性が機能しないのはよろしくないなぁ・・・。
        /// </remarks>
        static void RegisterMetadata()
        {
            var t = typeof(T);

            var meta = t.GetCustomAttributes(typeof(MetadataTypeAttribute), false).FirstOrDefault();

            if (meta != null)
            {
                var metadataAttribute = meta as MetadataTypeAttribute;
                var metadataType = metadataAttribute.MetadataClassType;

                TypeDescriptor.AddProviderTransparent(
                    new AssociatedMetadataTypeTypeDescriptionProvider(
                        t, metadataType), t);
            }
        }

        /// <summary>
        /// プロパティ set 時の検証。
        /// </summary>
        /// <param name="propertyName">プロパティ名</param>
        /// <param name="value">値。</param>
        void ValidateProperty(string propertyName, object value)
        {
            var c = new ValidationContext(this.Instance, null, null)
            {
                MemberName = propertyName
            };
            Validator.ValidateProperty(value, c);
        }

        #endregion
        #region Parser

        static readonly Dictionary<string, Func<string, object>> parserCache = new Dictionary<string, Func<string, object>>();

        static Func<string, object> GetConverterFunction(string name)
        {
            if (parserCache.ContainsKey(name))
            {
                return parserCache[name];
            }

            var p = typeof(T).GetProperty(name);

            var parser = Util.GetParseFunction(p.PropertyType);

            parserCache[name] = parser;
            return parser;
        }

        #endregion

        #endregion
        #region エラーの記録

        //TrySetError 内で起きた例外を WPF が拾ってくれないので苦肉の策

        public DynamicErrorInfo LastError { get; private set; }

        protected void SetLastError(OperationType type, string memberName, Exception error)
        {
            LastError = new DynamicErrorInfo
            {
                Type = type,
                MemberName = memberName,
                Error = error,
            };
            RaisePropertyChanged("LastError");
        }

        #endregion
        #region INotifyPropertyChanged メンバー

        public event PropertyChangedEventHandler PropertyChanged;

        void RaisePropertyChanged(string propertyName)
        {
            var d = this.PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
        #region IDataErrorInfo メンバー

        string IDataErrorInfo.Error
        {
            get
            {
                var c = new ValidationContext(this.Instance, null, null);
                var results = new List<ValidationResult>();

                if (Validator.TryValidateObject(this, c, results))
                    return null;

                return ConcatErrors(results);
            }
        }

        string IDataErrorInfo.this[string columnName]
        {
            get
            {
                var value = Util.GetProperty(this.Instance, columnName);

                var c = new ValidationContext(this.Instance, null, null)
                {
                    MemberName = columnName,
                };

                var results = new List<ValidationResult>();

                if (Validator.TryValidateProperty(value, c, results))
                    return null;

                return ConcatErrors(results);
            }
        }

        private static string ConcatErrors(List<ValidationResult> results)
        {
            return results.Select(x => x.ErrorMessage).Aggregate("", (x, y) => x + "\n" + y);
        }

        #endregion
    }
}
