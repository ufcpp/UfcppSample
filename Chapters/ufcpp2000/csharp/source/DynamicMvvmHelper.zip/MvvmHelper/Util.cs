﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using Microsoft.CSharp.RuntimeBinder;

using Binder = Microsoft.CSharp.RuntimeBinder.Binder;

namespace DynamicMvvmHelper
{
    public class Util
    {
        #region 動的生成

        /// <summary>
        /// プロパティの値を取得する。
        /// </summary>
        /// <param name="instance">取得元。</param>
        /// <param name="propertyName">プロパティ名。</param>
        /// <returns>取得した値。</returns>
        public static object GetProperty(object instance, string propertyName)
        {
            var site = GetGetMemberSite(propertyName);

            return site.Target(site, instance);
        }

        /// <summary>
        /// プロパティに値を設定する。
        /// </summary>
        /// <param name="instance">設定先。</param>
        /// <param name="propertyName">プロパティ名。</param>
        /// <param name="value">設定する値。</param>
        public static void SetProperty(object instance, string propertyName, object value)
        {
            var site = GetSetMemberSite(propertyName);
            site.Target(site, instance, value);
        }

        #region get member 用 CallSite

        static Dictionary<string, CallSite<Func<CallSite, object, object>>> getPropertySites = new Dictionary<string, CallSite<Func<CallSite, object, object>>>();

        private static CallSite<Func<CallSite, object, object>> GetGetMemberSite(string propertyName)
        {
            CallSite<Func<CallSite, object, object>> site;

            if (getPropertySites.ContainsKey(propertyName))
            {
                site = getPropertySites[propertyName];
            }
            else
            {
                site = CallSite<Func<CallSite, object, object>>.Create(
                    Binder.GetMember(CSharpBinderFlags.None, propertyName, typeof(Util),
                    new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));

                getPropertySites[propertyName] = site;
            }
            return site;
        }

        #endregion
        #region set member 用 CallSite

        static Dictionary<string, CallSite<Action<CallSite, object, object>>> setMemberSites = new Dictionary<string, CallSite<Action<CallSite, object, object>>>();

        private static CallSite<Action<CallSite, object, object>> GetSetMemberSite(string propertyName)
        {
            CallSite<Action<CallSite, object, object>> site;

            if (setMemberSites.ContainsKey(propertyName))
            {
                site = setMemberSites[propertyName];
            }
            else
            {
                site = CallSite<Action<CallSite, object, object>>.Create(
                    Binder.SetMember(CSharpBinderFlags.None, propertyName, typeof(Util),
                    new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null), CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));

                setMemberSites[propertyName] = site;
            }
            return site;
        }

        #endregion
        #region 文字列の Parse

        /// <summary>
        /// 文字列から t 型に変換。
        /// int.Parse みたいに、T.Parse メソッドを持っている型限定。
        /// </summary>
        /// <param name="t">変換先の型情報。</param>
        /// <param name="str">変換したい文字列。</param>
        /// <returns>変換結果。</returns>
        public static object Parse(Type t, string str)
        {
            var f = GetParseFunction(t);
            return f(str);
        }

        static readonly Dictionary<Type, Func<string, object>> parseCache = new Dictionary<Type, Func<string, object>>();

        public static Func<string, object> GetParseFunction(Type t)
        {
            if (parseCache.ContainsKey(t))
            {
                return parseCache[t];
            }

            if (t == typeof(string))
            {
                Func<string, object> c = s => s;
                parseCache[t] = c;
                return c;
            }

            var m = t.GetMethod("Parse", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public, null, new[] { typeof(string) }, null);

            var x = Expression.Parameter(typeof(string), "x");
            var lambda =
                Expression.Lambda<Func<string, object>>(
                    Expression.Convert(
                        Expression.Call(m, x),
                        typeof(object)),
                    x);

            var f = lambda.Compile();
            parseCache[t] = f;
            return f;
        }

        #endregion

        #endregion
        #region プロキシ関連

        /// <summary>
        /// 値型とか文字列型はプロキシ介してもしょうがないのではじくための判定関数。
        /// </summary>
        /// <param name="o">値</param>
        /// <returns>値型もしくは文字列型なら true</returns>
        public static bool IsNoProxy(object o)
        {
            var t = o.GetType();
            return IsNoProxy(t);
        }

        public static bool IsNoProxy(Type t)
        {
            return t.IsValueType || t == typeof(string);
        }

        public static object MakeProxy<T>(T o)
        {
            return MakeProxy(typeof(T), o);
        }

        /// <summary>
        /// プロキシ作成。
        /// o の型が IList<> かどうかで分岐。
        /// </summary>
        /// <param name="o">元インスタンス。</param>
        /// <returns>プロキシ挟んだもの。</returns>
        public static object MakeProxy(Type t, object o)
        {
            var proxyType = GetProxyType(t);

            return Activator.CreateInstance(proxyType, o);
        }

        public static Type GetProxyType(Type t)
        {
            if (t.IsGenericType)
            {
                var u = t.GetGenericArguments()[0];

                var listU = typeof(IList<>).MakeGenericType(u);

                if (listU.IsAssignableFrom(t))
                {
                    var vml = typeof(ObservableListProxy<>);
                    var vmlu = vml.MakeGenericType(u);

                    return vmlu;
                }
            }

            var vmp = typeof(ObservableProxy<>);
            var vmpt = vmp.MakeGenericType(t);

            return vmpt;
        }

        #endregion
    }
}
