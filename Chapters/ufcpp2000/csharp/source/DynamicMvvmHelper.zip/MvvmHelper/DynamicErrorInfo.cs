﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynamicMvvmHelper
{
    /// <summary>
    /// DynamicObject 中で起きたエラー情報の記録用クラス。
    /// </summary>
    /// <remarks>
    /// TrySetMember などの中で例外を起こすと、
    /// WPF のデータバインディングの仕組みは例外を拾ってくれないようなので困る。
    /// 苦肉の策で、「最後に起きた例外」をとっておくことに・・・。
    /// </remarks>
    public class DynamicErrorInfo
    {
        public OperationType Type { get; set; }
        public string MemberName { get; set; }
        public Exception Error { get; set; }

        public override string ToString()
        {
#if DEBUG
            return string.Format(
                "{0} に対する {1} 操作中にエラーが発生しました： {2}",
                MemberName, Type, Error.Message);
#else
            return Error.Message;
#endif
        }
    }

    public enum OperationType
    {
        GetMember,
        SetMember,
    }
}
