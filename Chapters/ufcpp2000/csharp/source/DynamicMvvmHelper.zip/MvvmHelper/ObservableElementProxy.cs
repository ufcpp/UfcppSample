﻿using System.ComponentModel;

namespace DynamicMvvmHelper
{
    /// <summary>
    /// ItemsControl.ItemTemplate 内で
    /// 双方向データバインディングでリストの中身を書き換えるためのプロキシ。
    /// 
    /// <![CDATA[
    /// <DataTemplate><TextBox Text="{Binding}"/></DataTemplate>
    /// ]]>
    /// </summary>
    /// 
    /// とかだと双方向バインディングできないんで、
    /// 
    /// <![CDATA[
    /// <DataTemplate><TextBox Text="{Binding Value}"/></DataTemplate>
    /// ]]>
    /// 
    /// でバインディングするためのラッパー。
    /// </summary>
    /// <typeparam name="T">元となるリストの要素の型。</typeparam>
    public class ObservableElementProxy<T> : INotifyPropertyChanged
    {
        readonly ObservableListProxy<T> list;
        internal int index { get; set; }

        /// <summary>
        /// 元インスタンスの ToString() 結果をそのまま返す。
        /// </summary>
        /// <returns>元インスタンスを文字列化したもの。</returns>
        public override string ToString()
        {
#if DEBUG
            return "dynamic " + this.list[index].ToString();
#else
            return this.list[index].ToString();
#endif
        }

        /// <summary>
        /// リストと更新位置のインデックスを指定して初期化。
        /// </summary>
        /// <param name="list">更新対象のリスト。</param>
        /// <param name="index">更新したい位置。</param>
        public ObservableElementProxy(ObservableListProxy<T> list, int index)
        {
            this.list = list;
            this.index = index;

        //    list.CollectionChanged += list_CollectionChanged;
        //}

        //void list_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        //{
        //    if (e.Action == NotifyCollectionChangedAction.Remove
        //        && e.OldItems != null && e.OldItems.Contains(this))
        //    {
        //        list.CollectionChanged -= list_CollectionChanged;
        //    }

        //    // Dispose 的なこと要る？
        }

        /// <summary>
        /// 値のset/get。
        /// </summary>
        public T Value
        {
            get { return list.Instance[index];}
            set
            {
                list.Instance[index] = value;
                this.RaisePropertyChanged("Value");
            }
        }

        #region INotifyPropertyChanged メンバー

        public event PropertyChangedEventHandler PropertyChanged;

        void RaisePropertyChanged(string propertyName)
        {
            var d = this.PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
