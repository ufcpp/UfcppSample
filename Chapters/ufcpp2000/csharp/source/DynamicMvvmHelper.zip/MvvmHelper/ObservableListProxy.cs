﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Specialized;
using System.Windows.Input;
using System.ComponentModel;

namespace DynamicMvvmHelper
{
    /// <summary>
    /// M-V-VM パターンで使うための INotifyPropertyChanged ラッパー。
    /// リスト用。
    /// </summary>
    /// <typeparam name="T">要素の型。</typeparam>
    public class ObservableListProxy<T> : IEnumerable<object>, IProxy<IList<T>>, INotifyCollectionChanged, INotifyPropertyChanged
    {
        /// <summary>
        /// 元インスタンス。
        /// </summary>
        public IList<T> Instance { get; private set; }

        /// <summary>
        /// 元インスタンスを指定して初期化。
        /// </summary>
        /// <param name="instance">元インスタンス</param>
        public ObservableListProxy(IList<T> instance)
        {
            this.Instance = instance;

            var t = typeof(T);

            if (t.IsValueType || t == typeof(string))
            {
                this.proxyObjects = Enumerable.Range(0, instance.Count).Select(i => (object)new ObservableElementProxy<T>(this, i)).ToList();
            }
            else
            {
                this.proxyObjects = instance.Select(x => GetProxyObject(x)).ToList();
            }
        }
        #region コマンド

        ICommand add;

        /// <summary>
        /// MVVM 的に要素を追加するためのコマンド。
        /// </summary>
        public ICommand AddCommand
        {
            get
            {
                if (add == null)
                    add = new ObservableListProxyAddCommand<T>(this);
                return add;
            }
        }

        ICommand remove;

        /// <summary>
        /// MVVM 的に要素を削除するためのコマンド。
        /// </summary>
        public ICommand RemoveCommand
        {
            get
            {
                if (remove == null)
                    remove = new ObservableListProxyRemoveCommand<T>(this);
                return remove;
            }
        }

        #endregion
        #region プロキシ

        /// <summary>
        /// 要素のプロキシを作っておかないといけないので、それ用のリスト。
        /// </summary>
        private List<object> proxyObjects;

        /// <summary>
        /// 要素用にプロキシ生成。
        /// </summary>
        /// <param name="item">要素。</param>
        /// <returns>プロキシ。</returns>
        static object GetProxyObject(T item)
        {
            var t = typeof(T);

            // 値型の場合と文字列の場合は仕組みがうまく動かないし、プロキシ介さない。
            if (t.IsValueType || t == typeof(string))
            {
                throw new InvalidOperationException();
                //return item;
            }

            return Util.MakeProxy(item);
        }

        #endregion
        #region IList もどきメンバー

        public T this[int index]
        {
            get { return this.Instance[index]; }
        }

        /// <summary>
        /// 要素数。
        /// </summary>
        public int Count
        {
            get { return Instance.Count; }
        }

        /// <summary>
        /// 読み取り専用かどうか。
        /// </summary>
        public bool IsReadOnly
        {
            get { return Instance.IsReadOnly; }
        }

        /// <summary>
        /// 要素を末尾に追加する。
        /// </summary>
        /// <param name="item">追加したい要素。</param>
        public void Add(T item)
        {
            Instance.Add(item);

            object newElement;

            var t = typeof(T);
            if (t.IsValueType || t == typeof(string))
            {
                newElement = new ObservableElementProxy<T>(this, this.Instance.Count - 1);
            }
            else
            {
                newElement = GetProxyObject(item);
            }

            proxyObjects.Add(newElement);

            RaiseCollectionAdd(newElement, Instance.Count - 1);
        }

        /// <summary>
        /// index の位置の要素を削除。
        /// </summary>
        /// <param name="index">削除したい要素のインデックス。</param>
        public void RemoveAt(int index)
        {
            if (index < 0)
                return;

            Instance.RemoveAt(index);

            var element = proxyObjects[index];

            proxyObjects.RemoveAt(index);

            RearrangeElementProxy();

            RaiseCollectionRemove(element, index);
        }

        /// <summary>
        /// 仕組み上、リスト構造を変えた後は ObservableElementProxy の index の振り直しが必要。
        /// </summary>
        /// <remarks>
        /// t.IsValueType || t == typeof(string) での分岐がちょっと不恰好。
        /// 何とかならないものか。
        /// </remarks>
        private void RearrangeElementProxy()
        {
            var t = typeof(T);
            if (t.IsValueType || t == typeof(string))
            {
                int i = 0;
                foreach (var item in proxyObjects)
                {
                    var e = item as ObservableElementProxy<T>;
                    e.index = i;
                    ++i;
                }
            }
        }

        #endregion
        #region ItemsControl バインド用

        int selected = 0;

        /// <summary>
        /// 現在選択中のインデックス。
        /// ItemsControl にバインドする前提。
        /// </summary>
        public int SelectedIndex
        {
            get { return selected; }
            set
            {
                if (selected != value)
                {
                    selected = value;
                    this.RaisePropertyChanged("SelectedIndex");
                    this.RaisePropertyChanged("SelectedItem");
                }
            }
        }

        /// <summary>
        /// 現在選択中の項目。
        /// </summary>
        public object SelectedItem
        {
            get
            {
                if (SelectedIndex < 0 || SelectedIndex >= this.proxyObjects.Count)
                    return null;

                return this.proxyObjects[this.SelectedIndex];
            }
        }

        #endregion
        #region INotifyCollectionChanged メンバー

        public event NotifyCollectionChangedEventHandler CollectionChanged;

        void RaiseCollectionAdd(object element, int index)
        {
            RaiseCollectionChanged(
                new NotifyCollectionChangedEventArgs(
                    NotifyCollectionChangedAction.Add,
                    element, index));
        }

        void RaiseCollectionRemove(object element, int index)
        {
            RaiseCollectionChanged(
                new NotifyCollectionChangedEventArgs(
                    NotifyCollectionChangedAction.Remove,
                    element, index));
        }

        void RaiseCollectionChanged(NotifyCollectionChangedEventArgs args)
        {
            var d = this.CollectionChanged;
            if (d != null)
                d(this, args);
        }

        #endregion
        #region IEnumerable<object> メンバー

        public IEnumerator<object> GetEnumerator()
        {
            return this.proxyObjects.GetEnumerator();
        }

        #endregion
        #region IEnumerable メンバー

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
        #region INotifyPropertyChanged メンバー

        public event PropertyChangedEventHandler PropertyChanged;

        void RaisePropertyChanged(string propertyName)
        {
            var d = this.PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
