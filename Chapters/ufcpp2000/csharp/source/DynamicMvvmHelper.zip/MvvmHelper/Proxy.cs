﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynamicMvvmHelper
{
    public static class Proxy
    {
        /// <summary>
        /// 型推論用の生成関数。
        /// </summary>
        /// <typeparam name="T">元インスタンスの型。</typeparam>
        /// <param name="instance">元インスタンス。</param>
        /// <returns>プロキシ通したもの。</returns>
        public static ObservableProxy<T> New<T>(T instance)
        {
            return new ObservableProxy<T>(instance);
        }
    }
}
