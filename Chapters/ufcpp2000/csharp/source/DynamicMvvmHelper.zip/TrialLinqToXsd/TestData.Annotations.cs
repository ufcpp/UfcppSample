﻿using System.ComponentModel.DataAnnotations;

[MetadataType(typeof(EntityMetadata))]
public partial class Entity
{
    /// <summary>
    /// LINQ to XSD のコード生成はデータ検証属性をつけてくれないので、ここだけ自前で。
    /// </summary>
    public class EntityMetadata
    {
        [Range(0, 99)]
        public int Code;

        [StringLength(30)]
        public string Name;
    }
}
