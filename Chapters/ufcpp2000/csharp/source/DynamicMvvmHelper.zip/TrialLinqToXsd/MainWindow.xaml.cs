﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace TrialLinqToXsd
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// 
    /// TrialWpf プロジェクトの方と同じことを LINQ to XSD 使って実行。
    /// 保存機能付き。
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainWindow_Loaded);
        }

        Group data;

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            data = Group.Load("TestData.xml");

            var proxy = DynamicMvvmHelper.Proxy.New(data);

            NewWindow(proxy);
            NewWindow(proxy);
        }

        private void NewWindow(object proxy)
        {
            var w = new TrialWpf.Window1();
            w.Owner = this;
            w.DataContext = proxy;
            w.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog();
            dlg.Filter = "*.xml|XML ファイル(*.xml)";

            if (dlg.ShowDialog() ?? false)
            {
                var name = dlg.FileName;
                data.Save(name);
            }
        }
    }
}
