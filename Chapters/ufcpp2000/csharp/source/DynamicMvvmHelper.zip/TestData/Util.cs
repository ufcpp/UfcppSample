﻿
namespace TestForMvvmHelper
{
    public class DataUtil
    {
        public static Group GetTestData()
        {
            var instance = new Group
            {
                Id = new Entity(1, "グループ"),
                Shops =
                {
                    new Shop
                    {
                        Id = new Entity(1, "店舗1"),
                        Products =
                        {
                            new Product { Id = new Entity(1, "製品1") },
                            new Product { Id = new Entity(2, "製品2") },
                        },
                        Logs =
                        {
                            "ログ1",
                            "ログ2",
                        }
                    },
                    new Shop
                    {
                        Id = new Entity(2, "店舗2"),
                        Products =
                        {
                            new Product { Id = new Entity(3, "製品3") },
                            new Product { Id = new Entity(4, "製品4") },
                        },
                        Logs =
                        {
                            "ログ3",
                            "ログ4",
                        }
                    },
                },
            };
            return instance;
        }
    }
}
