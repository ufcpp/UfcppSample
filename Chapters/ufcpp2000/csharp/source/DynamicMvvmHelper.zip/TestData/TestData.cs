﻿using System.Collections.Generic;

namespace TestForMvvmHelper
{
    public class Entity
    {
        public Entity()
            : this(0, string.Empty)
        {
        }

        public Entity(int code, string name)
        {
            this.Code = code;
            this.Name = name;
        }

        public int Code { get; set; }
        public string Name { get; set; }
    }

    public class Group
    {
        private Entity id = new Entity();

        public Entity Id
        {
            get { return id; }
            set { id = value; }
        }

        private List<Shop> shop = new List<Shop>();

        public IList<Shop> Shops
        {
            get { return shop; }
        }
    }

    public class Shop
    {
        private Entity id = new Entity();

        public Entity Id
        {
            get { return id; }
            set { id = value; }
        }

        private List<Product> prod = new List<Product>();

        public IList<Product> Products
        {
            get { return prod; }
        }

        private List<string> logs = new List<string>();

        public IList<string> Logs
        {
            get { return logs; }
        }
    }

    public class Product
    {
        private Entity id = new Entity();

        public Entity Id
        {
            get { return id; }
            set { id = value; }
        }
    }
}
        