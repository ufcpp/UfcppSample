﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Net;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace AsyncWpfSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.DataContext = new MainViewModel();
        }
    }

    public class MainViewModel
    {
        private ObservableCollection<string> titles = new ObservableCollection<string>();

        public ObservableCollection<string> Titles
        {
            get { return titles; }
        }

        public MainViewModel()
        {
            GetTitlesAsync();
        }

        private async void GetTitlesAsync()
        {
            var client = new WebClient();

            var index = await client.DownloadStringTaskAsync("http://ufcpp.net/study/csharp/index.xml");

            var xdoc = XDocument.Parse(index);

            var docs =
                from section in xdoc.Root.Elements().Where(x => x.Name.LocalName == "section")
                from doc in section.Elements().Where(x => x.Name.LocalName == "document")
                select doc;

            foreach (var doc in docs)
            {
                var uri = string.Format(
                    "http://ufcpp.net/study/csharp/{0}.xml",
                    doc.Attribute("href").Value);

                var content = await client.DownloadStringTaskAsync(uri);
                var title = Regex.Match(content, "title=\"(.*?)\"").Groups[1].Value;

                this.Titles.Add(title);
            }
        }
    }
}
