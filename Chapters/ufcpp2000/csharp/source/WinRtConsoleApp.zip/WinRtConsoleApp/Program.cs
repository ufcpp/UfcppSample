﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace WinRtConsoleApp
{
	class Program
	{
		static void Main(string[] args)
		{
			MainAsync().Wait();
		}

		static async Task MainAsync()
		{
			var files = await Windows.Storage.KnownFolders.PicturesLibrary.GetFilesAsync(
				Windows.Storage.Search.CommonFileQuery.OrderBySearchRank, 0, 10);

			var pics = files.Where(f => IsImageFile(f.Name));

			foreach (var pic in pics)
			{
				try
				{
					var desc = await GetDescription(pic);

					Console.WriteLine("name: {0}, width: {1}, height: {2}",
						desc.Name, desc.Width, desc.Height);
				}
				catch
				{
					continue;
				}
			}
		}

		private static async Task<PictureDescription> GetDescription(Windows.Storage.StorageFile pictureFile)
		{
			using (var stream = await pictureFile.OpenReadAsync())
			{
				var name = pictureFile.DisplayName;

				var decoder = await Windows.Graphics.Imaging.BitmapDecoder.CreateAsync(stream);
				var width = decoder.OrientedPixelWidth;
				var height = decoder.OrientedPixelHeight;

				return new PictureDescription
				{
					Name = name,
					Width = width,
					Height = height,
				};
			}
		}

		static string[] ImageExtensions = new[] { ".bmp", ".jpg", ".jpeg", ".png" };

		static bool IsImageFile(string filename)
		{
			return ImageExtensions.Any(ext => filename.EndsWith(ext));
		}
	}

	class PictureDescription
	{
		public string Name { get; set; }
		public uint Width { get; set; }
		public uint Height { get; set; }
	}
}
