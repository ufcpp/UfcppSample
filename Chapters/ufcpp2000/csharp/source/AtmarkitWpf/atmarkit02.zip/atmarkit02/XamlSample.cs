﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Markup;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Windows.Data;

namespace atmarkit02
{
    public static class XamlSample
    {
        public static void SavePoint()
        {
            using (var stream = File.Open("MyPoint.xaml", FileMode.Create))
                XamlWriter.Save(new Sample.Point { X = 1, Y = 2 }, stream);
        }

        public static void SaveUri()
        {
            using (var stream = File.Open("Uri.xaml", FileMode.Create))
                XamlWriter.Save(new System.Uri("http://www.atmarkit.co.jp/"), stream);

            var converter = new UriTypeConverter();
            var uri = converter.ConvertFrom("http://www.atmarkit.co.jp/");

            Console.WriteLine(uri.GetType().Name);
            Console.WriteLine((Uri)uri);
        }

        public static void LoadSample1()
        {
            object x;

            using (var s = File.OpenRead("data/Sample1.xaml"))
                x = XamlReader.Load(s);

            var button = new Button
            {
                Content = "ボタン",
                // Button （の親）クラスには [ContentProperty("Content")] 属性が付いている
                FontSize = 20,
                Background = new SolidColorBrush(Colors.Blue),
                // ↑BrushConverter.ConvertFrom("Blue") の結果
            };

            int dummy = 0; ++dummy;
        }

        public static void LoadSample2()
        {
            object x;

            using (var s = File.OpenRead("data/Sample2.xaml"))
                x = XamlReader.Load(s);

            var button1 = new Button { Content = "ボタン1" };
            var button2 = new Button { Content = "ボタン2" };
            Canvas.SetLeft(button2, 10);
            Canvas.SetTop(button2, 50);

            var obj = new Canvas
            {
                Width = 100,
                Height = 100,
                Children = { button1, button2 }
            };

            int dummy = 0; ++dummy;
        }

        public static void LoadSample3()
        {
            object x;

            using (var s = File.OpenRead("data/Sample3.xaml"))
                x = XamlReader.Load(s);

            var obj = new Button
            {
                Content = "ボタン",
                Background = new LinearGradientBrush
                {
                    StartPoint = new Point { X = 0, Y = 0 },
                    EndPoint = new Point { X = 1, Y = 1 },
                    GradientStops =
                    {
                        new GradientStop { Color = Colors.White, Offset = 0 },
                        new GradientStop { Color = Colors.Blue, Offset = 1 },
                    }
                }
            };

            int dummy = 0; ++dummy;
        }

        public static void LoadSample4()
        {
            object x;

            using (var s = File.OpenRead("data/Sample4.xaml"))
                x = XamlReader.Load(s);

            var obj = new StackPanel
            {
                Children =
                {
                    new Button { Content = "ボタン1" },
                    new Button { Content = "ボタン2" },
                    new Button { Content = "ボタン3" },
                }
            };

            int dummy = 0; ++dummy;
        }

        public static void LoadSample5()
        {
            object x;

            using (var s = File.OpenRead("data/Sample5.xaml"))
                x = XamlReader.Load(s);

            var slider = new Slider();
            var text = new TextBox();

            var binding = new Binding
            {
                Source = slider,
                Path = new PropertyPath("Value"),
            };
            text.SetBinding(TextBox.TextProperty, binding);

            var obj = new StackPanel
            {
                Width = 100,
                Children = { slider, text }
            };

            int dummy = 0; ++dummy;
        }

        public static void LoadSample6()
        {
            object x;

            using (var s = File.OpenRead("data/Sample6.xaml"))
                x = XamlReader.Load(s);

            var obj = new TextBlock
            {
                Text = "text",
                Foreground = SystemColors.HighlightTextBrush,
                Background = SystemColors.HighlightBrush,
            };

            // ↑実際には、以下のようなクラスのインスタンスが作られた上で、
            // extension.ProvideValue() メソッドが呼ばれた結果、静的メンバーが取得される
            //
            // var extension = new StaticExtension
            // {
            //     Member = "SystemColors.HighlightBrush"
            // };

            int dummy = 0; ++dummy;
        }

        public static void TestMyGrid()
        {
            var x = new Sample.MyGrid();
        }
    }
}
