﻿using System.Windows.Controls;
using System.Windows;

namespace Sample
{
    public partial class MyGrid : Grid
    {
        public MyGrid()
        {
            InitializeComponent();
        }

        void button1_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            MessageBox.Show("aaa");
        }
    }
}
