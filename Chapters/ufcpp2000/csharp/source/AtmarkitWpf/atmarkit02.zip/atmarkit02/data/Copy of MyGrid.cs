﻿using System.Windows.Controls;
using System.Windows;

namespace Sample
{
    public partial class MyGrid1 : Grid
    {
        internal Button button1;

        public MyGrid1()
        {
            button1 = new Button
            {
                Content = "ボタン"
            };

            button1.Click += button1_Click;
        }

        void button1_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            MessageBox.Show("aaa");
        }
    }
}
