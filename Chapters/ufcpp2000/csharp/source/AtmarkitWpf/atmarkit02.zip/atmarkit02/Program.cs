﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atmarkit02
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            XamlSample.SaveUri();
            //XamlSample.SavePoint();
            //XamlSample.LoadSample1();
            //XamlSample.TestMyGrid();
        }
    }
}
