﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace atmarkit01.View
{
    public class NotifyPropertyChangedViewModel : INotifyPropertyChanged
    {
        private int x;

        public int X
        {
            get { return x; }
            set { x = value; OnPropertyChanged("X", "Sum"); }
        }

        private int y;

        public int Y
        {
            get { return y; }
            set { y = value; OnPropertyChanged("Y", "Sum"); }
        }

        public int Sum
        {
            get
            {
                return x + y;
            }
        }

        #region INotifyPropertyChanged メンバー

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(params string[] propertyNames)
        {
            var d = this.PropertyChanged;
            if (d == null) return;

            foreach (var propertyName in propertyNames)
            {
                d(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
