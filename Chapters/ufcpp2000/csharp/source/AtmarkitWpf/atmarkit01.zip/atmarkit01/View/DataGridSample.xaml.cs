﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using atmarkit01.Model;

namespace atmarkit01.View
{
    /// <summary>
    /// DataGridSample.xaml の相互作用ロジック
    /// </summary>
    public partial class DataGridSample : Page
    {
        public DataGridSample()
        {
            InitializeComponent();

            var entity = new NorthwindEntities();
            this.dataGrid1.DataContext = entity.Customers;
        }
    }
}
