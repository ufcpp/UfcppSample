﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using Mvvm;
using System.Text.RegularExpressions;

namespace atmarkit06
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            this.panel1.DataContext = new ViewModel1();
            this.panel2.DataContext = new ViewModel2();
            this.panel3.DataContext = new ViewModel3();
        }
    }

    public class ViewModel4 : INotifyPropertyChanged, IDataErrorInfo
    {
        private int _x;

        public int X
        {
            get { return _x; }
            set
            {
                if (_x != value)
                {
                    _x = value;
                    RaisePropertyChanged("X");
                }
            }
        }

        public string Error
        {
            get { return X <= 0 ? "X は正の数" : null; }
        }

        public string this[string columnName]
        {
            get
            {
                switch(columnName)
                {
                    case "X": return X <= 0 ? "X は正の数" : null;
                }
                return null;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ViewModel3 : INotifyPropertyChanged
    {
        private int _x;

        public int X
        {
            get { return _x; }
            set
            {
                if (_x != value)
                {
                    _x = value;
                    RaisePropertyChanged("X");
                    ((DelegateCommand)OkCommand).RaiseCanExecuteChanged();
                }
            }
        }

        private void OkCommandExecute(object parameter)
        {
            MessageBox.Show("コマンドが実行されました。");
        }

        private bool OkCommandCanExecute(object parameter)
        {
            return X > 0;
        }

        ICommand _okCommand;

        public ICommand OkCommand
        {
            get
            {
                if (_okCommand == null)
                    _okCommand = new DelegateCommand
                    {
                        ExecuteHandler = OkCommandExecute,
                        CanExecuteHandler = OkCommandCanExecute,
                    };
                return _okCommand;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ViewModel1 : INotifyPropertyChanged
    {
        private int _x;

        public int X
        {
            get { return _x; }
            set
            {
                if (_x != value)
                {
                    _x = value;
                    RaisePropertyChanged("X");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ViewModel2 : INotifyPropertyChanged
    {
        public int Sum { get { return X + Y; } }

        private int _x;

        public int X
        {
            get { return _x; }
            set
            {
                if (_x != value)
                {
                    _x = value;
                    RaisePropertyChanged("X");
                    RaisePropertyChanged("Sum");
                }
            }
        }

        private int _y;

        public int Y
        {
            get { return _y; }
            set
            {
                if (_y != value)
                {
                    _y = value;
                    RaisePropertyChanged("Y");
                    RaisePropertyChanged("Sum");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
