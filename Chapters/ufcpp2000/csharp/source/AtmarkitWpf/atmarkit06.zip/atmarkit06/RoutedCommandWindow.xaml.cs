﻿using System.Windows;
using System.Windows.Input;

namespace atmarkit06
{
    public partial class RoutedCommandWindow : Window
    {
        public RoutedCommandWindow()
        {
            InitializeComponent();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("コマンドが実行されました。");
        }
    }
}
