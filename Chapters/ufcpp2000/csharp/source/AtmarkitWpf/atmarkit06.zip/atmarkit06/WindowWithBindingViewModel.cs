﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using System.Windows.Input;

namespace atmarkit06
{
    /// <summary>
    /// BindingWindow に対する View Model。
    /// </summary>
    /// <remarks>
    /// NoBindingWindow 版と比べるとすっきりした点：
    /// • コマンドの実行可否に応じたボタンなどの Enable/Disable を WPF にお任せするようになった。
    /// • 値の変更結果を手動で反映させるのではなく、INotifyPropertyChanged 越しに行うようになった。
    /// • 検証属性の利用で、データの満たすべき条件の指定がデータ定義と一緒になった。
    /// 
    /// いまだ問題となる点（現状の WPF/C# の限界）：
    /// • INotifyPropertyChanged の実装、超面倒。
    /// • IDataErrorInfo の実装、超面倒。
    /// • ICommand の実装、超面倒。
    /// • 検証属性使ったデータ検証とか、自前で実装しなくても最初から対応しててほしい。
    /// </remarks>
    public class WindowWithBindingViewModel : Mvvm.ViewModelBase
    {
        private int _value = 1;

        /// <summary>
        /// 値。
        /// </summary>
        /// <remarks>
        /// 検証属性でデータの満たすべき性質を指定。
        /// データの定義と検証ロジックが散らばらないのが素敵。
        /// </remarks>
        [Range(0, 10, ErrorMessage = "0～10 の範囲でなければいけません")]
        public int Value
        {
            get { return _value; }
            set
            {
                _value = value;
                RaisePropertyChanged("Value");
                (ShowValue as Mvvm.DelegateCommand).RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// メッセージ・ボックスを表示する。
        /// </summary>
        private void ExcuteShowValue()
        {
            var x = this.Value;
            MessageBox.Show(string.Format("{0} × {0} = {1}", x, x * x));
        }

        Mvvm.DelegateCommand _showValue;

        /// <summary>
        /// メッセージ・ボックスを表示するためのコマンド。
        /// </summary>
        /// <remarks>
        /// View Model 側からすると、どういう操作されたときにこのコマンドが実行されるかは知る必要のないこと。
        /// View 側で何に対してバインディングするかで操作方法が決まる。
        /// 
        /// View Model のデータ検証が通らないと実行できないようにしてある。
        /// </remarks>
        public ICommand ShowValue
        {
            get
            {
                if (_showValue == null)
                {
                    _showValue = new Mvvm.DelegateCommand
                    {
                        CanExecuteHandler = parameter => this.IsValid,
                        ExecuteHandler = parameter => { this.ExcuteShowValue(); },
                    };
                }
                return _showValue;
            }
        }
    }
}
