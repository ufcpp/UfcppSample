﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit06
{
    /// <summary>
    /// Interaction logic for WindowWithoutBinding.xaml
    /// </summary>
    public partial class WindowWithoutBinding : Window
    {
        public WindowWithoutBinding()
        {
            InitializeComponent();
            // 初期値設定、イベント・ハンドラー設定など
            this.textBlock.Text = "1";
            this.textBlock.TextChanged += textBlock_TextChanged;
            this.button.Click += button_Click;
            this.UpdateUI(true);
        }

        /// <summary>
        /// データが有効な時のテキスト・ボックス背景色。
        /// </summary>
        private static readonly Brush ValidBrush = SystemColors.ControlBrush;

        /// <summary>
        /// データが無効な時のテキスト・ボックス背景色。
        /// </summary>
        private static readonly Brush InvalidBrush = new SolidColorBrush(Colors.Red);

        /// <summary>
        /// データが有効な場合にしかボタンを Enable にしない。
        /// このサンプルの場合はボタンが1つだからいいものの…
        /// これがデータもたくさん、ボタンやメニューもたくさんだったら？…
        /// </summary>
        /// <param name="isValid">データが有効な時 true。</param>
        void UpdateUI(bool isValid)
        {
            if (isValid)
            {
                this.button.IsEnabled = true;
                this.textBlock.Background = ValidBrush;
                this.textBlock.ToolTip = string.Empty;
            }
            else
            {
                this.button.IsEnabled = false;
                this.textBlock.Background = InvalidBrush;
                this.textBlock.ToolTip = "0～10 の範囲でなければいけません";
            }
        }

        /// <summary>
        /// テキスト・ボックスの内容が書き換わるたびにデータを検証。
        /// </summary>
        /// <remarks>
        /// メソッド名が処理の内容を表していないので、本当はあんまりよろしくない設計。
        /// Validate みたいなメソッドを1つ用意して、イベント・ハンドラーからはそのメソッドを呼ぶだけみたいにした方が。
        /// </remarks>
        void textBlock_TextChanged(object sender, TextChangedEventArgs e)
        {
            int x;
            UpdateUI(int.TryParse(this.textBlock.Text, out x) && x >= 0 && x <= 10);
        }

        /// <summary>
        /// ボタンが押されたらメッセージ・ボックスを表示する。
        /// </summary>
        /// <remarks>
        /// メソッド名が処理の内容を表していないので、本当はあんまりよろしくない設計。
        /// ShowValue みたいなメソッドを1つ用意して、イベント・ハンドラーからはそのメソッドを呼ぶだけみたいにした方が。
        /// </remarks>
        void button_Click(object sender, RoutedEventArgs e)
        {
            int x = int.Parse(this.textBlock.Text);
            MessageBox.Show(string.Format("{0} × {0} = {1}", x, x * x));
        }
    }
}
