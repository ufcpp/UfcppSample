﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit06
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var data = new[]
            {
                new { Type = typeof(Window1), Description = "色々お試し" },
                new { Type = typeof(WindowWithoutBinding), Description = "データ・バインディングを使わない場合" },
                new { Type = typeof(WindowWithBinding), Description = "MVVM 的実装" },
                new { Type = typeof(CommandWindow), Description = "コマンド（ビュー・モデル）" },
                new { Type = typeof(RoutedCommandWindow), Description = "コマンド（ルーティング・コマンド）" },
                new { Type = typeof(CommandSourceWindow), Description = "インプット・バインディング" },
            };

            this.list.ItemsSource = data;
            this.button.Click += new RoutedEventHandler(button_Click);
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
