﻿using System;
using System.Windows;
using System.Windows.Input;

namespace atmarkit06
{
    public partial class CommandWindow : Window
    {
        public CommandWindow()
        {
            InitializeComponent();
            this.DataContext = new CommandWindowViewModel();
        }
    }

    public class CommandWindowViewModel
    {
        class OkCommandImpl : ICommand
        {
            public bool CanExecute(object parameter) {return true; }
            public event EventHandler CanExecuteChanged;

            public void Execute(object parameter)
            {
                MessageBox.Show("コマンドが実行されました。");
            }
        }

        public ICommand OkCommand { get; private set; }

        public CommandWindowViewModel() { this.OkCommand = new OkCommandImpl(); }
    }
}
