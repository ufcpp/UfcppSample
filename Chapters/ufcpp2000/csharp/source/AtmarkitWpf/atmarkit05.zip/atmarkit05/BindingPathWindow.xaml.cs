﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit05
{
    /// <summary>
    /// BindingPathWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class BindingPathWindow : Window
    {
        public BindingPathWindow()
        {
            InitializeComponent();

this.DataContext = new
{
    管理者 = new { 姓 = "岩永", 名 = "信之" },
    コンテンツ = new[]
    {
        new { タイトル = "C# 入門", URL = "csharp" },
        new { タイトル = "信号処理", URL = "dsp" },
        new { タイトル = "力学", URL = "dynamics" },
    }
};
        }
    }
}
