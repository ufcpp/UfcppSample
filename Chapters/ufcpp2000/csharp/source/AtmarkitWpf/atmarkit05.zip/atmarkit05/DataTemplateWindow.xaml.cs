﻿using System;
using System.Windows;
using System.Linq.Expressions;

namespace atmarkit05
{
    /// <summary>
    /// </summary>
    public partial class DataTemplateWindow : Window
    {
        public DataTemplateWindow()
        {
            InitializeComponent();

Expression<Func<int, int, int>> sample = (x, y) => x + y;
this.DataContext = sample;
        }
    }
}
