﻿using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System;

namespace atmarkit05.Mvvm
{
    public abstract class ViewModelBase : INotifyPropertyChanged, IDataErrorInfo
    {
        #region INotifyPropertyChanged メンバー

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
        #region IDataErrorInfo メンバー

        public string Error
        {
            get
            {
                var context = new ValidationContext(this, null, null);
                var results = new List<ValidationResult>();
                if (Validator.TryValidateObject(this, context, results, true))
                {
                    return string.Empty;
                }
                else
                {
                    return string.Join(Environment.NewLine, results.Select(x => x.MemberNames + ": " + x.ErrorMessage));
                }
            }
        }

        public string this[string columnName]
        {
            get
            {
                var context = new ValidationContext(this, null, null)
                {
                    MemberName = columnName,
                };
                var value = GetType().GetProperty(columnName).GetValue(this, null);
                var results = new List<ValidationResult>();

                if (Validator.TryValidateProperty(value, context, results))
                {
                    return string.Empty;
                }
                else
                {
                    return string.Join(Environment.NewLine, results.Select(x => x.ErrorMessage));
                }
            }
        }

        #endregion

        public bool IsValid
        {
            get
            {
                return string.IsNullOrEmpty(Error);
            }
        }
    }
}
