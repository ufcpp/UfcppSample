﻿using System.Windows;
using System.Collections.ObjectModel;

namespace atmarkit05
{
    public partial class HierarchicalBindingWindow : Window
    {
        public HierarchicalBindingWindow()
        {
            InitializeComponent();

            this.DataContext = new
            {
                管理者 = new { 姓 = "岩永", 名 = "信之" },
                コンテンツ = new[]
                {
                    new { タイトル = "C# 入門", URL = "csharp" },
                    new { タイトル = "信号処理", URL = "dsp" },
                    new { タイトル = "力学", URL = "dynamics" },
                }
            };
        }
    }
}
