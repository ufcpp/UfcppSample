﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit05
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var data = new[]
            {
                new { Type = typeof(MinimalSampleWindow), Description = "最小サンプル" },
                new { Type = typeof(HierarchicalBindingWindow), Description = "階層データのデータ・バインディング" },
                new { Type = typeof(BindingBetweenElementsWindow), Description = "要素間でのデータ・バインディング" },
                new { Type = typeof(XmlDataSourceWindow), Description = "XML データのバインディング" },
                new { Type = typeof(RelativeSourceWindow), Description = "RelativeSource の例" },
                new { Type = typeof(ConverterWindow), Description = "コンバーターの利用例" },
                new { Type = typeof(ValidationWindow), Description = "データ検証の利用例" },
                new { Type = typeof(BindingPathWindow), Description = "パス指定いろいろ" },
                new { Type = typeof(DataTemplateWindow), Description = "データ・テンプレートの例" },
                new { Type = typeof(AutoApplyedDataTemplateWindow), Description = "データ・テンプレートの自動適用" },
                new { Type = typeof(CollectionDataTemplateWindow), Description = "コレクションに対するデータ・テンプレート" },
                new { Type = typeof(HierarchicalDataTemplateWindow), Description = "HeaderedItemsControl に対するデータ・テンプレート" },
                new { Type = typeof(Expressions.ExpressionTreeWindow), Description = "式木" },
            };

            this.list.ItemsSource = data;
            this.button.Click += new RoutedEventHandler(button_Click);

            //var source = new { X = 10, Y = 20 };

            //var binding = new Binding();
            //binding.Source = source;
            //binding.Mode = BindingMode.OneWay;
            //binding.Path = new PropertyPath("X");

            //var target = new TextBlock();
            //target.SetBinding(TextBlock.TextProperty, binding);
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
