﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;

namespace atmarkit05
{
    /// <summary>
    /// Interaction logic for ValidationWindow.xaml
    /// </summary>
    public partial class ValidationWindow : Window
    {
        public ValidationWindow()
        {
            InitializeComponent();
            this.DataContext = new NonNegativePair
            {
                X = 10,
                Y = 20
            };
        }
    }

    public class NonNegativePair : IDataErrorInfo
    {
        public int X { get; set; }
        public int Y { get; set; }

        #region IDataErrorInfo Members

        public string Error
        {
            get
            {
                if (X < 0) return "X は 0 以上でなければいけません";
                if (Y < 0) return "Y は 0 以上でなければいけません";
                return null;
            }
        }

        public string this[string columnName]
        {
            get
            {
                if (columnName == "X" && X < 0) return "X は 0 以上でなければいけません";
                if (columnName == "Y" && Y < 0) return "Y は 0 以上でなければいけません";
                return null;
            }
        }

        #endregion
    }
}
