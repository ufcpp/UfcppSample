﻿using System;
using System.Windows.Data;

namespace atmarkit05
{
    public class DegreeToRadianConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double x = (double)value;
            return x / 180 * Math.PI;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double x = double.Parse((string)value);
            return (x / Math.PI * 180).ToString();
        }
    }
}
