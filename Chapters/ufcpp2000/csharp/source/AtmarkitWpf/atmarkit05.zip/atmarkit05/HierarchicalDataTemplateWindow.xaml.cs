﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq.Expressions;

namespace atmarkit05
{
    /// <summary>
    /// HierarchicalDataTemplateWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class HierarchicalDataTemplateWindow : Window
    {
        public HierarchicalDataTemplateWindow()
        {
            InitializeComponent();

            this.DataContext = new[]
            {
                new Tree
                {
                    Name = "1",
                    Children =
                    {
                        new Tree { Name = "A" },
                        new Tree { Name = "B" },
                    }
                },
                new Tree
                {
                    Name = "2",
                    Children =
                    {
                        new Tree { Name = "C" },
                        new Tree { Name = "D" },
                    }
                },
            };
        }
    }

    public class Tree
    {
        public string Name { get; set; }

        private List<Tree> children = new List<Tree>();

        public IList<Tree> Children
        {
            get { return children; }
        }
    }
}
