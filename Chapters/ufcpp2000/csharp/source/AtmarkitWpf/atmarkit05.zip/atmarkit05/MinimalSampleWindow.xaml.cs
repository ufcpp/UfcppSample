﻿using System.Windows;

namespace atmarkit05
{
    public partial class MinimalSampleWindow : Window
    {
        public MinimalSampleWindow()
        {
            InitializeComponent();

            this.DataContext = new { X = 10, Y = 20 };
        }
    }
}
