﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace atmarkit07
{
    /// <summary>
    /// Interaction logic for ViewBox.xaml
    /// </summary>
    public partial class ViewBoxWindow : Window
    {
        public ViewBoxWindow()
        {
            InitializeComponent();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.Filter = "画像ファイル|*.jpg;*.png";
            dlg.Multiselect = false;

            if (dlg.ShowDialog() ?? false)
            {
                this.Image.Source = new BitmapImage(new Uri(dlg.FileName));
            }
        }
    }
}
