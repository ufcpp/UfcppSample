﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit07
{
    /// <summary>
    /// FontSizeCtrlWheel.xaml の相互作用ロジック
    /// </summary>
    public partial class FontSizeCtrlWheel : Window
    {
        public FontSizeCtrlWheel()
        {
            InitializeComponent();
        }

        private void Window_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
            {
                this.FontSize += 3;
            }
            else
            {
                this.FontSize = Math.Max(this.FontSize - 1, 1);
            }
        }
    }
}
