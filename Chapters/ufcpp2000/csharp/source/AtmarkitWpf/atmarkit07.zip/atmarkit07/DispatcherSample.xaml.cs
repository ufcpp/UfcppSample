﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;
using System.Threading.Tasks;

namespace atmarkit07
{
    /// <summary>
    /// Interaction logic for DispatcherSampel.xaml
    /// </summary>
    public partial class DispatcherSample : Window
    {
        public DispatcherSample()
        {
            InitializeComponent();
        }

        //private async void Button_Click2(object sender, RoutedEventArgs e)
        //{
        //    this.StartButton.IsEnabled = false;
        //    var ui = SynchronizationContext.Current;

        //    await new SynchronizationContext().SwitchTo();

        //    HeavyWork();

        //    await ui.SwitchTo();

        //    this.StartButton.IsEnabled = true;
        //}

private void Button_Click(object sender, RoutedEventArgs e)
{
    var dispatcher = this.Dispatcher;

    Action asyncWork = () =>
    {
        HeavyWork();

        dispatcher.Invoke(new Action(() =>
        {
            // 処理が完了したらボタンを利用可能に戻す
            this.StartButton.IsEnabled = true;
        }));
    };

    // いったんボタンを利用不可にする
    this.StartButton.IsEnabled = false;

    asyncWork.BeginInvoke(null, null);
}

private static void HeavyWork()
{
    // 時間のかかる処理を Sleep を使って疑似的に作る
    System.Threading.Thread.Sleep(3000);
}
    }
}
