﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit07
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var data = new[]
            {
                new { Type = typeof(Panels.SplitterSample), Description = "スプリッター" },
                new { Type = typeof(Panels.GridSample), Description = "Grid" },
                new { Type = typeof(Panels.DockPanelSample), Description = "DockPanel" },
                new { Type = typeof(Panels.WrapPanelSample), Description = "WrapPanel" },
                new { Type = typeof(Panels.StackPanelHorizontalSample), Description = "StackPanel（横）" },
                new { Type = typeof(Panels.StackPanelSample), Description = "StackPanel（縦）" },
                new { Type = typeof(Panels.CanvasSample), Description = "Canvas" },
                new { Type = typeof(DispatcherSample), Description = "ディスパッチャー" },
                new { Type = typeof(ViewBoxWindow), Description = "ViewBox" },
                new { Type = typeof(FixedLayout), Description = "固定レイアウト" },
                new { Type = typeof(FontSizeCtrlWheel), Description = "マウスホイールでフォントサイズ変更" },
                new { Type = typeof(ShapeWindow), Description = "円の描画" },
            };

            this.list.ItemsSource = data;
            this.button.Click += new RoutedEventHandler(button_Click);
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
