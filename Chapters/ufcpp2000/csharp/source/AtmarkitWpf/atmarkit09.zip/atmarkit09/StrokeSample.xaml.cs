﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;

namespace atmarkit09
{
    /// <summary>
    /// Interaction logic for StrokeSample.xaml
    /// </summary>
    public partial class StrokeSample : Window
    {
        public StrokeSample()
        {
            InitializeComponent();

            this.DataContext = new StrokeSampleViewModel();
        }
    }

    public class StrokeSampleViewModel : INotifyPropertyChanged
    {
        #region StrokeThickness

        public double StrokeThickness
        {
            get { return _StrokeThickness; }
            set
            {
                _StrokeThickness = value;
                RaisePropertyChanged("StrokeThickness");
            }
        }

        private double _StrokeThickness = 10;

        #endregion
        #region StrokeDashArray

        public DoubleCollection StrokeDashArray
        {
            get { return _StrokeDashArray; }
            set
            {
                _StrokeDashArray = value;
                RaisePropertyChanged("StrokeDashArray");
            }
        }

        private DoubleCollection _StrokeDashArray = new DoubleCollection(new[] { 2.0, 2.0 });

        #endregion
        #region StrokeDashCap

        public PenLineCap StrokeDashCap
        {
            get { return _StrokeDashCap; }
            set
            {
                _StrokeDashCap = value;
                RaisePropertyChanged("StrokeDashCap");
            }
        }

        private PenLineCap _StrokeDashCap;

        public IEnumerable<PenLineCap> PenLineCaps
        {
            get { return Enum.GetValues(typeof(PenLineCap)).OfType<PenLineCap>(); }
        }

        #endregion
        #region StrokeDashOffset

        public double StrokeDashOffset
        {
            get { return _StrokeDashOffset; }
            set
            {
                _StrokeDashOffset = value;
                RaisePropertyChanged("StrokeDashOffset");
            }
        }

        private double _StrokeDashOffset = 0;

        #endregion
        #region StrokeStartLineCap

        public PenLineCap StrokeStartLineCap
        {
            get { return _StrokeStartLineCap; }
            set
            {
                _StrokeStartLineCap = value;
                RaisePropertyChanged("StrokeStartLineCap");
            }
        }

        private PenLineCap _StrokeStartLineCap;

        #endregion
        #region StrokeEndLineCap

        public PenLineCap StrokeEndLineCap
        {
            get { return _StrokeEndLineCap; }
            set
            {
                _StrokeEndLineCap = value;
                RaisePropertyChanged("StrokeEndLineCap");
            }
        }

        private PenLineCap _StrokeEndLineCap;

        #endregion
        #region StrokeLineJoin

        public PenLineJoin StrokeLineJoin
        {
            get { return _StrokeLineJoin; }
            set
            {
                _StrokeLineJoin = value;
                RaisePropertyChanged("StrokeLineJoin");
            }
        }

        private PenLineJoin _StrokeLineJoin;

        public IEnumerable<PenLineJoin> PenLineJoins
        {
            get { return Enum.GetValues(typeof(PenLineJoin)).OfType<PenLineJoin>(); }
        }

        #endregion
        #region StrokeMiterLimit

        public double StrokeMiterLimit
        {
            get { return _StrokeMiterLimit; }
            set
            {
                _StrokeMiterLimit = value;
                RaisePropertyChanged("StrokeMiterLimit");
            }
        }

        private double _StrokeMiterLimit;

        #endregion
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            var d = PropertyChanged;
            if (d != null)
                d(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }

    public class DoubleCollectionConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var c = (DoubleCollection)value;
            if (c == null) return null;
            return string.Join(", ", c);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var s = value as string;
            if (string.IsNullOrWhiteSpace(s)) return null;
            return new DoubleCollection(s.Split(',').Select(x => double.Parse(x)));
        }

        #endregion
    }

}
