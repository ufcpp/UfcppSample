﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit09
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var data = new[]
            {
                new { Type = typeof(MediaElementSample), Description = "MediaElement" },
                new { Type = typeof(Image), Description = "Image" },
                new { Type = typeof(StrokeSample), Description = "枠線" },
                new { Type = typeof(ZoopSample), Description = "拡大" },
                new { Type = typeof(VisualBrushSample), Description = "VisualBrush" },
                new { Type = typeof(DrawingVisualSample), Description = "DrawingVisual" },
                //new { Type = typeof(Trial), Description = "trial" },
            };

            this.list.ItemsSource = data;
            this.list.MouseDoubleClick += new MouseButtonEventHandler(list_MouseDoubleClick);
            this.button.Click += new RoutedEventHandler(button_Click);
        }

        void list_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowChildWindow();
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            ShowChildWindow();
        }

        private void ShowChildWindow()
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
