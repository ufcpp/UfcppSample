﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace atmarkit09
{
    class データ生成用
    {
        struct Vector3D
        {
            public double X;
            public double Y;
            public double Z;

            public override string ToString()
            {
                return X + " " + Y + " " + Z;
            }
        }
        struct Vector2D
        {
            public double X;
            public double Y;

            public override string ToString()
            {
                return X + " " + Y;
            }
        }

        public static void 円錐断面()
        {
            const int N = 16;

            var positions = new Vector3D[2 * (N + 1)];
            var coordinates = new Vector2D[2 * (N + 1)];
            var indices = new List<int>();

            for (int i = 0; i <= N; i++)
            {
                var x = -Math.Cos(Math.PI * i / (double)N);
                var z = -Math.Sin(Math.PI * i / (double)N);

                positions[i] = new Vector3D { X = 0.5 * x, Y = 0.8, Z = 0.5 * z };
                positions[N + 1 + i] = new Vector3D { X = x, Y = -0.8, Z = z };

                coordinates[i] = new Vector2D { X = 0, Y = (double)i / N };
                coordinates[N + 1 + i] = new Vector2D { X = 1, Y = (double)i / N };

                indices.Add(i);
                indices.Add(N + 1 + i);
                indices.Add(N + 2 + i);
                indices.Add(N + 2 + i);
                indices.Add(i + 1);
                indices.Add(i);
            }

            using (var w = new StreamWriter("test.txt"))
            {
                w.Write("Positions=\"");
                w.Write(string.Join(", ", positions.Select(x => x.ToString())));
                w.WriteLine("\"");

                w.Write("Normals=\"");
                w.Write(string.Join(", ", positions.Select(x => x.ToString())));
                w.WriteLine("\"");

                w.Write("TextureCoordinates=\"");
                w.Write(string.Join(", ", coordinates.Select(x => x.ToString())));
                w.WriteLine("\"");

                w.Write("TriangleIndices=\"");
                w.Write(string.Join(" ", indices));
                w.WriteLine("\"");
            }
        }
    }
}
