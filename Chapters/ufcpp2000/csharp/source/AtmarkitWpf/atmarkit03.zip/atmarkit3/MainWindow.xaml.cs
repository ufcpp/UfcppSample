﻿using System.Windows;
using System.Windows.Markup;

namespace SampleWpfApplication
{
    //public partial class MainWindow : Window, IComponentConnector
    //{
    //    private bool _contentLoaded;

    //    public void InitializeComponent()
    //    {
    //        if (_contentLoaded) return;
    //        _contentLoaded = true;
    //        System.Uri resourceLocater = new System.Uri(
    //            "/SampleWpfApplication;component/mainwindow.xaml", System.UriKind.Relative);

    //        System.Windows.Application.LoadComponent(this, resourceLocater);
    //    }

    //    internal System.Windows.Controls.TextBlock text1;
    //    internal System.Windows.Controls.Button button1;

    //    void IComponentConnector.Connect(int connectionId, object target)
    //    {
    //        switch (connectionId)
    //        {
    //            case 1:
    //                this.text1 = ((System.Windows.Controls.TextBlock)(target));
    //                return;
    //            case 2:
    //                this.button1 = ((System.Windows.Controls.Button)(target));
    //                this.button1.Click += new System.Windows.RoutedEventHandler(this.Button_Click);
    //                return;
    //        }
    //        this._contentLoaded = true;
    //    }
    //}

    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
