﻿using System.Windows;
using System.Windows.Controls;

public partial class MyControl : UserControl
{
    public MyControl()
    {
        InitializeComponent();

        this.list.ItemsSource = new[]
        {
            "A", "B", "C",
        };
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        var button = e.OriginalSource as Button;
        MessageBox.Show(button.DataContext.ToString());
    }

    public static DependencyProperty TextProperty =
        TextBox.TextProperty.AddOwner(typeof(MyControl));
}
