﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit10
{
    /// <summary>
    /// Interaction logic for Trial.xaml
    /// </summary>
    public partial class Trial : Window
    {
        public Trial()
        {
            InitializeComponent();

            this.Test.GiveFeedback += new GiveFeedbackEventHandler(Test_GiveFeedback);
        }

        void Test_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
        }

        void Trial_TouchDown(object sender, TouchEventArgs e)
        {
            throw new NotImplementedException();
        }

        void Trial_MouseDown(object sender, MouseButtonEventArgs e)
        {
        }

        void Trial_MouseWheel(object sender, MouseWheelEventArgs e)
        {
        }

        void Trial_LostFocus(object sender, RoutedEventArgs e)
        {
        }

        void Trial_KeyDown(object sender, KeyEventArgs e)
        {
            var d = e.KeyboardDevice;
            UIElement ui;
            FrameworkElement fe;
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
        }
    }
}
