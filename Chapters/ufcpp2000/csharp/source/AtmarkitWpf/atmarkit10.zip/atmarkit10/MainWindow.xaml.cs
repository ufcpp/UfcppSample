﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var data = new[]
            {
                new { Type = typeof(FluidMoveSample), Description = "FluidMoveBehaviorサンプル" },
                new { Type = typeof(DragAndDrop), Description = "Drag Moveサンプル" },
                new { Type = typeof(TouchManipurationSample), Description = "（マルチタッチ）操作イベント" },
                new { Type = typeof(ControlTemplateVsmSample), Description = "コントロール テンプレートに対する外観状態管理" },
                new { Type = typeof(VisualStateManagerSample), Description = "外観状態管理" },
                new { Type = typeof(MouseOverActionSample), Description = "マウス オーバーでアニメーション" },
                new { Type = typeof(TextInputSample), Description = "テキスト入力" },
                new { Type = typeof(FocusMoveSample), Description = "Enter でフォーカス移動" },
                new { Type = typeof(FocusSample), Description = "フォーカス" },
                new { Type = typeof(MouseCursorSample), Description = "マウス カーソル" },
                new { Type = typeof(Trial), Description = "trial" },
            };


            this.list.ItemsSource = data;
            this.list.MouseDoubleClick += new MouseButtonEventHandler(list_MouseDoubleClick);
            this.button.Click += new RoutedEventHandler(button_Click);
        }

        void list_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowChildWindow();
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            ShowChildWindow();
        }

        private void ShowChildWindow()
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
