﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Interactivity;
using System.Windows;
using System.Windows.Media;

namespace atmarkit10
{
    /// <summary>
    /// デモ用に、Blend SDK 付属の Microsoft.Expression.Interactivity.Layout.MouseDragElementBehavior に類するものを自作。
    /// 
    /// Blend SDK 付属のものと比べるとだいぶ手抜き。
    /// 例えば、RenderTransform が TranslateTransform 1個だけの場合しか動かない
    /// （Blend SDK のものは TransformGroup や MatrixTransform のことも考慮している）。
    /// </summary>
    public class MouseDragElementBehavior : Behavior<FrameworkElement>
    {
        Point _startPosition;

        protected override void OnAttached()
        {
            var element = this.AssociatedObject;
            element.MouseDown += element_MouseDown;
            element.MouseMove += element_MouseMove;
            element.MouseUp += element_MouseUp;
        }

        protected override void OnDetaching()
        {
            var element = this.AssociatedObject;
            element.MouseDown -= element_MouseDown;
            element.MouseMove -= element_MouseMove;
            element.MouseUp -= element_MouseUp;
        }

        void element_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var element = this.AssociatedObject;
            element.CaptureMouse();
            _startPosition = e.GetPosition(element);
        }

        void element_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            var element = this.AssociatedObject;

            if (!element.IsMouseCaptured) return;

            var p = e.GetPosition(element);

            var translate = element.RenderTransform as TranslateTransform;
            if (translate == null)
            {
                translate = new TranslateTransform();
                element.RenderTransform = translate;
            }

            var relative = p - _startPosition;

            translate.X += relative.X;
            translate.Y += relative.Y;
        }

        void element_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.AssociatedObject.ReleaseMouseCapture();
        }
    }
}
