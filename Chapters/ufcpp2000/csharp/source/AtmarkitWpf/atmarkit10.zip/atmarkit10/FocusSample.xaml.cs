﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit10
{
    /// <summary>
    /// Interaction logic for LogicalFocusSample.xaml
    /// </summary>
    public partial class FocusSample : Window
    {
        public FocusSample()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(FocusSample_Loaded);
        }

        void FocusSample_Loaded(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 2; i++)
            {
                var c = new FocusSampleSubWindow { Owner = this };
                c.Show();
            }
        }
    }
}
