﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit10
{
    /// <summary>
    /// Interaction logic for MouseCursorSample.xaml
    /// </summary>
    public partial class MouseCursorSample : Window
    {
        public MouseCursorSample()
        {
            InitializeComponent();
        }

        public System.Collections.IEnumerable Cursors
        {
            get
            {
                return new[]
                {
                    new { Cursor = System.Windows.Input.Cursors.AppStarting, Name = "AppStarting" },
                    new { Cursor = System.Windows.Input.Cursors.Arrow, Name = "Arrow" },
                    new { Cursor = System.Windows.Input.Cursors.ArrowCD, Name = "ArrowCD" },
                    new { Cursor = System.Windows.Input.Cursors.Cross, Name = "Cross" },
                    new { Cursor = System.Windows.Input.Cursors.Hand, Name = "Hand" },
                    new { Cursor = System.Windows.Input.Cursors.Help, Name = "Help" },
                    new { Cursor = System.Windows.Input.Cursors.IBeam, Name = "IBeam" },
                    new { Cursor = System.Windows.Input.Cursors.No, Name = "No" },
                    new { Cursor = System.Windows.Input.Cursors.None, Name = "None" },
                    new { Cursor = System.Windows.Input.Cursors.Pen, Name = "Pen" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollAll, Name = "ScrollAll" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollE, Name = "ScrollE" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollN, Name = "ScrollN" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollNE, Name = "ScrollNE" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollNS, Name = "ScrollNS" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollNW, Name = "ScrollNW" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollS, Name = "ScrollS" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollSE, Name = "ScrollSE" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollSW, Name = "ScrollSW" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollW, Name = "ScrollW" },
                    new { Cursor = System.Windows.Input.Cursors.ScrollWE, Name = "ScrollWE" },
                    new { Cursor = System.Windows.Input.Cursors.SizeAll, Name = "SizeAll" },
                    new { Cursor = System.Windows.Input.Cursors.SizeNESW, Name = "SizeNESW" },
                    new { Cursor = System.Windows.Input.Cursors.SizeNS, Name = "SizeNS" },
                    new { Cursor = System.Windows.Input.Cursors.SizeNWSE, Name = "SizeNWSE" },
                    new { Cursor = System.Windows.Input.Cursors.SizeWE, Name = "SizeWE" },
                    new { Cursor = System.Windows.Input.Cursors.UpArrow, Name = "UpArrow" },
                    new { Cursor = System.Windows.Input.Cursors.Wait, Name = "Wait" },
                };
            }
        }
    }
}
