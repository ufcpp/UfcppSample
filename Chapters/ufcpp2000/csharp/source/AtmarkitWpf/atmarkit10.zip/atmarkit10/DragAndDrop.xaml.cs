﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace atmarkit10
{
    /// <summary>
    /// Interaction logic for DragAndDrop.xaml
    /// </summary>
    public partial class DragAndDrop : Window
    {
        public DragAndDrop()
        {
            InitializeComponent();

            AttachDragMove(this.E1);
            AttachDragMove(this.E2);
        }

        private static void AttachDragMove(Ellipse element)
        {
            Point startPosition = new Point();

            element.MouseDown += (sender, e) =>
            {
                element.CaptureMouse();
                startPosition = e.GetPosition(element);
            };
            element.MouseMove += (sender, e) =>
            {
                if (!element.IsMouseCaptured) return;

                var p = e.GetPosition(element);

                var translate = element.RenderTransform as TranslateTransform;
                if (translate == null)
                {
                    translate = new TranslateTransform();
                    element.RenderTransform = translate;
                }

                var relative = p - startPosition;

                translate.X += relative.X;
                translate.Y += relative.Y;
            };
            element.MouseUp += (sender, e) =>
            {
                element.ReleaseMouseCapture();
            };
        }
    }
}
