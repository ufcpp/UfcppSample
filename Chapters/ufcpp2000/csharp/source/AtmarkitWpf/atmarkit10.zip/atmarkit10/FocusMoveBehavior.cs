﻿using System.Windows.Input;
using System.Windows.Interactivity;
using System.Windows;

namespace atmarkit10
{
    public class FocusMoveBehavior : Behavior<UIElement>
    {
        public Key Key { get; set; }

        protected override void OnAttached()
        {
            this.AssociatedObject.PreviewKeyDown += AssociatedObject_KeyDown;
        }

        protected override void OnDetaching()
        {
            this.AssociatedObject.PreviewKeyDown -= AssociatedObject_KeyDown;
        }

        void AssociatedObject_KeyDown(object sender, KeyEventArgs e)
        {
            if ((Keyboard.Modifiers == ModifierKeys.None) && (e.Key == this.Key))
            {
                var element = e.OriginalSource as UIElement;
                element.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            }
        }
    }
}
