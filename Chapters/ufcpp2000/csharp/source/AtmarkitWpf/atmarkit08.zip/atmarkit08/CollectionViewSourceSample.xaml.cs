﻿using System.Windows;

namespace atmarkit08
{
    public partial class CollectionViewSourceSample : Window
    {
        public CollectionViewSourceSample()
        {
            InitializeComponent();

this.DataContext = new[]
{
    new { Name="Button", Category="ボタン" },
    new { Name="CheckBox", Category="選択" },
    new { Name="ComboBox", Category="選択" },
    new { Name="TextBlock", Category="文字表示" },
    new { Name="RadioButton", Category="選択" },
    new { Name="RichTextBlock", Category="文字表示" },
    new { Name="ScrollBar", Category="表示" },
    new { Name="ToolTip", Category="表示" },
};
        }
    }
}
