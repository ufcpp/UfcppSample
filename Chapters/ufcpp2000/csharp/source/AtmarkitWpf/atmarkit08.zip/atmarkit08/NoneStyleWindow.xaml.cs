﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace atmarkit08
{
    /// <summary>
    /// NoneStyleWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class NoneStyleWindow : Window
    {
        public NoneStyleWindow()
        {
            InitializeComponent();

            this.KeyDown += (sender, e) => { this.Close(); };
            this.MouseLeftButtonDown += (sender, e) => { this.DragMove(); };
        }

        void NoneStyleWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                this.Close();
        }
    }
}
