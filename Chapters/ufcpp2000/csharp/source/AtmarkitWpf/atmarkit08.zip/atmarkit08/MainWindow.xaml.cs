﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace atmarkit08
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var data = new[]
            {
                //new { Type = typeof(), Description = "" },
                new { Type = typeof(NoneStyleWindow), Description = "枠線なし、リサイズ グリップ、半透明" },
                new { Type = typeof(ItemsControlSample), Description = "ItemsControl" },
                new { Type = typeof(CollectionViewSourceSample), Description = "CollectionViewSource" },
                new { Type = typeof(HeaderedItemsControlSample), Description = "HeaderedItemsControl" },
                new { Type = typeof(HeaderedContentControlSample), Description = "HeaderedContentControl" },
                new { Type = typeof(MouseCursor), Description = "マウス・カーソル" },
                new { Type = typeof(EmbeddedFont), Description = "埋め込みフォント" },
                new { Type = typeof(Test), Description = "test" },
            };

            this.list.ItemsSource = data;
            this.list.MouseDoubleClick += new MouseButtonEventHandler(list_MouseDoubleClick);
            this.button.Click += new RoutedEventHandler(button_Click);
        }

        void list_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowChildWindow();
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            ShowChildWindow();
        }

        private void ShowChildWindow()
        {
            dynamic data = this.list.SelectedItem;

            var t = (Type)data.Type;

            var w = (Window)Activator.CreateInstance(t);
            w.ShowDialog();
        }
    }
}
