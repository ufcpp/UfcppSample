﻿using System;
using System.Linq.Expressions;

namespace ExpressionTree
{
	static partial class Make
	{
		public static Expression<Func<TR>> Expression<TR>(Expression<Func<TR>> e)
		{
			return e;
		}

		public static Expression<Func<T1, TR>> Expression<T1, TR>(Expression<Func<T1, TR>> e)
		{
			return e;
		}

		public static Expression<Func<T1, T2, TR>> Expression<T1, T2, TR>(Expression<Func<T1, T2, TR>> e)
		{
			return e;
		}

		public static Expression<Func<T1, T2, T3, TR>> Expression<T1, T2, T3, TR>(Expression<Func<T1, T2, T3, TR>> e)
		{
			return e;
		}

		public static Expression<Func<T1, T2, T3, T4, TR>> Expression<T1, T2, T3, T4, TR>(Expression<Func<T1, T2, T3, T4, TR>> e)
		{
			return e;
		}
	}
}
