﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressionTree
{
	class QueryExpressionTest
	{
		#region クエリ式

		// 1～5
		static IEnumerable<int> five = Enumerable.Range(1, 5);

		// x の要素に重複がないとき true
		static bool Distinct(params int[] x)
		{
			return x.Distinct().Count() == x.Length;
		}

		// x, y が隣り合う数字でないとき true
		static bool Discrete(int x, int y)
		{
			return Math.Abs(checked(x - y)) != 1;
		}

		#endregion

		public static void Test()
		{
			var q1 = Make.Expression(()=>
				from x in five
				select x * x
			);
			var q2 = Make.Expression(() =>
				from x in five
				where x > 3
				select x * x
			);
			var q3 = Make.Expression(() =>
				from x in five
				select x * x into y
				where y > 4
				select y + 1
			);
			var q4 = Make.Expression(() =>
				from x in five
				let y = x * x
				where y > 4
				select y + 1
			);
			var q5 = Make.Expression(() =>
				from x in five
				let y = x * x
				where y > 4
				select y + 1 into z
				select z * 3
			);
			var q0 = Make.Expression((IEnumerable<int> five) =>
				from baker in five
				from cooper in five
				from fletcher in five
				from miller in five
				from smith in five
				where Distinct(baker, cooper, fletcher, miller, smith)
				where baker != 5
				where cooper != 1
				where fletcher != 1 && fletcher != 5
				where miller > cooper
				where Discrete(smith, fletcher)
				where Discrete(fletcher, cooper)
				select new { baker, cooper, fletcher, miller, smith }
				);

			var q = new QueryExpression(q0);

			foreach (var l in q.Queries)
			{
				Console.Write("{0}\n", l);
			}
		}
	}
}
