﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace ExpressionTree
{
	public enum QueryType
	{
		From,
		Select,
		Where,
		Let,
		Into,
		//! group by も対応したい
	}

	/// <summary>
	/// 
	/// </summary>
	public abstract class QueryLine
	{
		public virtual QueryType QueryType { get; protected set; }
	}

	/// <summary>
	/// from x in e
	/// を表すクラス。
	/// x → Paramter
	/// e → Enumerable
	/// </summary>
	public class FromQuery : QueryLine
	{
		public Expression Enumerable { private set; get; }
		public ParameterExpression Parameter { private set; get; }

		public FromQuery(Expression e, ParameterExpression x)
		{
			this.Enumerable = e;
			this.Parameter = x;
			this.QueryType = QueryType.From;
		}

		public override string ToString()
		{
			return string.Format("from {0} in {1}", this.Parameter, this.Enumerable);
		}
	}

	/// <summary>
	/// where Predicate(x)
	/// を表すクラス。
	/// 
	/// where x == y
	/// みたいな行は、
	/// <![CDATA[
	/// new WhereExpression { Predicate = Expression.Equal(x, y) }
	/// ]]>
	/// に翻訳。
	/// </summary>
	public class WhereQuery : QueryLine
	{
		public Expression Predicate { private set; get; }

		public WhereQuery(Expression pred)
		{
			this.Predicate = pred;
			this.QueryType = QueryType.Where;
		}

		public override string ToString()
		{
			return string.Format("where {0}", this.Predicate);
		}
	}

	/// <summary>
	/// select Selector(x)
	/// を表すクラス。
	/// </summary>
	public class SelectQuery : QueryLine
	{
		public Expression Selector { private set; get; }

		public SelectQuery(Expression selector)
		{
			this.Selector = selector;
			this.QueryType = QueryType.Select;
		}

		public override string ToString()
		{
			return string.Format("select {0}", this.Selector);
		}
	}

	/// <summary>
	/// select Selector(x) into y
	/// みたいなのの、into y の部分。
	/// </summary>
	/// <remarks>
	/// SelectQuery と別クラスにした方がパーサを書きやすかったので。
	/// </remarks>
	public class IntoQuery : QueryLine
	{
		public ParameterExpression Parameter { private set; get; }

		public IntoQuery(ParameterExpression x)
		{
			this.Parameter = x;
			this.QueryType = QueryType.Into;
		}

		public override string ToString()
		{
			return string.Format("into {0}", this.Parameter);
		}
	}

	/// <summary>
	/// let Parameter = Expression
	/// を表すクラス。
	/// </summary>
	public class LetQuery : QueryLine
	{
		public ParameterExpression Parameter { private set; get; }
		public Expression Expression { private set; get; }

		public LetQuery(ParameterExpression x, Expression e)
		{
			this.Parameter = x;
			this.Expression = e;
			this.QueryType = QueryType.Let;
		}

		public override string ToString()
		{
			return string.Format("let {0} = {1}", this.Parameter, this.Expression);
		}
	}
}
