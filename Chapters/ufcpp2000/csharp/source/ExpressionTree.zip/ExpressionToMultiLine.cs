﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Reflection;

namespace ExpressionTree
{
	/// <summary>
	/// System.Linq.Expressions.Expression 型の拡張メソッドとして
	/// </summary>
	public static class ExpressionToMultiLineStringExtension
	{
		public static string ToMultiLine(this Expression e)
		{
			var d = new ExpressionToMultiLineString();
			return d.ToMultiLine(e);
		}
	}

	class ExpressionToMultiLineString
	{
		public string ToMultiLine(Expression e)
		{
			this.sb = new StringBuilder();
			this.ToMultiLine(e, 0);
			return sb.ToString();
		}

		#region Show

		StringBuilder sb;

		void Show(int tabLevel, string msg)
		{
			var tab = new string(Enumerable.Repeat('\t', 2 * tabLevel).ToArray());
			this.sb.Append(tab + msg + "\n");
		}

		void Show(int tabLevel, string format, params object[] args)
		{
			Show(tabLevel, string.Format(format, args));
		}

		#endregion
		#region リフレクションを使って動的な型に応じて動的に ToMultiLine を実行

		// 名前が ToMultiLine のメソッド一覧をあらかじめ作っておく
		static IEnumerable<MethodInfo> disp;

		static ExpressionToMultiLineString()
		{
			disp = (
				from x in typeof(ExpressionToMultiLineString).GetMethods(BindingFlags.NonPublic | BindingFlags.Instance)
				where x.Name == "ToMultiLine"
				select x
				).ToArray();

			/*
			var dl =
				from x in disp
				let args = x.GetParameters()
				where args.Length == 2
				&& args[1].ParameterType == typeof(int)
				&& args[0].ParameterType == typeof(LambdaExpression)
				select x;

			dispLambda = dl.Single();
			 * */
		}

		/// <summary>
		/// t で指定された型に一致する ToMultiLine(T e, int tabLevel) を探す。
		/// </summary>
		/// <param name="t">T</param>
		/// <returns>一致したメソッドの MethodInfo</returns>
		static MethodInfo FindToMultiLine(Type t)
		{
			System.Diagnostics.Debug.Assert(typeof(Expression).IsAssignableFrom(t));

			var q =
				from x in disp
				let args = x.GetParameters()
				where args.Length == 2
				&& args[1].ParameterType == typeof(int)
				&& args[0].ParameterType == t
				select x;

			var m = q.SingleOrDefault();

			System.Diagnostics.Debug.Assert(m != null);

			return m;
		}

		#endregion

		void ToMultiLine(Expression e, int tabLevel)
		{
			if (typeof(LambdaExpression).IsAssignableFrom(e.GetType()))
			{
				this.ToMultiLine((LambdaExpression)e, tabLevel);
			}
			else
			{
				var m = FindToMultiLine(e.GetType());

				m.Invoke(this, new object[] { e, tabLevel });
			}
		}

		void ToMultiLine<T>(T e, int tabLevel)
			where T : LambdaExpression
		{
			this.ToMultiLine((LambdaExpression)e, tabLevel);
		}

		void ToMultiLine(LambdaExpression e, int tabLevel)
		{
			Show(tabLevel, "Lambda {");
			Show(tabLevel, "\tParamters = {");

			foreach (var p in e.Parameters)
			{
				ToMultiLine(p, tabLevel + 1);
			}

			Show(tabLevel, "\t}");

			Show(tabLevel, "\tBody = {");
			ToMultiLine(e.Body, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}

		void ToMultiLine(ParameterExpression e, int tabLevel)
		{
			Show(tabLevel, "Paramter {0} {1}", e.Type.Name, e.Name);
		}

		void ToMultiLine(ConstantExpression e, int tabLevel)
		{
			Show(tabLevel, "{0}", e.Value);
		}

		void ToMultiLine(UnaryExpression e, int tabLevel)
		{
			var msg = e.NodeType == ExpressionType.TypeAs ?
				string.Format("Unary(TypeAs {0})", e.Type.Name) + " {" :
				string.Format("Unary({0})", e.NodeType) + " {";

			Show(tabLevel, msg);
			Show(tabLevel, "\tOperand = {");
			ToMultiLine(e.Operand, tabLevel + 1);
			Show(tabLevel, "\t}");
			Show(tabLevel, "}");
		}

		void ToMultiLine(BinaryExpression e, int tabLevel)
		{
			var msg = string.Format("Binary({0})", e.NodeType) + " {";

			Show(tabLevel, msg);

			Show(tabLevel, "\tLeft = {");
			ToMultiLine(e.Left, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "\tRight = {");
			ToMultiLine(e.Right, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}

		void ToMultiLine(ConditionalExpression e, int tabLevel)
		{
			Show(tabLevel, "Conditional {");

			Show(tabLevel, "\tTest = {");
			ToMultiLine(e.Test, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "\tIfTrue = {");
			ToMultiLine(e.IfTrue, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "\tIfFalse = {");
			ToMultiLine(e.IfFalse, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}

		void ToMultiLine(TypeBinaryExpression e, int tabLevel)
		{
			var msg = string.Format("TypeIs {0}", e.TypeOperand) + " {";

			Show(tabLevel, msg);

			Show(tabLevel, "\tExpression = {");
			ToMultiLine(e.Expression, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}

		void ToMultiLine(MemberExpression e, int tabLevel)
		{
			if (e.Expression == null)
			{
				Show(tabLevel, "Member {0}", e.Member.Name);
			}
			else
			{
				var msg = string.Format("Member {0}", e.Member.Name) + " {";

				Show(tabLevel, msg);

				Show(tabLevel, "\tExpression = {");
				ToMultiLine(e.Expression, tabLevel + 1);
				Show(tabLevel, "\t}");

				Show(tabLevel, "}");
			}
		}

		void ToMultiLine(NewExpression e, int tabLevel)
		{
			var msg = string.Format("New {0}", e.Constructor.DeclaringType) + " {";

			Show(tabLevel, msg);

			foreach(var arg in e.Arguments)
			{
				Show(tabLevel, "\tExpression = {");
				ToMultiLine(arg, tabLevel + 1);
				Show(tabLevel, "\t}");
			}
			Show(tabLevel, "}");
		}

		void ToMultiLine(NewArrayExpression e, int tabLevel)
		{

			if (e.NodeType == ExpressionType.NewArrayInit)
			{
				var msg = string.Format("New {0}", e.Type) + " {";

				Show(tabLevel, msg);

				foreach (var elem in e.Expressions)
				{
					ToMultiLine(elem, tabLevel + 1);
					Show(tabLevel, "\t,");
				}
				Show(tabLevel, "}");
			}
			else
			{
				Show(tabLevel, "New {0}[", e.Type.GetElementType());

				ToMultiLine(e.Expressions[0], tabLevel + 1);

				Show(tabLevel, "\t]");
			}
		}

		void ToMultiLine(MemberInitExpression e, int tabLevel)
		{
			Show(tabLevel, "Member Init {");

			Show(tabLevel, "\tNewExpression = {");
			ToMultiLine(e.NewExpression, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "\tBindings = {");
			ToMultiLineMemberBinding(e.Bindings, tabLevel);
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}

		void ToMultiLineMemberBinding(IEnumerable<MemberBinding> bindings, int tabLevel)
		{
			foreach (var bind in bindings)
			{
				switch (bind.BindingType)
				{
					case MemberBindingType.Assignment:
						var assign = (MemberAssignment)bind;
						Show(tabLevel, "\tAssing " + bind.Member.Name + " = {");
						ToMultiLine(assign.Expression, tabLevel + 1);
						Show(tabLevel, "\t}");
						break;
					case MemberBindingType.MemberBinding:
						var mbind = (MemberMemberBinding)bind;
						Show(tabLevel, "\tMember Binding " + bind.Member.Name + " = {");
						ToMultiLineMemberBinding(mbind.Bindings, tabLevel + 1);
						Show(tabLevel, "\t}");
						break;
					case MemberBindingType.ListBinding:
						var lbind = (MemberListBinding)bind;
						Show(tabLevel, "\tMember Binding " + bind.Member.Name + " = {");
						ToMultiLineMemberBinding(lbind.Initializers, tabLevel + 1);
						Show(tabLevel, "\t}");
						break;
				}
			}
		}

		void ToMultiLineMemberBinding(IEnumerable<ElementInit> inits, int tabLevel)
		{
			foreach (var init in inits)
			{
				if (init.Arguments.Count == 1)
				{
					ToMultiLine(init.Arguments[0], tabLevel);
					Show(tabLevel, ",");
				}
				else
				{
					foreach (var args in init.Arguments)
					{
						Show(tabLevel, "\t{");
						ToMultiLine(init.Arguments[0], tabLevel + 1);
						Show(tabLevel, "\t}");
					}
				}
			}
		}

		void ToMultiLine(MethodCallExpression e, int tabLevel)
		{
			var msg = string.Format("Call {0}", e.Method.Name) + " {";

			Show(tabLevel, msg);

			Show(tabLevel, "\tArguments = {");
			foreach (var arg in e.Arguments)
			{
				ToMultiLine(arg, tabLevel + 1);
				Show(tabLevel, "\t,");
			}
			Show(tabLevel, "\t}");
			Show(tabLevel, "}");
		}

		void ToMultiLine(InvocationExpression e, int tabLevel)
		{
			Show(tabLevel, "Invoke");

			Show(tabLevel, "\tExpression = {");
			ToMultiLine(e.Expression, tabLevel + 1);
			Show(tabLevel, "\t}");

			Show(tabLevel, "\tArguments = {");
			foreach (var arg in e.Arguments)
			{
				ToMultiLine(arg, tabLevel + 1);
				Show(tabLevel, "\t,");
			}
			Show(tabLevel, "\t}");

			Show(tabLevel, "}");
		}
	}
}
