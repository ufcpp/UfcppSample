﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using System.Text;
using System.Reflection;

namespace ExpressionTree
{
	class Program
	{

		static void Main(string[] args)
		{
			//Console.Write(q.ToMultiLine());

			//ExpressionToMultiLineTest.Test();

			QueryExpressionTest.Test();
		}
	}
}
