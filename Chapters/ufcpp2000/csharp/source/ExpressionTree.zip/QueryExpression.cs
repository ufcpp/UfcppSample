﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Linq.Expressions;

using ParamterList = System.Collections.ObjectModel.ReadOnlyCollection<System.Linq.Expressions.ParameterExpression>;

namespace ExpressionTree
{
	/// <summary>
	/// クエリ式のコンパイル結果であるメソッド形式LINQクエリを、クエリ式に戻す。
	/// </summary>
	/// <remarks>
	/// 要するに、
	/// <![CDATA[
	/// from x in e1
	/// from y in e2
	/// where x == y
	/// select x
	/// ]]>
	/// みたいなのは、
	/// <![CDATA[
	/// e1
	///  .SelectMany(x => e2, (x, y) => new { x, y })
	///  .Where(transparent => transparent.x == transparent.y);
	/// ]]>
	/// みたいになってるので、
	/// 透過識別子を削除したり、SelectMany → from とかの置き換えをして、
	/// メソッド形式LINQをクエリ式に戻す。
	/// </remarks>
	public class QueryExpression
	{
		#region フィールド

		/// <summary>
		/// クエリ式中に渡されたパラメータ。
		/// 
		/// <![CDATA[
		/// Func<IEnumerable, IEnumerable> f = a => from x in a select x * x;
		/// ]]>
		/// みたいな式における a の方。
		/// </summary>
		ParamterList lambdaParameters;

		/// <summary>
		/// クエリ式中で定義されたパラメータ。
		/// 
		/// <![CDATA[
		/// Func<IEnumerable, IEnumerable> f = a => from x in a select x * x;
		/// ]]>
		/// みたいな式における x の方。
		/// </summary>
		Dictionary<string, ParameterExpression> innerParameters = new Dictionary<string,ParameterExpression>();

		/// <summary>
		/// 変換結果のクエリ式格納用のスタック。
		/// </summary>
		Stack<QueryLine> queryLines = new Stack<QueryLine>();

		#endregion
		#region 初期化

		/// <summary>
		/// 式木になったメソッド形式のLINQクエリをクエリ式に戻す。
		/// </summary>
		/// <param name="e">LINQクエリの式木</param>
		public QueryExpression(LambdaExpression e)
		{
			this.lambdaParameters = e.Parameters;
			this.Decompose(e.Body);
		}

		#endregion
		#region プロパティ

		public IEnumerable<QueryLine> Queries
		{
			get
			{
				foreach (var x in this.queryLines)
					yield return x;
			}
		}

		#endregion
		#region メソッド形式クエリ→クエリ式 本体

		/// <summary>
		/// 式木になったメソッド形式のLINQクエリをクエリ式に戻す。
		/// </summary>
		void Decompose(Expression e)
		{
			switch (e.NodeType)
			{
				case ExpressionType.Call:
					this.Decompose((MethodCallExpression)e);
					break;
			}
		}

		void Decompose(MethodCallExpression e)
		{
			var name = e.Method.Name;
			var parameters = e.Method.GetParameters();

			if (name == "Where" && parameters.Length == 2)
			{
				var arg = this.RemoveTransparentIdentifier(e.Arguments[1]);
				this.queryLines.Push(new WhereQuery(arg));
			}
			else if (name == "Select" && parameters.Length == 2)
			{
				// 末尾もしくは Into の前の Select は select 句
				if (this.queryLines.Count == 0 || this.queryLines.Peek().QueryType == QueryType.Into)
				{
					var arg = this.RemoveTransparentIdentifier(e.Arguments[1]);
					this.queryLines.Push(new SelectQuery(arg));
				}
				else
				{
					// let の変換結果は、
					// let y = x * x
					// ↓
					// .Select(x => new { x, y = x * x })
					// 
					// 見たいになってるはずなので、
					// NewExpression の中身を解析。

					//! 要エラーチェック
					var lambda = (LambdaExpression)e.Arguments[1];
					var p1 = lambda.Parameters[0];
					var body = (NewExpression)lambda.Body;
					var p2 = body.Constructor.DeclaringType.GetProperties()
						.Single(x => x.Name != p1.Name);

					var parameter = this.GetInnterParamter(p2);
					var expression = this.RemoveTransparentIdentifier(body.Arguments[1]);

					this.queryLines.Push(new LetQuery(parameter, expression));
				}
			}
			else if (name == "SelectMany" && parameters.Length == 3)
			{
				// 2重 from の変換結果は、
				// from x in list
				// from y in list
				// ↓
				// list
				// .SelectMany(x => list, (x, y) => new { x, y })
				// みたいな感じなので、第2引数の LambdaExpression.Parameters[1] を調べる。

				var enumerable = ((LambdaExpression)e.Arguments[1]).Body;
				var p2 = ((LambdaExpression)e.Arguments[2]).Parameters[1];
				var parameter = this.GetInnterParamter(p2);

				this.queryLines.Push(new FromQuery(enumerable, parameter));
			}
			else
			{
				throw new NotSupportedException("not supported");
			}

			var e0 = e.Arguments[0];
			//! ↓エラーチェック必要
			var p = ((LambdaExpression)e.Arguments[1]).Parameters[0];

			if (e0.NodeType != ExpressionType.Call)
			{
				// 先頭。from 句。
				this.queryLines.Push(new FromQuery(e0, this.GetInnterParamter(p)));
			}
			else
			{
				// 末尾以外に Select がある場合、
				// 透過識別子を持つ → let 句
				// 持たない         → select into 句
				// という判定。
				var call = (MethodCallExpression)e0;
				if (call.Method.Name == "Select" && !IsTransparentIdentifier(p.Name))
				{
					this.queryLines.Push(new IntoQuery(this.GetInnterParamter(p)));
				}

				this.Decompose(e0);
			}
		}

		#endregion
		#region 透過識別子の除去

		Expression RemoveTransparentIdentifier(Expression e)
		{
			if (e == null) return null;

			if (e.NodeType == ExpressionType.Lambda)
			{
				return this.RemoveTransparentIdentifier(((LambdaExpression)e).Body);
			}

			if (e.NodeType == ExpressionType.Constant)
				return e;

			if (e.NodeType == ExpressionType.Parameter)
				return this.RemoveTransparentIdentifier((ParameterExpression)e);

			if (e.NodeType == ExpressionType.MemberAccess)
				return this.RemoveTransparentIdentifier((MemberExpression)e);

			if (e.NodeType == ExpressionType.MemberInit)
				return this.RemoveTransparentIdentifier((MemberInitExpression)e);

			if (e.NodeType == ExpressionType.New)
				return this.RemoveTransparentIdentifier((NewExpression)e);

			if (e.NodeType == ExpressionType.Call)
				return this.RemoveTransparentIdentifier((MethodCallExpression)e);

			var na = e as NewArrayExpression;
			if (na != null)
				return this.RemoveTransparentIdentifier(na);

			var b = e as BinaryExpression;
			if (b != null)
			{
				var l = this.RemoveTransparentIdentifier(b.Left);
				var r = this.RemoveTransparentIdentifier(b.Right);
				return Make.Binary(b.NodeType, l, r);
			}

			var u = e as UnaryExpression;
			if (u != null)
			{
				var o = this.RemoveTransparentIdentifier(u.Operand);
				return Make.Unary(b.NodeType, o);
			}

			throw new NotSupportedException("not implemented yet");
		}

		NewArrayExpression RemoveTransparentIdentifier(NewArrayExpression e)
		{
			var ex = (
				from x in e.Expressions
				select this.RemoveTransparentIdentifier(x)
				).ToArray();

			if (e.NodeType == ExpressionType.NewArrayInit)
				return Expression.NewArrayInit(e.Type.GetElementType(), ex);
			else if (e.NodeType == ExpressionType.NewArrayBounds)
				return Expression.NewArrayBounds(e.Type.GetElementType(), ex);

			throw new ArgumentException("引数がおかしい");
		}

		MethodCallExpression RemoveTransparentIdentifier(MethodCallExpression e)
		{
			var obj = this.RemoveTransparentIdentifier(e.Object);
			var args = (
				from x in e.Arguments
				select this.RemoveTransparentIdentifier(x)
				).ToArray();

			return Expression.Call(obj, e.Method, args);
		}

		Expression RemoveTransparentIdentifier(ParameterExpression e)
		{
			if (IsTransparentIdentifier(e.Name))
				return null;
			else
				return e;
		}

		Expression RemoveTransparentIdentifier(MemberExpression e)
		{
			var ex = this.RemoveTransparentIdentifier(e.Expression);
			if (ex == null)
			{
				if (IsTransparentIdentifier(e.Member.Name))
					return null;
				else
					return this.GetInnterParamter(e.Member);
			}

			return Expression.MakeMemberAccess(ex, e.Member);
		}

		NewExpression RemoveTransparentIdentifier(NewExpression e)
		{
			var args = (
				from x in e.Arguments
				select this.RemoveTransparentIdentifier(x)
				).ToArray();

			return Expression.New(e.Constructor, args);
		}

		MemberInitExpression RemoveTransparentIdentifier(MemberInitExpression e)
		{
			var bindings = (
				from x in e.Bindings
				select this.RemoveTransparentIdentifier(x)
				).ToArray();

			var ctor = this.RemoveTransparentIdentifier(e.NewExpression);

			return Expression.MemberInit(ctor, bindings);
		}

		MemberBinding RemoveTransparentIdentifier(MemberBinding e)
		{
			switch (e.BindingType)
			{
				case MemberBindingType.Assignment:
					var assign = (MemberAssignment)e;
					var ex = this.RemoveTransparentIdentifier(assign.Expression);
					return Expression.Bind(assign.Member, ex);

				case MemberBindingType.MemberBinding:
					var member = (MemberMemberBinding)e;
					var bindings = (
						from x in member.Bindings
						select this.RemoveTransparentIdentifier(x)
						).ToArray();
					return Expression.MemberBind(member.Member, bindings);

				case MemberBindingType.ListBinding:
					var list = (MemberListBinding)e;
					var inits = (
						from x in list.Initializers
						let args = (
							from y in x.Arguments
							select this.RemoveTransparentIdentifier(y)
							).ToArray()
						select Expression.ElementInit(x.AddMethod, args)
						).ToArray();
					return Expression.ListBind(list.Member, inits);

				default:
					throw new NotSupportedException("起こらないはず");
			}
		}

		#region Innter Parameter

		ParameterExpression GetInnterParamter(System.Reflection.MemberInfo m)
		{
			if (this.innerParameters.ContainsKey(m.Name))
			{
				//! m と this.innerParameters[m.Name] の型が一致するか確認必要
				return this.innerParameters[m.Name];
			}

			Type t = null;
			if (m.MemberType == System.Reflection.MemberTypes.Property)
			{
				t = ((System.Reflection.PropertyInfo)m).PropertyType;
			}
			else if (m.MemberType == System.Reflection.MemberTypes.Field)
			{
				t = ((System.Reflection.FieldInfo)m).FieldType;
			}
			else
			{
				throw new ArgumentException("MemberType がおかしい");
			}

			var p = Expression.Parameter(t, m.Name);
			this.innerParameters[m.Name] = p;
			return p;
		}

		ParameterExpression GetInnterParamter(ParameterExpression p)
		{
			if (this.innerParameters.ContainsKey(p.Name))
			{
				//!p と this.innerParameters[p.Name] が一致するか確認必要
				return p;
			}

			this.innerParameters[p.Name] = p;
			return p;
		}

		#endregion
		#region 透過識別子の判定

		static Regex transparent = new Regex(@"\<\>h__TransparentIdentifier", RegexOptions.Compiled);

		static bool IsTransparentIdentifier(string name)
		{
			var m = transparent.Match(name);
			return m.Success;
		}

		static Regex anonymousType = new Regex(@"\<\>f__AnonymousType", RegexOptions.Compiled);

		static bool IsAnonymousType(string name)
		{
			var m = anonymousType.Match(name);
			return m.Success;
		}

		#endregion

		#endregion
	}
}

namespace ExpressionTree
{
	using Ex = System.Linq.Expressions.Expression;

	public static partial class Make
	{
		/// <summary>
		/// NodeTypeごとに Expression.Negate とか書くのが面倒だったので、
		/// Make.Unary に統合。
		/// </summary>
		/// <param name="type">NodeType</param>
		/// <param name="operand">オペランド</param>
		/// <returns>UnaryExpression</returns>
		public static UnaryExpression Unary(ExpressionType type, Expression operand)
		{
			switch (type)
			{
				case ExpressionType.UnaryPlus:
					return Ex.UnaryPlus(operand);
				case ExpressionType.Negate:
					return Ex.Negate(operand);
				case ExpressionType.NegateChecked:
					return Ex.NegateChecked(operand);
				case ExpressionType.Not:
					return Ex.Not(operand);
				case ExpressionType.Quote:
					return Ex.Quote(operand);
				case ExpressionType.ArrayLength:
					return Ex.ArrayLength(operand);

				//case ExpressionType.TypeAs:
				//	return Ex.(operand);
				//case ExpressionType.Convert:
				//	return Ex.Convert(operand);
				//case ExpressionType.ConvertChecked:
				//	return Ex.ConvertChecked(operand);
					//! ↑この辺りに対応

				default:
					throw new NotSupportedException("not implemented yet");
			}
		}

		/// <summary>
		/// NodeTypeごとに Expression.Negate とか書くのが面倒だったので、
		/// Make.Unary に統合。
		/// </summary>
		/// <param name="type">NodeType</param>
		/// <param name="left">左オペランド</param>
		/// <param name="right">右オペランド</param>
		/// <returns>BinaryExpression</returns>
		public static BinaryExpression Binary(ExpressionType type, Expression left, Expression right)
		{
			switch (type)
			{
				case ExpressionType.Add:
					return Ex.Add(left, right);
				case ExpressionType.Subtract:
					return Ex.Subtract(left, right);
				case ExpressionType.Multiply:
					return Ex.Multiply(left, right);
				case ExpressionType.Divide:
					return Ex.Divide(left, right);
				case ExpressionType.Modulo:
					return Ex.Modulo(left, right);
				case ExpressionType.Power:
					return Ex.Power(left, right);
				case ExpressionType.AddChecked:
					return Ex.AddChecked(left, right);
				case ExpressionType.SubtractChecked:
					return Ex.SubtractChecked(left, right);
				case ExpressionType.MultiplyChecked:
					return Ex.MultiplyChecked(left, right);
				case ExpressionType.And:
					return Ex.And(left, right);
				case ExpressionType.Or:
					return Ex.Or(left, right);
				case ExpressionType.ExclusiveOr:
					return Ex.ExclusiveOr(left, right);
				case ExpressionType.AndAlso:
					return Ex.AndAlso(left, right);
				case ExpressionType.OrElse:
					return Ex.OrElse(left, right);
				case ExpressionType.Equal:
					return Ex.Equal(left, right);
				case ExpressionType.NotEqual:
					return Ex.NotEqual(left, right);
				case ExpressionType.LessThan:
					return Ex.LessThan(left, right);
				case ExpressionType.LessThanOrEqual:
					return Ex.LessThanOrEqual(left, right);
				case ExpressionType.GreaterThan:
					return Ex.GreaterThan(left, right);
				case ExpressionType.GreaterThanOrEqual:
					return Ex.GreaterThanOrEqual(left, right);
				case ExpressionType.LeftShift:
					return Ex.LeftShift(left, right);
				case ExpressionType.RightShift:
					return Ex.RightShift(left, right);
				case ExpressionType.Coalesce:
					return Ex.Coalesce(left, right);
				case ExpressionType.ArrayIndex:
					return Ex.ArrayIndex(left, right);

				default:
					throw new NotSupportedException("not implemented yet");
			}
		}
	}
}
