﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SortVisualize
{
    public class SortVisualizer
    {
        const int N = 50;

        Canvas MainCanvas;
        UIElement[] canvasItems = null;
        SortItem[] target_;

        public SortItem[] Target
        {
            get { return target_; }
            set { target_ = value; }
        }

        static SortItem[] New(int n)
        {
            var rnd = new Random();

            var items = Enumerable.Range(0, n)
                .OrderBy(x => rnd.Next())
                .Select((x, i) => new SortItem(x));

            return items.ToArray();
        }

        public void Randamize()
        {
            var rnd = new Random();
            var r = Enumerable.Range(0, target_.Length).OrderBy(x => rnd.Next()).ToArray();

            for (int i = 0; i < target_.Length; i++)
            {
                int j = r[i];

                var t = target_[i];
                target_[i] = target_[j];
                target_[j] = t;
            }
        }

        public SortVisualizer(Canvas mainCanvas) : this(mainCanvas, N) { }

        public SortVisualizer(Canvas mainCanvas, int n) : this(mainCanvas, New(n)) { }

        public SortVisualizer(Canvas mainCanvas, SortItem[] target)
        {
            MainCanvas = mainCanvas;
            target_ = target;
        }

        public static readonly Color[] ColorTable = new[]
        {
            Colors.Gray,
            Colors.Blue,
            Colors.Red,
            Colors.Magenta,
            Colors.Orange,
            Colors.Purple,
            Colors.Green,
            Colors.Yellow,
            Colors.Cyan,
        };

        public static readonly Brush[] BrushTable = ColorTable.Select(x => new SolidColorBrush(x)).ToArray();
        const int BubbleSize = 8;

        public void UpdateItems()
        {
            if (canvasItems == null)
                canvasItems = new UIElement[target_.Length];

            for (int i = 0; i < canvasItems.Length; i++)
            {
                Shape item;

                if (canvasItems[i] == null)
                {
                    item = new Ellipse
                    {
                        Width = BubbleSize,
                        Height = BubbleSize,
                    };
                    canvasItems[i] = item;
                    this.MainCanvas.Children.Add(item);
                }
                else item = (Shape)canvasItems[i];

                item.RenderTransform = new TranslateTransform
                {
                    X = target_[i].Value * BubbleSize,
                    Y = i * BubbleSize,
                };

                item.Fill = BrushTable[(int)target_[i].State];
            }
        }
    }
}
