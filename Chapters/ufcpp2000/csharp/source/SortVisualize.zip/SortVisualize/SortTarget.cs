﻿using System.ComponentModel;

namespace SortVisualize
{
    /// <summary>
    /// ソート実行途中に配列の要素がどういう扱いを受けているかを視覚化するために使う状態。
    /// </summary>
    public enum SortItemState
    {
        Inactive,
        Active,
        Compare,
        Swap,
    }

    /// <summary>
    /// ソートの視覚化用に、値と状態のペアを持つクラス。
    /// </summary>
    public class SortItem : INotifyPropertyChanged
    {
        /// <summary>
        /// 0初期化。
        /// </summary>
        public SortItem() : this(0) { }

        /// <summary>
        /// 値を指定して初期化。
        /// </summary>
        /// <param name="value">値。</param>
        public SortItem(int value)
        {
            value_ = value;
        }

        int value_ = 0;

        /// <summary>
        /// 値。
        /// </summary>
        public int Value
        {
            get
            {
                return value_;
            }
            set
            {
                value_ = value;
                this.Notify("Value");
            }
        }

        SortItemState state_ = 0;

        /// <summary>
        /// 状態。
        /// </summary>
        public SortItemState State
        {
            get
            {
                return state_;
            }
            set
            {
                state_ = value;
                this.Notify("VisualType");
            }
        }

        #region INotifyPropertyChanged メンバ

        void Notify(string propertyName)
        {
            var f = this.PropertyChanged;
            if (f != null)
                f(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

    //public class SortTargetConverter : IValueConverter
    //{
    //    public static readonly Color[] ColorTable = new[]
    //    {
    //        Colors.Gray,
    //        Colors.Blue,
    //        Colors.Red,
    //        Colors.Purple,
    //        Colors.Green,
    //        Colors.Yellow,
    //        Colors.Cyan,
    //        Colors.Magenta,
    //        Colors.Orange,
    //    };

    //    public static readonly Brush[] BrushTable = ColorTable.Select(x => new SolidColorBrush(x)).ToArray();

    //    public const double SIZE = 8;
    //    public const double MARGIN = 0;

    //    public static UIElement Convert(SortTarget t)
    //    {
    //        var x = new Ellipse
    //        {
    //            Fill = BrushTable[t.VisualType],
    //            Width = SIZE,
    //            Height = SIZE,
    //            RenderTransform = new TranslateTransform
    //            {
    //                X = t.Value * (SIZE + MARGIN),
    //                //Y = t.Position * (SIZE + MARGIN),
    //            },
    //        };

    //        return x;
    //    }

    //    public object Convert(object value, System.Type targetType,
    //      object parameter, System.Globalization.CultureInfo culture)
    //    {
    //        var t = value as SortTarget;

    //        if (t == null) return null;

    //        return Convert(t);
    //    }

    //    public object ConvertBack(object value, System.Type targetType,
    //      object parameter, System.Globalization.CultureInfo culture)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}

}
