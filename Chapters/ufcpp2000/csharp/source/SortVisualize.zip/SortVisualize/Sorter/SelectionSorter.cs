﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// 選択ソート。
    /// </summary>
    public class SelectionSorter : Sorter
    {
        public override string Name
        {
            get { return "選択ソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            var a = Target;

            int n = a.Length;
            for (int i = 0; i < n; i++)
            {
                a[i].State = SortItemState.Active;

                var min = i;
                for (int j = i + 1; j < n; j++)
                {
                    a[j].State = SortItemState.Compare;
                    yield return null;

                    if (a[min].Value > a[j].Value)
                    {
                        if (min != i)
                            a[min].State = SortItemState.Inactive;
                        min = j;
                        if (min != i)
                            a[min].State = SortItemState.Active;
                    }
                    if (j != min)
                        a[j].State = SortItemState.Inactive;
                }
                a[i].State = SortItemState.Swap;
                a[min].State = SortItemState.Swap;
                yield return null;

                Swap(ref a[i], ref a[min]);

                a[i].State = SortItemState.Inactive;
                a[min].State = SortItemState.Inactive;
            }
            yield return null;
        }
    }
}
