﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// 挿入ソート。
    /// </summary>
    public class InsertionSorter : Sorter
    {
        public override string Name
        {
            get { return "挿入ソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            var a = Target;
            int n = a.Length;
            for (int i = 1; i < n; i++)
            {
                for (int j = i; j >= 1 && a[j - 1].Value > a[j].Value; --j)
                {
                    a[j].State = SortItemState.Compare;
                    a[j - 1].State = SortItemState.Compare;
                    yield return null;

                    a[j].State = SortItemState.Swap;
                    a[j - 1].State = SortItemState.Swap;
                    yield return null;

                    Swap(ref a[j], ref a[j - 1]);

                    a[j].State = SortItemState.Inactive;
                    a[j - 1].State = SortItemState.Inactive;
                }
            }

            yield return null;
        }
    }
}
