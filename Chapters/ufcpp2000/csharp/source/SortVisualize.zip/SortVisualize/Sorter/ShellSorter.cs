﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// シェルソート。
    /// </summary>
    public class ShellSorter : Sorter
    {
        public override string Name
        {
            get { return "シェルソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            var a = Target;
            int n = a.Length;
            int h;
            for (h = 1; h < n / 9; h = h * 3 + 1) ;
            for (; h > 0; h /= 3)
            {
                for (int i = 0; i < n; i += h)
                {
                    a[i].State = SortItemState.Active;
                }

                for (int i = h; i < n; i++)
                {
                    for (int j = i; j >= h && a[j - h].Value > a[j].Value; j -= h)
                    {
                        a[j].State = SortItemState.Compare;
                        a[j - h].State = SortItemState.Compare;
                        yield return null;

                        a[j].State = SortItemState.Swap;
                        a[j - h].State = SortItemState.Swap;
                        yield return null;

                        Swap(ref a[j], ref a[j - h]);

                        a[j].State = SortItemState.Inactive;
                        a[j - h].State = SortItemState.Inactive;
                    }
                }

                for (int i = 0; i < n; i += h)
                {
                    a[i].State = SortItemState.Inactive;
                }
            }

            yield return null;
        }
    }
}
