﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// バブルソート。
    /// </summary>
    public class BubbleSorter : Sorter
    {
        public override string Name
        {
            get { return "バブルソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            var a = Target;

            int n = a.Length;
            for (int i = 0; i < n - 1; i++)
            {
                a[i].State = SortItemState.Active;

                for (int j = n - 1; j > i; j--)
                {
                    a[j].State = SortItemState.Compare;
                    a[j - 1].State = SortItemState.Compare;
                    yield return null;

                    if (a[j].Value < a[j - 1].Value)
                    {
                        a[j].State = SortItemState.Swap;
                        a[j - 1].State = SortItemState.Swap;
                        yield return null;

                        Swap(ref a[j], ref a[j - 1]);
                    }
                    a[j].State = SortItemState.Inactive;
                    a[j - 1].State = SortItemState.Inactive;
                }

                a[i].State = 0;
            }
            yield return null;
        }
    }
}
