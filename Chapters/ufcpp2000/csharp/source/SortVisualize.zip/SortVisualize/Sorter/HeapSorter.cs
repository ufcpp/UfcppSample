﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// ヒープソート。
    /// </summary>
    public class HeapSorter : Sorter
    {
        public override string Name
        {
            get { return "ヒープソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            var a = Target;
            for (int i = 1; i < a.Length; ++i)
                foreach (var x in MakeHeap(i)) yield return null;
            for (int i = a.Length - 1; i >= 0; --i)
                foreach (var x in PopHeap(i)) yield return null;

            yield return null;
        }

        IEnumerable<object> MakeHeap(int n)
        {
            var a = Target;
            while (n != 0)
            {
                int i = (n - 1) / 2;

                a[i].State = SortItemState.Compare;
                a[n].State = SortItemState.Compare;
                yield return null;

                if (a[n].Value > a[i].Value)
                {
                    a[i].State = SortItemState.Swap;
                    a[n].State = SortItemState.Swap;
                    yield return null;

                    Swap(ref a[n], ref a[i]);
                }
                a[i].State = SortItemState.Inactive;
                a[n].State = SortItemState.Inactive;

                n = i;
            }
        }

        IEnumerable<object> PopHeap(int n)
        {
            var a = Target;
            var max = a[0];

            Swap(ref a[0], ref a[n]);

            for (int i = 0, j; (j = 2 * i + 1) < n; )
            {
                a[j].State = SortItemState.Compare;
                a[j + 1].State = SortItemState.Compare;
                yield return null;

                a[j].State = SortItemState.Inactive;
                a[j + 1].State = SortItemState.Inactive;

                if ((j != n - 1) && (a[j].Value < a[j + 1].Value)) j++;

                a[i].State = SortItemState.Compare;
                a[j].State = SortItemState.Compare;
                yield return null;

                if (a[i].Value < a[j].Value)
                {
                    a[i].State = SortItemState.Swap;
                    a[j].State = SortItemState.Swap;
                    yield return null;

                    Swap(ref a[i], ref a[j]);
                }

                a[i].State = SortItemState.Inactive;
                a[j].State = SortItemState.Inactive;

                i = j;
            }

            a[n].State = SortItemState.Swap;
            yield return null;

            Swap(ref a[n], ref max);

            a[n].State = SortItemState.Inactive;
        }
    }
}
