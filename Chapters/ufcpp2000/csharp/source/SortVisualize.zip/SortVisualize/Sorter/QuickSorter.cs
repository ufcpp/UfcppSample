﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// クイックソート。
    /// </summary>
    public class QuickSorter : Sorter
    {
        public override string Name
        {
            get { return "クイックソート"; }
        }

        protected override IEnumerator<object> DoSort()
        {
            foreach (var x in DoSort(Target, 0, Target.Length - 1)) yield return null;
            yield return null;
        }

        static IEnumerable<object> DoSort(SortItem[] a, int first, int last)
        {
            if (first == last)
            {
                yield break;
            }

            var pivot = Median(a[first].Value, a[(first + last) / 2].Value, a[last].Value);

            int l = first;
            int r = last;

            for (int i = first; i <= last; i++)
            {
                a[i].State = SortItemState.Active;
            }

            while (l <= r)
            {
                a[l].State = SortItemState.Compare;
                a[r].State = SortItemState.Compare;

                while (a[l].Value < pivot && l < last)
                {
                    a[l].State = SortItemState.Compare;
                    yield return null;
                    a[l].State = SortItemState.Inactive;
                    l++;
                }
                while (a[r].Value >= pivot && r > first)
                {
                    a[r].State = SortItemState.Compare;
                    yield return null;
                    a[r].State = SortItemState.Inactive;

                    r--;
                }
                if (l > r)
                {
                    break;
                }

                a[l].State = SortItemState.Swap;
                a[r].State = SortItemState.Swap;
                yield return null;

                Swap(ref a[l], ref a[r]);

                a[l].State = SortItemState.Active;
                a[r].State = SortItemState.Active;

                l++; r--;
            }

            for (int i = first; i <= last; i++)
            {
                a[i].State = SortItemState.Inactive;
            }

            if (first < l)
                foreach (var x in DoSort(a, first, l - 1)) yield return null;
            if (last > l)
                foreach (var x in DoSort(a, l, last)) yield return null;
        }

        static int Median(int a, int b, int c)
        {
            if (a > b) { var t = a; a = b; b = t; }
            if (a > c) { var t = a; a = c; c = t; }
            if (b > c) { var t = b; b = c; c = t; }
            return b;
        }
    }
}
