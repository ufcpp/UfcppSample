﻿using System.Collections.Generic;

namespace SortVisualize.Sorter
{
    /// <summary>
    /// ソートの視覚化用に、ソートを1ステップずつ実行するクラスの基底。
    /// </summary>
    /// <remarks>
    /// ソートの実体は、サブクラスで DoSort メソッドを実装する。
    /// 1ステップずつ実行するために、イテレーターブロックを使って、処理を中断したい個所に yield return null を挟む。
    /// ガイドライン： yield return null は要素の比較とスワップを行う直前に入れる。
    /// </remarks>
    public abstract class Sorter
    {
        /// <summary>
        /// ソート対象となる配列。
        /// </summary>
        public SortItem[] Target { set; get; }

        IEnumerator<object> e_;
        bool done_ = false;

        /// <summary>
        /// 初期化。
        /// </summary>
        public Sorter()
        {
            this.Reset();
        }

        /// <summary>
        /// ソートの状態を初期状態に戻す。
        /// </summary>
        public void Reset()
        {
            e_ = this.DoSort();
            done_ = false;
        }

        /// <summary>
        /// 1ステップずつソートを実行。
        /// </summary>
        /// <returns>ソートが完了しているなら true</returns>
        public bool DoSortStep()
        {
            if (!done_)
                done_ = !e_.MoveNext();

            return done_;
        }

        /// <summary>
        /// ソートの実体。
        /// </summary>
        /// <returns>ダミー。使わない。</returns>
        protected abstract IEnumerator<object> DoSort();

        /// <summary>
        /// ソートの種名。
        /// </summary>
        public abstract string Name { get; }

        /// <summary>
        /// SortItem 同士のスワップ。
        /// </summary>
        /// <param name="x">要素1。</param>
        /// <param name="y">要素2。</param>
        public static void Swap(ref SortItem x, ref SortItem y)
        {
            var t2 = x;
            x = y;
            y = t2;
        }

        /// <summary>
        /// 状態のリセット。
        /// Target の全要素の状態を Inactive に戻す。
        /// </summary>
        protected void ResetState()
        {
            foreach (var x in Target)
            {
                x.State = SortItemState.Inactive;
            }
        }

        public static Sorter[] ListUp(SortItem[] target)
        {
            var s = new Sorter[]
            {
                new BubbleSorter(),
                new SelectionSorter(),
                new InsertionSorter(),
                new ShellSorter(),
                new HeapSorter(),
                new QuickSorter(),
            };
            foreach (var x in s) x.Target = target;

            return s;
        }
    }
}
