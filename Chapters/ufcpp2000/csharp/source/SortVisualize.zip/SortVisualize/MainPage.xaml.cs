﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SortVisualize
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        //SortItem[] target_;
        DispatcherTimer timer_;
        Sorter.Sorter[] sorter_;
        Sorter.Sorter selectedSorter_;

        SortVisualizer visualizer_;

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            var rnd = new Random();

            visualizer_ = new SortVisualizer(this.MainCanvas);

            sorter_ = Sorter.Sorter.ListUp(visualizer_.Target);

            SorterCombo.ItemsSource = sorter_;
            SorterCombo.SelectedIndex = 0;
            SorterCombo.SelectionChanged += new SelectionChangedEventHandler(SorterCombo_SelectionChanged);

            selectedSorter_ = sorter_[0];
            this.visualizer_.UpdateItems();

            timer_ = new DispatcherTimer();
            timer_.Interval = new TimeSpan(0, 0, 0, 0, 10);
            timer_.Tick += new EventHandler(timer_Tick);
            timer_.Start();
        }

        void SorterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var s = SorterCombo.SelectedItem as Sorter.Sorter;

            if (s == null)
                return;

            visualizer_.Randamize();
            s.Reset();
            selectedSorter_ = s;
        }

        void timer_Tick(object sender, EventArgs e)
        {
            var rnd = new Random();

            selectedSorter_.DoSortStep();
            this.visualizer_.UpdateItems();
        }
    }
}
