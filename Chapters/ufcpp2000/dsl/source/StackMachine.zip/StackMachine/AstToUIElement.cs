﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace StackMachine
{
    public class AstToUIElement
    {
        public static UIElement Convert(Ast.Node node)
        {
            switch (node.GetType().Name)
            {
                case "Constant": { var x = node as Ast.Constant; return Convert(x); }
                case "Parameter": { var x = node as Ast.Parameter; return Convert(x); }
                case "UnaryExpression": { var x = node as Ast.UnaryExpression; return Convert(x); }
                case "BinaryExpression": { var x = node as Ast.BinaryExpression; return Convert(x); }
                case "ConditionalExpression": { var x = node as Ast.ConditionalExpression; return Convert(x); }
                case "Call": { var x = node as Ast.Call; return Convert(x); }
                case "Assignment": { var x = node as Ast.Assignment; return Convert(x); }
                case "Function": { var x = node as Ast.Function; return Convert(x); }
                case "Return": { var x = node as Ast.Return; return Convert(x); }
                case "Block": { var x = node as Ast.Block; return Convert(x); }
            }

            return null;
        }

        static UIElement Convert(Ast.Block x)
        {
            return MakeContent(
                Convert(x.Statements, Orientation.Vertical),
                Color.FromArgb(255, 128, 255, 0));
        }

        static UIElement Convert(Ast.Return x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    MakeText("return"),
                    Convert(x.Expression)
                ),
                Color.FromArgb(255, 128, 255, 128));
        }

        static UIElement Convert(Ast.Function x)
        {
            return MakeContent(
                MakeStack(
                    MakeStack(
                        Orientation.Horizontal,
                        MakeText(string.Format("{0}(", x.Name)),
                        Convert(x.Arguments),
                        MakeText(")")),
                    MakeText("{"),
                    Convert(x.Body),
                    MakeText("}")
                ),
                Color.FromArgb(255, 255, 255, 0));
        }

        static UIElement Convert(Ast.Assignment x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    MakeText(string.Format("{0} = ", x.Variable.Name)),
                    Convert(x.Expression)
                ),
                Color.FromArgb(255, 0, 255, 0));
        }

        static UIElement Convert(Ast.Call x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    MakeText(string.Format("{0}(", x.Name)),
                    Convert(x.Parameters),
                    MakeText(")")
                ),
                Color.FromArgb(255, 255, 128, 0));
        }

        static StackPanel Convert<T>(IEnumerable<T> list)
            where T: Ast.Node
        {
            return Convert(list, Orientation.Horizontal);
        }

        static StackPanel Convert<T>(IEnumerable<T> list, Orientation orientation)
            where T : Ast.Node
        {
            return MakeStack(
                orientation,
                list.Select(x => Convert(x)));
        }

        static UIElement Convert(Ast.ConditionalExpression x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    MakeText("if"),
                    Convert(x.Condition),
                    MakeText("then"),
                    Convert(x.TrueExpression),
                    MakeText("else"),
                    Convert(x.FalseExpression)
                ),
                Color.FromArgb(255, 255, 128, 128));
        }

        static UIElement Convert(Ast.BinaryExpression x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    Convert(x.Left),
                    MakeText(Operator(x.Operator)),
                    Convert(x.Right)
                ),
                Color.FromArgb(255, 0, 255, 255));
        }

        static UIElement Convert(Ast.UnaryExpression x)
        {
            return MakeContent(
                MakeStack(
                    Orientation.Horizontal,
                    MakeText(Operator(x.Operator)),
                    Convert(x.Operand)
                ),
                Color.FromArgb(255, 0, 0, 255));
        }

        static UIElement Convert(Ast.Parameter x)
        {
            return MakeContent(x.Name, Color.FromArgb(255, 196, 128, 196));
        }

        static UIElement Convert(Ast.Constant x)
        {
            return MakeContent(x.Value.ToString(), Color.FromArgb(255, 128, 128, 128));
        }

        static readonly Thickness gridMargin = new Thickness(5);
        static readonly Thickness textMargin = new Thickness(3);

        static TextBlock MakeText(string text)
        {
            return new TextBlock { Text = text, Margin = textMargin };
        }

        static StackPanel MakeStack(params UIElement[] children)
        {
            return MakeStack(Orientation.Vertical, (IEnumerable<UIElement>)children);
        }

        static StackPanel MakeStack(IEnumerable<UIElement> children)
        {
            return MakeStack(Orientation.Vertical, children);
        }

        static StackPanel MakeStack(Orientation orientation, params UIElement[] children)
        {
            return MakeStack(orientation, (IEnumerable<UIElement>)children);
        }

        static StackPanel MakeStack(Orientation orientation, IEnumerable<UIElement> children)
        {
            var s = new StackPanel { Orientation = orientation };
            foreach (var c in children)
            {
                s.Children.Add(c);
            }
            return s;
        }

        public static Grid MakeContent(string content, Color color)
        {
            return MakeContent(MakeText(content), color);
        }

        public static Grid MakeContent(object content, Color color)
        {
            var fill = Design.CreateBrush(color);
            var stroke = new SolidColorBrush(color);

            return new Grid
            {
                Children =
                {
                    new Rectangle
                    {
                        RadiusX = 5,
                        RadiusY = 5,
                        Fill = fill,
                        Stroke = stroke,
                        StrokeThickness = 1,
                    },
                    new ContentControl
                    {
                        Content = content,
                    }
                },
                Margin = gridMargin,
            };
        }

        static string Operator(Ast.OperatorType opType)
        {
            switch (opType)
            {
                case Ast.OperatorType.Plus: return "+";
                case Ast.OperatorType.Minus: return "⁻";
                case Ast.OperatorType.Multiply: return "×";
                case Ast.OperatorType.Divide: return "÷";
                case Ast.OperatorType.Equal: return "=";
                case Ast.OperatorType.NotEqual: return "≠";
                case Ast.OperatorType.LessThan: return "＜";
                case Ast.OperatorType.GreaterThan: return "＞";
                case Ast.OperatorType.LessEqual: return "≦";
                case Ast.OperatorType.GreaterEqual: return "≧";
                case Ast.OperatorType.And: return "∧";
                case Ast.OperatorType.Or: return "∨";
            }
            return null;
        }
    }
}
