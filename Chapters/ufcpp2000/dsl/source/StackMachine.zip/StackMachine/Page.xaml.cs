﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace StackMachine
{
    public partial class Page : UserControl
    {
        StackMachine.Emurator.Machine stack;

        public Page()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Page_Loaded);
            this.runButton.Click += new RoutedEventHandler(runButton_Click);
            this.resetButton.Click += new RoutedEventHandler(resetButton_Click);

            this.editButton.Click += new RoutedEventHandler(editButton_Click);
            this.okButton.Click += new RoutedEventHandler(okButton_Click);
            this.cancelButton.Click += new RoutedEventHandler(cancelButton_Click);
        }

        void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.editPane.Visibility = Visibility.Collapsed;
        }

        void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.Compile(this.sourceText.Text);

            this.editPane.Visibility = Visibility.Collapsed;
        }

        void editButton_Click(object sender, RoutedEventArgs e)
        {
            this.sourceText.Text = this.source.Text;
            this.editPane.Visibility = Visibility.Visible;
            this.sourceText.Focus();
        }

        void resetButton_Click(object sender, RoutedEventArgs e)
        {
            this.stack.Reset();

            this.UpdateStackMachineInfo();
        }

        void runButton_Click(object sender, RoutedEventArgs e)
        {
            this.stack.Run();

            this.UpdateStackMachineInfo();
        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.lastOperation.Background = Design.CreateBrush(Color.FromArgb(255, 196, 196, 196));


            const string sampleSource = 
@"let factorial(x) = x > 1 ? x * factorial(x - 1) : 1;
let sum(n) = n * (n + 1 ) / 2;
let n = 5;
let x = factorial(n);
let y = sum(n);
(x + y) * x * y;
";

            Compile(sampleSource);
        }

        private void Compile(string source)
        {
            this.source.Text = source;
            this.errorText.Text = string.Empty;

            Ast.Node root;

            try
            {
                var parser = new Compiler.Parser(source);
                root = parser.Parse();
                this.tree.Content = AstToUIElement.Convert(root);

                int xxx = 0; xxx++;
            }
            catch (StackMachine.Compiler.ParseException exc)
            {
                this.errorText.Text = exc.Message;
                return;
            }

            IEnumerable<Emurator.Instruction> inst;

            try
            {
                inst = root.Compile();
                this.instructions.ItemsSource = inst.Select((x, i) => string.Format("{0:00}: {1}", i, x.ToString()));
            }
            catch (Exception exc)
            {
                this.errorText.Text = exc.Message;
                return;
            }

            this.stack = new StackMachine.Emurator.Machine(inst);

            UpdateStackMachineInfo();
        }

        private void UpdateStackMachineInfo()
        {
            this.instructions.SelectedIndex = this.stack.ProgramCounter;
            this.basePointer.Text = string.Format("base pointer: {0}", this.stack.BasePointer);
            this.stackPointer.Text = string.Format("stack pointer: {0}", this.stack.StackPointer);
            this.lastOperation.Text = this.stack.LastOperation;

            this.stackView.ItemsSource = this.stack.Stack
                .Select((x, i) =>
                    new TextBlock
                    {
                        Text = string.Format("{0:00}: {2,8} ({1})", i, x.Usage, x.Value),
                        Foreground = new SolidColorBrush(Design.bgColors[x.NestLevel & Design.bgColors.Length]),
                    });

            //forDebug
            //this.basePointer.Text = AstToUIElement.Test().Name;
        }
    }
}
