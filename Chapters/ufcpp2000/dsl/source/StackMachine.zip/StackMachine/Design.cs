﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows;

namespace StackMachine
{
    public class Design
    {
        public static readonly Color[] bgColors = new[]
            {
                Color.FromArgb(255, 0,0,0),
                //Color.FromArgb(255, 128,0,0),
                //Color.FromArgb(255, 96,96,0),
                //Color.FromArgb(255, 0,128,0),
                //Color.FromArgb(255, 0,96,96),
                //Color.FromArgb(255, 0,0,128),
                //Color.FromArgb(255, 96,0,96),
                Color.FromArgb(255, 255,0,0),
                Color.FromArgb(255, 192,192,0),
                Color.FromArgb(255, 0,255,0),
                Color.FromArgb(255, 0,192,192),
                Color.FromArgb(255, 0,0,255),
                Color.FromArgb(255, 192,192,0),
            };

        private const double Rate = 0.8;

        private static byte Medium(byte r, byte g, byte b)
        {
            int max = Math.Max(Math.Max(r, g), b);
            int min = Math.Min(Math.Min(r, g), b);
            int m = max + min;

            return (byte)(m / 2);
        }

        private static byte Average(byte x, byte y, double rate)
        {
            var m = rate * x + (1 - rate) * y;
            return (byte)m;
        }

        private static Color Whiten(Color c)
        {
            var m = Medium(c.R, c.G, c.B);

            var r = Average(c.R, m, 0.2);
            var g = Average(c.G, m, 0.2);
            var b = Average(c.B, m, 0.2);

            return Color.FromArgb(255, r, g, b);
        }

        private static Color Brighter(Color c)
        {
            var r = (byte)(255 - Rate * (255 - c.R));
            var g = (byte)(255 - Rate * (255 - c.G));
            var b = (byte)(255 - Rate * (255 - c.B));
            return Color.FromArgb(255, r, g, b);
        }

        private static Color Darker(Color c)
        {
            var r = (byte)(Rate * (c.R));
            var g = (byte)(Rate * (c.G));
            var b = (byte)(Rate * (c.B));
            return Color.FromArgb(255, r, g, b);
        }

        public static Brush CreateBrush(Color c)
        {
            c = Whiten(c);
            var d = Brighter(c);
            c = Brighter(d);
            var b = Brighter(c);
            return new LinearGradientBrush
                {
                    GradientStops = {
                        new GradientStop { Color = b, Offset = 0 },
                        new GradientStop { Color = b, Offset = 0.1 },
                        new GradientStop { Color = c, Offset = 0.5 },
                        new GradientStop { Color = d, Offset = 0.9 },
                        new GradientStop { Color = d, Offset = 1 },
                    },
                    StartPoint = new Point(0, 0),
                    EndPoint = new Point(1, 1),
                };
        }

        public static Brush CreateBrushV(Color c) // 縦方向のグラデーション
        {
            var b = Brighter(c);
            var d = Darker(c);
            return new LinearGradientBrush
            {
                GradientStops = {
                        new GradientStop { Color = b, Offset = 0 },
                        new GradientStop { Color = b, Offset = 0.1 },
                        new GradientStop { Color = c, Offset = 0.5 },
                        new GradientStop { Color = d, Offset = 0.9 },
                        new GradientStop { Color = d, Offset = 1 },
                    },
                StartPoint = new Point(0, 0),
                EndPoint = new Point(0, 1),
            };
        }
    }
}
