﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StackMachine
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        static readonly Color[] bgColors = new[]
            {
                Color.FromArgb(255, 0,0,0),
                //Color.FromArgb(255, 128,0,0),
                //Color.FromArgb(255, 96,96,0),
                //Color.FromArgb(255, 0,128,0),
                //Color.FromArgb(255, 0,96,96),
                //Color.FromArgb(255, 0,0,128),
                //Color.FromArgb(255, 96,0,96),
                Color.FromArgb(255, 255,0,0),
                Color.FromArgb(255, 192,192,0),
                Color.FromArgb(255, 0,255,0),
                Color.FromArgb(255, 0,192,192),
                Color.FromArgb(255, 0,0,255),
                Color.FromArgb(255, 192,192,0),
            };

        public Window1()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Window1_Loaded);
        }

        void Window1_Loaded(object sender, RoutedEventArgs e)
        {
            //this.TestTokenizer();
//            const string test = @"
//let x = 1;
//let y = x > 0 ? x : 0;
//let z = 1 + 2 < 4 * 3 & 5 == 5;
//1 > 4 & x != 1 | y == 0 & z == 0;
//let f(x, y) = -1 + x * y;
//let g(x)
//{
//    let y = x * x;
//    1 * 2 - f(3, 4) * +y;
//}
//let v = 3;
//let w = (1 + 2) * (x - 5) * f(1 + 2, 4 / 2);
//(x);
//+(-(-x) / -4);
//-5;
//";
            const string test = @"
let factorial(x) = x > 1 ? x * factorial(x - 1) : 1;
let sum(n) = n * (n + 1 ) / 2;
let n = 5;
let x = factorial(n);
let y = sum(n);
(x + y) * x * y;
";
//            const string test = @"
//let sum(n) = n * (n + 1 ) / 2;
//let x = sum(5);
//let y = sum(8);
//let z = sum(12);
//x + y + z;
//";
            Ast.Node root;

            try
            {
                var parser = new Compiler.Parser(test);
                root = parser.Parse();
                this.tree.Content = root;

                int xxx = 0; xxx++;
            }
            catch (Exception)
            {
                int yyy = 0; ++yyy;
                return;
            }

            IEnumerable<Emurator.Instruction> inst;

            try
            {
                inst = root.Compile();
                this.instructions.ItemsSource = inst.Select((x, i) => string.Format("{0:00}: {1}", i, x.ToString()));
            }
            catch (Exception)
            {
                int yyy = 0; ++yyy;
                return;
            }

            this.stack = new StackMachine.Emurator.Machine(inst);
            this.instructions.SelectedIndex = this.stack.ProgramCounter;

            this.tree.MouseDown += new MouseButtonEventHandler(Window1_MouseDown);
        }

        Emurator.Machine stack;

        void Window1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.stack.Run();

            this.instructions.SelectedIndex = this.stack.ProgramCounter;
            this.lastOperation.Text = this.stack.LastOperation;
            this.stackView.ItemsSource = this.stack.Stack
                .Select((x, i) => 
                    new TextBlock
                    {
                        Text = string.Format("{0:00}: {2,8} ({1})", i, x.Usage, x.Value),
                        Foreground = new SolidColorBrush(bgColors[x.NestLevel & bgColors.Length]),
                    });
        }

        private void TestTokenizer()
        {
            const string test = @"
let f(x, y) = x * y;
let g(x, y, z)
{
    let f(x, y) = x + y;
    let t = f(x, y);
    z * t;
}

let x = 1 + 2 * 3;
let y = (-3 + 2 * 4) * f(1, 2);
let z = g(x, y, 10);

x + y + z;

;;;
";
            var tokenizer = new Compiler.Tokenizer(test);

            StringBuilder sb = new StringBuilder();

            try
            {
                for (; tokenizer.HasToken(); tokenizer.MoveNext())
                {
                    var c = tokenizer.Current;
                    sb.Append(c.Value);

                    if (c.Value == ";" || c.Value == "}" || c.Value == "{")
                        sb.AppendLine();
                    else
                        sb.Append(" ");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

            //this.text.Text = sb.ToString();
        }
    }
}
