﻿using StackMachine.Compiler;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;

namespace StackMachineTestProject
{
    
    
    /// <summary>
    ///TokenizerTest のテスト クラスです。すべての
    ///TokenizerTest 単体テストをここに含めます
    ///</summary>
    [TestClass()]
    public class TokenizerTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///現在のテストの実行についての情報および機能を
        ///提供するテスト コンテキストを取得または設定します。
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region 追加のテスト属性
        // 
        //テストを作成するときに、次の追加属性を使用することができます:
        //
        //クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //各テストを実行する前にコードを実行するには、TestInitialize を使用
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //各テストを実行した後にコードを実行するには、TestCleanup を使用
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///Tokenize のテスト
        ///</summary>
        [TestMethod()]
        public void TokenizeTest()
        {
            string source = @"
let x = 1 ;
let y = x > 0 ? x : 0;
let z=1+2<4*3&5==5;
1>4&x!=1|y == 0 & z == 0;
let f(x, y) = -1 + x * y;
let g(x)
{
    let y =
x * x;
    1 * 2 - f(3, 4) * +y;
}
let v = 3;
let w = (1 + 2) * (x - 5) * f(1 + 2, 4 / 2);
(x);
+(-(-x) / -4);
-5;
";
            string spacedSource = @"
let x = 1 ;
let y = x > 0 ? x : 0 ;
let z = 1 + 2 < 4 * 3 & 5 == 5 ;
1 > 4 & x != 1 | y == 0 & z == 0 ;
let f ( x , y ) = - 1 + x * y ;
let g ( x )
{
    let y = x * x ;
    1 * 2 - f ( 3 , 4 ) * + y ;
}
let v = 3 ;
let w = ( 1 + 2 ) * ( x - 5 ) * f ( 1 + 2 , 4 / 2 ) ;
( x ) ;
+ ( - ( - x ) / - 4 ) ;
- 5 ; 
";
            Regex whitespace = new Regex(@"[\s\n\r]+", RegexOptions.Multiline);

            var expected = whitespace.Split(spacedSource).Where(x => !string.IsNullOrEmpty(x)).ToArray();
            IEnumerable<Token> actual;
            actual = Tokenizer.Tokenize(source);

            var a = actual.Select(x => x.Value).ToArray();

            Assert.AreEqual(expected.Length, a.Length);

            for (int i = 0; i < a.Length; i++)
            {
                Assert.AreEqual(expected[i], a[i]);
            }
        }
    }
}
