﻿using StackMachine.Compiler;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StackMachine.Ast;
using AstNode = StackMachine.Ast.Node;
using System.Text;

namespace StackMachineTestProject
{
    
    
    /// <summary>
    ///ParserTest のテスト クラスです。すべての
    ///ParserTest 単体テストをここに含めます
    ///</summary>
    [TestClass()]
    public class ParserTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///現在のテストの実行についての情報および機能を
        ///提供するテスト コンテキストを取得または設定します。
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region 追加のテスト属性
        // 
        //テストを作成するときに、次の追加属性を使用することができます:
        //
        //クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //各テストを実行する前にコードを実行するには、TestInitialize を使用
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //各テストを実行した後にコードを実行するには、TestCleanup を使用
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///Parse のテスト
        ///</summary>
        [TestMethod()]
        public void ParseTest()
        {
            ParseExpressionTest("1", AstNode.Constant(1));
            ParseExpressionTest("-15", AstNode.Constant(-15));
            ParseExpressionTest("x", AstNode.Parameter("x"), "x");

            ParseExpressionTest("x + 1", AstNode.Add(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x - 1", AstNode.Subtract(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x * 1", AstNode.Multiply(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x / 1", AstNode.Divide(AstNode.Parameter("x"), AstNode.Constant(1)), "x");

            ParseExpressionTest("x < 1", AstNode.LessThan(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x > 1", AstNode.GreaterThan(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x <= 1", AstNode.LessEqual(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x >= 1", AstNode.GreaterEqual(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x == 1", AstNode.Equal(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x != 1", AstNode.NotEqual(AstNode.Parameter("x"), AstNode.Constant(1)), "x");

            ParseExpressionTest("x & 1", AstNode.And(AstNode.Parameter("x"), AstNode.Constant(1)), "x");
            ParseExpressionTest("x | 1", AstNode.Or(AstNode.Parameter("x"), AstNode.Constant(1)), "x");

            //todo:
            // x + y + z
            // x * 2 + y * 3
            // let x = ...
            // 複文
            // 関数
            // 関数再帰呼び出し
            // 関数内関数

            //todo: Node に ToString() 欲しい。
        }

        void ParseTest(string source, StackMachine.Ast.Node expected)
        {
            Parser target = new Parser(source);
            Node actual;
            actual = target.Parse();
            Assert.AreEqual(expected, actual);
        }

        void ParseExpressionTest(string source, StackMachine.Ast.Expression expression)
        {
            var block = AstNode.Block(
                AstNode.Return(expression)
                );

            ParseTest(source + ";", block);
        }

        void ParseExpressionTest(string source, StackMachine.Ast.Expression expression, params string[] variables)
        {
            StringBuilder sb = new StringBuilder();

            var block = AstNode.Block();

            foreach (var v in variables)
            {
                sb.AppendFormat("let {0} = 0;", v);

                block.Statements.Add(AstNode.Assignment(v, AstNode.Constant(0)));
            }

            block.Statements.Add(AstNode.Return(expression));

            ParseTest(sb.ToString() + source + ";", block);
        }
    }
}
