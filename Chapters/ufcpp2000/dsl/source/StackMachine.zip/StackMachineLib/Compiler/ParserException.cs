﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StackMachine.Compiler
{
    /// <summary>
    /// 構文解析中に生じる例外。
    /// </summary>
    public class ParseException : Exception
    {
        /// <summary>
        /// どの字句を解析中に例外が生じたか。
        /// </summary>
        public Token CurrentToken { get; private set; }

        public ParseException(Token currentToken, string message) : base(message) { this.CurrentToken = currentToken; }
        public ParseException(Token currentToken, string message, Exception innerException) : base(message, innerException) { this.CurrentToken = currentToken; }
    }
}
