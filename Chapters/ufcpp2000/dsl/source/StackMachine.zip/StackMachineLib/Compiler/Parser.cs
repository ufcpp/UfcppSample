﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StackMachine.Compiler
{
    /// <summary>
    /// 構文解析器。
    /// </summary>
    public class Parser
    {
        Tokenizer tokenizer;

        /// <summary>
        /// ソースコードを渡して初期化。
        /// </summary>
        /// <param name="source">ソースコード。</param>
        public Parser(string source)
        {
            this.tokenizer = new Tokenizer(source);
        }

        /// <summary>
        /// 構文解析して抽象構文木を得る。
        /// </summary>
        /// <returns>抽象構文木。</returns>
        public Ast.Node Parse()
        {
            var block = new Ast.Block();
            var scope = new Scope();
            this.ParseBlock(block, scope);

            return block;
        }

        /// <summary>
        /// 文一覧をパース。
        /// </summary>
        /// <param name="block">結果格納先のASTノード。</param>
        /// <param name="scope">変数スコープ。</param>
        void ParseBlock(Ast.Block block, Scope scope)
        {
            while (true)
            {
                if (!ParseStatement(block, scope))
                    break;
            }
        }

        /// <summary>
        /// 単文をパース。
        /// </summary>
        /// <param name="block">結果格納先のASTノード。</param>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>正しくパースできたらtrue。</returns>
        bool ParseStatement(Ast.Block block, Scope scope)
        {
            if (!this.tokenizer.HasToken())
            {
                return false;
            }

            var c = this.tokenizer.Current;

            if (c.Value == "}")
            {
                return false;
            }

            // let: assignment or function
            if (this.ParseLet(block, scope))
            {
                return true;
            }

            // return: expression;
            Ast.Expression e = this.ParseExpression(scope);

            if (e == null)
            {
                throw this.UnexpectedToken();
            }

            block.Statements.Add(new Ast.Return
            {
                Expression = e,
            });

            if (!this.tokenizer.HasToken())
                throw UnexpectedEof();

            if (this.tokenizer.Current.Type == TokenType.Delimiter)
            {
                this.tokenizer.MoveNext();
                return true;
            }
            else
                throw this.UnexpectedToken();
        }

        /// <summary>
        /// let から始まる文（代入と関数定義）をパース。
        /// </summary>
        /// <param name="block">結果格納先のASTノード。</param>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>正しくパースできたらtrue。</returns>
        /// <remarks>
        /// 代入と関数定義のキーワード変えた方がパース楽だったなぁ。
        /// function f(x, y) { x + y}
        /// lambda g(x, y) = x + y;
        /// var x = 0;
        /// とかでもよかったかも。
        /// 
        /// 逆に、let すらなくすって選択肢もあるんだけど。
        /// = とか { の辺りまで字句の先読みするんなら、
        /// 実は let がなくても正しくパースできるんで。
        /// 宣言とか定義は一目で分かってほしかったんで、let だけは残す。
        /// </remarks>
        bool ParseLet(Ast.Block block, Scope scope)
        {
            if (this.tokenizer.Current.Type != TokenType.Let) return false;
            if (!this.tokenizer.HasToken(1) && this.tokenizer.Next(1).Type != TokenType.Identifier) return false;

            if (!this.tokenizer.HasToken(2)) return false;

            var name = this.tokenizer.Next(1).Value;

            if (scope.Contains(name))
                throw new ParseException(this.tokenizer.Current, string.Format("identifier {0} already defined", name));

            var token2 = this.tokenizer.Next(2);

            // assignment: let x = expression;
            if(token2.Type == TokenType.Equal)
            {
                this.tokenizer.MoveNext(3);

                Ast.Expression e = this.ParseExpression(scope);

                if (e == null)
                {
                    throw this.UnexpectedToken();
                }

                var p = new Ast.Parameter { Name = name };
                scope.AddLocal(p);

                block.Statements.Add(new Ast.Assignment
                {
                    Variable = p,
                    Expression = e,
                });

                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();

                if (this.tokenizer.Current.Type != TokenType.Delimiter)
                    throw this.UnexpectedToken();

                this.tokenizer.MoveNext();
                return true;
            }

            // function: let f (args) ...
            if (token2.Type == TokenType.Parenthesis && token2.Value == "(")
            {
                this.tokenizer.MoveNext(3);

                List<Ast.Parameter> list = new List<StackMachine.Ast.Parameter>();

                Scope innerScope = new Scope { Parent = scope };

                this.ParseArgumentList(list, innerScope);

                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();

                if (this.tokenizer.Current.Type != TokenType.Parenthesis || this.tokenizer.Current.Value != ")")
                    throw this.UnexpectedToken();

                this.tokenizer.MoveNext();

                var f = new Ast.Function
                {
                    Name = name,
                    Arguments = list,
                };
                scope.AddFunction(f);

                // body
                var body = new Ast.Block();

                if (this.tokenizer.Current.Type == TokenType.Parenthesis && this.tokenizer.Current.Value == "{")
                {
                    // let f(args) { body }
                    this.tokenizer.MoveNext();

                    this.ParseBlock(body, innerScope);

                    if (!this.tokenizer.HasToken())
                        throw UnexpectedEof();

                    if (this.tokenizer.Current.Type != TokenType.Parenthesis || this.tokenizer.Current.Value != "}")
                        throw this.UnexpectedToken();

                    this.tokenizer.MoveNext();
                }
                else if (this.tokenizer.Current.Type == TokenType.Equal)
                {
                    // let f(args) = expression
                    this.tokenizer.MoveNext();

                    Ast.Expression e = this.ParseExpression(innerScope);

                    if (e == null)
                    {
                        throw this.UnexpectedToken();
                    }

                    body.Statements.Add(new Ast.Return
                    {
                        Expression = e,
                    });

                    if (!this.tokenizer.HasToken())
                        throw UnexpectedEof();

                    if (this.tokenizer.Current.Type != TokenType.Delimiter)
                        throw this.UnexpectedToken();

                    this.tokenizer.MoveNext();
                }
                else
                    throw this.UnexpectedToken();

                f.Body = body;

                block.Statements.Add(f);

                return true;
            }

            return false;
        }

        /// <summary>
        /// 式のパース。
        /// </summary>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>パース結果のASTノード。正しくパースできない場合はnull。</returns>
        Ast.Expression ParseExpression(Scope scope)
        {
            return ParseConditionalExpression(scope);
        }

        /// <summary>
        /// 条件演算式のパース。
        /// </summary>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>パース結果のASTノード。正しくパースできない場合はnull。</returns>
        Ast.Expression ParseConditionalExpression(Scope scope)
        {
            Ast.Expression expression = this.ParseLogicalOrExpression(scope);

            if (expression == null) return null;

            if (!this.tokenizer.HasToken() || this.tokenizer.Current.Type != TokenType.Operator || this.tokenizer.Current.Value != "?")
                return expression;

            this.tokenizer.MoveNext();

            Ast.Expression trueExpression = this.ParseExpression(scope);

            if (trueExpression == null)
                throw this.UnexpectedToken();

            if (!this.tokenizer.HasToken() || this.tokenizer.Current.Type != TokenType.Operator || this.tokenizer.Current.Value != ":")
                throw this.UnexpectedToken();

            this.tokenizer.MoveNext();

            Ast.Expression falseExpression = this.ParseExpression(scope);

            if (falseExpression == null)
                throw this.UnexpectedToken();

            return new Ast.ConditionalExpression
                {
                    Condition = expression,
                    TrueExpression = trueExpression,
                    FalseExpression = falseExpression,
                };
        }

        #region 二項演算

        // 二項演算のパースはパターンがあるので ParseBinaryExpression メソッドで処理を共通化。

        Ast.Expression ParseLogicalOrExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "|", Ast.OperatorType.Or },
                },
                this.ParseLogicalAndExpression
                );
        }

        Ast.Expression ParseLogicalAndExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "&", Ast.OperatorType.And },
                },
                this.ParseEqualityExpression
                );
        }

        Ast.Expression ParseEqualityExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "==", Ast.OperatorType.Equal },
                    { "!=", Ast.OperatorType.NotEqual },
                },
                this.ParseRelationalExpression
                );
        }

        Ast.Expression ParseRelationalExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "<", Ast.OperatorType.LessThan },
                    { ">", Ast.OperatorType.GreaterThan },
                    { "<=", Ast.OperatorType.LessEqual },
                    { ">=", Ast.OperatorType.GreaterEqual },
                },
                this.ParseAdditiveExpression
                );
        }

        Ast.Expression ParseAdditiveExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "+", Ast.OperatorType.Plus },
                    { "-", Ast.OperatorType.Minus },
                },
                this.ParseMultiplicativeExpression
                );
        }

        Ast.Expression ParseMultiplicativeExpression(Scope scope)
        {
            return this.ParseBinaryExpression(
                scope,
                new Dictionary<string, StackMachine.Ast.OperatorType>
                {
                    { "*", Ast.OperatorType.Multiply },
                    { "/", Ast.OperatorType.Divide },
                },
                this.ParseUnaryExpression
                );
        }

        /// <summary>
        /// 二項演算式のパース。
        /// </summary>
        /// <param name="scope">変数スコープ。</param>
        /// <param name="opTable">演算子一覧。</param>
        /// <param name="subParser">サブ式のパーサー。</param>
        /// <returns>パース結果のASTノード。正しくパースできない場合はnull。</returns>
        /// <remarks>
        /// 要するに、
        /// syntax 加減 = 乗除 | 加減 '+' 乗除 | 加減 '-' 乗除;
        /// の場合だと、
        /// opTable には '+' と '-' を渡して、
        /// subParse には乗除をパースするためのデリゲートを渡す。
        /// </remarks>
        Ast.Expression ParseBinaryExpression(Scope scope, Dictionary<string, Ast.OperatorType> opTable, Func<Scope, Ast.Expression> subParser)
        {
            Ast.Expression expression = subParser(scope);

            while (true)
            {
                if (!this.tokenizer.HasToken() || this.tokenizer.Current.Type != TokenType.Operator)
                    return expression;

                Ast.OperatorType otype;

                if (!opTable.ContainsKey(this.tokenizer.Current.Value))
                    return expression;

                otype = opTable[this.tokenizer.Current.Value];

                this.tokenizer.MoveNext();

                Ast.Expression right = subParser(scope);

                expression = new Ast.BinaryExpression
                {
                    Operator = otype,
                    Left = expression,
                    Right = right,
                };

                if (right == null)
                    return expression;
            }
        }

        #endregion

        /// <summary>
        /// 単項演算式のパース。
        /// </summary>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>パース結果のASTノード。正しくパースできない場合はnull。</returns>
        Ast.Expression ParseUnaryExpression(Scope scope)
        {
            if (this.tokenizer.Current.Type == TokenType.Operator)
            {
                Ast.OperatorType otype;

                if (this.tokenizer.Current.Value == "+")
                    otype = Ast.OperatorType.Plus;
                else if (this.tokenizer.Current.Value == "-")
                    otype = Ast.OperatorType.Minus;
                else
                {
                    return null;
                }

                this.tokenizer.MoveNext();

                Ast.Expression inner = this.ParsePrimaryExpression(scope);

                if (inner.Type == StackMachine.Ast.NodeType.Constant)
                {
                    if (otype == StackMachine.Ast.OperatorType.Minus)
                    {
                        ((Ast.Constant)inner).Value *= -1;
                    }
                    return inner;
                }

                return new Ast.UnaryExpression
                    {
                        Operator = otype,
                        Operand = inner,
                    };
            }

            return this.ParsePrimaryExpression(scope);
        }

        /// <summary>
        /// 定数 | 変数 | 関数呼び出し | '(' 式 ')'
        /// </summary>
        /// <param name="scope">変数スコープ。</param>
        /// <returns>パース結果のASTノード。正しくパースできない場合はnull。</returns>
        Ast.Expression ParsePrimaryExpression(Scope scope)
        {
            if (this.tokenizer.Current.Type == TokenType.Integer)
            {
                // 定数

                var expression = new Ast.Constant
                {
                    Value = int.Parse(this.tokenizer.Current.Value),
                };

                this.tokenizer.MoveNext();

                return expression;
            }
            else if (this.tokenizer.Current.Type == TokenType.Identifier)
            {
                var name = this.tokenizer.Current.Value;

                if (this.tokenizer.HasToken(1))
                {
                    var next = this.tokenizer.Next(1);

                    if (next.Type == TokenType.Parenthesis && next.Value == "(")
                    {
                        // 関数呼び出し: f(式)
                        var f = scope.GetFunction(name);

                        if (f == null)
                            throw new ParseException(this.tokenizer.Current, string.Format("use undefined function {0}", name));

                        this.tokenizer.MoveNext(2);

                        var list = new List<Ast.Expression>();
                        this.ParseParameterList(list, scope);

                        if (this.tokenizer.Current.Type != TokenType.Parenthesis || this.tokenizer.Current.Value != ")")
                            throw this.UnexpectedToken();

                        this.tokenizer.MoveNext();

                        var c = new Ast.Call
                        {
                            Function = f,
                            Parameters = list,
                        };

                        return c;
                    }
                }

                // 変数

                var p = scope.GetVariable(name);

                if (p == null)
                    throw new ParseException(this.tokenizer.Current, string.Format("use undefined variable {0}", name));

                this.tokenizer.MoveNext();

                return p;
            }
            else if (this.tokenizer.Current.Type == TokenType.Parenthesis && this.tokenizer.Current.Value == "(")
            {
                // ( 式 )

                this.tokenizer.MoveNext();

                Ast.Expression inner = this.ParseExpression(scope);

                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();

                if (this.tokenizer.Current.Type != TokenType.Parenthesis || this.tokenizer.Current.Value != ")")
                    throw this.UnexpectedToken();

                this.tokenizer.MoveNext();

                return inner;
            }

            throw this.UnexpectedToken();
        }

        /// <summary>
        /// 仮引数リストをパース。
        /// let f(x, y) = x + y; の x, y の部分。
        /// </summary>
        /// <param name="list">結果格納先のリスト。</param>
        /// <param name="scope">変数スコープ。</param>
        void ParseArgumentList(List<Ast.Parameter> list, Scope scope)
        {
            if (!this.tokenizer.HasToken())
                throw UnexpectedEof();

            if (this.tokenizer.Current.Type == TokenType.Parenthesis && this.tokenizer.Current.Value == ")")
                return;

            while (true)
            {
                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();
                if (this.tokenizer.Current.Type != TokenType.Identifier)
                    throw this.UnexpectedToken();

                var p = new Ast.Parameter { Name = this.tokenizer.Current.Value };
                scope.AddArgument(p);

                list.Add(p);

                if (!this.tokenizer.HasToken(1))
                    throw UnexpectedEof();

                this.tokenizer.MoveNext();

                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();

                if (this.tokenizer.Current.Type == TokenType.Comma)
                {
                    this.tokenizer.MoveNext();
                    continue;
                }
                else
                    return;
            }
        }

        /// <summary>
        /// 実引数リストをパース。
        /// let x = f(1 + 2, 3 * 4); の 1 + 2, 3 * 4 の部分。
        /// </summary>
        /// <param name="list">結果格納先のリスト。</param>
        /// <param name="scope">変数スコープ。</param>
        void ParseParameterList(List<Ast.Expression> list, Scope scope)
        {
            if (!this.tokenizer.HasToken())
                throw UnexpectedEof();

            if (this.tokenizer.Current.Type == TokenType.Parenthesis && this.tokenizer.Current.Value == ")")
                return;

            while (true)
            {
                var e = this.ParseExpression(scope);

                list.Add(e);

                if (!this.tokenizer.HasToken())
                    throw UnexpectedEof();

                if (this.tokenizer.Current.Type == TokenType.Comma)
                {
                    this.tokenizer.MoveNext();
                    continue;
                }
                else
                    return;
            }
        }

        /// <summary>
        /// エラー。
        /// 予期しない字句が来ました。
        /// </summary>
        /// <returns>例外。</returns>
        ParseException UnexpectedToken()
        {
            var token = this.tokenizer.Current;

            return new ParseException(
                token,
                string.Format(
                    "Unexpected Token {0} at {1} (length {2})",
                    token.Value, token.Index, token.Length)
                );
        }

        /// <summary>
        /// エラー。
        /// 予期しないファイル終端が来ました。
        /// </summary>
        /// <returns>例外。</returns>
        ParseException UnexpectedEof()
        {
            return new ParseException(null, "Unexpected EOF");
        }
    }
}
