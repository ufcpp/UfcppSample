﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace StackMachine.Compiler
{
    /// <summary>
    /// 字句タイプ。
    /// </summary>
    public enum TokenType
    {
        Let,
        Identifier,
        Parenthesis,
        Integer,
        Operator,
        Delimiter,
        Equal,
        Comma,
        Invalid,
    }

    /// <summary>
    /// 字句。
    /// </summary>
    public class Token
    {
        /// <summary>
        /// 字句の中身。
        /// </summary>
        public string Value;

        /// <summary>
        /// ソースコードのどの位置にあるか。
        /// </summary>
        public int Index;

        /// <summary>
        /// 字句長。
        /// </summary>
        public int Length;

        /// <summary>
        /// 字句タイプ。
        /// </summary>
        public TokenType Type;
    }

    /// <summary>
    /// 字句解析器。
    /// </summary>
    public class Tokenizer
    {
        int current;
        Token[] tokens;

        /// <summary>
        /// ソースコードを渡して初期化。
        /// </summary>
        /// <param name="source">ソースコード。</param>
        public Tokenizer(string source)
        {
            this.current = 0;
            this.tokens = Tokenize(source).ToArray();
        }

        /// <summary>
        /// 今現在の位置の字句。
        /// </summary>
        public Token Current
        {
            get { return this.tokens[this.current]; }
        }

        /// <summary>
        /// i 個先にある字句を読みだす。
        /// </summary>
        /// <param name="i">読み飛ばす字句の数。</param>
        /// <returns>i 個先にある字句</returns>
        public Token Next(int i)
        {
            i += this.current;
            return this.tokens[i];
        }

        /// <summary>
        /// 字句が残ってるかどうか（EOFでないか確認）。
        /// </summary>
        /// <returns>残ってるならtrue。</returns>
        public bool HasToken()
        {
            return this.HasToken(0);
        }

        /// <summary>
        /// i 個先に字句が残ってるかどうか（EOFでないか確認）。
        /// </summary>
        /// <returns>残ってるならtrue。</returns>
        public bool HasToken(int i)
        {
            i += this.current;
            return i < this.tokens.Length;
        }

        /// <summary>
        /// 字句を進める。
        /// </summary>
        public void MoveNext()
        {
            this.MoveNext(1);
        }

        /// <summary>
        /// i 個字句を進める。
        /// </summary>
        public void MoveNext(int n)
        {
            this.current += n;
        }

        #region 字句パターンの定義

        /// <summary>
        /// 字句のパターンと、正規表現用のタグIDと、字句タイプの組。
        /// </summary>
        class PatternItem
        {
            /// <summary>
            /// 正規表現用のタグID。
            /// </summary>
            public string id;

            /// <summary>
            /// 字句パターン。
            /// </summary>
            public string pattern;

            /// <summary>
            /// 字句タイプ。
            /// </summary>
            public TokenType type;

            public PatternItem(string id, string pattern, TokenType type)
            {
                this.id = id;
                this.pattern = pattern;
                this.type = type;
            }
        }

        /// <summary>
        /// 字句のパターン定義。
        /// </summary>
        static readonly List<PatternItem> patterns = new List<PatternItem>
        {
            new PatternItem("let", "let", TokenType.Let),
            new PatternItem("int", @"\d+", TokenType.Integer),
            new PatternItem("id", @"\w+", TokenType.Identifier),
            new PatternItem("paren", @"\(|\)|\{|\}", TokenType.Parenthesis),
            new PatternItem("op", @"\+|-|\*|/|\<=|\>=|\<|\>|==|\!=|&|\||\?|:", TokenType.Operator),
            new PatternItem("delim", @";", TokenType.Delimiter),
            new PatternItem("eq", @"=", TokenType.Equal),
            new PatternItem("comma", @",", TokenType.Comma),
        };

        /// <summary>
        /// パターンを正規表現化したもの。
        /// </summary>
        static readonly Regex tokenPattern;

        /// <summary>
        /// 静的コンストラクター内で
        /// パターンから正規表現を構築。
        /// </summary>
        static Tokenizer()
        {
            StringBuilder sb = new StringBuilder();

            bool first = true;

            foreach (var p in patterns)
            {
                if (first) first = false;
                else sb.Append("|");

                sb.AppendFormat("(?<{0}>{1})", p.id, p.pattern);
            }

            tokenPattern = new Regex(sb.ToString());
        }

        /// <summary>
        /// パターン定義表と照らし合わせて、
        /// 正規表現のマッチ結果がどのパターンかを調べる。
        /// </summary>
        /// <param name="m"></param>
        /// <returns></returns>
        static TokenType GetTypeOf(Match m)
        {
            foreach (var p in patterns)
            {
                if (!string.IsNullOrEmpty(m.Groups[p.id].Value))
                    return p.type;
            }
            return TokenType.Invalid;
        }

        #endregion

        /// <summary>
        /// 字句解析して字句一覧を返す。
        /// </summary>
        /// <param name="source">ソースコード。</param>
        /// <returns>字句一覧。</returns>
        public static IEnumerable<Token> Tokenize(string source)
        {
            var m = tokenPattern.Match(source);

            for (; m.Success; m = m.NextMatch())
            {
                yield return new Token
                {
                    Value = m.Value,
                    Index = m.Index,
                    Length = m.Length,
                    Type = GetTypeOf(m),
                };
            }
        }
    }
}
