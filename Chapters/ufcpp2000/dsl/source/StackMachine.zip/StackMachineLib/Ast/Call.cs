﻿using System.Collections.Generic;

namespace StackMachine.Ast
{
    /// <summary>
    /// 関数呼び出し。
    /// </summary>
    public class Call : Expression
    {
        /// <summary>
        /// 呼び出す対象。
        /// </summary>
        public Function Function { get; internal set; }

        /// <summary>
        /// 呼び出す対象の関数名。
        /// </summary>
        public string Name { get { return this.Function.Name; } }

        /// <summary>
        /// 与える実引数リスト。
        /// </summary>
        public List<Expression> Parameters { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.Call; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as Call;

            if (x == null) return false;

            if (this.Name != x.Name) return false;

            if (this.Parameters.Count != x.Parameters.Count) return false;

            for (int i = 0; i < this.Parameters.Count; i++)
            {
                if (!this.Parameters[i].Equals(x.Parameters[i])) return false;
            }

            return true;
        }

        public override int GetHashCode()
        {
            return this.Name.GetHashCode() ^ this.Parameters.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            foreach (var p in this.Parameters)
            {
                foreach (var instruction in p.Compile(localTable, addressTable, functionTable))
                {
                    yield return instruction;
                }
            }

            yield return StackMachine.Emurator.Instruction.Call(this.Function, addressTable);
        }
    }
}
