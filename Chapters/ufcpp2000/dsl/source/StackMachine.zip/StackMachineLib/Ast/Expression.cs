﻿
namespace StackMachine.Ast
{
    /// <summary>
    /// 式の共通基底。
    /// </summary>
    public abstract class Expression : Node
    {
    }

    /// <summary>
    /// 演算子のタイプ。
    /// </summary>
    public enum OperatorType
    {
        Plus,
        Minus,
        Multiply,
        Divide,
        LessThan,
        GreaterThan,
        LessEqual,
        GreaterEqual,
        Equal,
        NotEqual,
        And,
        Or,
    }
}
