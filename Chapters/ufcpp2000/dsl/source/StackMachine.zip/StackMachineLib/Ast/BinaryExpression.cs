﻿using System.Collections.Generic;

namespace StackMachine.Ast
{
    /// <summary>
    /// 二項演算。
    /// </summary>
    public class BinaryExpression : Expression
    {
        /// <summary>
        /// 演算子のタイプ。
        /// </summary>
        public OperatorType Operator { get; internal set; }

        /// <summary>
        /// 左辺のオペランド。
        /// </summary>
        public Expression Left { get; internal set; }

        /// <summary>
        /// 右辺のオペランド。
        /// </summary>
        public Expression Right { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.BinaryExpression; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as BinaryExpression;

            if (x == null) return false;

            return this.Operator == x.Operator
                && this.Left.Equals(x.Left)
                && this.Right.Equals(x.Right);
        }

        public override int GetHashCode()
        {
            return this.Operator.GetHashCode() ^ this.Left.GetHashCode() ^ this.Right.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            foreach (var instruction in this.Left.Compile(localTable, addressTable, functionTable))
            {
                yield return instruction;
            }

            foreach (var instruction in this.Right.Compile(localTable, addressTable, functionTable))
            {
                yield return instruction;
            }

            switch (this.Operator)
            {
                case OperatorType.Plus: yield return StackMachine.Emurator.Instruction.Add(); break;
                case OperatorType.Minus: yield return StackMachine.Emurator.Instruction.Subtract(); break;
                case OperatorType.Multiply: yield return StackMachine.Emurator.Instruction.Multiply(); break;
                case OperatorType.Divide: yield return StackMachine.Emurator.Instruction.Divide(); break;
                case OperatorType.LessThan: yield return StackMachine.Emurator.Instruction.LessThan(); break;
                case OperatorType.LessEqual: yield return StackMachine.Emurator.Instruction.LessEqual(); break;
                case OperatorType.GreaterThan: yield return StackMachine.Emurator.Instruction.GreaterThan(); break;
                case OperatorType.GreaterEqual: yield return StackMachine.Emurator.Instruction.GreaterEqual(); break;
                case OperatorType.Equal: yield return StackMachine.Emurator.Instruction.Equal(); break;
                case OperatorType.NotEqual: yield return StackMachine.Emurator.Instruction.NotEqual(); break;
                case OperatorType.And: yield return StackMachine.Emurator.Instruction.And(); break;
                case OperatorType.Or: yield return StackMachine.Emurator.Instruction.Or(); break;
            }
        }
    }
}
