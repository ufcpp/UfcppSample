﻿using System.Collections.Generic;

namespace StackMachine.Ast
{
    /// <summary>
    /// リターン文。
    /// </summary>
    public class Return : Statement
    {
        /// <summary>
        /// 戻り値の式。
        /// </summary>
        public Expression Expression { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.Return; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as Return;

            if (x == null) return false;

            return this.Expression.Equals(x.Expression);
        }

        public override int GetHashCode()
        {
            return this.Expression.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            foreach (var instruction in this.Expression.Compile(localTable, addressTable, functionTable))
            {
                yield return instruction;
            }

            yield return StackMachine.Emurator.Instruction.Return();
        }
    }
}
