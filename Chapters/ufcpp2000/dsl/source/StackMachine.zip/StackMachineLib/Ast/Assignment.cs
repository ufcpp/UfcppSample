﻿using System.Collections.Generic;

namespace StackMachine.Ast
{
    /// <summary>
    /// 代入文。
    /// </summary>
    public class Assignment : Statement
    {
        /// <summary>
        /// 代入先の変数。
        /// </summary>
        public Parameter Variable { get; internal set; }

        /// <summary>
        /// 右辺値の式。
        /// </summary>
        public Expression Expression { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.Assignment; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as Assignment;

            if (x == null) return false;

            return this.Expression.Equals(x.Expression)
                && this.Variable.Equals(x.Variable);
        }

        public override int GetHashCode()
        {
            return this.Variable.GetHashCode() ^ this.Expression.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            foreach (var instruction in this.Expression.Compile(localTable, addressTable, functionTable))
            {
                yield return instruction;
            }

            int index = localTable[this.Variable];
            yield return StackMachine.Emurator.Instruction.StoreLocal(index);
        }
    }
}
