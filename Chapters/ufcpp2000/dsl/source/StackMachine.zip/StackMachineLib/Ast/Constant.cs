﻿using System.Collections.Generic;

namespace StackMachine.Ast
{
    /// <summary>
    /// 定数。
    /// </summary>
    /// <remarks>
    /// 今作ってる言語だと、直定数しかないけども。
    /// </remarks>
    public class Constant : Expression
    {
        /// <summary>
        /// 定数の値。
        /// </summary>
        public int Value { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.Constant; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as Constant;

            if (x == null) return false;

            return this.Value == x.Value;
        }

        public override int GetHashCode()
        {
            return this.Value.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            yield return StackMachine.Emurator.Instruction.LoadConstant(this.Value);
        }
    }
}
