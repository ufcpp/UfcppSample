﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StackMachine.Ast
{
    /// <summary>
    /// 変数。
    /// </summary>
    public class Parameter : Expression
    {
        /// <summary>
        /// 変数名。
        /// </summary>
        public string Name { get; internal set; }

        public override NodeType Type
        {
            get { return NodeType.Parameter; }
        }

        public override bool Equals(object obj)
        {
            var x = obj as Parameter;

            if (x == null) return false;

            return this.Name == x.Name;
        }

        public override int GetHashCode()
        {
            return this.Name.GetHashCode();
        }

        protected internal override IEnumerable<StackMachine.Emurator.Instruction> Compile(Dictionary<Parameter, int> localTable, Dictionary<Function, int> addressTable, Dictionary<Function, IEnumerable<StackMachine.Emurator.Instruction>> functionTable)
        {
            yield return StackMachine.Emurator.Instruction.LoadLocal(localTable[this]);
        }
    }
}
