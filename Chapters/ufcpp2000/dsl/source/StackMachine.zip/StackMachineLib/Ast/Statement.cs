﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StackMachine.Ast
{
    /// <summary>
    /// 文の共通基底。
    /// </summary>
    public abstract class Statement : Node
    {
    }
}
