﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StateMachine
{
	/// <summary>
	/// 有限ステートマシン実行エンジン。
	/// </summary>
	/// <typeparam name="State">ステートの型</typeparam>
	/// <typeparam name="Event">イベントの型</typeparam>
	public class StateMachine<State, Event>
		where State : IComparable
		where Event : IComparable
	{
		#region 内部型

		/// <summary>
		/// 遷移（遷移先の状態＋遷移時のアクション）。
		/// </summary>
		class Transition
		{
			public Action<object> Action { get; set; }
			public State Next { get; set; }

			public Transition(State next, Action<object> action)
			{
				this.Next = next;
				this.Action = action;
			}
		}

		#endregion
		#region private

		State current;
		SortedDictionary<Pair<State, Event>, Transition> table;

		#endregion
		#region 初期化

		/// <summary>
		/// 初期状態を指定して初期化。
		/// </summary>
		/// <param name="init">初期状態</param>
		public StateMachine(State init)
		{
			this.current = init;
			this.table = new SortedDictionary<Pair<State, Event>, Transition>();
		}

		#endregion
		#region public

		/// <summary>
		/// 状態遷移を遷移テーブルに登録。
		/// </summary>
		/// <param name="current">現状態</param>
		/// <param name="e">イベント</param>
		/// <param name="next">遷移先の状態</param>
		/// <param name="action">遷移時のアクション</param>
		public void RegisterTransition(
			State current, Event e,
			State next, Action<object> action)
		{
			this.table[new Pair<State, Event>(current, e)]
				= new Transition(next, action);
		}

		/// <summary>
		/// イベントを発生させる。
		/// </summary>
		/// <param name="e">イベント</param>
		/// <param name="parameter">イベントに付随するパラメータ</param>
		/// <remarks>
		/// パラメータは、例えば、Digit(n) （10進数字 n が入力された）みたいなイベントを表すときに使う。
		/// </remarks>
		public void Raise(Event e, object parameter)
		{
			var pair = new Pair<State, Event>(this.current, e);

			if (this.table.ContainsKey(pair))
			{
				Transition t = this.table[pair];
				this.current = t.Next;
				if (t.Action != null)
					t.Action(parameter);
			}
		}

		#endregion
	}
}
