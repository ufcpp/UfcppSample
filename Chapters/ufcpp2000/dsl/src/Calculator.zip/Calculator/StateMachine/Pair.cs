﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StateMachine
{
	/// <summary>
	/// 辞書式順序比較が可能なペア。
	/// </summary>
	/// <typeparam name="T1">値1</typeparam>
	/// <typeparam name="T2">値2</typeparam>
	class Pair<T1, T2> : IComparable<Pair<T1, T2>>
		where T1 : IComparable
		where T2 : IComparable
	{
		T1 x1;
		T2 x2;

		public Pair(T1 x1, T2 x2)
		{
			this.x1 = x1;
			this.x2 = x2;
		}


		#region IComparable<Pair<T1,T2>> メンバ

		int IComparable<Pair<T1, T2>>.CompareTo(Pair<T1, T2> other)
		{
			int i = this.x1.CompareTo(other.x1);
			if (i != 0) return i;
			return this.x2.CompareTo(other.x2);
		}

		#endregion
	}
}
