param($filename)

$xml = [xml](Get-Content $filename)
$State = $xml.Fsm.States.TypeName
$Event = $xml.Fsm.Events.TypeName

$xml.Fsm.Head

@"
namespace $($xml.Fsm.Namespace)
{
	public enum $State
	{
		$($xml.Fsm.States.State | %{$_.Name + ', '})
	}

	public enum $Event
	{
		$($xml.Fsm.Events.Event | %{$_.Name + ', '})
	}

	public partial class $($xml.Fsm.Class)
	{
		StateMachine.StateMachine<$State, $Event> fsm;

		void InitializeState()
		{
			this.fsm = new StateMachine.StateMachine<$State, $Event>(
				$State.$($xml.Fsm.InitialState));

"@

foreach($t in $xml.Fsm.Transitions.Transition)
{
	$from = $t.From
	$to = $t.To
	$e = $t.Event
	$actionBody = $t.'#text'

	$eventElement = ($xml.Fsm.Events.Event | ?{$_.Name -eq $e})
	$opType = $eventElement.OptionType

	if([string]::IsNullOrEmpty($opType))
	{
		$action = @"
				_dummy => {
$actionBody
				}
"@
	}
	else
	{
		$x = $t.Param
		$action = @"
				_dummy => {
					$opType $x = ($opType)_dummy;
$actionBody
					}
"@
	}

@"
			this.fsm.RegisterTransition(
				$State.$from, $Event.$e,
				$State.$to,
$action
				);
"@
}


@"
		}
	}
}
"@
