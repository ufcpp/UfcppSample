& .\Translate.ps1 ..\CalcForm\Calculator.xml | Set-Content ..\CalcForm\Calculator.generated.cs
