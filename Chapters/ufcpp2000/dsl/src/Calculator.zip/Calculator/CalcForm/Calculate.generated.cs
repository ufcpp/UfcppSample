namespace 
{
	public enum 
	{
		, 
	}

	public enum 
	{
		, 
	}

	public partial class 
	{
		StateMachine.StateMachine<, > fsm;

		void InitializeState()
		{
			this.fsm = new StateMachine.StateMachine<, >(
				.);

			this.fsm.RegisterTransition(
				., .,
				.,
				_dummy => {

				}
				);
		}
	}
}
