﻿
using System;
	
namespace CalcForm
{
	public enum StateType
	{
		Initial,  InputDigit,  Compute,  Equal, 
	}

	public enum EventType
	{
		Digit,  Operator,  Equal,  Clear, 
	}

	public partial class Calculator
	{
		StateMachine.StateMachine<StateType, EventType> fsm;

		void InitializeState()
		{
			this.fsm = new StateMachine.StateMachine<StateType, EventType>(
				StateType.Initial);

			this.fsm.RegisterTransition(
				StateType.Initial, EventType.Digit,
				StateType.InputDigit,
				_dummy => {
					double x = (double)_dummy;

			dspValue = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.Initial, EventType.Operator,
				StateType.Compute,
				_dummy => {
					Operator x = (Operator)_dummy;

			CalKey();
			op = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.InputDigit, EventType.Digit,
				StateType.InputDigit,
				_dummy => {
					double x = (double)_dummy;

			dspValue = dspValue * 10 + x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.InputDigit, EventType.Operator,
				StateType.Compute,
				_dummy => {
					Operator x = (Operator)_dummy;

			CalKey();
			op = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.InputDigit, EventType.Equal,
				StateType.Equal,
				_dummy => {

			CalKey();
		
				}
				);
			this.fsm.RegisterTransition(
				StateType.InputDigit, EventType.Clear,
				StateType.Initial,
				_dummy => {

			Init();
		
				}
				);
			this.fsm.RegisterTransition(
				StateType.Compute, EventType.Digit,
				StateType.InputDigit,
				_dummy => {
					double x = (double)_dummy;

			memValue = dspValue;
			dspValue = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.Compute, EventType.Operator,
				StateType.Compute,
				_dummy => {
					Operator x = (Operator)_dummy;

			op = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.Compute, EventType.Equal,
				StateType.Equal,
				_dummy => {

				}
				);
			this.fsm.RegisterTransition(
				StateType.Compute, EventType.Clear,
				StateType.Initial,
				_dummy => {

			Init();
		
				}
				);
			this.fsm.RegisterTransition(
				StateType.Equal, EventType.Digit,
				StateType.InputDigit,
				_dummy => {
					double x = (double)_dummy;

			memValue = 0d;
			dspValue = (double)x;
			op = Operator.None;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.Equal, EventType.Operator,
				StateType.Compute,
				_dummy => {
					Operator x = (Operator)_dummy;

			op = x;
		
					}
				);
			this.fsm.RegisterTransition(
				StateType.Equal, EventType.Equal,
				StateType.Equal,
				_dummy => {

			CalKey();
		
				}
				);
			this.fsm.RegisterTransition(
				StateType.Equal, EventType.Clear,
				StateType.Initial,
				_dummy => {

			Init();
		
				}
				);
		}
	}
}
