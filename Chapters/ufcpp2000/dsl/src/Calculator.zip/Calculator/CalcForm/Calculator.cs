﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalcForm
{
	public enum Operator
	{
		Plus,
		Minus,
		Mul,
		Div,
		None,
	}

	public partial class Calculator
	{
		Operator op;
		double memValue;
		double dspValue;

		public Calculator()
		{
			InitializeState();
		}

		public string PushKey(string keyId)
		{
			EventType e = GetKeyType(keyId);
			object parameter = GetNum(keyId);

			this.fsm.Raise(e, parameter);

			return this.dspValue.ToString();
		}

		protected void CalKey()
		{
			double tmp = dspValue;
			switch (op)
			{
				case Operator.Div:
					dspValue = memValue / dspValue;
					break;
				case Operator.Mul:
					dspValue = memValue * dspValue;
					break;
				case Operator.Minus:
					dspValue = memValue - dspValue;
					break;
				case Operator.Plus:
					dspValue = memValue + dspValue;
					break;
			}
			memValue = tmp;
		}

		public void Init()
		{
			op = Operator.None;
			memValue = 0d;
			dspValue = 0d;
		}

		public override string ToString()
		{
			return dspValue.ToString();
		}

		private object GetNum(string keyId)
		{
			switch (keyId)
			{
				case "1": return 1d;
				case "2": return 2d;
				case "3": return 3d;
				case "4": return 4d;
				case "5": return 5d;
				case "6": return 6d;
				case "7": return 7d;
				case "8": return 8d;
				case "9": return 9d;
				case "0": return 0d;

				case "/": return Operator.Div;
				case "*": return Operator.Mul;
				case "-": return Operator.Minus;
				case "+": return Operator.Plus;
			}
			return null;
		}

		protected EventType GetKeyType(string keyId)
		{
			switch (keyId)
			{
				case "1":
				case "2":
				case "3":
				case "4":
				case "5":
				case "6":
				case "7":
				case "8":
				case "9":
				case "0":
					return EventType.Digit;
				case "/":
				case "*":
				case "-":
				case "+":
					return EventType.Operator;
				case "=":
					return EventType.Equal;
				default: // "C"
					return EventType.Clear;
			}
		}
	}
}
