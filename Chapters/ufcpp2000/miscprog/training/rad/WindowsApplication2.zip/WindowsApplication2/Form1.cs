﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication2
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		Image img = null;

		private void 開くToolStripMenuItem_Click(object sender, EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Filter = "画像ファイル|*.png;*.jpg";

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				if (this.img != null)
					this.img.Dispose();

				this.img = Image.FromFile(dlg.FileName);
				this.Invalidate();
			}
		}

		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			if (this.img == null)
				return;

			Graphics g = e.Graphics;

			g.DrawImage(this.img, 0, this.menuStrip1.Height);
		}

		private void 終了ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.img != null)
				this.img.Dispose();

			this.Close();
		}
	}
}