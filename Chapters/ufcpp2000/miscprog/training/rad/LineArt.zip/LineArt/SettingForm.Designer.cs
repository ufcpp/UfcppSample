﻿namespace LineArt
{
	partial class SettingForm
	{
		/// <summary>
		/// 必要なデザイナ変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナで生成されたコード

		/// <summary>
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.textVertex = new System.Windows.Forms.TextBox();
			this.textLines = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textWait = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.buttonOk = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 12);
			this.label1.TabIndex = 0;
			this.label1.Text = "頂点の数";
			// 
			// textVertex
			// 
			this.textVertex.Location = new System.Drawing.Point(69, 6);
			this.textVertex.Name = "textVertex";
			this.textVertex.Size = new System.Drawing.Size(61, 19);
			this.textVertex.TabIndex = 1;
			// 
			// textLines
			// 
			this.textLines.Location = new System.Drawing.Point(69, 31);
			this.textLines.Name = "textLines";
			this.textLines.Size = new System.Drawing.Size(61, 19);
			this.textLines.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(51, 12);
			this.label2.TabIndex = 2;
			this.label2.Text = "線の本数";
			// 
			// textWait
			// 
			this.textWait.Location = new System.Drawing.Point(69, 56);
			this.textWait.Name = "textWait";
			this.textWait.Size = new System.Drawing.Size(61, 19);
			this.textWait.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 59);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(55, 12);
			this.label3.TabIndex = 4;
			this.label3.Text = "タイマ間隔";
			// 
			// buttonOk
			// 
			this.buttonOk.Location = new System.Drawing.Point(26, 81);
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Size = new System.Drawing.Size(49, 23);
			this.buttonOk.TabIndex = 6;
			this.buttonOk.Text = "OK";
			this.buttonOk.UseVisualStyleBackColor = true;
			this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(81, 81);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(49, 23);
			this.buttonCancel.TabIndex = 7;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.UseVisualStyleBackColor = true;
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// SettingForm
			// 
			this.AcceptButton = this.buttonOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(141, 112);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonOk);
			this.Controls.Add(this.textWait);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textLines);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textVertex);
			this.Controls.Add(this.label1);
			this.Name = "SettingForm";
			this.ShowIcon = false;
			this.Text = "設定";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textVertex;
		private System.Windows.Forms.TextBox textLines;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textWait;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonOk;
		private System.Windows.Forms.Button buttonCancel;
	}
}