﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LineArt
{
	public partial class SettingForm : Form
	{
		public SettingForm()
		{
			InitializeComponent();
		}

		private void buttonOk_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		public void SetVertexNum(int num){this.textVertex.Text = num.ToString();}
		public void SetLineNum(int num){this.textLines.Text = num.ToString();}
		public void SetWaitTime(int num){this.textWait.Text = num.ToString();}
		public bool GetVertexNum(out int num){return int.TryParse(this.textVertex.Text, out num);}
		public bool GetLineNum(out int num){return int.TryParse(this.textLines.Text, out num);}
		public bool GetWaitTime(out int num){return int.TryParse(this.textWait.Text, out num);}
	}
}