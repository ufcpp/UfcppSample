﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LineArt
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();

			InitializeObjects();
		}

		int vertex = 4;      // 1つの多角形あたりの頂点数
		int lines = 4;       // 何セットの多角形を表示するか
		int wait_time = 10; // タイマー間隔[ms]

		public Point[][] p; // 点
		public Size[] v;    // 各点の速度
		Timer timer;

		void InitializeObjects()
		{
			Random rnd = new Random();

			this.p = new Point[this.lines][];
			this.p[0] = new Point[this.vertex];
			this.v = new Size[this.vertex];
			for (int j = 0; j < this.vertex; ++j)
			{
				this.p[0][j].X = (rnd.Next() >> 3) % this.ClientSize.Width;
				this.p[0][j].Y = (rnd.Next() >> 3) % this.ClientSize.Height;
				double theta = rnd.NextDouble() * 2 * Math.PI;
				double r = rnd.NextDouble() * 5 + 2;
				this.v[j].Width = (int)(r * Math.Cos(theta));
				this.v[j].Height = (int)(r * Math.Sin(theta));
			}
			for (int i = 1; i < this.lines; ++i)
			{
				this.p[i] = new Point[this.vertex];
				for (int j = 0; j < this.vertex; ++j)
				{
					this.p[i][j] = this.p[i - 1][j];
				}
			}

			if (this.timer != null && this.timer.Enabled)
			{
				this.timer.Stop();
				this.timer.Dispose();
			}
			this.timer = new Timer();
			this.timer.Interval = this.wait_time;
			this.timer.Tick += this.Update;
			this.timer.Start();
		}

		void Update(object o, EventArgs e)
		{
			for (int j = 0; j < this.vertex; ++j)
			{
				//残像を作る
				for (int i = this.lines - 1; i > 0; --i)
				{
					this.p[i][j] = this.p[i - 1][j];
				}
				//点の位置の更新
				this.p[0][j] += this.v[j];
				//画面からはみ出したときの処理
				if (this.p[0][j].X >= this.ClientSize.Width)
				{
					this.p[0][j].X = this.ClientSize.Width * 2 - this.p[0][j].X;
					this.v[j].Width = -this.v[j].Width;
				}
				else if (this.p[0][j].X < 0)
				{
					this.p[0][j].X = -this.p[0][j].X;
					this.v[j].Width = -this.v[j].Width;
				}
				if (this.p[0][j].Y >= this.ClientSize.Height)
				{
					this.p[0][j].Y = this.ClientSize.Height * 2 - this.p[0][j].Y;
					this.v[j].Height = -this.v[j].Height;
				}
				else if (this.p[0][j].Y < 0)
				{
					this.p[0][j].Y = -this.p[0][j].Y;
					this.v[j].Height = -this.v[j].Height;
				}
			}

			this.Invalidate();
		}

		private void 設定ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SettingForm dlg = new SettingForm();
			dlg.SetVertexNum(this.vertex);
			dlg.SetLineNum(this.lines);
			dlg.SetWaitTime(this.wait_time);

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				int x;
				if (dlg.GetVertexNum(out x)) this.vertex = x;
				if (dlg.GetLineNum(out x)  ) this.lines  = x;
				if (dlg.GetWaitTime(out x) ) this.wait_time = x;

				this.InitializeObjects();
			}
		}

		protected override void OnPaintBackground(PaintEventArgs e)
		{
			Bitmap bmp = new Bitmap(this.Width, this.Height);
			Graphics g = Graphics.FromImage(bmp);

			g.FillRectangle(new SolidBrush(Color.White), 0, 0, this.Width, this.Height);
			for (int i = 0; i < this.lines; ++i)
			{
				g.DrawPolygon(new Pen(Color.Black), this.p[i]);
			}
			e.Graphics.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);
		}
	}
}