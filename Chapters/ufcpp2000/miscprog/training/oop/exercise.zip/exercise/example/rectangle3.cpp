// �����`�N���X 3
// ���N���X Shape ����h���B

#include <cmath>

const double PI = 3.14159265358979;

// ���N���X�B
// ����݂̂��`�B
class Shape
{
public:
	virtual double GetArea() = 0;
	virtual double GetPerimeter() = 0;
};

// �����`
class Rectangle : public Shape
{
private:
	double width_;
	double height_;

public:
	Rectangle()
	{
		width_ = 0;
		height_ = 0;
	}

	Rectangle(double w, double h)
	{
		width_ = w;
		height_ = h;
	}

	// setter/getter

	double GetWidth() { return width_; }
	void SetWidth(double w) { width_ = w; }

	double GetHeight() { return height_; }
	void SetHeight(double h) { height_ = h; }

	// �ʐ�
	virtual double GetArea()
	{
		return width_ * height_;
	}

	// ����
	virtual double GetPerimeter()
	{
		return 2 * (width_ + height_);
	}
};

// �~
class Circle : public Shape
{
private:
	double r_;

public:
	Circle()
	{
		r_ = 0;
	}

	Circle(double r)
	{
		r_ = r;
	}

	// setter/getter

	double GetRadius() { return r_; }
	void SetRadius(double r) { r_ = r; }

	// �ʐ�
	virtual double GetArea()
	{
		return PI * r_ * r_;
	}

	// ����
	virtual double GetPerimeter()
	{
		return 2 * PI * r_;
	}
};

// ���`�F�b�N�v���O����

#include <cstdio>

void Check(Shape& x)
{
	std::printf("area     : %5.2f\n", x.GetArea());
	std::printf("perimeter: %5.2f\n", x.GetPerimeter());
}

int main()
{
	Rectangle r;
	r = Rectangle(1, 2); Check(r);
	r = Rectangle(3, 4); Check(r);
	r = Rectangle(5, 6); Check(r);

	Circle c;
	c = Circle(1); Check(c);
	c = Circle(2); Check(c);
	c = Circle(3); Check(c);

	return 0;
}
