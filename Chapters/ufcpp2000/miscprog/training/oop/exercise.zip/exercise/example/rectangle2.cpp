// �����`�N���X 2
// �������B���B

#include <cmath>

class Rectangle
{
private:
	double width_;
	double height_;

public:
	Rectangle()
	{
		width_ = 0;
		height_ = 0;
	}

	Rectangle(double w, double h)
	{
		width_ = w;
		height_ = h;
	}

	// setter/getter

	double GetWidth() { return width_; }
	void SetWidth(double w) { width_ = w; }

	double GetHeight() { return height_; }
	void SetHeight(double h) { height_ = h; }

	// �ʐ�
	double GetArea()
	{
		return width_ * height_;
	}

	// ����
	double GetPerimeter()
	{
		return 2 * (width_ + height_);
	}
};

// ���`�F�b�N�v���O����

#include <cstdio>

void Check(Rectangle x)
{
	std::printf("width    : %5.2f\n", x.GetWidth());
	std::printf("height   : %5.2f\n", x.GetHeight());
	std::printf("area     : %5.2f\n", x.GetArea());
	std::printf("perimeter: %5.2f\n", x.GetPerimeter());
}

int main()
{
	Check(Rectangle(1, 2));
	Check(Rectangle(3, 4));
	Check(Rectangle(5, 6));

	return 0;
}
