// �����`�N���X 1

#include <cmath>

class Rectangle
{
public:
	double Width;
	double Height;

	Rectangle()
	{
		Width = 0;
		Height = 0;
	}

	Rectangle(double w, double h)
	{
		Width = w;
		Height = h;
	}

	// �ʐ�
	double GetArea()
	{
		return Width * Height;
	}

	// ����
	double GetPerimeter()
	{
		return 2 * (Width + Height);
	}
};

// ���`�F�b�N�v���O����

#include <cstdio>

void Check(Rectangle x)
{
	std::printf("width    : %5.2f\n", x.Width);
	std::printf("height   : %5.2f\n", x.Height);
	std::printf("area     : %5.2f\n", x.GetArea());
	std::printf("perimeter: %5.2f\n", x.GetPerimeter());
}

int main()
{
	Check(Rectangle(1, 2));
	Check(Rectangle(3, 4));
	Check(Rectangle(5, 6));

	return 0;
}
